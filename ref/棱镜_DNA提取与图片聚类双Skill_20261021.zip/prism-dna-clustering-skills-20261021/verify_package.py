"""离线核对交接清单，不启动模型、网络或原项目服务。"""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
errors = []
for row in manifest["files"]:
    path = root / row["path"]
    if not path.resolve().is_relative_to(root) or not path.is_file():
        errors.append(row["path"] + ": missing or outside package")
        continue
    raw = path.read_bytes()
    if len(raw) != row["bytes"] or hashlib.sha256(raw).hexdigest() != row["sha256"]:
        errors.append(row["path"] + ": size or SHA mismatch")
print(json.dumps({"checked_files": len(manifest["files"]), "ok": not errors, "errors": errors}, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
