"""Install selected Prism skills and their shared source snapshots into a project.

Default is dry-run. Existing different files cause an error before any write.
This never edits Codex global settings, installs packages, or starts models.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import sys


def xp(p):
    s = os.path.normpath(os.path.abspath(p))
    return '\\\\?\\' + s if os.name == 'nt' and not s.startswith('\\\\?\\') else s


def digest(p):
    with open(xp(p), 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def files_under(root):
    for current, dirs, names in os.walk(xp(root)):
        for name in sorted(names):
            yield Path(os.path.join(current, name).removeprefix('\\\\?\\'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', type=Path, required=True)
    parser.add_argument('--skills', nargs='+', help='Skill folder names; default: all ten')
    parser.add_argument('--apply', action='store_true', help='Actually copy; omitted means dry-run')
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parents[1]
    skill_root = bundle / '.agents/skills'
    available = {p.name: p for p in skill_root.iterdir() if p.is_dir()}
    selected = args.skills or sorted(available)
    if len(set(selected)) != len(selected) or not set(selected) <= set(available):
        parser.error('Unknown or duplicate skill name')
    target = args.project_root.resolve()
    roots = [available[name] for name in selected] + [bundle / 'prism_skill_support']
    plan, conflicts = [], []
    for root in roots:
        for src in files_under(root):
            dest = target / src.relative_to(bundle)
            if not dest.resolve().is_relative_to(target):
                conflicts.append({'path': str(dest), 'reason': 'symlink_outside_target'})
            elif os.path.exists(xp(dest)):
                if not os.path.isfile(xp(dest)) or digest(src) != digest(dest):
                    conflicts.append({'path': str(dest), 'reason': 'different_existing_file'})
            else:
                plan.append((src, dest))
    if conflicts:
        print(json.dumps({'status': 'conflict_no_writes', 'conflicts': conflicts}, ensure_ascii=False))
        return 2
    if args.apply:
        for src, dest in plan:
            Path(xp(dest.parent)).mkdir(parents=True, exist_ok=True)
            with open(xp(src), 'rb') as source, open(xp(dest), 'xb') as output:
                shutil.copyfileobj(source, output)
    print(json.dumps({'status': 'installed' if args.apply else 'dry_run',
                      'skills': selected, 'new_files': len(plan), 'project_root': str(target),
                      'global_configuration_changed': False, 'model_calls': 0}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
