"""Verify package hashes and the links of the ten newly authored small skills."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
from urllib.parse import unquote, urlsplit


def xp(p):
    s = os.path.normpath(os.path.abspath(p))
    return '\\\\?\\' + s if os.name == 'nt' and not s.startswith('\\\\?\\') else s


def digest(path):
    with open(xp(path), 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def main():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / 'metadata/manifest.json').read_text(encoding='utf-8'))
    failures = []
    for row in manifest['files']:
        path = root / row['path']
        if not os.path.isfile(xp(path)) or digest(path) != row['sha256']:
            failures.append({'file': row['path'], 'reason': 'missing_or_hash_mismatch'})
    skills = sorted((root / '.agents/skills').glob('*/SKILL.md'))
    for entry in skills:
        text = entry.read_text(encoding='utf-8')
        if not text.startswith('---\n') or not re.search(r'^name: ' + re.escape(entry.parent.name) + r'$', text, re.M):
            failures.append({'file': str(entry.relative_to(root)), 'reason': 'frontmatter'})
        for md in [entry, *entry.parent.glob('references/*.md')]:
            for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', md.read_text(encoding='utf-8')):
                u = urlsplit(link)
                if not u.scheme and u.path and not os.path.exists(xp((md.parent / unquote(u.path)).resolve())):
                    failures.append({'file': str(md.relative_to(root)), 'link': link, 'reason': 'broken_skill_reference'})
    print(json.dumps({'passed': not failures and len(skills) == 10, 'skills': len(skills),
                      'files_checked': len(manifest['files']), 'failures': failures,
                      'model_calls': 0}, ensure_ascii=False))
    return 0 if not failures and len(skills) == 10 else 2


if __name__ == '__main__':
    sys.exit(main())
