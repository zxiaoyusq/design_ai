# 棱镜 · 趋势图片入库判标：输入输出与实现

当前可继承范围：v0.6.1离线协议26项历史通过；真实判别效果仍partial。

输入：含image_id、source_kind、provenance的图片记录，已有首次/复核判定及其原版本。输出：保留原身份的TrendQualityDecision；不适用或异常有独立状态。

Python入口：`prism_runtime.quality.route_quality(image, result_loader, source_ref=...)`、`adapt_file(...)`；组合规则是`quality.policy.resolve(primary, confirmation=None)`、`aggregate_children(children)`。

源码README仍保留v0.6.0时期的说明；本包验收身份以capabilities和冻结来源记录为准，不把旧自测数当当前独立测试。冻结提示词/模型历史位于完整交接包的outputs/prism-quality-pilot-20260926；配套源码不是视觉模型调用服务。

26项历史通过证明路由、原判定保真与组合边界，不证明真实精确率、负例拦截率或新图稳定性。

## 配套资料

- [capabilities.md](../../../../prism_skill_support/docs/capabilities.md)
- [冻结实现：quality/README.md](../../../../prism_skill_support/runtime/prism_runtime/quality/README.md)
