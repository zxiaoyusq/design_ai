---
name: prism-trend-quality
description: "按棱镜来源路由和高级感规则导出、复核趋势图片的入库判定；用于趋势参考库资格检查，不给用研图片设高级感门槛。"
metadata:
  version: "1.0.0"
---

# 棱镜 · 趋势图片入库判标

只负责趋势图片的参考资格和判定来源。

1. 先核source_kind及真实provenance。research/generated/unknown/synthetic绕过；calibration仅进入明确校准路径，不能转成正式趋势入库。
2. 读取既有判定并保留原版本、原话和SHA256；使用route_quality/adapt_file导出，不用当前规则重写旧有效FAIL。
3. 新判标只在本轮明确范围内执行。有效PASS/FAIL与HTTP错误、空回复、无效JSON、身份冲突分开，执行错误不得进入审美淘汰库。
4. 按policy.resolve决定有界复核资格，保留两次记录；离线规则不自己调用模型。整板PASS不能覆盖子图FAIL或异常。
5. 输出TrendQualityDecision、入库/淘汰/待处理原因和校准身份；将结果交给趋势参考库消费，不替代用研态度或设计师审美结论。

接口、提示词依赖和旧说明版本差异见 [交接契约](references/io.md)。
