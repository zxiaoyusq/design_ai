# 棱镜 · 第二次局部特征握手：输入输出与实现

当前可继承范围：B限定H02已登记并被消费；原A负向映射未完成。

位于`prism_runtime.handshake.stage_scope_v1.h02`：`inspect_h02_scope(config)`、`prepare_h02(config)`、`accept_h02_proposal(config, prepared, response_path)`、`compile_confirmed(config_path, prepared_path, draft_path, confirmation_path, output_dir=NEW_DIR)`、`verify_context(context_path, request=request, inventory_path=inventory_path)`。

输出request/context必须由官方入口生成并验证，后续消费使用返回结果而非自填状态。H02未来义务仍为unfulfilled，不能因匹配出了图组变成已验证材料、测量或产品方案。

本次B：第一轮“金色+金属外观+半光”只有一张图，不满足多图组要求；实际反馈后的新提案把非当前必需的半光留作后续比较，重新确认“金色+金属外观”才得到3图5局部。它是特定案例，不是每次失败都删条件的通用策略。

本次AI代确认只继承为历史证据；新任务须记录真实确认者或本轮明确AI代理授权。

## 配套资料

- [capabilities.md](../../../../prism_skill_support/docs/capabilities.md)
- [phase-boundaries.md](../../../../prism_skill_support/docs/phase-boundaries.md)
- [冻结实现：handshake/stage_scope_v1/h02.py](../../../../prism_skill_support/runtime/prism_runtime/handshake/stage_scope_v1/h02.py)
- [冻结实现：handshake/NEGATIVE_SCOPES.md](../../../../prism_skill_support/runtime/prism_runtime/handshake/NEGATIVE_SCOPES.md)
