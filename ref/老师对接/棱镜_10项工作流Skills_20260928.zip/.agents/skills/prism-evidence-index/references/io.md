# 棱镜 · 资料接入与同源索引：输入输出与实现

当前可继承范围：复用来源协议；本次新增离线索引小工具。

输入 manifest.records，每条包含 occurrence_id、path、source_kind、source_id、source_group；可额外保留 image_id、原标签、页码、时间、原话。path相对于manifest位置；支持trend/research/calibration/generated/synthetic/unknown。

```json
{"records":[{"occurrence_id":"example-occ-1","path":"sample.png","image_id":"example-img-1","source_kind":"synthetic","source_id":"example-source","source_group":"example-group"}]}
```

在项目根运行：

```text
python -B -X utf8 .agents/skills/prism-evidence-index/scripts/index_assets.py --manifest INPUT.json --output NEW_INDEX.json
```

输出assets按完整SHA256去重，occurrences保留每次来源；counts分别统计文件、出现次数、同源组。缺文件、重复occurrence_id、同一image_id对应不同字节会报错。输出文件拒绝覆盖。分类由输入证据提供，脚本不猜来源。

下游不得把索引成功当作图片可读、原话真实或研究人群有效。

## 配套资料

- [CONTRACT.md](../../../../prism_skill_support/docs/CONTRACT.md)
