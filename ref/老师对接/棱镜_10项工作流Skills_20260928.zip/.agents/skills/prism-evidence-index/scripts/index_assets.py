"""Index supplied local evidence by bytes while preserving every source occurrence."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

KINDS = {'trend', 'research', 'calibration', 'generated', 'synthetic', 'unknown'}


def build(manifest, base):
    rows = manifest['records']
    if not isinstance(rows, list):
        raise ValueError('records must be an array')
    assets, occurrences, occurrence_ids, image_ids = {}, [], set(), {}
    for record in rows:
        occurrence_id = record['occurrence_id']
        if not isinstance(occurrence_id, str) or not occurrence_id or occurrence_id in occurrence_ids:
            raise ValueError('occurrence_id must be nonempty and unique')
        if record['source_kind'] not in KINDS:
            raise ValueError('invalid source_kind; do not infer it from appearance')
        if not record.get('source_id') or not record.get('source_group'):
            raise ValueError('explicit source_id and source_group are required')
        path = (base / record['path']).resolve()
        payload = path.read_bytes()
        digest = hashlib.sha256(payload).hexdigest()
        image_id = record.get('image_id')
        if image_id and image_id in image_ids and image_ids[image_id] != digest:
            raise ValueError('one image_id refers to different bytes')
        if image_id:
            image_ids[image_id] = digest
        occurrence_ids.add(occurrence_id)
        asset_id = 'sha256:' + digest
        assets.setdefault(asset_id, {'asset_id': asset_id, 'sha256': digest, 'bytes': len(payload)})
        # Preserve provided labels, attitude, semantics and provenance verbatim.
        occurrences.append({**record, 'asset_id': asset_id, 'resolved_path': str(path)})
    return {'schema_version': 'prism.skill.evidence_index.v1', 'assets': list(assets.values()),
            'occurrences': occurrences, 'counts': {'unique_files': len(assets),
            'occurrences': len(occurrences), 'source_groups': len({r['source_group'] for r in occurrences})},
            'visual_or_semantic_validation': False, 'new_model_calls': 0}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    result = build(json.loads(args.manifest.read_text(encoding='utf-8-sig')), args.manifest.resolve().parent)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(json.dumps(result['counts'], ensure_ascii=False))


if __name__ == '__main__':
    main()
