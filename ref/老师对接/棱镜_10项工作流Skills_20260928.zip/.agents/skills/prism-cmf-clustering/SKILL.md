---
name: prism-cmf-clustering
description: "执行已确认的棱镜局部CMF条件请求，保留同载体、负向范围、未知和完整图片去向；用于实际分组或冻结末段重放，不替代两次握手。"
metadata:
  version: "1.0.0"
---

# 棱镜 · 局部CMF条件聚类

消费正式请求并运行原聚类器，成员由算法计算。

1. 对新执行先核H02官方context及完整inventory；局部投影逐份走官方verify_projection，保留所有对象、未准入和负向覆盖审计。
2. B-STAGE消费桥目前固定绑定本次brief和inventory哈希、39张趋势图与495个载体。用于其他数据前由owner建立并验证新范围版本；不能改哈希或删检查冒称通用。
3. 使用stage_scope_cmf_bridge_v1.run_grouping调用未改动的engine 0.2.0，完整传递stage_audit。不得按必需特征预筛母库、拼接不同载体、猜数值容差或把unknown当相同。
4. 保留原engine_result的partial、boundary和排除理由。reconcile_inventory按全部原图合账；尚未执行是null/pending，不是零组。
5. 回查每个成员的原图区域、字段和值。只有一张图的singleton不通过“多图组”验收；多图成组也不证明整图、真实材质或用户偏好合格。

需要核对保存结果时运行 [末段离线重放](scripts/replay_frozen.py)。它只重算保存的C01，不重跑模型、不新增H01/H02授权。

数据契约与限制见 [交接契约](references/io.md)。
