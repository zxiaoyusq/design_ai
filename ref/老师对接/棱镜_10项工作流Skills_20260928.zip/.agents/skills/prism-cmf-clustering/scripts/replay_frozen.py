"""Replay only the saved final deterministic C01 result; no inference or new authority."""
from pathlib import Path
import hashlib
import json
import os
import sys


def main():
    root = next((p for p in Path(__file__).resolve().parents if (p / 'prism_skill_support/bundle.json').is_file()), None)
    if root is None:
        raise RuntimeError('Install this skill together with prism_skill_support')
    support = root / 'prism_skill_support'
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(support / 'runtime'))
    allowed = str(root).replace('\\', '/').casefold().rstrip('/') + '/'
    original = 'd:/codex/传音ai创客营/'
    def audit(event, args):
        if event in {'socket.connect', 'socket.getaddrinfo', 'subprocess.Popen'}:
            raise RuntimeError('Frozen replay forbids network and child processes')
        if event == 'open' and args and isinstance(args[0], (str, bytes, os.PathLike)):
            name = os.fsdecode(args[0]).replace('\\', '/').casefold().removeprefix('//?/')
            if name.startswith(original) and not name.startswith(allowed):
                raise RuntimeError('Original workspace fallback is forbidden')
    sys.addaudithook(audit)
    from prism_runtime.clustering.engine import cluster_candidates, VERSION
    data = support / 'examples/final-group'
    read = lambda name: json.loads((data / name).read_text(encoding='utf-8-sig'))
    request, images, expected = read('request.json'), read('engine-inputs.json'), read('expected-result.json')
    actual = cluster_candidates(request, images)
    equal = actual == expected
    canonical = json.dumps(actual, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    print(json.dumps({'passed': equal, 'scope': 'saved_final_C01_only', 'engine_version': VERSION,
                      'candidate_images': len(images), 'summary': actual.get('summary'),
                      'result_canonical_sha256': hashlib.sha256(canonical).hexdigest(),
                      'exact_expected_result': equal, 'upstream_model_stages_rerun': False,
                      'new_model_calls': 0, 'network_calls': 0}, ensure_ascii=False))
    return 0 if equal else 2


if __name__ == '__main__':
    sys.exit(main())
