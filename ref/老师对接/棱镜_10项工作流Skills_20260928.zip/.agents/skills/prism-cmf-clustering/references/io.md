# 棱镜 · 局部CMF条件聚类：输入输出与实现

当前可继承范围：engine 0.2.0末段可离线重放；B消费桥固定绑定该案例，非通用适配器。

输入：官方GroupingRequest、完整image_id→投影映射、inventory_path、已登记exploration_context_path。输出：原engine_result、完整stage_audit/coverage_audits、每图和每载体的去向与未履行义务。

新执行API：`prepare_request_views(...)`、`run_grouping(...)`、`reconcile_inventory(...)`来自`prism_runtime.clustering.stage_scope_cmf_bridge_v1`。B桥的固定验证入口是`handshake.stage_scope_v1.h02.verify_context`，没有任意callback或fixture豁免。

从技能包根或安装后的项目运行：

```text
python -B -X utf8 .agents/skills/prism-cmf-clustering/scripts/replay_frozen.py
```

重放使用配套examples/final-group中的39图原请求/输入/结果；网络、子进程和原工作区回退被禁止。成功只表示同一确定性末段能复现1组3图5局部，raw engine仍partial。运行不需要原图下载、账号或API。

原算法按字段/值精确JSON组合匹配，尚无语义嵌入、通用数值容差或物理测量。

## 配套资料

- [capabilities.md](../../../../prism_skill_support/docs/capabilities.md)
- [冻结实现：clustering/README.md](../../../../prism_skill_support/runtime/prism_runtime/clustering/README.md)
- [冻结实现：clustering/stage_scope_cmf_bridge_v1/README.md](../../../../prism_skill_support/runtime/prism_runtime/clustering/stage_scope_cmf_bridge_v1/README.md)
