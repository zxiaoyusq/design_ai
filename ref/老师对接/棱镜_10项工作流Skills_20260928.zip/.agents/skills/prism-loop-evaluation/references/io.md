# 棱镜 · 独立验收与定点修复单：输入输出与实现

当前可继承范围：已沉淀独立验收规则；每个新交付仍需实际复验。

输入：一个明确ready范围的交付、源码依赖和冻结输入，或者一条依赖齐备的链路。输出：独立run目录、冻结manifest、逐项actual/expected、明确结论；失败时额外dispatch。

修复单最低字段：issue_id、owner、source_version、code_hashes、rule_hashes、input_hashes、minimal_input、expected、actual、evidence_refs、suggestion、retest_conditions、attempt、stop_after_attempt。dispatch去重键至少包括issue与版本/输入身份。

首轮历史范围：DNA22、quality26、trends11、preferences17，另有同一组preferences→handshake→clustering联合40项，只算一次。新增owner的6/14项与Root实际检查分开。

小模型格式失败、视觉归属失败、证据不足和条件过窄分别定性。修复编码不等于提高图像典型性；语义或接口变化先重新核判标，不为通过改预期。

只观察到“完成”而没有实际输出/receipt时，不宣称已执行成功。

## 配套资料

- [evaluation-rules.md](../../../../prism_skill_support/docs/evaluation-rules.md)
- [coordination.md](../../../../prism_skill_support/docs/coordination.md)
- [capabilities.md](../../../../prism_skill_support/docs/capabilities.md)
