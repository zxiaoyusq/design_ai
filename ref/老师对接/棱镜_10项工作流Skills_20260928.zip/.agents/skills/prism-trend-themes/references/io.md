# 棱镜 · 趋势主题与案例：输入输出与实现

当前可继承范围：trends v0.1.1，11项历史协议通过；主题内容仍需逐来源核对。

输入：图文证据bundle、scope、ImageDNA和趋势质量记录。调用`prism_runtime.trends.api.prepare(bundle, scope=None)`；模型提案后调用`accept(prepared, proposal)`。

输出：主题、案例、引用身份、排除/缺失原因和来源范围。Qwen wire是历史传输适配，不授权新调用，也不把宿主直接写的内容假称模型真实返回。

在当前最终案例中复用了已有10个T01主题结果；这是历史运行数量，不是技能默认产出数量。批量文章、同源图片和词频均不等于独立市场需求或目标用户偏好。

## 配套资料

- [capabilities.md](../../../../prism_skill_support/docs/capabilities.md)
- [冻结实现：trends/README.md](../../../../prism_skill_support/runtime/prism_runtime/trends/README.md)
- [冻结实现：trends/qwen_wire_v01/README.md](../../../../prism_skill_support/runtime/prism_runtime/trends/qwen_wire_v01/README.md)
