# 棱镜 · 用研偏好与语义复核：输入输出与实现

当前可继承范围：preferences v0.3.1协议历史通过；原A负向字段映射仍阻断。

输入：研究bundle、findings、真实提取身份extraction_context及可信reviewer_registry。输出：PreferenceProfile、原子偏好、语义组、原话引用、审阅回执与support_eligibility。

关键入口：`prism_runtime.preferences.engine.compile_preferences`；`review.prepare_semantic_review`；`review.apply_semantic_reviews`；`review.validate_reviewed_profile(bundle, profile, reviewer_registry=registry)`。最后一个入口返回重建后的可信副本；输入对象不应直接向下游转交。

`prism_sidecars/preferences_case_b_condition_wire_v1`保留了宽主题条件提取/审核传输；它不解决任意负向词到字典的映射。原A有9条负向记录未完成，含8条字段阻断、10个非规范参数名。B成功不能修复A。

同一被访者按身份去重；公开帖子、模拟访谈、设计师校准分别计算，不能将提及人数解释成偏好率。

## 配套资料

- [capabilities.md](../../../../prism_skill_support/docs/capabilities.md)
- [冻结实现：preferences/README.md](../../../../prism_skill_support/runtime/prism_runtime/preferences/README.md)
- [冻结实现：preferences/SEMANTIC_REVIEW.md](../../../../prism_skill_support/runtime/prism_runtime/preferences/SEMANTIC_REVIEW.md)
