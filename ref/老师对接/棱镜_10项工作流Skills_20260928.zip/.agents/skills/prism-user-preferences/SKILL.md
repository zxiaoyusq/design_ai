---
name: prism-user-preferences
description: "从带身份和情境的用研原话、选择记录中提取主题与局部特征偏好，并验证独立审阅回执；用于棱镜偏好整理，不替用户补造态度。"
metadata:
  version: "1.0.0"
---

# 棱镜 · 用研偏好与语义复核

分别输出主题诉求和对象/特征级态度，保持原话、原因、条件与研究对象身份。

1. 按项目简报筛选证据并保留排除理由；画像标签不能推导审美偏好。用研图不走高级感入库。
2. 用prepare_request/prepare_requests准备输入，compile_preferences或accept_batches接收真实提取稿。整图Like不能分摊给全部DNA；未提及不是Dislike。
3. 由另一实际上下文或可信审阅者核对态度、归因、条件、摘要和人群范围。候选自填reviewed/supported或自称另一审阅者不构成独立复核。
4. 持久化profile再次消费时，调用validate_reviewed_profile并使用返回副本。不能相信profile里的supported缓存；来源或候选变化会使旧回执失效。
5. 输出正向、条件、负向、未知和冲突。自然语言到字典参数的映射不足时保留pending，交给H02处理，不能删除负向以凑可执行请求。

官方入口和未解决范围见 [交接契约](references/io.md)。
