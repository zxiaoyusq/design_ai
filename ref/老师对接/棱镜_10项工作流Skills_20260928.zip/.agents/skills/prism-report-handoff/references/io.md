# 棱镜 · 图文报告与交接：输入输出与实现

当前可继承范围：120图单文件导出及独立目录浏览器检查已完成；模板需配套原数据。

输入：已完成运行的summary、原图、逐图详情/原始调用记录、版本和工作量账本。输出：可读HTML、可追溯资料、打开说明、hash/ZIP完整性检查与浏览器QA。

配套`prism_skill_support/exporter/`保存本次已验证的build_singlefile.py与viewer.html原字节。它按脚本父目录定位原loop布局：如需复用，将两文件放入完整交接包的project/outputs/<loop任务>/prism-evaluation-loop/下新建的导出目录，再执行build_singlefile.py。它需要完整120图和原始详情；技能包未重复携带80MB原图，不能在缺数据时直接运行。

当前导出结果120张原图、120逐图页内嵌，独立目录里123个图像元素全部正常（3张在成组区重复显示）；图片和详情无需网络，公开来源网页外链需网络。3个早期历史入口明确指向完整交接包，不伪称已内嵌所有源码。

重新导出仍要检查新产物。图片/JS资源内嵌和JSON可解析不等于算法效果通过。

## 配套资料

- [capabilities.md](../../../../prism_skill_support/docs/capabilities.md)
- [coordination.md](../../../../prism_skill_support/docs/coordination.md)
