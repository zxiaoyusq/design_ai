# 棱镜 · 第一次主题握手：输入输出与实现

当前可继承范围：stage_scope_v1在B宽主题探索中完成；不代表真实用户认可。

输入：config、原始证据引用、可信偏好副本、T01主题、H01阶段角色及独立审阅。输出：H01候选结果、确认记录、theme_selection与冻结快照。

API：`prepare_h01(config)`；`accept_h01(prepared_path, response_path, mode='exploration')`；`validate_h01_selection(prepared, result, confirmation)`，位于`prism_runtime.handshake.stage_scope_v1.h01`。

阶段角色由`stage_scope_v1.roles`准备/接收/复核；原config与真实执行文件的格式以源码和完整交接记录为准。本包保留源码快照，未声称历史路径绑定已自动迁移。

验收：主题回到双侧来源，选择回到具体版本；没有选择记录不能伪造“已确认”；未知宗教意义或未验证人群仍保留。H01不产GroupingRequest。

## 配套资料

- [capabilities.md](../../../../prism_skill_support/docs/capabilities.md)
- [phase-boundaries.md](../../../../prism_skill_support/docs/phase-boundaries.md)
- [冻结实现：handshake/stage_scope_v1/h01.py](../../../../prism_skill_support/runtime/prism_runtime/handshake/stage_scope_v1/h01.py)
- [冻结实现：handshake/stage_scope_v1/roles.py](../../../../prism_skill_support/runtime/prism_runtime/handshake/stage_scope_v1/roles.py)
