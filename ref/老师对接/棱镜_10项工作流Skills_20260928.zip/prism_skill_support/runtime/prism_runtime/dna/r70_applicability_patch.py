"""D01 repair v1: exhaustive applicability diagnostics around frozen R70.

This module never repairs a wire by itself. It supplies original permission
facts to the model and audits the model's explicit edits under the unchanged
R70 validator. The seven-key correction response format is unchanged.
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import copy
import hashlib
import importlib.util

PROJECT = Path(__file__).resolve().parents[2]
OPT = PROJECT / "outputs/01a0c2a0-b850-7fd1-a032-78e192743557/dna-optimization-loop-20260925"
BASELINE_PATH = OPT / "round46/visual_review.py"
VERSION = "r70-applicability-d01-v1"
_spec = importlib.util.spec_from_file_location("prism_d01_frozen_r70", BASELINE_PATH)
baseline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(baseline)

base = baseline.base
P, ACTIVE, CORE, DICT_PATH = (getattr(baseline, k) for k in ["P", "ACTIVE", "CORE", "DICT_PATH"])
compact, loads, require, exact, KEY = (getattr(baseline, k) for k in ["compact", "loads", "require", "exact", "KEY"])
FACETS = baseline.FACETS
BASE_ALLOWED = baseline.BASE_ALLOWED
# These aliases intentionally retain the original implementation, not a fork.
validate = baseline.validate
can_review = baseline.can_review
partial_preview = baseline.partial_preview
correction_schema = baseline.correction_schema
apply_correction = baseline.apply_correction

PRIMARY_RULES = '''
字段与载体的权限先于字段取值：写入对象dna前，先核对该原PID的applicable_object_types是否包含当前对象type。只有允许的绑定才能填写具体值、null或false；unknown、不适用、无、未开启等状态不会使不允许的绑定合法。
下面的权限表完全由原字典派生，没有新增或放宽类型。objects仍只使用原对象类型，frame仍只使用CTX字段。不要在所有实体上复制一个族的false/无列表。
尤其注意：EMI-001至EMI-014在原字典中仅允许O09。若看图后判断没有相应发光载体，完整审阅的全图状态由你明确写入review.families/原PID的exceptions，不要在其他类型对象的dna上写EMI字段来表示没有发光。也不能为容纳字段而把真实载体改成O09。
原类型必填core仍必须逐一明确判断，不能通过删除对象、改ID或大批unknown来凑结构。全部148视觉项仍按原定义审阅，65项输入条件及3项派生关系保持原合同；字段未出现在某个不适用对象上不等于免除整图审阅。
'''

REVIEW_RULES = '''
适用性复核补充规则：primary_validation_errors可能只是原校验器遇到的第一个错误。structural_diagnostics是逐项预检列表；必须遍历所有出现位置，不能只修第一个对象或第一个PID。incompatible_binding_groups提供同类问题的索引，诊断本身不是视觉答案。
每条original_field_object_incompatible都含原对象ID/类型、准确field_key、existing_value和原允许类型。null/false/无不豁免原绑定限制；看图后由你决定真实对象类型是否正确，并按既有dna_edits/object_edits协议提出明确修正。若真实类型正确，错误挂载的非核心字段由你明确提出remove（old精确匹配、value=null）；不能由程序自动删，也不能把字段移到无依据的载体上。若类型确实错了，必须按原图修正类型并补齐真实新类型的核心字段，而非为通过校验改类型。
如果不再有某字段的适用实例，核对其整图review状态；状态变更须由你使用原review_edits协议明确给出，程序不补unknown或NA。原图有发光载体时应保留合法O09上的相关值，不因其他对象违规而删除整族信息。
八个facet的not_present/retained说明不能代替实际字段修改。输出前对最终各对象重新核对所有适用性诊断；无法解决的写入unresolved_issues，保留失败，不声称已经修好。原PID、值类型、核心字段、对象ID/区域及旧值快照规则全部维持。
'''
INSTRUCTIONS = baseline.INSTRUCTIONS + REVIEW_RULES


def permission_groups():
    """Compact original dictionary facts, not a new whitelist or guessed rule."""
    groups = defaultdict(list)
    for pid in sorted(ACTIVE):
        types = tuple(P[pid]["applicable_object_types"])
        slot = "frame_only" if pid.startswith("CTX-") else "objects_only"
        groups[(types, slot)].append(pid)
    return [{"parameter_ids": pids, "original_allowed_object_types": list(types), "original_wire_slot": slot}
            for (types, slot), pids in groups.items()]


def applicability_diagnostics(draft):
    """Read every present field/type pair, including explicit unknown/NA values.

    Does not mutate, drop, remap or normalize input observations. It augments
    the old preflight, not replaces the original final validator.
    """
    findings = []
    if not isinstance(draft, dict):
        return findings
    carriers = []
    for index, node in enumerate(draft.get("objects", [])):
        if not isinstance(node, dict) or type(node.get("id")) is not int or not isinstance(node.get("dna"), dict):
            continue  # R70 retains responsibility for malformed carrier records.
        carriers.append((node["id"], node.get("type"), node["dna"], f"/objects/{index}/dna"))
    if isinstance(draft.get("frame"), dict):
        carriers.append((0, "O19", draft["frame"], "/frame"))
    for oid, object_type, fields, pointer in carriers:
        for field_key, value in fields.items():
            match = KEY.fullmatch(field_key) if isinstance(field_key, str) else None
            if match is None or match.group(1) not in ACTIVE:
                continue  # Existing R70 invalid-PID diagnostics remain in scope.
            pid = match.group(1)
            allowed = P[pid]["applicable_object_types"]
            detail = {"object_id": oid, "object_ref": f"o{oid}", "object_type_id": object_type,
                      "parameter_id": pid, "field_key": field_key,
                      "json_pointer": pointer + "/" + field_key.replace("~", "~0").replace("/", "~1"),
                      "existing_value": copy.deepcopy(value), "original_allowed_object_types": copy.deepcopy(allowed),
                      "state_does_not_override_applicability": True,
                      "host_chosen_replacement": False}
            if object_type not in allowed:
                findings.append({"diagnostic_id": f"app:o{oid}:{field_key}",
                                 "code": "original_field_object_incompatible", **detail})
            if pid.startswith("CTX-") != (oid == 0):
                findings.append({"diagnostic_id": f"slot:o{oid}:{field_key}",
                                 "code": "original_wire_slot_mismatch", **detail})
    return findings


def build_inputs(photo):
    prompt, schema, width, height, _ = baseline.build_inputs(photo)
    prompt += ("\n" + PRIMARY_RULES + "\n原字典字段—对象类型权限（按相同权限压缩列出）：\n"
               + compact(permission_groups()))
    return prompt, schema, width, height, prompt


def review_scope(draft, normalized):
    scope = baseline.review_scope(draft, normalized)
    additions = applicability_diagnostics(draft)
    scope["structural_diagnostics"] = copy.deepcopy(scope.get("structural_diagnostics", [])) + additions
    scope["allowed_pids"] = sorted(set(scope["allowed_pids"]) | {d["parameter_id"] for d in additions})
    groups = defaultdict(list)
    for diagnostic in additions:
        groups[(diagnostic["code"], diagnostic["parameter_id"])].append(diagnostic["diagnostic_id"])
    scope["incompatible_binding_groups"] = [{"code": code, "parameter_id": pid, "diagnostic_ids": ids}
                                            for (code, pid), ids in groups.items()]
    scope["applicability_preflight"] = {
        "version": VERSION, "all_present_original_visual_pairs_checked": True,
        "diagnostic_count": len(additions), "state_independent": True,
        "draft_sha256": hashlib.sha256(compact(draft).encode()).hexdigest(),
        "read_only": True, "host_selected_fills_or_removals": False,
    }
    return scope


def critic_prompt(draft, scope):
    prior = baseline.critic_prompt(draft, scope)
    require(prior.startswith(baseline.INSTRUCTIONS), "Baseline review prompt layout changed")
    return INSTRUCTIONS + prior[len(baseline.INSTRUCTIONS):]


def validate_after(draft, final, response, scope, width, height):
    result, normalized = baseline.validate_after(draft, final, response, scope, width, height)
    before = applicability_diagnostics(draft)
    remaining = applicability_diagnostics(final)
    remaining_ids = {d["diagnostic_id"] for d in remaining}
    result["applicability_preflight_after"] = {"version": VERSION, "remaining_count": len(remaining),
        "remaining": remaining, "closures": [{"diagnostic_id": d["diagnostic_id"],
            "dictionary_constraint_no_longer_violated": d["diagnostic_id"] not in remaining_ids}
            for d in before], "visual_correctness_established": False,
        "host_selected_fills_or_removals": False}
    # This cannot permit anything rejected by the original validator.
    result["passed"] = bool(result["passed"]) and not remaining
    return result, normalized


def association_registry():
    registry = copy.deepcopy(baseline.association_registry())
    registry["applicability_repair"] = {
        "version": VERSION, "original_permission_groups": permission_groups(),
        "all_present_field_occurrences_reported": True, "unknown_na_exemptions": False,
        "response_schema_changed": False, "final_validator_changed": False,
        "automatic_wire_repairs": False,
    }
    return registry
