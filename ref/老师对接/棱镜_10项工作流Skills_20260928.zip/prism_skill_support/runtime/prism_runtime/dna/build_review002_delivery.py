"""Offline package for REVIEW-002; no provider calls or corrected visual output."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import io
import json
import shutil
import unittest

from prism_runtime.dna import r70_review_contract_patch as patch

ROOT = patch.PROJECT
LOOP = ROOT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
CLI = LOOP / "qwen-cli-20260927"
RUN = CLI / "runs/full120-qwen-v1-20260927"
OUT = ROOT / "outputs/prism-algorithm-loop-20260926/modules/dna/repairs/QWEN-D01-REVIEW-002/v1"

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def text_sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")

def prompt_text(path):
    return "".join(p["text"] for m in read(path)["input"]["messages"] for p in m["content"] if "text" in p)

def main():
    if (OUT / "handoff.json").exists():
        raise SystemExit("Delivery already published; do not overwrite a frozen handoff.")
    OUT.mkdir(parents=True, exist_ok=True)
    dispatch_path = LOOP / "dispatches/QWEN-D01-REVIEW-002.json"
    dispatch = read(dispatch_path)
    freeze_path = CLI / "candidate-freeze-v1.json"
    freeze = read(freeze_path)
    unchanged = []
    for name, expected in freeze["original_R70_freeze"]["source_hashes"].items():
        p = patch.OPT / name
        assert sha(p) == expected, str(p)
        unchanged.append({"path": str(p), "sha256": expected})
    for item in freeze["candidate_source_files"]:
        p = Path(item.get("source") or item["path"])
        assert sha(p) == item["sha256"], str(p)
        unchanged.append({"path": str(p), "sha256": item["sha256"]})
    for item in freeze["source_files"]:
        p = Path(item["source"])
        if p.parent == ROOT / "prism_runtime/dna":
            assert sha(p) == item["sha256"], str(p)
            unchanged.append({"path": str(p), "sha256": item["sha256"]})
    assert sha(patch.DICT_PATH) == freeze["original_R70_freeze"]["dictionary_sha256"]
    unchanged.append({"path": str(patch.DICT_PATH), "sha256": sha(patch.DICT_PATH)})
    inputs = [{"path": str(dispatch_path), "sha256": sha(dispatch_path)}, {"path": str(freeze_path), "sha256": sha(freeze_path)}]
    cases = []
    expected_errors = {"R002": "PID outside frozen visual-review facets", "R005": "Cannot remove required core or supply a remove value"}
    for case in dispatch["minimum_cases"]:
        cid = case["image_id"]
        source = Path(case["primary_wire"]).parent
        dest = OUT / "cases" / cid
        (dest / "inputs").mkdir(parents=True, exist_ok=True)
        (dest / "outputs").mkdir(exist_ok=True)
        draft = read(Path(case["primary_wire"]))
        reply = read(Path(case["review_response"]))
        old_scope = read(Path(case["review_scope"]))
        metadata = read(source / "input-manifest.json")
        width, height = metadata["photo_original_pixels"]
        source_manifest = Path(metadata["source_manifest_ref"])
        image = next(x for x in read(source_manifest)["records"] if x["image_id"] == cid)
        photo = Path(image["path"])
        assert sha(photo) == image["sha256"] == metadata["photo_sha256"]
        validation, normalized = patch.validate(draft, width, height)
        scope = patch.review_scope(draft, normalized)
        scope["primary_validation_errors"] = validation.get("errors", [])
        assert scope["allowed_pids"] == old_scope["allowed_pids"]
        original_parts = {k:v for k,v in scope.items() if k != "edit_contract"}
        assert original_parts == old_scope, "Existing v1 scope must be unchanged"
        old_primary_path = RUN / "jobs" / cid / "calls" / (cid + "-primary") / "request.json"
        old_review_path = RUN / "jobs" / cid / "calls" / (cid + "-visual-review") / "request.json"
        primary, primary_schema, _, _, _ = patch.build_inputs(photo)
        assert primary == prompt_text(old_primary_path)
        old_prompt = prompt_text(old_review_path)
        old_pack = json.loads(old_prompt.split("\n同图初稿与原字典复核范围：\n",1)[1].split("\n输出结构：\n",1)[0])
        assert old_pack["review_scope"]["allowed_pids"] == old_scope["allowed_pids"]
        assert old_pack["core_required_by_type"]["O05"] == patch.CORE["O05"]
        candidate_prompt = patch.critic_prompt(draft, scope)
        before = (text_sha(patch.compact(draft)), text_sha(patch.compact(reply)))
        diagnostic = patch.review_reply_preflight(draft, reply, scope)
        rejects = {}
        for label, algo, use_scope in [("v1", patch.prior, old_scope), ("review002", patch, scope)]:
            try:
                algo.apply_correction(draft, reply, use_scope)
            except Exception as exc:
                rejects[label] = type(exc).__name__ + ": " + str(exc)
            else:
                raise AssertionError("Old invalid reply was incorrectly accepted")
        assert rejects["v1"] == rejects["review002"]
        assert expected_errors[cid] in rejects["review002"]
        assert before == (text_sha(patch.compact(draft)), text_sha(patch.compact(reply)))
        for name in ["initial-wire.json", "final-wire.json", "input-manifest.json", "primary-validation.json", "visual-review-scope.json", "benchmark-result.json"]:
            p = source / name
            if p.exists():
                shutil.copyfile(p, dest / "inputs" / name)
                inputs.append({"path": str(p), "sha256": sha(p)})
        shutil.copyfile(Path(case["review_response"]), dest / "inputs/actual-qwen-review-output.json")
        for stage in ["primary", "visual-review"]:
            call = RUN / "jobs" / cid / "calls" / (cid + "-" + stage)
            for name in ["request.json", "provider-response.json", "output.json", "result.json"]:
                p = call / name
                inputs.append({"path": str(p), "sha256": sha(p)})
        inputs += [{"path": str(photo), "sha256": sha(photo)}, {"path": str(source_manifest), "sha256": sha(source_manifest)}]
        dump(dest / "outputs/edit-contract.json", scope["edit_contract"])
        dump(dest / "outputs/review-scope.json", scope)
        dump(dest / "outputs/request-encoding-schema.json", patch.request_schema(draft, scope))
        dump(dest / "outputs/actual-reply-preflight.json", diagnostic)
        dump(dest / "outputs/unchanged-replay-rejection.json", {"errors": rejects, "draft_unchanged": True,
            "reply_unchanged": True, "partial_edits_published": False, "host_created_corrected_wire": False})
        (dest / "outputs/candidate-review-from-recorded-draft.prompt.txt").write_text(candidate_prompt, encoding="utf-8")
        cases.append({"image_id": cid, "source_kind": metadata["source_kind"], "image_ref": str(photo), "image_sha256": sha(photo),
            "producer_and_edit_engine_scope_agree": True, "old_request_already_included_core_rules": True,
            "allowed_pids_unchanged": True, "original_scope_unchanged_except_sidecar": True,
            "old_and_new_engine_reject_identically": rejects["review002"],
            "preflight_diagnostic_count": diagnostic["diagnostic_count"], "diagnostics": diagnostic["diagnostics"],
            "primary_prompt_unchanged": True, "primary_prompt_sha256": text_sha(primary),
            "old_review_prompt_sha256": text_sha(old_prompt), "candidate_review_prompt_sha256": text_sha(candidate_prompt),
            "review_prompt_utf8_bytes": {"v1":len(old_prompt.encode()), "review002":len(candidate_prompt.encode())},
            "new_paid_calls": 0})
    stream = io.StringIO()
    tests = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName("prism_runtime.dna.test_r70_review_contract_patch"))
    (OUT / "offline-tests.txt").write_text(stream.getvalue(), encoding="utf-8")
    assert tests.wasSuccessful()
    for item in inputs + unchanged:
        assert sha(Path(item["path"])) == item["sha256"], item["path"]
    sources = [Path(patch.__file__).resolve(), ROOT / "prism_runtime/dna/test_r70_review_contract_patch.py", Path(__file__).resolve()]
    dump(OUT / "source-hashes.json", [{"path": str(p), "sha256": sha(p)} for p in sources])
    dump(OUT / "input-hashes.json", inputs)
    dump(OUT / "unchanged-v1-and-baseline-hashes.json", unchanged)
    dump(OUT / "rules/static-response-encoding-schema.json", patch.correction_schema())
    dump(OUT / "rules/association-registry.json", patch.association_registry())
    (OUT / "rules/review-addendum.txt").write_text(patch.PROTOCOL_RULES, encoding="utf-8")
    now = datetime.now(timezone.utc).isoformat()
    verify = {"version":patch.VERSION, "checked_utc":now, "tests":tests.testsRun, "failures":len(tests.failures), "errors":len(tests.errors),
        "offline_protocol_scope_qualified":True, "fresh_qwen_retest_performed":False, "new_paid_calls":0,
        "v1_primary_prompt_preserved":True, "v1_apply_engine_preserved":patch.apply_correction is patch.prior.apply_correction,
        "original_final_validator_preserved":patch.validate is patch.prior.validate, "allowed_edit_scope_not_expanded":True,
        "existing_adapter_and_v1_source_hashes_preserved":True, "full120_baseline_not_modified":True, "cases":cases}
    dump(OUT / "verification.json", verify)
    dump(OUT / "self-assessment.json", {"module":"dna", "issue_id":"QWEN-D01-REVIEW-002", "repair_cycle":1,
        "status":"partial", "algorithm_version":patch.VERSION, "offline_protocol_scope_qualified":True,
        "ready_for_two_image_qwen_retest":True, "fresh_model_effectiveness_qualified":False,
        "self_assessment":{"qualified":False,"qualified_scope":"Explicit original edit-contract communication, typed request schema and read-only diagnostics only",
            "actual_results":{"offline_tests_passed":tests.testsRun,"old_replies_rejected_unchanged":2,"new_paid_calls":0},
            "known_failures":["No new Qwen responses have been tested; prompt adherence and end-to-end success remain unknown.",
                              "The original two replies remain invalid, with5 and4 checked violations respectively."]},
        "holdout_description":"Only R002/R005 supplied failure pairs were diagnosed. Synthetic protocol fragments are tests, not corrected image answers.",
        "paid_calls_required_for_offline_replay":0, "handoff_ref":str(OUT/'handoff.json')})
    (OUT / "README.md").write_text(README, encoding="utf-8")
    dump(OUT / "handoff.json", {"module":"dna", "issue_id":"QWEN-D01-REVIEW-002", "repair_cycle":1,
        "status":"partial", "contract_version":"0.1", "algorithm_version":patch.VERSION,
        "entrypoint":"import prism_runtime.dna.r70_review_contract_patch as algo", "source_entrypoint":str(Path(patch.__file__).resolve()),
        "ready_for_two_image_qwen_retest":True, "production_qualified":False,
        "qualified_scope":"Offline edit contract, detailed model-facing schema and read-only preflight; no semantic accuracy claim",
        "files":[str(p) for p in sources]+[str(OUT/n) for n in ["README.md","verification.json","self-assessment.json","source-hashes.json","input-hashes.json","unchanged-v1-and-baseline-hashes.json"]],
        "fixture_or_existing_output":[str(OUT/'cases'/cid/'outputs/actual-reply-preflight.json') for cid in ['R002','R005']],
        "verification":{"command":"python -B -X utf8 -m unittest prism_runtime.dna.test_r70_review_contract_patch -v",
            "result":"offline_pass:24 tests; both bad replies retain exact original rejection; no repaired visual wires", "record":str(OUT/'verification.json')},
        "new_paid_calls":0,"v1_or_original_validator_changed":False,
        "integration":{"primary_prompt":"same as v1","review_response":"same seven-key wire; more detailed encoding schema and dynamic per-request constraints",
            "optional_reply_diagnostics":"algo.review_reply_preflight(fresh_draft, fresh_reply, fresh_scope) before unchanged apply; preserve rejection even if this narrow preflight reports no issues",
            "max_retest_calls":"Root-authorized fresh primary plus one same-image review on R002 and R005 only"},
        "limitations":["No fresh Qwen, latency or token-price validation in this delivery.","Byte growth of review prompts is recorded; dynamic constraints may increase input cost.","Scope remains bounded: fields outside allowed_pids stay read-only rather than silently becoming editable."]})
    dump(OUT / "delivery-hashes.json", {"version":patch.VERSION,"generated_utc":now,
        "files":[{"path":str(p),"sha256":sha(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='delivery-hashes.json']})
    print(json.dumps({"status":"partial_ready_for_two_image_qwen_retest","tests":tests.testsRun,"new_paid_calls":0,"cases":cases,"handoff":str(OUT/'handoff.json')},ensure_ascii=False))

README = '''# QWEN-D01-REVIEW-002 · 第1轮有界修复

版本：r70-review-contract-d01-v2。状态partial。只自评离线协议说明、模型格式约束及只读预检范围合格；新鲜Qwen效果仍待Root定点复测。

## 两个实际反例

R002：Qwen提出remove对象5的STR-007。它是原字典中定义明确的“接缝路径”，也允许该对象类型，但不在当次review_scope.allowed_pids。原请求的allowed_pids与apply引擎实际范围一致，不是执行器偷偷少了一项。Qwen另声称GEO-012未定义，但原请求中该字段、名称“曲面类型”和定义均已提供。旧提示一句“限allowed_pids”和宽泛视觉复核任务、缺少item约束的数组schema，未能有效阻止这种理解错误。

R005：Qwen要求remove O05对象5的OPT-001、OPT-002、OPT-007。这三项均是初稿类型的必填core，旧请求已经提供了core_required_by_type，真实引擎也按它保护删除。这不是“remove.value不是null”：实际三个remove.value都是null，真正触发的是核心删除保护。

额外只读诊断：R002又向O15提出4项不适用字段；R005将数值字段TXT-008赋为true。它们属于最终字典约束，不能与编辑器范围混为一类。本轮没有替模型决定颜色、材质、发光、文字或其他视觉值。

## 最小变更

新增独立sidecar：prism_runtime/dna/r70_review_contract_patch.py。

- 原v1、R70、主解析提示、原编辑引擎和最终validator不改；allowed_pids不扩大。
- 每个已有字段明确列出原始old、完整field_key、可执行操作、core删除锁、原类型适用性；范围外的有效原字段标为只读并保留定义，避免把“不能编辑”误当“未定义”。
- 同一原七键回复格式加入详细item schema及本请求的范围/core限制，只是模型侧格式提示，官方调用仍是JSON-object，不声称provider强制执行JSON Schema。
- 明确old值的JSON类型、add/set/remove前提、删除按旧类型保护、review状态全称、五项已知值非自身宿主、原ID列表和区域引用格式。
- 提供只读review_reply_preflight，汇总所检查的协议/取值/绑定/引用问题，不应用任何修改；空诊断不代表完整协议或视觉内容合格。

## 验证

在D:/Codex/传音AI创客营执行：

```powershell
& 'C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B -X utf8 -m unittest prism_runtime.dna.test_r70_review_contract_patch -v
```

24项离线测试通过，包括两份真实回复、原请求/执行范围一致性、核心删除锁、false与0旧值不同、remove.value必须null、old_state及完整状态、非自身参照及缺失引用、JSON Schema有效性、独立绝对路径加载。

原R002/R005坏回复在新旧入口下分别仍报出原来的“PID outside frozen visual-review facets”和“Cannot remove required core or supply a remove value”。没有输出手工修好的wire，没有发布部分已应用编辑。现有v1、R70、原字典、旧适配器和两例原始证据哈希保持。

## Root接入与复测边界

新算法入口可用上述.py绝对路径通过现有import_path加载，也可导入模块。常用build_inputs、validate、can_review、review_scope、critic_prompt、apply_correction、validate_after接口均保留；apply与最终validate直接沿用v1原函数。

新候选应另行冻结sidecar及原依赖。主提示hash仍是v1；INSTRUCTIONS、correction_schema及association_registry的候选hash会改变。不要覆盖candidate-freeze-v1.json或120图基线。

Root可在新鲜复核响应到达后先保存review_reply_preflight结果，再调用原apply和最终validate。不要把预检当作独立放行器。动态request_schema由新鲜主稿与新鲜scope生成；cases目录的候选prompt仅是旧失败稿的离线示例，不能直接喂入新鲜主解析后的复测。

只对R002/R005按用户给Root的边界做首次加一次复核，且必须由Qwen生成语义。当前交付新增付费调用为0，没有重跑120张、恢复计时器或替用户/模型填值。它不证明16图范围错误或15图核心删除错误都已解决，也不证明视觉准确率提高；输入字节增量已记录，成本和时延尚未重测。
'''

if __name__ == "__main__":
    main()
