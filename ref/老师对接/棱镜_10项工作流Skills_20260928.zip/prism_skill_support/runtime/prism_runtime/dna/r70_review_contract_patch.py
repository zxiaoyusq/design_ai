"""REVIEW-002 v1: communicate the existing edit engine's exact contract.

No new edit permissions, visual guesses or repair operations are introduced.
Applicability v1, the R70 edit engine and the original final validator remain
unchanged. This sidecar adds model-facing constraints and read-only diagnostics.
"""
from __future__ import annotations
import copy
import hashlib
import importlib.util
from pathlib import Path

_spec = importlib.util.spec_from_file_location("prism_review002_frozen_v1", Path(__file__).with_name("r70_applicability_patch.py"))
prior = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(prior)

VERSION = "r70-review-contract-d01-v2"
PROJECT, OPT, P, ACTIVE, CORE, DICT_PATH = (getattr(prior, k) for k in ["PROJECT", "OPT", "P", "ACTIVE", "CORE", "DICT_PATH"])
base = prior.base
compact, loads, require, exact, KEY = (getattr(prior, k) for k in ["compact", "loads", "require", "exact", "KEY"])
FACETS = prior.FACETS
METADATA_FIELDS = {"type", "label", "parent", "box", "origin"}
HOST_FIELDS = frozenset(base.region.HOST_FIELDS)
build_inputs = prior.build_inputs
validate = prior.validate
can_review = prior.can_review
partial_preview = prior.partial_preview
apply_correction = prior.apply_correction
validate_after = prior.validate_after

PROTOCOL_RULES = '''
本次编辑协议的精确边界：原字典有效字段、当次可编辑PID、当前对象必填core是三件不同的事。review_scope.allowed_pids是当次唯一编辑授权集。初稿可能包含有效但本轮只读的字段；不在allowed_pids不代表“未定义”，不能set/add/remove，也不能改其review状态。没有证据的改动不要做，范围外的疑问只写unresolved_issues。
edit_contract.field_snapshots逐项给出原始field_key、原始old以及编辑器允许的操作。field_key包括已有@参照后缀，必须完整照用；object_id是对象整数ID，不是数组位置。old须逐字值及JSON类型一致，不用规范化结果替换旧值；false、null、0和字符串不是同一值。set/remove要求原键存在，add要求原键不存在且old=null；同一对象/键只能操作一次。
每个原对象的core_locked字段永远不能remove，即使旧值为空、你认为不适用，或你同时拟改对象type。原编辑器先处理dna_edits，再处理object_edits，删除保护按初稿类型计算。合法载体上的core若应未知/不适用，必须由你看图明确set为null/false，不能删除占位，也不能以新type绕过旧core。false仍不能使不允许的载体绑定合法。非core也只有在allowed_pids内且原键存在时才能remove，remove.value必须为JSON null而非false。
reference_contract列出原五项“已知值必须有非自身参照”的字段。仅在按原定义得到具体值时，需要写成原PID@真实参照整数ID，参照必须实际存在且非当前对象；不能由程序默认父级。核心字段不得加@；需要改参照时，按原协议明确remove旧非core键、add新完整键，不能把reference塞进value对象。对象ID数组使用o1等原ID字符串；区域引用仍用原value_schema。语法合法的参照ID不代表它在图像上就是正确宿主。
review_edits只允许完整字符串unknown/not_applicable；不能写known、u/n、null、false。old_state复制当前effective_review；这个字段级全图兜底不覆盖已存在对象实例，也不能由“初稿没写在此对象上”推断全部不适用。
详细JSON schema仅说明已有响应格式和执行约束，不是新视觉答案。所有新值必须符合原参数value_schema与实际载体；编辑器先接受操作格式，最终原validator仍可能拒绝错误类型、宿主或区域。不要通过删除正确的描述或发明新值求通过；不能修的明确保留未解决。
'''
INSTRUCTIONS = prior.INSTRUCTIONS + PROTOCOL_RULES


def _effective_review(draft, pid):
    raw = draft["review"]["exceptions"].get(pid, draft["review"]["families"][pid[:3]])
    return {"u": "unknown", "n": "not_applicable"}.get(raw, raw)


def edit_contract(draft, scope):
    """Derive allowed operations from the original draft without changing it."""
    allowed = set(scope["allowed_pids"])
    rows, read_only, carriers = [], [], []
    entries = [(n["id"], n["type"], n["dna"]) for n in draft["objects"]] + [(0, "O19", draft["frame"])]
    for oid, otype, values in entries:
        core = set(CORE[otype]) if oid else set()
        carriers.append([oid, otype, sorted(core)])
        for key, old in values.items():
            match = KEY.fullmatch(key) if isinstance(key, str) else None
            pid = match.group(1) if match else None
            active = pid in ACTIVE
            in_scope = active and pid in allowed
            locked = pid in core
            operations = (["set"] + ([] if locked else ["remove"])) if in_scope else []
            rows.append([oid, key, copy.deepcopy(old), operations, locked,
                         active and otype in P[pid]["applicable_object_types"]])
            if active and not in_scope:
                read_only.append({"object_id": oid, "field_key": key, "parameter_id": pid,
                    "original_name": P[pid]["name"], "original_definition": P[pid]["definition"],
                    "reason": "original_field_exists_but_not_in_this_review_allowed_pids"})
    return {"version": VERSION, "draft_sha256": hashlib.sha256(compact(draft).encode()).hexdigest(),
        "allowed_pids_unchanged": sorted(allowed),
        "carrier_columns": ["object_id", "original_object_type", "core_locked_against_remove"], "carriers": carriers,
        "field_snapshot_columns": ["object_id", "field_key", "exact_raw_old", "engine_allowed_existing_key_operations", "core_locked", "original_type_applicable"],
        "field_snapshots": rows, "read_only_existing_fields": read_only,
        "add_rule": "Only absent exact keys, original allowed PID, existing target, old=null; final original type/value/reference constraints also apply.",
        "phase_order": ["dna_edits", "object_edits", "new_objects", "review_edits", "checks"],
        "remove_lock_uses": "original draft object type, even if object_edits proposes a new type",
        "effective_review": {pid: _effective_review(draft, pid) for pid in sorted(allowed)},
        "review_state_domain": ["unknown", "not_applicable"],
        "reference_contract": {"known_nonself_host_pids": sorted(HOST_FIELDS), "key_format": "PID@integer_id",
            "existing_reference_ids": [0] + [n["id"] for n in draft["objects"]],
            "new_reference_ids": "Only IDs actually declared by valid consecutive new_objects",
            "required_only_for_known_values": True, "core_extra_reference_forbidden": True,
            "host_chooses_reference": False},
        "host_selects_new_values_or_operations": False, "not_a_visual_correctness_certificate": True}


def correction_schema():
    """Detailed encoding schema; same seven-key wire and original edit semantics."""
    props = {
        "dna_edits": {"type": "array", "items": {"type": "object", "additionalProperties": False,
            "required": ["op", "object_id", "pid", "old", "value"], "properties": {
                "op": {"enum": ["set", "add", "remove"]}, "object_id": {"type": "integer", "minimum": 0},
                "pid": {"type": "string", "pattern": KEY.pattern}, "old": {}, "value": {}},
            "allOf": [{"if": {"properties": {"op": {"const": "add"}}}, "then": {"properties": {"old": {"type": "null"}}}},
                      {"if": {"properties": {"op": {"const": "remove"}}}, "then": {"properties": {"value": {"type": "null"}}}}]}},
        "object_edits": {"type": "array", "items": {"type": "object", "additionalProperties": False,
            "required": ["object_id", "field", "old", "value"], "properties": {"object_id": {"type": "integer", "minimum": 1},
                "field": {"enum": sorted(METADATA_FIELDS)}, "old": {}, "value": {}}}},
        "new_objects": copy.deepcopy(base.schema()["properties"]["objects"]),
        "review_edits": {"type": "array", "items": {"type": "object", "additionalProperties": False,
            "required": ["pid", "old_state", "state"], "properties": {"pid": {"type": "string"},
                "old_state": {"enum": ["unknown", "not_applicable"]}, "state": {"enum": ["unknown", "not_applicable"]}}}},
        "checks": {"type": "array", "items": {"type": "object", "additionalProperties": False,
            "required": ["facet", "result", "evidence"], "properties": {"facet": {"enum": list(FACETS)},
                "result": {"enum": ["retained", "corrected", "not_present", "unresolved"]},
                "evidence": {"type": "string", "minLength": 1}}}},
        "unresolved_issues": {"type": "array", "items": {"type": "string"}},
        "review_complete": {"const": True}}
    return {"type": "object", "additionalProperties": False, "required": list(props), "properties": props}


def request_schema(draft, scope):
    schema = correction_schema()
    ids = [n["id"] for n in draft["objects"]]
    rule = schema["properties"]["dna_edits"]["items"]
    rule["properties"]["object_id"] = {"enum": [0] + ids}
    rule["properties"]["pid"]["pattern"] = "^(?:" + "|".join(scope["allowed_pids"]) + r")(?:@(0|[1-9]\d*))?$"
    for node in draft["objects"]:
        removable = [k for k in node["dna"] if KEY.fullmatch(k) and KEY.fullmatch(k).group(1) in scope["allowed_pids"] and KEY.fullmatch(k).group(1) not in CORE[node["type"]]]
        rule["allOf"].append({"if": {"properties": {"op": {"const": "remove"}, "object_id": {"const": node["id"]}}},
                              "then": {"properties": {"pid": {"enum": removable}}} if removable else False})
    schema["properties"]["object_edits"]["items"]["properties"]["object_id"] = {"enum": ids}
    schema["properties"]["review_edits"]["items"]["properties"]["pid"] = {"enum": list(scope["allowed_pids"])}
    return schema


def review_scope(draft, normalized):
    scope = copy.deepcopy(prior.review_scope(draft, normalized))
    scope["edit_contract"] = edit_contract(draft, scope)
    return scope


def critic_prompt(draft, scope):
    previous = prior.critic_prompt(draft, scope)
    require(previous.startswith(prior.INSTRUCTIONS), "Frozen v1 review prompt layout changed")
    return (INSTRUCTIONS + previous[len(prior.INSTRUCTIONS):]
            + "\n本请求的详细编辑格式（授权范围仍以原allowed_pids为准）：\n" + compact(request_schema(draft, scope)))


def review_reply_preflight(draft, response, scope):
    """Read-only targeted checks. Never applies even the valid prefix of edits.

    Covers DNA edit scope/core/old values, review states, original value types
    and reference obligations. It is not a replacement for the full original
    edit engine, geometry checks, or final validator.
    """
    findings = []
    def flag(code, section, index, **detail):
        findings.append({"code": code, "section": section, "index": index, **detail})
    if not isinstance(response, dict):
        return {"version": VERSION, "diagnostics": [{"code": "response_not_object"}], "read_only": True, "not_a_complete_validator": True}
    nodes = {n["id"]: n for n in draft["objects"]}
    allowed = set(scope["allowed_pids"])
    final_ids = {0} | set(nodes)
    declared_new = response.get("new_objects", [])
    if isinstance(declared_new, list):
        next_id = len(nodes) + 1
        for item in declared_new:
            if (not isinstance(item, dict) or set(item) != {"id", "type", "label", "parent", "box", "origin", "dna"}
                or type(item.get("id")) is not int or item["id"] != next_id
                or not isinstance(item.get("type"), str) or item["type"] not in CORE
                or not isinstance(item.get("dna"), dict) or not set(CORE[item["type"]]).issubset(item["dna"])):
                break
            if any(not isinstance(k, str) or KEY.fullmatch(k) is None or KEY.fullmatch(k).group(1) not in allowed for k in item["dna"]):
                break
            final_ids.add(next_id); next_id += 1
    type_updates = {}
    for item in response.get("object_edits", []) if isinstance(response.get("object_edits"), list) else []:
        if isinstance(item, dict) and item.get("field") == "type" and type(item.get("object_id")) is int and item["object_id"] in nodes:
            oid = item["object_id"]
            if isinstance(item.get("value"), str) and item["value"] in CORE and exact(item.get("old"), nodes[oid]["type"]):
                type_updates[oid] = item["value"]
    seen = set()
    edits = response.get("dna_edits", [])
    if not isinstance(edits, list):
        flag("dna_edits_not_list", "dna_edits", None); edits = []
    for index, edit in enumerate(edits):
        if not isinstance(edit, dict) or set(edit) != {"op", "object_id", "pid", "old", "value"}:
            flag("dna_edit_shape", "dna_edits", index); continue
        op, oid, key = edit["op"], edit["object_id"], edit["pid"]
        if op not in ["set", "add", "remove"] or type(oid) is not int or oid not in ({0} | set(nodes)):
            flag("operation_or_target_invalid", "dna_edits", index); continue
        match = KEY.fullmatch(key) if isinstance(key, str) else None
        if match is None:
            flag("pid_key_invalid", "dna_edits", index, field_key=key); continue
        pid, suffix = match.groups()
        values = draft["frame"] if oid == 0 else nodes[oid]["dna"]
        core = set() if oid == 0 else set(CORE[nodes[oid]["type"]])
        if pid not in allowed:
            flag("pid_outside_exact_review_scope", "dna_edits", index, object_id=oid, field_key=key)
        if (oid, key) in seen:
            flag("duplicate_dna_edit", "dna_edits", index, object_id=oid, field_key=key)
        seen.add((oid, key))
        exists = key in values
        if op == "add" and (exists or edit["old"] is not None):
            flag("add_requires_absent_key_and_null_old", "dna_edits", index, object_id=oid, field_key=key)
        if op in ["set", "remove"] and (not exists or not exact(values[key], edit["old"])):
            flag("old_value_or_key_mismatch", "dna_edits", index, object_id=oid, field_key=key)
        if op == "remove":
            if pid in core:
                flag("cannot_remove_original_core", "dna_edits", index, object_id=oid, field_key=key)
            if edit["value"] is not None:
                flag("remove_value_must_be_json_null", "dna_edits", index, object_id=oid, field_key=key)
            continue
        if pid not in ACTIVE:
            continue
        otype = "O19" if oid == 0 else type_updates.get(oid, nodes[oid]["type"])
        if otype not in P[pid]["applicable_object_types"]:
            flag("proposed_binding_incompatible", "final_original_validator", index, object_id=oid, field_key=key, object_type=otype)
        if pid.startswith("CTX-") != (oid == 0):
            flag("proposed_wire_slot_mismatch", "final_original_validator", index, object_id=oid, field_key=key)
        if pid in core and suffix is not None:
            flag("core_extra_reference_forbidden", "final_original_validator", index, object_id=oid, field_key=key)
        try:
            tag = base.decode_value(pid, edit["value"], f"proposal/{index}", [])
        except Exception as exc:
            flag("proposed_original_value_type_violation", "final_original_validator", index, object_id=oid, field_key=key, detail=str(exc)); continue
        ref = int(suffix) if suffix is not None else oid
        if ref not in final_ids:
            flag("reference_id_not_declared", "final_original_validator", index, object_id=oid, field_key=key)
        if tag[0] == "k" and pid in HOST_FIELDS and ref == oid:
            flag("known_value_requires_nonself_reference", "final_original_validator", index, object_id=oid, field_key=key)
        if tag[0] == "k" and P[pid]["value_type"] in ["id_list", "ordered_id_list"]:
            if not set(tag[1]).issubset({f"o{i}" for i in final_ids}):
                flag("value_object_ids_not_declared", "final_original_validator", index, object_id=oid, field_key=key)
        if tag[0] == "k" and P[pid]["value_type"] == "region_reference":
            if tag[1].get("region") not in {f"o{i}" for i in final_ids}:
                flag("value_region_not_declared", "final_original_validator", index, object_id=oid, field_key=key)
    review_seen = set()
    reviews = response.get("review_edits", [])
    if not isinstance(reviews, list):
        flag("review_edits_not_list", "review_edits", None); reviews = []
    for index, edit in enumerate(reviews):
        if not isinstance(edit, dict) or set(edit) != {"pid", "old_state", "state"}:
            flag("review_edit_shape", "review_edits", index); continue
        pid = edit["pid"]
        if not isinstance(pid, str) or pid not in allowed:
            flag("review_pid_outside_scope", "review_edits", index); continue
        if pid in review_seen:
            flag("duplicate_review_edit", "review_edits", index, parameter_id=pid)
        review_seen.add(pid)
        if edit["old_state"] != _effective_review(draft, pid):
            flag("old_review_state_mismatch", "review_edits", index, parameter_id=pid)
        if edit["state"] not in ["unknown", "not_applicable"]:
            flag("review_state_requires_full_explicit_string", "review_edits", index, parameter_id=pid)
    return {"version": VERSION, "diagnostics": findings, "diagnostic_count": len(findings),
            "read_only": True, "host_selected_or_applied_repairs": False, "not_a_complete_validator": True,
            "empty_list_does_not_certify_visual_or_full_protocol_validity": True}


def association_registry():
    result = copy.deepcopy(prior.association_registry())
    result["review_edit_contract_sidecar"] = {"version": VERSION, "allowed_pids_policy_changed": False,
        "primary_prompt_changed": False, "seven_key_wire_changed": False, "typed_request_schema_added": True,
        "original_apply_and_validator_preserved": True, "reference_host_fields": sorted(HOST_FIELDS),
        "read_only_preflight": True, "automatic_repairs": False}
    return result
