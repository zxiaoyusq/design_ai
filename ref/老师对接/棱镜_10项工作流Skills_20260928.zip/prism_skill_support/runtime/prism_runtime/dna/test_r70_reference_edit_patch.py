"""Offline failure replay and synthetic wire tests; no model/image answers."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest

from prism_runtime.dna import r70_reference_edit_patch as patch
import jsonschema

RUN = patch.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/qwen-cli-20260927/runs/dna-review-v2-two-image-retest"


def read(path):
    return patch.loads(path.read_text(encoding="utf-8"))


def empty_reply():
    return {"dna_edits": {}, "object_edits": {}, "new_objects": [], "review_edits": {},
        "checks": [{"facet": f, "result": "retained", "evidence": "synthetic protocol fixture, no image judgment"}
                   for f in patch.FACETS], "unresolved_issues": [], "review_complete": True}


def synthetic_draft():
    # Artificial IDs and explicit nulls are only protocol fixtures. These are
    # never exported as a repaired real image or an accuracy ground truth.
    nodes = []
    for oid, otype in [(1, "O01"), (2, "O02"), (3, "O15")]:
        nodes.append({"id": oid, "type": otype, "label": "synthetic " + str(oid),
            "parent": None if oid == 1 else 1, "box": [0, 0, 1000, 1000], "origin": "surface",
            "dna": {pid: None for pid in patch.CORE[otype]}})
    nodes[2]["dna"]["STR-006"] = 0.123
    return {"objects": nodes, "frame": {}, "review": {
        "families": {family: "unknown" for family in patch.base.FAMILIES}, "exceptions": {}}, "issues": []}


def synthetic_retarget():
    r = empty_reply()
    r["dna_edits"] = {"3": {
        "STR-006": {"op": "remove", "old": 0.123, "value": None},
        "STR-006@2": {"op": "add", "old": None, "value": 0.456}}}
    return r


class ReferenceEditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = {}
        for cid in ["R002", "R005"]:
            folder = RUN / "jobs" / cid / "dna" / cid
            draft = read(folder / "initial-wire.json")
            meta = read(folder / "input-manifest.json")
            validation, normalized = patch.validate(draft, *meta["photo_original_pixels"])
            cls.cases[cid] = {"draft": draft, "meta": meta, "validation": validation,
                "old_scope": read(folder / "visual-review-scope.json"),
                "scope": patch.review_scope(draft, normalized),
                "reply": read(RUN / "jobs" / cid / "calls" / (cid + "-visual-review") / "output.json")}

    def setUp(self):
        self.draft = synthetic_draft()
        self.scope = patch.review_scope(self.draft, None)

    def test_fresh_r002_all_three_missing_hosts_are_exposed(self):
        findings = patch.reference_diagnostics(self.cases["R002"]["draft"])
        self.assertEqual([(d["object_id"], d["field_key"]) for d in findings], [(6, "STR-006"), (7, "STR-006"), (8, "STR-006")])
        self.assertTrue(all(d["existing_value"] == 0.01 for d in findings))
        self.assertTrue(all(not d["semantic_reference_selected"] for d in findings))

    def test_fresh_r005_missing_host_and_grant_are_exposed(self):
        c = self.cases["R005"]["scope"]["reference_repair_contract"]
        self.assertEqual(c["extra_cell_grants"], {"10": {"STR-006": ["STR-006"]}})
        self.assertEqual(c["reference_diagnostics"][0]["existing_value"], 0.005)

    def test_old_scopes_cannot_legally_repair_str006(self):
        for c in self.cases.values():
            self.assertNotIn("STR-006", c["old_scope"]["allowed_pids"])
            self.assertEqual(c["scope"]["base_allowed_pids"], c["old_scope"]["allowed_pids"])
            self.assertEqual(set(c["scope"]["allowed_pids"]) - set(c["old_scope"]["allowed_pids"]), {"STR-006"})

    def test_original_r002_reply_still_fails_final_validator_unchanged(self):
        c = self.cases["R002"]
        before = patch.compact([c["draft"], c["reply"]])
        final, _ = patch.prior.apply_correction(c["draft"], c["reply"], c["old_scope"])
        v, n = patch.prior.validate_after(c["draft"], final, c["reply"], c["old_scope"], *c["meta"]["photo_original_pixels"])
        self.assertFalse(v["passed"])
        self.assertIn("Explicit non-self host required for STR-006", " ".join(v["structure_validation"]["errors"]))
        self.assertIsNone(n)
        self.assertEqual(patch.compact([c["draft"], c["reply"]]), before)

    def test_original_r005_keeps_duplicate_edit_rejection(self):
        c = self.cases["R005"]
        before = patch.compact([c["draft"], c["reply"]])
        with self.assertRaisesRegex(ValueError, "Duplicate DNA edit"):
            patch.prior.apply_correction(c["draft"], c["reply"], c["old_scope"])
        self.assertEqual(patch.compact([c["draft"], c["reply"]]), before)

    def test_v3_does_not_silently_convert_or_deduplicate_old_arrays(self):
        for c in self.cases.values():
            with self.assertRaisesRegex(ValueError, "v3 unique-key object required"):
                patch.apply_correction(c["draft"], c["reply"], c["scope"])

    def test_four_real_calls_are_stop_not_transport_truncated(self):
        for cid in self.cases:
            for stage in ["primary", "visual-review"]:
                packet = read(RUN / "jobs" / cid / "calls" / (cid + "-" + stage) / "provider-response.json")
                self.assertEqual(packet["http_status"], 200)
                self.assertEqual(packet["data"]["output"]["choices"][0]["finish_reason"], "stop")

    def test_scope_and_preflight_never_modify_draft(self):
        before = patch.compact(self.draft)
        patch.reference_diagnostics(self.draft)
        patch.review_scope(self.draft, None)
        patch.review_reply_preflight(self.draft, synthetic_retarget(), self.scope)
        self.assertEqual(patch.compact(self.draft), before)

    def test_unknown_bare_host_does_not_invent_reference(self):
        self.draft["objects"][2]["dna"]["STR-006"] = None
        self.assertEqual(patch.reference_diagnostics(self.draft), [])

    def test_unknown_missing_reference_is_still_reported(self):
        self.draft["objects"][2]["dna"] = {"STR-006@999": None}
        f = patch.reference_diagnostics(self.draft)
        self.assertEqual(f[0]["codes"], ["reference_id_not_declared"])

    def test_explicit_self_reference_is_not_exempt(self):
        self.draft["objects"][2]["dna"] = {"STR-006@3": 0.123}
        self.assertIn("known_value_requires_nonself_reference", patch.reference_diagnostics(self.draft)[0]["codes"])

    def test_invalid_value_remains_original_preflight_problem(self):
        self.draft["objects"][2]["dna"]["STR-006"] = {"ratio": 0.123}
        _, diagnostics = patch.partial_preview(self.draft)
        self.assertIn("invalid_original_value", [d["code"] for d in diagnostics])
        self.assertEqual(patch.reference_diagnostics(self.draft), [])

    def test_valid_explicit_reference_does_not_gain_extra_edit_permission(self):
        self.draft["objects"][2]["dna"] = {"STR-006@2": 0.123}
        scope = patch.review_scope(self.draft, None)
        self.assertEqual(scope["reference_repair_contract"]["extra_cell_grants"], {})
        self.assertNotIn("STR-006", scope["allowed_pids"])

    def test_lossless_compile_copies_model_values_and_ops_exactly(self):
        r = synthetic_retarget()
        before = patch.compact(r)
        c = patch.compile_response(self.draft, r, self.scope)
        self.assertEqual(c["dna_edits"], [
            {"object_id": 3, "pid": "STR-006", "op": "remove", "old": 0.123, "value": None},
            {"object_id": 3, "pid": "STR-006@2", "op": "add", "old": None, "value": 0.456}])
        self.assertEqual(patch.compact(r), before)

    def test_frozen_engine_applies_only_explicit_synthetic_proposal(self):
        r = synthetic_retarget()
        out, audit = patch.apply_correction(self.draft, r, self.scope)
        self.assertEqual(out["objects"][2]["dna"]["STR-006@2"], 0.456)
        self.assertNotIn("STR-006", out["objects"][2]["dna"])
        self.assertIn("STR-006", self.draft["objects"][2]["dna"])
        self.assertFalse(audit["review_serialization"]["reference_target_inferred"])
        expected, _ = patch.prior.apply_correction(self.draft, patch.compile_response(self.draft, r, self.scope), self.scope)
        self.assertEqual(out, expected)

    def test_extra_grant_cannot_escape_to_other_object(self):
        r = empty_reply()
        r["dna_edits"] = {"2": {"STR-006@1": {"op": "add", "old": None, "value": 0.1}}}
        with self.assertRaisesRegex(ValueError, "outside diagnosed reference cell"):
            patch.compile_response(self.draft, r, self.scope)

    def test_extra_grant_cannot_modify_other_existing_key(self):
        self.draft["objects"][2]["dna"]["STR-006@2"] = 0.7
        scope = patch.review_scope(self.draft, None)
        r = empty_reply()
        r["dna_edits"] = {"3": {"STR-006@2": {"op": "set", "old": 0.7, "value": 0.9}}}
        with self.assertRaisesRegex(ValueError, "only covers diagnosed original keys"):
            patch.compile_response(self.draft, r, scope)

    def test_retarget_requires_model_remove_and_model_new_value(self):
        r = synthetic_retarget()
        del r["dna_edits"]["3"]["STR-006"]
        with self.assertRaisesRegex(ValueError, "paired explicit removal"):
            patch.compile_response(self.draft, r, self.scope)
        r = synthetic_retarget()
        del r["dna_edits"]["3"]["STR-006@2"]["value"]
        with self.assertRaisesRegex(ValueError, "Explicit op, old and value"):
            patch.compile_response(self.draft, r, self.scope)

    def test_extra_add_cannot_duplicate_or_use_self_host(self):
        r = synthetic_retarget()
        r["dna_edits"]["3"]["STR-006@1"] = {"op": "add", "old": None, "value": 0.123}
        with self.assertRaisesRegex(ValueError, "paired explicit removal"):
            patch.compile_response(self.draft, r, self.scope)
        del r["dna_edits"]["3"]["STR-006@1"]
        r["dna_edits"]["3"]["STR-006@3"] = r["dna_edits"]["3"].pop("STR-006@2")
        with self.assertRaisesRegex(ValueError, "explicit non-self key"):
            patch.compile_response(self.draft, r, self.scope)

    def test_extra_grant_does_not_extend_global_review_states(self):
        r = empty_reply()
        r["review_edits"] = {"STR-006": {"old_state": "unknown", "state": "not_applicable"}}
        with self.assertRaisesRegex(ValueError, "does not authorize global review states"):
            patch.compile_response(self.draft, r, self.scope)

    def test_extra_grant_does_not_extend_new_carrier_dna(self):
        r = empty_reply()
        r["new_objects"] = [{"id": 4, "dna": {"STR-006@2": 0.1}}]
        with self.assertRaisesRegex(ValueError, "does not authorize new-object DNA"):
            patch.compile_response(self.draft, r, self.scope)

    def test_missing_reference_not_accepted_by_preflight(self):
        r = synthetic_retarget()
        r["dna_edits"]["3"]["STR-006@999"] = r["dna_edits"]["3"].pop("STR-006@2")
        result = patch.review_reply_preflight(self.draft, r, self.scope)
        self.assertIn("reference_id_not_declared", [d["code"] for d in result["diagnostics"]])

    def test_add_existing_key_still_rejected_by_original_engine(self):
        r = empty_reply()
        r["dna_edits"] = {"3": {"COL-006": {"op": "add", "old": None, "value": "synthetic"}}}
        with self.assertRaisesRegex(ValueError, "Add requires absent field and old=null"):
            patch.apply_correction(self.draft, r, self.scope)

    def test_false_and_zero_old_values_are_not_interchangeable(self):
        self.draft["objects"][2]["dna"]["COL-006"] = False
        scope = patch.review_scope(self.draft, None)
        r = empty_reply()
        r["dna_edits"] = {"3": {"COL-006": {"op": "set", "old": 0, "value": None}}}
        with self.assertRaisesRegex(ValueError, "Old-value precondition mismatch"):
            patch.apply_correction(self.draft, r, scope)

    def test_original_core_remove_still_rejected(self):
        r = empty_reply()
        r["dna_edits"] = {"3": {"COL-006": {"op": "remove", "old": None, "value": None}}}
        with self.assertRaisesRegex(ValueError, "Cannot remove required core"):
            patch.apply_correction(self.draft, r, self.scope)

    def test_remove_requires_explicit_json_null_value(self):
        r = synthetic_retarget()
        r["dna_edits"]["3"]["STR-006"]["value"] = False
        with self.assertRaisesRegex(ValueError, "Cannot remove required core or supply a remove value"):
            patch.apply_correction(self.draft, r, self.scope)

    def test_aliased_ids_rejected_not_normalized(self):
        for alias in ["03", "o3", "3.0", 3, "+3"]:
            r = empty_reply()
            r["dna_edits"] = {alias: {}}
            with self.subTest(alias=alias), self.assertRaisesRegex(ValueError, "Canonical decimal"):
                patch.compile_response(self.draft, r, self.scope)

    def test_duplicate_json_keys_rejected_before_any_compile(self):
        for raw in ['{"dna_edits":{"3":{"STR-006":{},"STR-006":{}}}}',
                    '{"dna_edits":{"3":{},"3":{}}}', '{"op":"set","op":"add"}']:
            with self.assertRaisesRegex(ValueError, "Duplicate key"):
                patch.loads(raw)

    def test_nonfinite_raw_json_rejected(self):
        for raw in ['{"value":NaN}', '{"value":Infinity}', '{"value":-Infinity}']:
            with self.assertRaisesRegex(ValueError, "Nonfinite"):
                patch.loads(raw)

    def test_stale_draft_grants_rejected(self):
        self.draft["objects"][2]["dna"]["STR-006"] = 0.8
        with self.assertRaisesRegex(ValueError, "snapshot mismatch"):
            patch.compile_response(self.draft, empty_reply(), self.scope)

    def test_unexplained_extra_scope_rejected(self):
        self.scope["allowed_pids"].append("STR-007")
        with self.assertRaisesRegex(ValueError, "Unexplained scope expansion"):
            patch.compile_response(self.draft, empty_reply(), self.scope)

    def test_json_schemas_valid_and_scoped(self):
        for schema in [patch.correction_schema(), patch.request_schema(self.draft, self.scope)]:
            jsonschema.Draft202012Validator.check_schema(schema)
            jsonschema.validate(synthetic_retarget(), schema)
        r = empty_reply()
        r["dna_edits"] = {"2": {"STR-006@1": {"op": "add", "old": None, "value": 0.1}}}
        with self.assertRaises(jsonschema.ValidationError):
            jsonschema.validate(r, patch.request_schema(self.draft, self.scope))

    def test_original_validator_and_strict_loader_are_exact_aliases(self):
        self.assertIs(patch.validate, patch.prior.validate)
        self.assertIs(patch.loads, patch.prior.loads)
        self.assertEqual(len(patch.P), 216)
        self.assertEqual(len(patch.ACTIVE), 148)

    def test_complete_checks_cannot_mask_remaining_host_failure(self):
        c = self.cases["R002"]
        r = empty_reply()
        final, _ = patch.apply_correction(c["draft"], r, c["scope"])
        v, _ = patch.validate_after(c["draft"], final, r, c["scope"], *c["meta"]["photo_original_pixels"])
        self.assertFalse(v["passed"])
        self.assertEqual(v["reference_preflight_after"]["remaining_count"], 3)
        self.assertFalse(v["visual_accuracy_established"])

    def test_prompt_has_one_wire_contract_and_all_original_definitions(self):
        prompt = patch.critic_prompt(self.draft, self.scope)
        self.assertNotIn("dna_edits每项", prompt)
        self.assertIn("同一对象/完整字段键仅一条提案", prompt)
        pack = patch.loads(prompt.split("\n同图初稿与原字典复核范围：\n")[1].split("\n输出结构：\n")[0])
        self.assertEqual({p[0] for p in pack["original_parameters"]}, set(self.scope["allowed_pids"]))
        self.assertEqual(pack["core_required_by_type"], patch.CORE)

    def test_standalone_absolute_import_supported(self):
        code = "import importlib.util,sys;s=importlib.util.spec_from_file_location('probe',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print(m.VERSION)"
        result = subprocess.run([sys.executable, "-B", "-X", "utf8", "-c", code, str(Path(patch.__file__).resolve())],
                                cwd=patch.PROJECT.parent, capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), patch.VERSION)


if __name__ == "__main__":
    unittest.main()
