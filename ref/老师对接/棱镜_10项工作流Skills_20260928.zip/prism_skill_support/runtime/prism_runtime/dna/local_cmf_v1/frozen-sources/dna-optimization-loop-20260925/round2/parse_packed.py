"""R7 packed transport (R8): same visual contract, lossless known-attribute tuples."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,json,re,sys
from PIL import Image
import parse_compact as base

ROOT=Path(__file__).resolve().parent;t=base.t
INSTRUCTIONS=base.INSTRUCTIONS.replace(
    'd是该对象其他known字段列表，{k:参数ID,r:参照ID或null(自身),v:合法值,s:o|e,n:必要补充或null}。',
    'd是该对象其他known字段列表，{k:参数ID,x:[r,v,s,n]}。x恰好4槽：r=参照对象ID或null(自身)，v=原字典合法值，s=o或e，n=必要补充或null。')+"""
表达压缩：proof只保留定位与判读需要的可见事实，通常一个短句。整张照片无实物/BOM等限制已在输入协议说明，不能在每个字段再次重复。x的第4槽没有特定限制时必须null；limits同因只列一次，理由用简短具体表达，不写长解释。
压缩只去重复，不省略对象、字段、可辨文字、明显局部或证据边界；不能为了短而把多种表面合并。
"""

def make_schema():
    schema=base.make_schema()
    atom={'anyOf':[{'$ref':'#/$defs/value'},{'type':'null'}]}
    for name,value in schema['$defs'].items():
        if not name.startswith('attr'):continue
        k=copy.deepcopy(value['properties']['k'])
        schema['$defs'][name]=base.c.obj({'k':k,'x':base.c.arr(atom,minItems=4,maxItems=4)})
    return schema

def unpack(raw):
    result=copy.deepcopy(raw)
    for o in result['objects']:
        entries=[]
        for a in o['d']:
            if set(a)!=set(['k','x']) or len(a['x'])!=4:raise ValueError('invalid packed attribute')
            r,v,s,n=a['x']
            if r is not None and not isinstance(r,str):raise ValueError('invalid reference type')
            if s not in ['o','e']:raise ValueError('invalid observation source')
            if n is not None and not isinstance(n,str):raise ValueError('invalid evidence note')
            entries.append({'k':a['k'],'r':r,'v':v,'s':s,'n':n})
        o['d']=entries
    return result

def validate(raw,w,h):
    canonical=unpack(raw);report,rows=base.validate(canonical,w,h)
    raw['objects']=canonical['objects'];raw['scope']=canonical['scope'];raw['visual_summary']=[]
    report['wire_codec']='lossless packed known attributes; all216 fields retained'
    return report,rows

def build_inputs(photo):
    with Image.open(photo) as im:w,h=im.size
    slots='\ncoverage家族固定槽位（从左至右，每一项都必须审阅）：\n'+json.dumps(base.FAMILIES,ensure_ascii=False,separators=(',',':'))
    prompt=INSTRUCTIONS+'\n148项视觉判断原参数：\n'+base.c.runtime_dictionary()+slots+f'\n本次图片文件尺寸：{w}×{h}px。'
    return prompt,make_schema(),w,h

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','run']);ap.add_argument('--trial',required=True)
    ap.add_argument('--case',choices=['radio','teapot','switch','chair','phoneboxes'],default='radio');ap.add_argument('--image',type=Path)
    ap.add_argument('--model',default='gpt-6-astra');ap.add_argument('--effort',default='low');args=ap.parse_args()
    if not re.fullmatch('[a-z0-9_-]+',args.trial):raise SystemExit('Bad trial name')
    photos={'radio':ROOT.parent.parent/'dna-timing-test-20260925/test-photo.jpg','teapot':ROOT.parent/'cases/teapot.jpg',
            'switch':ROOT.parent/'cases/switch.jpg','chair':ROOT/'cases/chair.jpg','phoneboxes':ROOT/'cases/phoneboxes.jpg'}
    photo=args.image.resolve() if args.image else photos[args.case];trial=ROOT/'trials'/args.trial;trial.mkdir(parents=True,exist_ok=True)
    if (trial/'events-timed.jsonl').exists():raise SystemExit('Refusing overwrite')
    prompt,schema,w,h=build_inputs(photo)
    def prepare():
        (trial/'prompt.txt').write_text(prompt,encoding='utf-8');t.dump(trial/'output-schema.json',schema)
        manifest={'prepared_at':datetime.now(timezone.utc).isoformat(),'algorithm':'direct-typed-packed-dna-r8','parameter_count':216,
          'vision_parameter_count':148,'contract_parameter_count':65,'geometry_parameter_count':3,
          'dictionary_version':base.c.D['schema_version'],'dictionary_sha256':t.sha(base.c.prev.m.DICT.read_bytes()),
          'photo_sha256':t.sha(photo.read_bytes()),'photo_original_pixels':[w,h],
          'prompt_sha256':t.sha(prompt.encode('utf-8')),'prompt_bytes':len(prompt.encode('utf-8')),
          'output_schema_sha256':t.sha((trial/'output-schema.json').read_bytes()),
          'case_id':'asset' if args.image else args.case,'previous_answer_included':False,'reference_checklist_included':False,
          'derived_fields':sorted(base.c.DERIVED),'core_fields':base.c.CORE,'image_preprocessing':'original image unchanged',
          'codec':'Same R7 object/core/coverage contract; other known attributes packed as [reference,value,source,note].'}
        t.dump(trial/'input-manifest.json',manifest);return prompt,manifest
    t.HERE=trial;t.PHOTO=photo;t.prepare=prepare;t.validate=lambda raw:validate(raw,w,h)
    sys.argv=[str(__file__),args.mode,'--model',args.model,'--effort',args.effort,'--http-only','--respect-system-proxy'];t.main()
if __name__=='__main__':main()
