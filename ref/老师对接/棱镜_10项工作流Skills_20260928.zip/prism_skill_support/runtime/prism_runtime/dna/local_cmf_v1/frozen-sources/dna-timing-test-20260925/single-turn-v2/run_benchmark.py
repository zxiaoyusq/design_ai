"""Fixed single-turn image extraction harness. No API key or auth file is read.

Uses the installed, officially supported Codex CLI with its saved ChatGPT login.
The process under test receives only the fixture, dictionary and fixed prompt.
No generated code is executed. Output and timing are captured by this harness.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import argparse, base64, hashlib, json, math, os, shutil, subprocess, sys, threading, time

HERE=Path(__file__).resolve().parent
PHOTO=HERE.parent/'test-photo.jpg'
DICTIONARY=HERE.parent.parent/'棱镜_DNA基础字典_AI版_v0.3.json'
def dump(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(data): return hashlib.sha256(data).hexdigest()
def obj(props):
    return {'type':'object','properties':props,'required':list(props),'additionalProperties':False}
def array(item,**kwargs): return {'type':'array','items':item,**kwargs}
S={'type':'string'}

def prepare():
    dictionary=json.loads(DICTIONARY.read_text(encoding='utf-8'))
    allowed_sets={}
    parameters=[]
    for p in dictionary['parameters']:
        key=','.join(p['applicable_object_types'])
        if key not in allowed_sets: allowed_sets[key]='A'+str(len(allowed_sets)+1)
        parameters.append([p['parameter_id'],p['name'],p['definition'],p['value_type'],
            p['value_domain'],p['value_schema'],p['unit'],p['applicability'],
            allowed_sets[key],p['reading_note']])
    compact={
       'schema_version':dictionary['schema_version'],
       'value_conventions':dictionary['value_conventions'],
       'families':dictionary['families'],
       'object_types':dictionary['object_types'],
       'applicable_object_type_sets':{v:k.split(',') for k,v in allowed_sets.items()},
       'parameter_columns':['id','name','definition','value_type','value_domain','value_schema','unit','applicability','allowed_type_set','reading_note'],
       'parameters':parameters}
    input_json=json.dumps(compact,ensure_ascii=False,separators=(',',':'))
    (HERE/'dictionary-runtime.json').write_text(input_json,encoding='utf-8')
    fixed="""任务：只分析随消息附带的一张静态产品照片，按下列DNA字典输出结构化JSON。你是本次受测模型，直接回答，不调用任何工具、不读文件、不写程序、不联网、不启动其他代理。不要查阅先前答案。

范围与证据：
1. 识别主体和主要可见部件，建立简短object_id及对象类型；不做216项与所有部件的笛卡儿展开，每个参数选择一个主要实例。
2. 所有216个parameter_id必须且只能出现在observations或unresolved_groups中一次。不能遗漏、杜撰ID或把未检查项自动填成不适用。
3. observations仅记录known值，value必须符合字典value_schema。数值没有测量或可靠图像估计就保留unknown；估计要写明图像坐标/比例口径。实际材料、工艺、真实触感、功能和用户喜好不能凭照片确认。
4. unknown表示适用但证据不足，not_applicable表示本次对象或研究范围确实不适用。相同原因的多个字段用一个unresolved_groups记录，不逐项重复理由。
5. 本轮仅静态外观研究，动态、实物触感和真实用户偏好研究未启动。相关开关可记录design_setting，其余按适用条件处理。未见发光不能等同于硬件没有光源。
6. 参考候选是开放词表，不是强制穷尽分类。材料视觉外观与真实材料组成分开。角色/关系参数必须绑定对象、参照系和区域。
7. evidence和reason只写短证据或限制，避免重复说明。可以在scope中写一次通用约束。不要输出思维过程或代码。
8. 照片尺寸为1600×1200px；这是文件元数据。除字典和这张照片外，无产品资料、BOM、视频或用户反馈。

输出：
scope: 一句研究范围与通用限制。
objects: 各对象的object_id、object_type_id、name、region（简短图像位置）。
observations: parameter_id、object_id、value、source_kind、evidence。
unresolved_groups: parameter_ids、object_id（检查范围）、value_status、reason。value隐含为null。
visual_summary: 最多5条简短视觉特点，不给真实用户偏好或未证实风格年代。

完整字典的精简运行表示（未删减216个参数；表格列名在parameter_columns中）：
"""
    prompt=fixed+input_json
    (HERE/'prompt.txt').write_text(prompt,encoding='utf-8')
    values={'anyOf':[
      {'type':'string'},{'type':'number'},array(S),
      obj({'reference_id':S,'coordinate_system':S,'coordinates':array({'type':'number'},minItems=2,maxItems=3)}),
      obj({'image_id':S,'region':S}),
      array(obj({'object_id':S,'channel':S}))]}
    schema=obj({
      'scope':S,
      'objects':array(obj({'object_id':S,'object_type_id':{'type':'string','enum':[o['object_type_id'] for o in dictionary['object_types']]},'name':S,'region':S})),
      'observations':array(obj({'parameter_id':S,'object_id':S,'value':values,
        'source_kind':{'type':'string','enum':dictionary['value_conventions']['source_kind_values']},'evidence':S})),
      'unresolved_groups':array(obj({'parameter_ids':array(S),'object_id':S,
        'value_status':{'type':'string','enum':['unknown','not_applicable']},'reason':S})),
      'visual_summary':array(S)})
    dump(HERE/'output-schema.json',schema)
    manifest={
      'prepared_at':datetime.now(timezone.utc).isoformat(),
      'dictionary_version':dictionary['schema_version'],'parameter_count':len(parameters),
      'original_dictionary_bytes':DICTIONARY.stat().st_size,
      'runtime_dictionary_bytes':len(input_json.encode('utf-8')),
      'prompt_bytes':len(prompt.encode('utf-8')),
      'dictionary_sha256':sha(DICTIONARY.read_bytes()),'prompt_sha256':sha(prompt.encode('utf-8')),
      'photo_sha256':sha(PHOTO.read_bytes()),'photo_original_pixels':[1600,1200],
      'output_schema_sha256':sha((HERE/'output-schema.json').read_bytes()),
      'previous_answer_included':False,
      'scope':'Same single photo, all216 parameters assessed on main objects; no cross-product of parameters and all objects.',
      'transport':'Codex CLI single turn using saved ChatGPT auth; not a bare API/server-compute benchmark',
      'image_preprocessing':'Original JPEG attached; CLI/model default image processing, not a guaranteed original-detail API setting.'
    }
    dump(HERE/'input-manifest.json',manifest)
    return prompt,manifest

def type_ok(value,typ):
    return {'string':isinstance(value,str),'integer':isinstance(value,int) and not isinstance(value,bool),
       'number':isinstance(value,(float,int)) and not isinstance(value,bool),
       'object':isinstance(value,dict),'array':isinstance(value,list),'null':value is None,'boolean':isinstance(value,bool)}.get(typ,False)
def check_value(v,s,path):
    types=s.get('type')
    if isinstance(types,list):
        if not any(type_ok(v,t) for t in types): return [path+': incorrect type']
    elif types and not type_ok(v,types): return [path+': incorrect type']
    errors=[]
    if isinstance(v,(int,float)) and not isinstance(v,bool):
        if not math.isfinite(v): errors.append(path+': nonfinite')
        for k,op in [('minimum',lambda a,b:a>=b),('maximum',lambda a,b:a<=b),('exclusiveMinimum',lambda a,b:a>b),('exclusiveMaximum',lambda a,b:a<b)]:
            if k in s and not op(v,s[k]): errors.append(path+': '+k)
    if isinstance(v,list):
        if 'minItems' in s and len(v)<s['minItems']: errors.append(path+': minItems')
        if 'maxItems' in s and len(v)>s['maxItems']: errors.append(path+': maxItems')
        if s.get('uniqueItems') and len({json.dumps(x,sort_keys=True) for x in v})!=len(v): errors.append(path+': duplicate items')
        if 'items' in s:
            for i,item in enumerate(v): errors+=check_value(item,s['items'],path+'['+str(i)+']')
    if isinstance(v,dict):
        for k in s.get('required',[]):
            if k not in v: errors.append(path+': missing '+k)
        for k,sv in s.get('properties',{}).items():
            if k in v: errors+=check_value(v[k],sv,path+'.'+k)
    return errors

def validate(result):
    d=json.loads(DICTIONARY.read_text(encoding='utf-8'))
    parameters={p['parameter_id']:p for p in d['parameters']}
    objects={o['object_id']:o for o in result['objects']}
    errors=[]
    if len(objects)!=len(result['objects']): errors.append('duplicate object IDs')
    records={}
    for o in result['observations']:
        pid=o['parameter_id']
        if pid not in parameters: errors.append('unknown ID: '+pid);continue
        if pid in records: errors.append('repeated ID: '+pid);continue
        records[pid]={**o,'value_status':'known'}
        if o['object_id'] not in objects: errors.append(pid+': missing object')
        elif objects[o['object_id']]['object_type_id'] not in parameters[pid]['applicable_object_types']: errors.append(pid+': incompatible object type')
        errors+=check_value(o['value'],parameters[pid]['value_schema'],pid)
    for group in result['unresolved_groups']:
        for pid in group['parameter_ids']:
            if pid not in parameters: errors.append('unknown ID: '+pid);continue
            if pid in records: errors.append('repeated ID: '+pid);continue
            records[pid]={'parameter_id':pid,'object_id':group['object_id'],'value':None,'value_status':group['value_status'],'source_kind':'image_observation','evidence':group['reason']}
    missing=sorted(set(parameters)-set(records))
    errors+=['missing ID: '+pid for pid in missing]
    rows=[{**records[p['parameter_id']],'parameter_name':p['name'],'unit':p['unit']} for p in d['parameters'] if p['parameter_id'] in records]
    return {'passed':not errors,'errors':errors,'covered_parameters':len(records),'statuses':dict(Counter(r['value_status'] for r in records.values()))},rows

def main():
    global HERE
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=['prepare','run'])
    parser.add_argument('--model',default='gpt-6-astra')
    parser.add_argument('--effort',default='low',choices=['low','medium','high','xhigh'])
    parser.add_argument('--timeout',type=int,default=600)
    parser.add_argument('--trial')
    parser.add_argument('--http-only',action='store_true')
    parser.add_argument('--respect-system-proxy',action='store_true')
    args=parser.parse_args()
    if args.trial:
        if not args.trial.replace('-','').replace('_','').isalnum(): raise SystemExit('Invalid trial label')
        HERE=HERE/args.trial
        HERE.mkdir(exist_ok=True)
    prompt,manifest=prepare()
    if args.mode=='prepare':
        print(json.dumps(manifest,ensure_ascii=True));return
    codex=shutil.which('codex')
    if not codex: raise SystemExit('Installed Codex CLI not found.')
    if (HERE/'events-timed.jsonl').exists(): raise SystemExit('A trial already exists here; refusing to overwrite it.')
    flags=['apps','plugins','memories','multi_agent','multi_agent_v2','shell_tool','unified_exec','browser_use','computer_use','image_generation','view_image','sleep_tool','goals','unbounded_connection_retries']
    cmd=[codex,'exec','--ignore-user-config','--ephemeral','--json','--skip-git-repo-check',
         '--sandbox','read-only','--model',args.model,
         '-c','model_reasoning_effort="'+args.effort+'"',
         '--image',str(PHOTO),'--output-schema',str(HERE/'output-schema.json'),
         '--output-last-message',str(HERE/'model-output.json'),'--color','never']
    if args.http_only:
        for config in ['model_provider="openai_http_benchmark"',
          'model_providers.openai_http_benchmark.name="OpenAI HTTP benchmark"',
          'model_providers.openai_http_benchmark.requires_openai_auth=true',
          'model_providers.openai_http_benchmark.wire_api="responses"',
          'model_providers.openai_http_benchmark.supports_websockets=false',
          'model_providers.openai_http_benchmark.request_max_retries=0',
          'model_providers.openai_http_benchmark.stream_max_retries=0']:
            cmd+=['-c',config]
    if args.respect_system_proxy: cmd+=['--enable','respect_system_proxy']
    for flag in flags: cmd+=['--disable',flag]
    cmd+=['-']
    run={'model_requested':args.model,'reasoning_effort':args.effort,'command_without_prompt':cmd,'input_manifest':manifest,
       'http_only_requested':args.http_only,'respect_existing_system_proxy':args.respect_system_proxy,
       'started_utc':datetime.now(timezone.utc).isoformat(),
       'timing_definition':'Monotonic parent timestamps of CLI start, turn.started, final message, and turn.completed. Includes client/network/provider queue and generation; no model-internal pure-compute time.'}
    dump(HERE/'run-config.json',run)
    started=time.perf_counter()
    process=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
       cwd=HERE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    stderr_chunks=[]
    def stderr_reader():
        for chunk in iter(lambda:process.stderr.read(4096),b''): stderr_chunks.append(chunk)
    thread=threading.Thread(target=stderr_reader,daemon=True);thread.start()
    timed_out=threading.Event()
    def timeout():
        if process.poll() is None:
            timed_out.set();process.terminate()
    watchdog=threading.Timer(args.timeout,timeout);watchdog.start()
    try:
        process.stdin.write(prompt.encode('utf-8'));process.stdin.close()
    except (BrokenPipeError,OSError) as error:
        watchdog.cancel()
        code=process.wait(timeout=15);thread.join(timeout=5)
        stderr=b''.join(stderr_chunks)
        (HERE/'client-stderr.log').write_bytes(stderr)
        dump(HERE/'benchmark-result.json',{**run,'exit_code':code,'stage':'client_initialization',
          'usage':None,'single_turn_wall_seconds':None,'error':str(error),
          'cli_process_wall_seconds':round(time.perf_counter()-started,3)})
        print(json.dumps({'exit_code':code,'stage':'client_initialization','stderr':stderr.decode('utf-8',errors='replace')[-5000:]},ensure_ascii=True),flush=True)
        raise SystemExit(1)
    usage=None;turn_start=None;turn_end=None;answer_at=None;tool_events=[];event_types=Counter();warnings=[];model_events=[]
    try:
        with (HERE/'events-timed.jsonl').open('w',encoding='utf-8') as f:
            for line in iter(process.stdout.readline,b''):
                elapsed=time.perf_counter()-started
                text=line.decode('utf-8',errors='replace').strip()
                if not text: continue
                try: event=json.loads(text)
                except json.JSONDecodeError:
                    warnings.append('Non-JSON stdout line captured.')
                    f.write(json.dumps({'elapsed_seconds':elapsed,'non_json_stdout':text},ensure_ascii=False)+'\n');f.flush();continue
                f.write(json.dumps({'elapsed_seconds':elapsed,'event':event},ensure_ascii=False)+'\n');f.flush()
                typ=event.get('type');event_types[typ]+=1
                if typ=='thread.started': print(json.dumps({'progress':'thread.started','elapsed_seconds':round(elapsed,3)}),flush=True)
                if typ=='turn.started':
                    turn_start=elapsed
                    print(json.dumps({'progress':'turn.started','elapsed_seconds':round(elapsed,3)}),flush=True)
                if typ=='turn.completed':
                    turn_end=elapsed;usage=event.get('usage')
                    print(json.dumps({'progress':'turn.completed','elapsed_seconds':round(elapsed,3),'usage':usage}),flush=True)
                if typ in ['item.started','item.completed']:
                    item=event.get('item',{});item_type=item.get('type')
                    if item_type=='agent_message' and typ=='item.completed':
                        answer_at=elapsed;model_events.append(item)
                    elif item_type=='error':
                        warnings.append({'kind':'client_notice','message':item.get('message','')})
                    elif item_type not in ['agent_message','reasoning']:
                        tool_events.append({'type':item_type,'event':typ})
                if typ in ['error','turn.failed']:
                    warnings.append(event)
                    print(json.dumps({'progress':typ,'elapsed_seconds':round(elapsed,3),'detail':event},ensure_ascii=True),flush=True)
        code=process.wait()
    finally:
        watchdog.cancel();thread.join(timeout=5)
        (HERE/'client-stderr.log').write_bytes(b''.join(stderr_chunks))
    total=time.perf_counter()-started
    result_path=HERE/'model-output.json'
    validation=None
    if result_path.exists():
        try:
            result=json.loads(result_path.read_text(encoding='utf-8'))
            validation,rows=validate(result)
            dump(HERE/'normalized-analysis.json',{'scope':result.get('scope'),'objects':result.get('objects'),'assessments':rows,'visual_summary':result.get('visual_summary')})
        except Exception as error:
            validation={'passed':False,'errors':[type(error).__name__+': '+str(error)]}
    report={**run,'finished_utc':datetime.now(timezone.utc).isoformat(),'exit_code':code,'timed_out':timed_out.is_set(),
      'cli_process_wall_seconds':round(total,3),'turn_started_after_seconds':round(turn_start,3) if turn_start is not None else None,
      'single_turn_wall_seconds':round(turn_end-turn_start,3) if turn_end is not None and turn_start is not None else None,
      'answer_after_turn_start_seconds':round(answer_at-turn_start,3) if answer_at is not None and turn_start is not None else None,
      'usage':usage,'event_types':dict(event_types),'tool_events':tool_events,'warnings':warnings,'validation':validation,
      'single_turn_no_tools_verified':event_types['turn.started']==1 and event_types['turn.completed']==1 and len(tool_events)==0,
      'cost_money':None,'cost_note':'Uses existing ChatGPT/Codex account; token usage is not an API dollar bill.'}
    dump(HERE/'benchmark-result.json',report)
    print(json.dumps({k:report[k] for k in ['exit_code','timed_out','cli_process_wall_seconds','single_turn_wall_seconds','usage','single_turn_no_tools_verified','validation']},ensure_ascii=True),flush=True)
    if code or not report['single_turn_no_tools_verified'] or not validation or not validation.get('passed'): raise SystemExit(1)

if __name__=='__main__': main()
