import argparse
import json
from . import pipeline


def main():
    p = argparse.ArgumentParser(description="Offline prepare/accept only; never invokes a model")
    sub = p.add_subparsers(dest="mode", required=True)
    prep = sub.add_parser("prepare")
    for name in ["image", "image-id", "source-kind", "source-provenance-ref", "output-dir"]:
        prep.add_argument("--" + name, required=True)
    for name in ["accept", "accept-review"]:
        q = sub.add_parser(name)
        for key in ["prepared-dir", "raw-output", "run-record"]:
            q.add_argument("--" + key, required=True)
    q = sub.add_parser("verify")
    q.add_argument("--path", required=True)
    args = vars(p.parse_args())
    mode = args.pop("mode")
    fn = {"prepare": pipeline.prepare, "accept": pipeline.accept, "accept-review": pipeline.accept_review,
          "verify": pipeline.verify_projection}[mode]
    print(json.dumps(fn(**args), ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
