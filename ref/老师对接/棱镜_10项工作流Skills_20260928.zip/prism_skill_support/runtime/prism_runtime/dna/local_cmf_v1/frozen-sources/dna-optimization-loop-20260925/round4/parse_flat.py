"""R17: reversible flat key/value wire; typed singleton-set shorthand."""
from pathlib import Path
import copy
from PIL import Image
import parse_header as base

ROOT=Path(__file__).resolve().parent
INSTRUCTIONS=base.INSTRUCTIONS+"""
最终传输格式覆盖上文d三元素行写法：d是扁平的键、值交替序列：[k1,v1,k2,v2,...]，不再给每条加一层方括号。
k为字段code整数时，参照默认本对象；有其他参照时k=[字段code,r]。例如本对象code20取2、以对象1为参照的code160取3，写d:[20,2,[160,1],3]。保留原记录顺序和全部判断，程序恢复原三元组，不新增语义推断。
原字典类别集合字段：多个值仍写数组；只有一个类别时允许直接写一个编号或短文字，程序按字段类型恢复单元素数组。这是原集合的单值简写，不能把不同值挤成一个含糊字符串。d键、值交替的个数必须为偶数。g、c、f、q沿用前述格式。
"""

def pack(raw):
    out=copy.deepcopy(raw)
    for o in out['o']:
        flat=[]
        for code,ref,value in o['d']:flat.extend([code if ref==-1 else [code,ref],value])
        o['d']=flat
    return out

def unpack(raw):
    out=copy.deepcopy(raw)
    for o in out['o']:
        flat=o['d'];rows=[]
        if len(flat)%2:raise ValueError('Flat known-value stream must have an even length')
        for i in range(0,len(flat),2):
            key,value=flat[i:i+2]
            if isinstance(key,int) and not isinstance(key,bool):code,ref=key,-1
            elif isinstance(key,list) and len(key)==2 and all(isinstance(x,int) and not isinstance(x,bool) for x in key):code,ref=key
            else:raise ValueError('Bad field/reference key')
            rows.append([code,ref,value])
        o['d']=rows
    return out

def make_schema():
    schema=base.make_schema()
    schema['properties']['o']['items']['properties']['d']=base.t.array({'$ref':'#/$defs/v'})
    return schema

def build_inputs(photo):
    with Image.open(photo) as im:w,h=im.size
    prompt=INSTRUCTIONS+'\n原字典完整视觉部分及原ID/编码对应：\n'+base.base.runtime_dictionary()+'\n定位以完整可见图像边界归一化0..1000，不使用像素尺寸换算；分辨率由程序记录。'
    return prompt,make_schema(),w,h

def _validate(raw,w,h,validator):
    expanded=unpack(raw);original_decode=base.base.value_decode;singletons=[]
    def decode(pid,value):
        schema=base.base.P[pid]['value_schema']
        if schema.get('type')=='array' and schema.get('items',{}).get('type')=='string' and isinstance(value,(str,int)) and not isinstance(value,bool):
            singletons.append({'parameter_id':pid,'wire_value':value});value=[value]
        return original_decode(pid,value)
    base.base.value_decode=decode
    try:report,rows=validator(expanded,w,h)
    finally:base.base.value_decode=original_decode
    raw['objects']=expanded['objects'];raw['scope']=expanded['scope']+' R17 flat key/value stream restored; typed singleton-set shorthand allowed.';raw['visual_summary']=[]
    report['flat_value_codec']='alternating key/value; integer key=self; [field,reference] key=explicit reference'
    report['singleton_set_expansions']=singletons
    return report,rows

def validate(raw,w,h):return _validate(raw,w,h,base.validate)

def main():
    original_schema=base.make_schema;original_validate=base.validate;original_dump=base.t.dump;original_instructions=base.INSTRUCTIONS
    schema=make_schema();base.make_schema=lambda:schema
    base.validate=lambda raw,w,h:_validate(raw,w,h,original_validate)
    base.INSTRUCTIONS=INSTRUCTIONS
    def dump(path,data):
        if Path(path).name=='input-manifest.json':
            data['algorithm']='packed-attributed-dna-r17'
            data['known_value_encoding']='flat key/value stream; typed singleton-set shorthand'
        return original_dump(path,data)
    base.t.dump=dump
    try:base.main()
    finally:
        base.make_schema=original_schema;base.validate=original_validate;base.t.dump=original_dump;base.INSTRUCTIONS=original_instructions

if __name__=='__main__':main()
