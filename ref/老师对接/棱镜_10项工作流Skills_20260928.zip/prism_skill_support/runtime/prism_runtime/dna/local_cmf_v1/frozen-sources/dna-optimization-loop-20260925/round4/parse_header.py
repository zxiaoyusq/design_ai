"""R15: lossless packing of R14 object headers; same dictionary and visual contract."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,json,re,sys
from PIL import Image
import parse_attributed as base

ROOT=Path(__file__).resolve().parent;t=base.t
ORIGINS=['none','surface','image','uncertain']
INSTRUCTIONS=base.INSTRUCTIONS+"""
本版只把对象头字段无损合并，以下编码覆盖上文对象头写法：
每个o元素只含g,c,d。g固定9个整数，依次为[t,p,x0,y0,x1,y1,ax,ay,z]。
t和p含义不变；bbox与anchor仍0..1000归一化。原来允许a=[]的整体/语境对象，用ax=ay=-1；可见表面必须有实际锚点。
z来源编号固定：0=none，1=surface，2=image，3=uncertain。只简化来源标签的编码，不取消判断。
c仍按对象t对应的核心顺序；d仍[字段code,参照r,值]。不得在o另写t/p/b/a/z键名，不要生成名称或解释。程序恢复全部头字段、原字典值与原图定位。
"""

def make_schema():
    schema=base.make_schema()
    value={'$ref':'#/$defs/v'}
    schema['properties']['o']=t.array(t.obj({
      'g':t.array({'type':'integer','minimum':-1,'maximum':1000},minItems=9,maxItems=9),
      'c':t.array(value,maxItems=max(len(base.base.core_ids('O'+str(i).zfill(2))) for i in range(1,20))),
      'd':t.array(t.array(value,minItems=3,maxItems=3))}),minItems=1)
    return schema

def pack(raw):
    out=copy.deepcopy(raw);nodes=[]
    for o in out['o']:
        a=o['a'] or [-1,-1]
        nodes.append({'g':[o['t'],o['p'],*o['b'],*a,ORIGINS.index(o['z'])],'c':o['c'],'d':o['d']})
    out['o']=nodes;return out

def unpack(raw):
    out=copy.deepcopy(raw);nodes=[]
    for o in out['o']:
        if len(o['g'])!=9 or not all(isinstance(x,int) and not isinstance(x,bool) for x in o['g']):raise ValueError('Bad object header')
        typ,parent,x0,y0,x1,y1,ax,ay,z=o['g']
        if not 1<=typ<=19 or parent<0 or not 0<=z<len(ORIGINS):raise ValueError('Bad type/parent/origin')
        if (ax==-1)!=(ay==-1):raise ValueError('Partial missing anchor')
        nodes.append({'t':typ,'p':parent,'b':[x0,y0,x1,y1],'a':[] if ax==ay==-1 else [ax,ay],
                      'z':ORIGINS[z],'c':o['c'],'d':o['d']})
    out['o']=nodes;return out

def validate(raw,w,h):
    unpacked=unpack(raw);report,rows=base.validate(unpacked,w,h)
    raw['objects']=unpacked['objects'];raw['scope']=unpacked['scope']+' R15 lossless packed object header.';raw['visual_summary']=[]
    report['object_header_codec']='[type,parent,bbox4,anchor2,texture-origin]; reversible to R14'
    return report,rows

def build_inputs(photo):
    with Image.open(photo) as im:w,h=im.size
    prompt=INSTRUCTIONS+'\n原字典完整视觉部分及原ID/编码对应：\n'+base.runtime_dictionary()+'\n定位以完整可见图像边界归一化0..1000，不使用像素尺寸换算；分辨率由程序记录。'
    return prompt,make_schema(),w,h

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','run']);ap.add_argument('--trial',required=True)
    ap.add_argument('--case',default='phoneboxes');ap.add_argument('--image',type=Path);ap.add_argument('--model',default='gpt-6-astra')
    ap.add_argument('--effort',default='low');ap.add_argument('--client',choices=['standard','minimal'],default='minimal');args=ap.parse_args()
    if not re.fullmatch('[a-z0-9_-]+',args.trial):raise SystemExit('Bad trial')
    photos={'radio':ROOT.parent.parent/'dna-timing-test-20260925/test-photo.jpg','teapot':ROOT.parent/'cases/teapot.jpg','switch':ROOT.parent/'cases/switch.jpg',
      'chair':ROOT.parent/'round2/cases/chair.jpg','phoneboxes':ROOT.parent/'round2/cases/phoneboxes.jpg','facade':ROOT.parent/'round3/cases/facade.jpg','camera':ROOT/'cases/camera.jpg'}
    photo=args.image.resolve() if args.image else photos[args.case];trial=ROOT/'trials'/args.trial;trial.mkdir(parents=True,exist_ok=True)
    if (trial/'events-timed.jsonl').exists():raise SystemExit('Trial exists')
    prompt,schema,w,h=build_inputs(photo)
    def prepare():
        (trial/'prompt.txt').write_text(prompt,encoding='utf-8');t.dump(trial/'output-schema.json',schema)
        m={'prepared_at':datetime.now(timezone.utc).isoformat(),'algorithm':'packed-attributed-dna-r15','parameter_count':216,
          'vision_parameter_count':148,'contract_parameter_count':65,'calculated_parameter_count':3,
          'dictionary_sha256':t.sha(base.base.old.base.c.prev.m.DICT.read_bytes()),'photo_sha256':t.sha(photo.read_bytes()),'photo_original_pixels':[w,h],
          'prompt_sha256':t.sha(prompt.encode('utf-8')),'prompt_bytes':len(prompt.encode('utf-8')),'output_schema_sha256':t.sha((trial/'output-schema.json').read_bytes()),
          'case_id':'asset' if args.image else args.case,'client_profile':args.client,'previous_answer_included':False,'reference_checklist_included':False,
          'image_preprocessing':'original bytes unchanged','evidence_policy':'original ROI/anchor plus model-declared texture origin; model values conservatively image_estimate',
          'header_encoding':'lossless R14 object data in9 integer slots'}
        t.dump(trial/'input-manifest.json',m);return prompt,m
    t.HERE=trial;t.PHOTO=photo;t.prepare=prepare;t.validate=lambda raw:validate(raw,w,h)
    original=t.subprocess.Popen
    if args.client=='minimal':
        def popen(command,*pos,**kwargs):
            if '--output-schema' in command:
                command[-1:-1]=['--strict-config','-c','model_instructions_file="'+(ROOT/'vision-only.txt').resolve().as_posix()+'"']
                cfg=trial/'run-config.json'
                if cfg.exists():
                    d=json.loads(cfg.read_text(encoding='utf-8'));d['command_without_prompt']=command;d['one_off_instructions_file']=str(ROOT/'vision-only.txt');t.dump(cfg,d)
            return original(command,*pos,**kwargs)
        t.subprocess.Popen=popen
    sys.argv=[str(__file__),args.mode,'--model',args.model,'--effort',args.effort,'--http-only','--respect-system-proxy']
    try:t.main()
    finally:t.subprocess.Popen=original
if __name__=='__main__':main()
