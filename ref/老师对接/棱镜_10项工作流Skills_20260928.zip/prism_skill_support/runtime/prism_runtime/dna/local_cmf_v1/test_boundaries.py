"""Offline contract fixtures only. No image truth or inference is synthesized."""
import copy
from pathlib import Path
import tempfile
import unittest

from . import audit, common as c, pipeline


def fixture():
    objects = [{"object_id": "o0", "object_type_id": "O19", "parent": None, "name": "frame",
        "region": [0, 0, 1, 1], "evidence_anchor": None, "texture_evidence_origin": None},
        {"object_id": "o1", "object_type_id": "O01", "parent": "o0", "name": "whole",
        "region": [0, 0, 1, 1], "evidence_anchor": None, "texture_evidence_origin": "none"},
        {"object_id": "o2", "object_type_id": "O02", "parent": "o1", "name": "surface",
        "region": [0.1, 0.1, 0.9, 0.9], "evidence_anchor": [0.5, 0.5], "texture_evidence_origin": "surface"}]
    rows = [{"parameter_id": pid, "parameter_name": p["name"], "object_id": "o1", "reference_object_id": "o1",
        "value_status": "unknown", "value": None, "resolved_by": "vision_model", "unit": p["unit"],
        "evidence": "SYNTHETIC explicit fallback"} for pid, p in audit.PARAMETERS.items()]
    bindings = []
    for pid, value in [("COL-006", "蓝色"), ("OPT-002", "哑光"), ("TEX-002", "网格"), ("TEX-003", 0.1)]:
        r = next(x for x in rows if x["parameter_id"] == pid)
        r.update(object_id="o2", reference_object_id="o2", value_status="known", value=value,
                 evidence="SYNTHETIC visible assertion fixture, not image evidence")
        bindings.append([pid, "o2", "o2"])
    return {"objects": objects, "assessments": rows}, bindings


def proposal_for(a):
    return {"image_id": "synthetic", "image_sha256": "a" * 64, "proposal_sha256": "b" * 64,
        "observations": [u for u in a["units"] if u["observation_id"] in a["candidates"]]}


def supported(p):
    return {"image_id": p["image_id"], "image_sha256": p["image_sha256"], "proposal_sha256": p["proposal_sha256"],
        "checks": {r["observation_id"]: {"verdict": "supported", "evidence": "SYNTHETIC protocol fixture; no model or image judgment",
            "carrier_ok": True, "reference_ok": True, "origin_ok": True} for r in p["observations"]}, "issues": []}


class UnitBoundaries(unittest.TestCase):
    def setUp(self):
        self.n, self.bindings = fixture()

    def run_audit(self):
        return audit.audit_units(self.n, self.bindings, "synthetic", {"passed": True, "errors": []})

    def row(self, pid):
        return next(r for r in self.n["assessments"] if r["parameter_id"] == pid)

    def unit(self, a, pid):
        return next(u for u in a["units"] if u["parameter_id"] == pid)

    def test_legitimate_unknown_na_preserved_without_blocking_known(self):
        self.row("EMI-001")["value_status"] = "not_applicable"
        self.row("COL-010")["value_status"] = "not_applicable"
        before = c.canonical(self.n)
        a = self.run_audit()
        self.assertEqual(len(a["candidates"]), 4)
        self.assertEqual(self.unit(a, "COL-010")["value_status"], "not_applicable")
        self.assertEqual(c.canonical(self.n), before)
        self.assertFalse(a["useful"])  # Program acceptance never replaces review.

    def test_schema_invalid_known_blocked_but_independent_colour_survives(self):
        self.row("TEX-003")["value"] = {"ratio": 0.1}
        a = self.run_audit()
        self.assertFalse(self.unit(a, "TEX-003")["program_eligible"])
        self.assertTrue(self.unit(a, "COL-006")["program_eligible"])

    def test_wrong_carrier_type_cannot_be_supported(self):
        self.n["objects"][2]["object_type_id"] = "O12"
        a = self.run_audit()
        self.assertFalse(self.unit(a, "OPT-002")["program_eligible"])

    def test_unknown_does_not_legalize_wrong_explicit_binding(self):
        self.n["objects"][2]["object_type_id"] = "O12"
        self.row("OPT-002").update(value_status="unknown", value=None)
        self.assertIn("Field not applicable to declared carrier type", self.unit(self.run_audit(), "OPT-002")["program_errors"])

    def test_broken_parent_blocks_image(self):
        self.n["objects"][2]["parent"] = "missing"
        a = self.run_audit()
        self.assertTrue(a["global_errors"])
        self.assertEqual(a["candidates"], [])

    def test_parent_cycle_blocks_image(self):
        self.n["objects"][1]["parent"] = "o2"
        self.assertFalse(self.run_audit()["ready_for_review"])

    def test_bad_region_blocks_image(self):
        self.n["objects"][2]["region"] = [0.9, 0.1, 0.1, 0.9]
        self.assertFalse(self.run_audit()["ready_for_review"])

    def test_outside_anchor_blocks_dependent_carrier(self):
        self.n["objects"][2]["evidence_anchor"] = [0.99, 0.99]
        a = self.run_audit()
        self.assertFalse(self.unit(a, "COL-006")["program_eligible"])

    def test_missing_reference_blocks_observation(self):
        self.row("TEX-003")["reference_object_id"] = "o900"
        self.bindings[-1][-1] = "o900"
        self.assertFalse(self.unit(self.run_audit(), "TEX-003")["program_eligible"])

    def test_ambiguous_duplicate_is_not_deduplicated(self):
        self.n["assessments"].append(copy.deepcopy(self.row("COL-006")))
        a = self.run_audit()
        relevant = [u for u in a["units"] if u["parameter_id"] == "COL-006"]
        self.assertEqual(len(relevant), 2)
        self.assertTrue(all(not u["program_eligible"] for u in relevant))

    def test_wire_duplicate_identity_cannot_be_hidden_by_normalizer(self):
        self.bindings.append(["COL-006", "o2", "o2"])
        self.assertFalse(self.unit(self.run_audit(), "COL-006")["program_eligible"])

    def test_uncertain_texture_origin_does_not_erase_colour(self):
        self.n["objects"][2]["texture_evidence_origin"] = "uncertain"
        a = self.run_audit()
        self.assertFalse(self.unit(a, "TEX-002")["program_eligible"])
        self.assertTrue(self.unit(a, "COL-006")["program_eligible"])

    def test_ratio_requires_valid_counting_unit(self):
        self.row("TEX-002").update(value_status="unknown", value=None)
        a = self.run_audit()
        self.assertFalse(self.unit(a, "TEX-003")["program_eligible"])

    def test_review_uncertain_unit_removes_supported_dependent_ratio(self):
        a = self.run_audit(); p = proposal_for(a); r = supported(p)
        oid = self.unit(a, "TEX-002")["observation_id"]
        r["checks"][oid]["verdict"] = "uncertain"
        result = audit.resolve_review(a, p, r)
        self.assertNotIn(self.unit(a, "TEX-003")["observation_id"], result["accepted_observation_ids"])
        self.assertTrue(result["useful_local_cmf"])

    def test_all_unknown_is_not_useful_success(self):
        for r in self.n["assessments"]:
            r.update(value_status="unknown", value=None)
        a = self.run_audit()
        self.assertFalse(a["ready_for_review"])
        self.assertFalse(a["useful"])

    def test_missing_field_is_not_padded_unknown(self):
        self.n["assessments"].remove(self.row("COL-010"))
        a = self.run_audit()
        self.assertIn("COL-010", a["not_checked_parameter_ids"])
        self.assertFalse(a["ready_for_review"])

    def test_review_cannot_change_identity_or_leave_an_item_unchecked(self):
        a = self.run_audit(); p = proposal_for(a)
        for key, value in [("image_id", "other"), ("image_sha256", "c" * 64), ("proposal_sha256", "d" * 64)]:
            r = supported(p); r[key] = value
            with self.assertRaises(Exception): audit.resolve_review(a, p, r)
        r = supported(p); r["checks"].pop(next(iter(r["checks"])))
        with self.assertRaises(Exception): audit.resolve_review(a, p, r)

    def test_supported_boolean_does_not_override_bad_carrier(self):
        a = self.run_audit(); p = proposal_for(a); r = supported(p)
        for check in r["checks"].values(): check["carrier_ok"] = False
        self.assertFalse(audit.resolve_review(a, p, r)["useful_local_cmf"])

    def test_global_issue_blocks_all_local_support(self):
        a = self.run_audit(); p = proposal_for(a); r = supported(p)
        r["issues"] = [{"scope": "image", "observation_ids": [], "evidence": "SYNTHETIC wrong image identity"}]
        self.assertFalse(audit.resolve_review(a, p, r)["useful_local_cmf"])

    def test_local_issue_only_blocks_named_item_and_dependencies(self):
        a = self.run_audit(); p = proposal_for(a); r = supported(p)
        oid = self.unit(a, "COL-006")["observation_id"]
        r["issues"] = [{"scope": "observations", "observation_ids": [oid], "evidence": "SYNTHETIC colour ambiguity"}]
        result = audit.resolve_review(a, p, r)
        self.assertNotIn(oid, result["accepted_observation_ids"])
        self.assertTrue(result["useful_local_cmf"])

    def test_strict_raw_json_rejects_duplicate_and_nonfinite(self):
        for text in ['{"x":1,"x":2}', '{"x":NaN}', '{"x":1e999}']:
            with self.assertRaises(ValueError): c.loads(text)


class PersistenceBoundaries(unittest.TestCase):
    def test_synthetic_roundtrip_and_tamper_protection(self):
        # This is a schema/provenance fixture, not a visual review or new model
        # result. All output is explicitly source_kind=synthetic.
        scratch = c.HERE / ".test-scratch"
        scratch.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as td:
            root = Path(td)
            photo = c.OPT / "round4/cases/camera.jpg"
            source = c.write_new(root / "manifest.json", {"records": [{"image_id": "synthetic-camera",
                "sha256": c.file_hash(photo), "source_kind": "synthetic", "basis": "Protocol replay fixture only"}]})
            folder = root / "prepared"
            pipeline.prepare(photo, "synthetic-camera", "synthetic", source, folder)
            raw = c.OPT / "round4/trials/r17-camera/model-output.json"
            def receipt(stage, output, prompt, schema):
                info = {"stage": stage, "model": "gpt-6-astra", "service_tier": "default",
                    "image_sha256": c.file_hash(photo), "prompt_sha256": c.file_hash(prompt),
                    "schema_sha256": c.file_hash(schema), "schema_ref": str(schema),
                    "raw_output_sha256": c.file_hash(output), "call_id": "synthetic-" + stage,
                    "execution_kind": "synthetic_fixture", "source_ref": str(source)}
                return c.write_new(root / (stage + "-run.json"), info)
            first = receipt("primary", raw, folder / "primary.prompt.txt", folder / "primary.schema.json")
            original_record = c.read(first)
            for forbidden in ["fast", "priority"]:
                wrong = dict(original_record, service_tier=forbidden)
                path = c.write_new(root / (forbidden + ".json"), wrong)
                with self.assertRaises(ContractError):
                    pipeline._run_record(path, raw, c.read(folder / "preparation.json"), "primary", folder / "primary.prompt.txt", folder / "primary.schema.json")
            initial = pipeline.accept(folder, raw, first)
            self.assertTrue(initial["ready_for_review"])
            p = c.read(folder / "review.proposal.json")
            response = c.write_new(root / "synthetic-review.json", supported(p))
            second = receipt("review", response, folder / "review.prompt.txt", folder / "review.schema.json")
            final = pipeline.accept_review(folder, response, second)
            self.assertTrue(final["useful_local_cmf"])
            path = Path(final["projection_ref"])
            checked = pipeline.verify_projection(path)
            self.assertTrue(checked["passed"])
            document = c.read(path)
            self.assertEqual(document["source_kind"], "synthetic")
            self.assertTrue(document["cmf_admission"]["requires_scope_aware_consumer"])
            self.assertFalse(document["cmf_admission"]["whole_image_negative_conditions_qualified"])
            self.assertEqual(document["objects"], c.read(folder / "normalized.json")["objects"])
            original_bytes = path.read_bytes()
            document["observations"][0]["value"] = "FAKE TAMPER"
            path.write_text(c.canonical(document), encoding="utf-8")
            with self.assertRaises(ContractError): pipeline.verify_projection(path)
            path.write_bytes(original_bytes)
            npath = folder / "normalized.json"
            n = c.read(npath); n["objects"][1]["region"] = [0, 0, 1, 1]
            npath.write_text(c.canonical(n), encoding="utf-8")
            with self.assertRaises(ContractError): pipeline.verify_projection(path)


ContractError = c.ContractError

if __name__ == "__main__":
    unittest.main()
