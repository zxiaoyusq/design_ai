"""Isolate legacy R17 imports/temporary codec hooks. Never invoke its runner."""
from pathlib import Path
import copy
import hashlib
import json
import sys
import types

sys.dont_write_bytecode = True
PROJECT = Path(__file__).resolve().parents[3]
BASE = PROJECT / "outputs/01a0c2a0-b850-7fd1-a032-78e192743557"
OPT = BASE / "dna-optimization-loop-20260925"
sys.path.insert(0, str(OPT / "round4"))
import parse_flat as producer


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sources():
    pending, seen, found = [producer], set(), {}
    while pending:
        m = pending.pop()
        if id(m) in seen:
            continue
        seen.add(id(m))
        path = getattr(m, "__file__", None)
        if not path or not Path(path).resolve().is_relative_to(BASE):
            continue
        path = Path(path).resolve()
        found[str(path)] = digest(path)
        pending.extend(v for v in vars(m).values() if isinstance(v, types.ModuleType))
    dictionary = BASE / "棱镜_DNA基础字典_AI版_v0.3.json"
    found[str(dictionary)] = digest(dictionary)
    return [{"path": p, "sha256": v} for p, v in sorted(found.items())]


def declared_bindings(raw):
    """Read explicit instance identity before any legacy decoding mutates it."""
    expanded = producer.base.unpack(producer.unpack(copy.deepcopy(raw)))
    r14 = producer.base.base
    bindings = []
    for index, node in enumerate(expanded["o"], 1):
        oid = "o" + str(index)
        for pid in r14.base.core_ids("O" + str(node["t"]).zfill(2)):
            bindings.append([pid, oid, oid])
        for code, ref, value in node["d"]:
            bindings.append([r14.IDS[code], oid, oid if ref == -1 else "o" + str(ref)])
    for code, value in expanded["f"]:
        bindings.append([r14.IDS[code], "o0", "o0"])
    return bindings


def main():
    payload = json.loads(sys.stdin.read())
    action = payload["action"]
    result = {"producer": "R17", "sources": sources()}
    if action == "prepare":
        prompt, schema, width, height = producer.build_inputs(Path(payload["image"]))
        result.update(prompt=prompt, schema=schema, pixels=[width, height])
    elif action == "decode":
        raw = copy.deepcopy(payload["raw"])
        try:
            bindings = declared_bindings(raw)
            report, rows = producer.validate(raw, *payload["pixels"])
            result.update(report=report, normalized={"scope": raw["scope"], "objects": raw["objects"],
                "assessments": rows, "visual_summary": []}, declared_bindings=bindings, decode_error=None)
        except Exception as exc:
            result.update(report=None, normalized=None, declared_bindings=None,
                          decode_error=type(exc).__name__ + ": " + str(exc))
    else:
        raise ValueError("Only local prepare/decode actions exist")
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
