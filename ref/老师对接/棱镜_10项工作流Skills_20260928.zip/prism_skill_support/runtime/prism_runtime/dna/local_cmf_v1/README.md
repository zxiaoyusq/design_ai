# R17 local CMF v1

本模块执行本地准备、确定性验收和投影，不调用模型、API或Codex CLI。推理由协调任务统一使用标准Astra；Fast和priority在运行记录及实际请求中都必须关闭。旧QWEN-D01-REVIEW-002三轮保持停止。

原R17提示与原216字典保持不变。历史`round4/final-audit.json`记录5次结构通过、4张不同图，45.442–54.138秒；不是独立视觉准确率。生产者11个实际导入文件/字典按哈希冻结，`frozen-sources/`保留字节副本。执行前校验原文件，使用单独的本地Python进程隔离旧代码的可变导入与编码函数；不会执行旧runner的main、计时器或模型请求。

## 接口

在项目根用附带Python运行，或调用`pipeline`同名函数：

```text
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1 prepare --image PATH --image-id R002 --source-kind calibration --source-provenance-ref MANIFEST --output-dir NEW_DIR
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1 accept --prepared-dir NEW_DIR --raw-output MODEL_TEXT --run-record PRIMARY_RECORD
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1 accept-review --prepared-dir NEW_DIR --raw-output REVIEW_TEXT --run-record REVIEW_RECORD
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1 verify --path NEW_DIR/cmf.image-dna.json
```

`prepare`产出原R17 `primary.prompt.txt`、`primary.schema.json`与身份清单。目录必须新建/为空，不覆盖已存在结果。来源manifest的records或images中必须有对应image_id、sha256，已记载的source_kind不能重标。

`accept`先核实际模型记录、严格JSON、原schema、原R17字典/载体/覆盖合同，再保留完整normalized.json、原验收和全部CMF状态。存在可复核的已知项才生成`review.prompt.txt`、`review.schema.json`和`review.proposal.json`。来源不明纹理、错误值/载体/引用、歧义重复等不能成为候选；不能隔离的原校验或整体载体错误阻断整图。

复核是看同一原图的独立模型调用，不读取前次对话。回复只有image_id、image_sha256、proposal_sha256、checks、issues五键；checks以不可变observation_id为键，每项verdict、evidence、carrier_ok、reference_ok、origin_ok。verdict只能supported/contradicted/uncertain。代码不修值、不清问题、不默认成功。单条supported仍须载体、参照、来源三项核查全部通过，并满足程序依赖；比例项不能脱离被否定的计数单元。

运行记录最少包含：stage(primary/review)、model(gpt-6-astra)、service_tier(default/standard)、image_sha256、prompt_sha256、schema_sha256、raw_output_sha256、call_id、source_ref及request_ref。source_ref指原始CLI receipt，request_ref指实际request.json。真实请求必须显式`--disable fast_mode`、使用独立`--ephemeral`上下文；receipt须退出0、无超时、schema_valid=true且无工具事件。

若CLI输出schema文件缩进不同，提供schema_ref。程序验证实际文件hash，再比较schema的JSON语义；不会因缩进差异要求重复推理。可附prompt_ref、raw_output_ref、usage、timing_seconds。请求及记录哈希保留模型身份与运行配置，不声称能取得服务商模型权重文件的哈希。单元测试使用明确synthetic_fixture，仅允许source_kind=synthetic，不能据此证明实图通过。

## CMF使用边界

- 本范围是原COL、OPT、TEX字段；OPT只是可见材质/光学，不是真实材料组成或工艺证明。
- unknown、not_applicable、未检查、非任务范围和程序错误分别保留。未知不强行补全，也不按0或“没有”入聚类。缺原完整账本字段不会被补成已审阅。
- 对象/区域/原图坐标、原父级与祖先、reference_object_id全部保留。歧义重复不去重，断父级或整体区域错误不能猜补。
- 已知纹理必须有surface或image来源；uncertain/none保留在审计中，不成为已核查纹理。TEX相对尺度/间距/密度依赖唯一有效计数单元；颜色面积比需明确颜色身份与分母参照。机器只能核查依赖存在与类型，真实分母含义仍由同图模型逐项复核。
- 合法未知不阻断无关已知局部。所有候选unknown或全部复核失败时，useful_local_cmf=false；有输出JSON不等于有用成功。

## 与ImageDNA/聚类衔接

`cmf.image-dna.json`沿用`prism.image_dna.v0.1`外壳，但明确是partial CMF projection。`observations`只包含程序和同图模型双通过的known项；`objects`保留原始完整载体清单。`source_ref`指保留全部216评估的normalized.json，原字段ID、值、证据和原始模型输出不改。

`cmf_admission.all_cmf_units`完整保留CMF原观察、身份、原状态/值、程序错误、观察/对象依赖和复核处置。`not_checked_parameter_ids`与非任务范围单独列出。未投影不代表不存在，完整对象中仍可有未准入/有疑点的载体。

不能把稀疏known投影直接交给未识别此范围的旧聚类器，尤其不能据此证明整图没有禁用特征。消费方须先调用 **`pipeline.verify_projection(path)`**；它从持久化原始模型字节重新执行原编码、身份/字典/区域/依赖检查和审核协议，重新生成并逐项比较投影，不仅信任admitted布尔值。然后消费方还须依据完整objects与cmf_admission完成本次载体/整图范围覆盖判断。当前`whole_image_negative_conditions_qualified=false`、`requires_scope_aware_consumer=true`；整图禁用条件无法靠投影缺项证明，应该进入边界。载体级已核实局部可单独使用。

`dictionary_contract.original_parameter_count=216`仅指原字典大小，实际投影项数另列；不会宣称216项视觉完整合格。旧全量ImageDNA适配器的verify_export要求原样全表，因此不用于这个投影；这里提供独立重验入口，不改旧适配器/聚类器。

## 验证与限制

`python -B -X utf8 -m unittest prism_runtime.dna.local_cmf_v1.test_boundaries -v`测试合法unknown/NA、非法known、错误载体、坏父级/区域/参照、纹理来源、重复项、计数依赖、全unknown、审核身份变更、Fast禁止以及持久化投影篡改。

程序检查与模型复核均不是独立设计师金标，不能据此给视觉准确率百分比。本模块未实现返修或额外调用；R17不可安全解码/全局问题会保留失败。初稿没有发现的重要CMF遗漏，依赖同图复核报告image级问题；无法证明所有遗漏必定被发现。当前范围仅准备进入3图对照，原120是否扩展由协调任务依据真实复核结果决定，已有原图/初稿应复用。
