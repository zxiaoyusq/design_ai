"""Dependency checks for CMF observations, separate from full R17 acceptance."""
from collections import Counter, defaultdict
import copy
import math
import re

from .common import DICTIONARY, canonical, digest, jsonschema, read

PARAMETERS = {p["parameter_id"]: p for p in read(DICTIONARY)["parameters"]}
CMF_PIDS = frozenset(p for p in PARAMETERS if p.startswith(("COL-", "OPT-", "TEX-")))
STATES = {"known", "unknown", "not_applicable"}
HOST_PIDS = {"GEO-017", "STR-006", "EMI-005", "EMI-013", "TXT-009"}
NUMERIC_TEXTURE_RATIOS = {"TEX-003", "TEX-008", "TEX-009"}


def _box(value):
    return (isinstance(value, list) and len(value) == 4
        and all(type(x) in (float, int) and math.isfinite(x) and 0 <= x <= 1 for x in value)
        and value[0] < value[2] and value[1] < value[3])


def _anchor(value, box):
    return (value is None or (isinstance(value, list) and len(value) == 2
        and all(type(x) in (float, int) and math.isfinite(x) for x in value)
        and box[0] <= value[0] <= box[2] and box[1] <= value[1] <= box[3]))


def audit_units(normalized, declared_bindings, image_id, original_report=None):
    """Never fill states, move values, delete raw rows or choose references.

    The complete ledger is retained. Unknown/NA are valid states; only known,
    dependency-valid CMF observations become candidates for a second model.
    """
    objects = normalized.get("objects", [])
    rows = normalized.get("assessments", [])
    global_errors, carrier_errors = [], defaultdict(list)
    index = {}
    if not isinstance(objects, list) or not isinstance(rows, list):
        return {"global_errors": ["Malformed normalized envelope"], "units": [], "candidates": [], "useful": False}
    for obj in objects:
        if not isinstance(obj, dict) or not isinstance(obj.get("object_id"), str) or obj["object_id"] in index:
            global_errors.append("Ambiguous or missing carrier ID"); continue
        index[obj["object_id"]] = obj
        if not _box(obj.get("region")):
            global_errors.append("Invalid source region: " + obj["object_id"])
        elif not _anchor(obj.get("evidence_anchor"), obj["region"]):
            carrier_errors[obj["object_id"]].append("Evidence anchor outside carrier region")
    for oid, obj in index.items():
        visited = {oid}
        parent = obj.get("parent")
        while parent is not None:
            if parent not in index or parent in visited:
                global_errors.append("Broken or cyclic carrier hierarchy: " + oid); break
            visited.add(parent)
            parent = index[parent].get("parent")
    if set(r.get("parameter_id") for r in rows if isinstance(r, dict)) != set(PARAMETERS):
        global_errors.append("Incomplete original216 ledger; missing is not unknown")
    declared = Counter(tuple(x) for x in declared_bindings)
    occurrence = Counter((r.get("parameter_id"), r.get("object_id"), r.get("reference_object_id"))
                         for r in rows if isinstance(r, dict))
    units = []
    for position, row in enumerate(rows):
        if not isinstance(row, dict):
            global_errors.append("Malformed assessment record"); continue
        pid, oid, ref = row.get("parameter_id"), row.get("object_id"), row.get("reference_object_id")
        state, value = row.get("value_status"), row.get("value")
        key = (pid, oid, ref)
        errors = []
        fallback = declared[key] == 0 and row.get("resolved_by") == "vision_model"
        if pid not in PARAMETERS:
            errors.append("Unknown original PID")
        if state not in STATES or (state == "known") != (value is not None):
            errors.append("Invalid explicit state/value pairing")
        if oid not in index or (ref is not None and ref not in index):
            errors.append("Missing carrier/reference")
        if occurrence[key] != 1 or declared[key] > 1:
            errors.append("Ambiguous duplicate field/carrier/reference")
        if state == "known" and fallback:
            errors.append("Known value has no original explicit instance")
        if pid in PARAMETERS:
            definition = PARAMETERS[pid]
            # Original fallback rows are global decisions, not assertions that
            # every dimension applies to the bookkeeping carrier o1.
            if not fallback and oid in index and index[oid].get("object_type_id") not in definition["applicable_object_types"]:
                errors.append("Field not applicable to declared carrier type")
            if state == "known":
                try:
                    canonical(value)
                    jsonschema.Draft202012Validator(definition["value_schema"]).validate(value)
                except Exception:
                    errors.append("Known value violates original value schema")
                if pid in HOST_PIDS and (ref is None or ref == oid):
                    errors.append("Known value lacks original required non-self host")
                if definition["value_type"] in ["id_list", "ordered_id_list"]:
                    if not isinstance(value, list) or any(not isinstance(x, str) or x not in index for x in value):
                        errors.append("Value references absent carrier")
                if definition["value_type"] == "region_reference":
                    if not isinstance(value, dict) or value.get("region") not in index:
                        errors.append("Value references absent region")
        deps = []
        if oid in index:
            deps.append(oid)
        if ref in index and ref != oid:
            deps.append(ref)
        for target in list(deps):
            visited = set()
            while target in index and target not in visited:
                visited.add(target)
                if target not in deps:
                    deps.append(target)
                target = index[target].get("parent")
        for dependency in deps:
            errors.extend("Dependency " + dependency + ": " + e for e in carrier_errors[dependency])
        if pid in CMF_PIDS and state == "known":
            if not isinstance(row.get("evidence"), str) or not row["evidence"].strip():
                errors.append("No original evidence trace")
            if pid.startswith("TEX-") and oid in index:
                if index[oid].get("texture_evidence_origin") not in ["surface", "image"]:
                    errors.append("Texture origin absent or uncertain")
            if ref is None:
                errors.append("CMF scope/reference is not explicit in normalized source")
        units.append({"observation_id": image_id + ":a" + str(position).zfill(4),
            "row_index": position, "parameter_id": pid, "object_id": oid, "reference_object_id": ref,
            "value_status": state, "value": copy.deepcopy(value), "in_cmf_scope": pid in CMF_PIDS,
            "is_global_fallback": fallback, "dependency_object_ids": deps,
            "dependency_observation_ids": [], "program_errors": errors, "native_assessment": copy.deepcopy(row)})
    by_pair = defaultdict(list)
    for u in units:
        by_pair[(u["object_id"], u["parameter_id"])].append(u)
    for u in units:
        if u["value_status"] != "known" or not u["in_cmf_scope"]:
            continue
        supporting = []
        if u["parameter_id"] in NUMERIC_TEXTURE_RATIOS:
            supporting = [x for x in by_pair[(u["object_id"], "TEX-002")] if x["value_status"] == "known" and not x["program_errors"]]
            if len(supporting) != 1:
                u["program_errors"].append("Texture ratio/count has no unique valid declared counting unit")
        if u["parameter_id"] == "COL-009":
            supporting = [x for pid in ["COL-006", "COL-007", "COL-008"] for x in by_pair[(u["object_id"], pid)]
                          if x["value_status"] == "known" and not x["program_errors"]]
            if len(supporting) != 1:
                u["program_errors"].append("Colour area fraction has ambiguous or missing colour identity")
        u["dependency_observation_ids"] = [s["observation_id"] for s in supporting]
    # Preserve every legacy error. Only errors with an exact, recognizable
    # carrier/texture scope can be isolated; other failures block the image.
    for error in (original_report or {}).get("errors", []):
        match = re.fullmatch(r"(o\d+): known pattern with no origin", error)
        if match:
            for u in units:
                if u["object_id"] == match.group(1) and str(u["parameter_id"]).startswith("TEX-"):
                    u["program_errors"].append(error)
        else:
            global_errors.append("Unisolated original validation failure: " + str(error))
    candidates = []
    for u in units:
        u["program_eligible"] = bool(u["in_cmf_scope"] and u["value_status"] == "known"
                                     and not u["program_errors"] and not global_errors)
        if u["program_eligible"]:
            candidates.append(u["observation_id"])
    reviewed = {u["parameter_id"] for u in units if u["parameter_id"] in CMF_PIDS}
    return {"scope": "local_cmf_only", "original_full_216_pass": bool((original_report or {}).get("passed")),
        "global_errors": global_errors, "units": units, "candidates": candidates,
        "states": dict(Counter(u["value_status"] for u in units if u["in_cmf_scope"])),
        "not_checked_parameter_ids": sorted(CMF_PIDS - reviewed),
        "out_of_scope_parameter_ids": sorted(set(PARAMETERS) - CMF_PIDS),
        "ready_for_review": bool(candidates) and not global_errors, "useful": False,
        "program_checks_are_not_visual_verification": True}


def review_schema(proposal):
    item = {"type": "object", "additionalProperties": False,
        "properties": {"verdict": {"type": "string", "enum": ["supported", "contradicted", "uncertain"]},
            "evidence": {"type": "string"}, "carrier_ok": {"type": "boolean"},
            "reference_ok": {"type": "boolean"}, "origin_ok": {"type": "boolean"}},
        "required": ["verdict", "evidence", "carrier_ok", "reference_ok", "origin_ok"]}
    ids = [r["observation_id"] for r in proposal["observations"]]
    issue = {"type": "object", "additionalProperties": False,
        "properties": {"scope": {"type": "string", "enum": ["image", "observations"]},
            "observation_ids": {"type": "array", "items": {"type": "string", "enum": ids}}, "evidence": {"type": "string"}},
        "required": ["scope", "observation_ids", "evidence"]}
    props = {"image_id": {"type": "string", "enum": [proposal["image_id"]]},
        "image_sha256": {"type": "string", "enum": [proposal["image_sha256"]]},
        "proposal_sha256": {"type": "string", "enum": [proposal["proposal_sha256"]]},
        "checks": {"type": "object", "additionalProperties": False,
            "properties": {oid: {"$ref": "#/$defs/check"} for oid in ids}, "required": ids},
        "issues": {"type": "array", "items": issue}}
    return {"type": "object", "additionalProperties": False, "properties": props,
            "required": list(props), "$defs": {"check": item}}


def resolve_review(audit, proposal, response):
    """Accept no replacement facts: select only independently reviewed rows."""
    jsonschema.Draft202012Validator(review_schema(proposal)).validate(response)
    expected = {r["observation_id"] for r in proposal["observations"]}
    blocked, image_issues = set(), []
    for issue in response["issues"]:
        if not issue["evidence"].strip():
            raise ValueError("Review issue needs source-image evidence")
        if issue["scope"] == "image":
            if issue["observation_ids"]:
                raise ValueError("Image issue must not masquerade as a local issue")
            image_issues.append(issue["evidence"])
        else:
            if not issue["observation_ids"] or not set(issue["observation_ids"]) <= expected:
                raise ValueError("Local issue needs explicit known observation IDs")
            blocked.update(issue["observation_ids"])
    accepted = set()
    for oid, check in response["checks"].items():
        if not check["evidence"].strip():
            raise ValueError("Every review verdict needs source-image evidence")
        if check["verdict"] == "supported" and all(check[k] for k in ["carrier_ok", "reference_ok", "origin_ok"]):
            accepted.add(oid)
    accepted -= blocked
    accepted &= set(audit["candidates"])
    if image_issues or audit["global_errors"]:
        accepted.clear()
    # A supported ratio cannot survive a contradicted/uncertain counting unit.
    changed = True
    while changed:
        changed = False
        for u in audit["units"]:
            oid = u["observation_id"]
            if oid in accepted and not set(u["dependency_observation_ids"]) <= accepted:
                accepted.remove(oid); changed = True
    return {"accepted_observation_ids": sorted(accepted), "useful_local_cmf": bool(accepted),
        "image_issues": image_issues, "blocked_by_review_issue": sorted(blocked),
        "review_verdict_counts": dict(Counter(c["verdict"] for c in response["checks"].values())),
        "complete_216_visual_qualified": False, "independent_human_accuracy_established": False}
