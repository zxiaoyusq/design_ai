"""Offline CLOSURE-DNA-001 handoff; consumes already completed Root calls."""
from datetime import datetime, timezone
import io
from pathlib import Path
import unittest

from . import VERSION, common as c, pipeline

LOOP = c.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
ROOT_RUN = LOOP / "closure-20260927"
OUT = c.PROJECT / "outputs/prism-algorithm-loop-20260926/modules/dna/repairs/CLOSURE-DNA-001/v1"


def main():
    c.require(not (OUT / "handoff.json").exists(), "Delivery already frozen")
    OUT.mkdir(parents=True, exist_ok=True)
    before = c.verify_freeze()
    inputs = [c.file_identity(LOOP / "dispatches/CLOSURE-DNA-001.md")]
    manifest_path = LOOP / "qwen-cli-20260927/inputs/image-manifest.json"
    records = c.read(manifest_path)["records"]
    pilots = []
    for cid in ["R002", "R005", "R009"]:
        record = next(r for r in records if r["image_id"] == cid)
        folder = OUT / "primary-preparations" / cid
        preparation = pipeline.prepare(record["path"], cid, record["source_kind"], manifest_path, folder)
        raw = ROOT_RUN / "calls" / ("P-" + cid) / "answer.json"
        run_record = ROOT_RUN / "controls" / cid / "primary-run-record.json"
        result = pipeline.accept(folder, raw, run_record)
        c.require(result["ready_for_review"], cid + ": " + str(result))
        c.jsonschema.Draft202012Validator.check_schema(c.read(folder / "review.schema.json"))
        pilots.append({"image_id": cid, "source_kind": record["source_kind"],
            "image_sha256": record["sha256"], "original_R17_complete_structure_pass": result["original_full_216_pass"],
            "program_eligible_CMF_observations": result["candidate_observations"], "ready_for_model_review": True,
            "model_review_performed_by_owner": False, "useful_local_cmf_qualified": False,
            "preparation": preparation, "acceptance_ref": str(folder / "acceptance.json"),
            "review_schema_ref": result["review_schema_ref"], "review_prompt_ref": result["review_prompt_ref"]})
        inputs.extend([c.file_identity(raw), c.file_identity(run_record)])
        rr = c.read(run_record)
        inputs.extend(c.file_identity(rr[k]) for k in ["source_ref", "request_ref", "schema_ref", "prompt_ref"])
    stream = io.StringIO()
    tests = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromName("prism_runtime.dna.local_cmf_v1.test_boundaries"))
    c.write_new(OUT / "offline-tests.txt", stream.getvalue(), text=True)
    c.require(tests.wasSuccessful(), "Offline tests failed")
    for item in before["producer_sources"] + inputs:
        c.verify_identity(item)
    projection_schema = c.HERE / "schemas/cmf-image-dna.schema.json"
    c.jsonschema.Draft202012Validator.check_schema(c.read(projection_schema))
    sources = c.module_sources() + [c.file_identity(c.FREEZE), c.file_identity(c.HERE / "README.md"), c.file_identity(projection_schema)]
    c.write_new(OUT / "source-hashes.json", sources)
    c.write_new(OUT / "input-hashes.json", inputs + [c.file_identity(manifest_path)])
    c.write_new(OUT / "verification.json", {"checked_utc": datetime.now(timezone.utc).isoformat(),
        "version": VERSION, "tests": tests.testsRun, "failures": len(tests.failures), "errors": len(tests.errors),
        "owner_model_calls": 0, "old_R17_and_dictionary_unchanged": True,
        "old_three_cycle_issue_remains_stopped": True, "primary_calls_reused": 3,
        "fresh_actual_review_calls_by_owner": 0, "pilots": pilots})
    c.write_new(OUT / "self-assessment.json", {"module": "dna", "issue_id": "CLOSURE-DNA-001", "version": VERSION,
        "status": "partial_ready_for_independent_review", "qualified": False,
        "qualified_scope": "Offline identity/schema/dependency/projection and persistence boundaries; three real existing Astra primary outputs decoded without alteration",
        "tests_passed": tests.testsRun, "production_qualified": False, "visual_accuracy_established": False,
        "local_cmf_useful_live_examples": 0, "ready_for_root_three_same_image_reviews": True,
        "owner_model_calls": 0, "automatic_retry": False,
        "known_limits": ["Independent model review has not yet been run for these3 proposals.",
            "Original full schema/undecodable/global carrier failures can conservatively block the entire image.",
            "No repair or extra inference stage is implemented.",
            "Whole-image absence/forbidden-feature qualification is deliberately false for this positive sparse projection.",
            "Human gold accuracy and detection of every important visual omission are not established."],
        "holdout_scope": "R002/R005/R009 are development counterexamples/control, not a new unbiased population sample"})
    c.write_new(OUT / "handoff.json", {"module": "dna", "issue_id": "CLOSURE-DNA-001", "version": VERSION,
        "status": "partial_ready_for_independent_review", "source_entrypoint": str(c.HERE / "pipeline.py"),
        "cli": "python -B -X utf8 -m prism_runtime.dna.local_cmf_v1",
        "operations": {
            "prepare": "prepare(image,image_id,source_kind,source_provenance_ref,output_dir)",
            "accept": "accept(prepared_dir,raw_output,run_record)",
            "accept_review": "accept_review(prepared_dir,raw_output,run_record)",
            "persisted_verifier": "verify_projection(path)"},
        "readme_ref": str(c.HERE / "README.md"), "producer_freeze_ref": str(c.FREEZE),
        "projection_schema_ref": str(projection_schema), "source_hashes_ref": str(OUT / "source-hashes.json"),
        "self_assessment_ref": str(OUT / "self-assessment.json"), "verification_ref": str(OUT / "verification.json"),
        "pilots": pilots, "owner_model_calls": 0, "producer_model": "gpt-6-astra",
        "service_tier": "default", "fast_or_priority_allowed": False,
        "root_execution": "Recreate prepare/accept under Root's closure output with the same existing raw answers and run records; no repeated primary calls. Then only3 distinct same-image model reviews, standard tier. Recreating local preparation may change proposal hashes/paths, so use its corresponding new review.prompt/schema.",
        "image_dna_contract": {"schema_version": "prism.image_dna.v0.1", "observations": "only dual-passed known CMF",
            "objects": "all original objects, unchanged", "cmf_admission": "all CMF rows/states/errors/review dispositions/dependencies, including unprojected carriers",
            "unknown_or_unprojected_means_absent": False, "requires_scope_aware_consumer": True,
            "whole_image_negative_conditions_qualified": False, "complete216_visual_qualified": False},
        "downstream_gate": "Call verify_projection on persisted artifacts, then a new scope-aware clustering guard; never apply frozen old full-image forbidden matching directly to sparse known observations.",
        "metrics": "Keep original R17 full check, local program candidates, review verdicts, final admitted units/useful images and caller total time/tokens separate. No fabricated pass from empty/unknown results.",
        "expansion": "Root decides original120 expansion after independent pilot review; no owner inference, no modification of old13/120 or stopped Qwen issue."})
    c.write_new(OUT / "delivery-hashes.json", {"version": VERSION,
        "files": [c.file_identity(p) for p in sorted(OUT.rglob("*")) if p.is_file() and p.name != "delivery-hashes.json"]})
    print(c.canonical({"handoff": str(OUT / "handoff.json"), "tests": tests.testsRun,
        "owner_model_calls": 0, "pilot_candidates": {p["image_id"]: p["program_eligible_CMF_observations"] for p in pilots}}))


if __name__ == "__main__":
    main()
