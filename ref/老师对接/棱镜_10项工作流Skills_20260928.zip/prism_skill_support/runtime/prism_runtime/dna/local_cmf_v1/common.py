"""File identity and strict JSON utilities, without network capabilities."""
from pathlib import Path
import hashlib
import json
import math
import subprocess
import sys

from . import VERSION

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
BASE = PROJECT / "outputs/01a0c2a0-b850-7fd1-a032-78e192743557"
OPT = BASE / "dna-optimization-loop-20260925"
DICTIONARY = BASE / "棱镜_DNA基础字典_AI版_v0.3.json"
FREEZE = HERE / "producer-freeze.json"
sys.path.insert(0, str(OPT / "round15/vendor"))
import jsonschema


class ContractError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ContractError(message)


def loads(text):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            require(key not in out, "Duplicate JSON key: " + key)
            out[key] = value
        return out
    def constant(token):
        raise ContractError("Nonfinite JSON token: " + token)
    def finite_number(token):
        value = float(token)
        require(math.isfinite(value), "Nonfinite JSON number")
        return value
    return json.loads(text, object_pairs_hook=unique, parse_constant=constant, parse_float=finite_number)


def read(path):
    return loads(Path(path).read_text(encoding="utf-8-sig"))


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def text_hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_new(path, value, *, text=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(value if text else json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    return path


def file_identity(path):
    p = Path(path).resolve()
    require(p.is_file(), "Required source file missing: " + str(p))
    return {"path": str(p), "sha256": file_hash(p)}


def verify_identity(item):
    require(file_hash(item["path"]) == item["sha256"], "Source changed: " + item["path"])


def worker(payload):
    # Only our local codec worker, never codex, a provider runner or a shell.
    proc = subprocess.run([sys.executable, "-B", "-X", "utf8", str(HERE / "worker.py")],
        input=json.dumps(payload, ensure_ascii=False, allow_nan=False), text=True, encoding="utf-8",
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    require(proc.returncode == 0, "Local codec failed: " + proc.stderr[-3000:])
    return loads(proc.stdout)


def verify_freeze(sources=None):
    frozen = read(FREEZE)
    for item in frozen["producer_sources"]:
        verify_identity(item)
    if sources is not None:
        require(sources == frozen["producer_sources"], "Loaded R17 dependency set changed")
    require(file_hash(DICTIONARY) == frozen["dictionary_sha256"], "Original dictionary changed")
    return frozen


def module_sources():
    return [file_identity(p) for p in sorted(HERE.glob("*.py"))]
