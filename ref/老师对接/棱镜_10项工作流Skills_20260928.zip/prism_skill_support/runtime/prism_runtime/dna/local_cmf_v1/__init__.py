"""Scoped CMF preparation and acceptance; inference belongs to the caller."""

VERSION = "r17-local-cmf-v1"
