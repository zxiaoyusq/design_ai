"""R7: compact lossless wire codec over direct dictionary-guided object parsing."""
from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict
import argparse,copy,json,re,sys
from PIL import Image
import parse_direct as c

ROOT=Path(__file__).resolve().parent
t=c.t
FAMILIES={f['family_id']:[p['parameter_id'] for p in c.D['parameters'] if p['family_id']==f['family_id'] and p['parameter_id'] in c.ACTIVE] for f in c.D['families']}
FAMILIES={f:p for f,p in FAMILIES.items() if p}
original_core_ids=c.core_ids
def core_ids(typ):
    return ['GEO-001','COL-006'] if typ=='O01' else original_core_ids(typ)
c.core_ids=core_ids

FORMAT="""逐对象直接判断和无损短编码：
core的每个字段使用字符串编码：o:值（图像观察）、e:值（图像估计）、u:索引（未知）、n:索引（不适用）。o/e冒号后的全部文字是原字典合法值；u/n冒号后是limits数组的0起始索引，引用短的证据不足/不适用原因。不能给未知字段编造值。
d是该对象其他known字段列表，{k:参数ID,r:参照ID或null(自身),v:合法值,s:o|e,n:必要补充或null}。core字段不重复放d；一个参数可有多个对象实例。
每个具有光学/表面属性的可见实体给a:[x,y]证据锚点，位置落在bbox内实际描述的可见实体上；负空间的锚点放在空隙，不能拿空隙代替环带表面。整体/画面可a:null。锚点是目视估计，坐标不是实际测量。
coverage按下文固定家族顺序逐槽检查全部148项。每槽只有p、u:索引或n:索引：p表示该参数已在任一对象core/d中判断；其余表示全图未实例化该参数时的明确状态。每个数组长度固定，不得省项。已有对象实例时以实例的判断为准，全图兜底不能覆盖局部事实；没有对象实例的槽不能填p。
limits数组可共用同因理由，不能用“缺少尺度”否定一个明明可见的类别特征。程序按固定槽位无损展开216项，不让模型重复写参数名/单位/长字段名。
"""
INSTRUCTIONS=c.INSTRUCTIONS.split('逐对象直接判断：')[0]+FORMAT+'\n视觉与物理身份的边界：'+c.INSTRUCTIONS.split('视觉与物理身份的边界：',1)[1]+"""
附加范围约束：整体O01只强制轮廓和主色；材质/光学差异主要落在具体可见表面。覆盖在透明主体外面的不透明或反光表层要单独定位，不能因底层透明而把覆盖区也归为透明。检查区域不靠整体bbox包住所有东西来充数。
型面、操作件或文字的来源不能靠熟悉产品的知识补全；按当前可见证据用中性名称。主要承载面上已记录的纹理不必再建同范围重复纹理对象。note只在有特定参照或重要局限时填写。
只输出JSON，不输出中间描述或检查过程。
"""

def make_schema():
    generic=c.prev.m.schema()['$defs']['known']['properties']['v']
    defs={'value':generic};groups=defaultdict(list);attrs={}
    for typ in c.TYPE_IDS:groups[(tuple(core_ids(typ)),tuple(sorted(c.allowed(typ))))].append(typ)
    names=[]
    for (cores,ids),types in groups.items():
        extra=tuple(sorted(set(ids)-set(cores)))
        if extra not in attrs:
            a='attr'+str(len(attrs));attrs[extra]=a
            defs[a]=c.obj({'k':{'type':'string','enum':list(extra)},'r':{'type':['string','null']},
                          'v':{'$ref':'#/$defs/value'},'s':{'type':'string','enum':['o','e']},'n':{'type':['string','null']}})
        props={'i':c.S,'t':{'type':'string','enum':types},'n':c.S,'p':{'type':['string','null']},
               'b':c.arr({'type':'number','minimum':0,'maximum':1},minItems=4,maxItems=4),
               'a':{'anyOf':[c.arr({'type':'number','minimum':0,'maximum':1},minItems=2,maxItems=2),{'type':'null'}]},
               'proof':c.S,'core':c.obj({pid:c.S for pid in cores}),'d':c.arr({'$ref':'#/$defs/'+attrs[extra]})}
        name='node'+str(len(names));defs[name]=c.obj(props);names.append(name)
    schema=c.obj({'objects':c.arr({'anyOf':[{'$ref':'#/$defs/'+n} for n in names]},minItems=2),
                  'coverage':c.obj({f:c.arr(c.S,minItems=len(ps),maxItems=len(ps)) for f,ps in FAMILIES.items()}),
                  'limits':c.arr(c.S,minItems=1)})
    schema['$defs']=defs;return schema

def decode(raw):
    decoded={'objects':[],'remaining':[]};errors=[];notices=[];seen=set()
    def state(code,allow_p=False):
        if allow_p and code=='p':return ('p',None)
        if not isinstance(code,str):raise ValueError('state is not a string')
        match=re.fullmatch(r'([oeun]):([\s\S]+)',code)
        if not match:raise ValueError('invalid state code '+code)
        kind,val=match.groups()
        if kind in ['u','n']:
            if not re.fullmatch('[0-9]+',val) or int(val)>=len(raw['limits']):raise ValueError('invalid limitation reference '+code)
            return kind,raw['limits'][int(val)]
        if allow_p:raise ValueError('coverage cannot contain values')
        return kind,val
    for o in raw['objects']:
        node=copy.deepcopy(o);node['core']={}
        for pid,code in o['core'].items():
            kind,val=state(code);seen.add(pid)
            node['core'][pid]={'s':kind,'v':val if kind in ['o','e'] else None,'n':val if kind in ['u','n'] else None}
        seen|={a['k'] for a in o['d']}
        anchor=o.get('a');b=o['b']
        if any(k.startswith('OPT-') for k in o['core']) and o['t'] not in ['O01','O19'] and anchor is None:
            errors.append(o['i']+': visible-surface anchor missing')
        if anchor is not None and not(b[0]<=anchor[0]<=b[2] and b[1]<=anchor[1]<=b[3]):errors.append(o['i']+': anchor outside bbox')
        decoded['objects'].append(node)
    if set(raw['coverage'])!=set(FAMILIES):errors.append('coverage family mismatch')
    for family,pids in FAMILIES.items():
        slots=raw['coverage'].get(family,[])
        if len(slots)!=len(pids):errors.append(family+': wrong coverage slot count')
        for pid,code in zip(pids,slots):
            kind,val=state(code,True)
            if pid in seen:
                if kind!='p':notices.append({'parameter_id':pid,'ignored_global_fallback':code,'reason':'Preserve explicit object observations over whole-image fallback.'})
                continue
            if kind=='p':errors.append(pid+': marked present but no object observation');continue
            decoded['remaining'].append({'k':[pid],'s':kind,'why':val})
    return decoded,errors,notices

def validate(raw,width,height):
    decoded,errors,notices=decode(raw)
    anchors={o['i']:o.get('a') for o in raw['objects']}
    report,rows=c.validate(decoded,width,height)
    report['errors']=errors+report['errors'];report['passed']=not report['errors']
    report['global_fallback_notices']=notices
    for o in decoded['objects']:o['evidence_anchor']=anchors[o['object_id']]
    raw['objects']=decoded['objects'];raw['scope']=decoded['scope'];raw['visual_summary']=[]
    return report,rows

def build_inputs(photo):
    with Image.open(photo) as im:width,height=im.size
    # Put variable image metadata after the reusable instructions and dictionary.
    slots='\ncoverage家族固定槽位（从左至右，每一项都必须审阅）：\n'+json.dumps(FAMILIES,ensure_ascii=False,separators=(',',':'))
    prompt=INSTRUCTIONS+'\n148项视觉判断原参数：\n'+c.runtime_dictionary()+slots+f'\n本次图片文件尺寸：{width}×{height}px。'
    return prompt,make_schema(),width,height

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','run'])
    ap.add_argument('--trial',required=True);ap.add_argument('--case',choices=['radio','teapot','switch','chair','phoneboxes'],default='radio')
    ap.add_argument('--image',type=Path);ap.add_argument('--model',default='gpt-6-sol');ap.add_argument('--effort',default='low')
    args=ap.parse_args()
    if not re.fullmatch('[a-z0-9_-]+',args.trial):raise SystemExit('Bad trial name')
    photos={'radio':ROOT.parent.parent/'dna-timing-test-20260925/test-photo.jpg','teapot':ROOT.parent/'cases/teapot.jpg',
            'switch':ROOT.parent/'cases/switch.jpg','chair':ROOT/'cases/chair.jpg','phoneboxes':ROOT/'cases/phoneboxes.jpg'}
    photo=args.image.resolve() if args.image else photos[args.case]
    trial=ROOT/'trials'/args.trial;trial.mkdir(parents=True,exist_ok=True)
    if (trial/'events-timed.jsonl').exists():raise SystemExit('Refusing to overwrite an existing inference')
    prompt,schema,width,height=build_inputs(photo)
    def prepare():
        (trial/'prompt.txt').write_text(prompt,encoding='utf-8');t.dump(trial/'output-schema.json',schema)
        manifest={'prepared_at':datetime.now(timezone.utc).isoformat(),'algorithm':'direct-typed-compact-dna-r7','parameter_count':216,
            'vision_parameter_count':148,'contract_parameter_count':65,'geometry_parameter_count':3,
            'dictionary_version':c.D['schema_version'],'dictionary_sha256':t.sha(c.prev.m.DICT.read_bytes()),
            'photo_sha256':t.sha(photo.read_bytes()),'photo_original_pixels':[width,height],
            'prompt_sha256':t.sha(prompt.encode('utf-8')),'prompt_bytes':len(prompt.encode('utf-8')),
            'output_schema_sha256':t.sha((trial/'output-schema.json').read_bytes()),
            'case_id':'asset' if args.image else args.case,'previous_answer_included':False,'reference_checklist_included':False,
            'derived_fields':sorted(c.DERIVED),'core_fields':c.CORE,'image_preprocessing':'original image unchanged',
            'codec':'Core state-prefixed strings with shared limitations; fixed family coverage slots; no semantic remapping.'}
        t.dump(trial/'input-manifest.json',manifest);return prompt,manifest
    t.HERE=trial;t.PHOTO=photo;t.prepare=prepare;t.validate=lambda raw:validate(raw,width,height)
    sys.argv=[str(__file__),args.mode,'--model',args.model,'--effort',args.effort,'--http-only','--respect-system-proxy'];t.main()
if __name__=='__main__':main()
