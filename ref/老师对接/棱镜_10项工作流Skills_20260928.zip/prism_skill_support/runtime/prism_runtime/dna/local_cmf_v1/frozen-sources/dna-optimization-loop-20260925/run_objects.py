"""R4: evidence-availability rules + direct object-local dictionary inference.
No free-form description-to-dictionary matching stage. Every one of 216 fields
is resolved by a declared deterministic rule or by the vision call.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import argparse,copy,importlib.util,json,re,sys
from PIL import Image
ROOT=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('variant',ROOT/'run_variant.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
t=m.transport
D=copy.deepcopy(m.dictionary);PARAMS={p['parameter_id']:p for p in D['parameters']}
AUTO=set()
for prefix,count in [('MAT',16),('FIN',17),('MOT',10),('TOU',9),('SEM',10)]:
    AUTO|={f'{prefix}-{i:03}' for i in range(1,count+1)}
AUTO|={'CTX-015','CTX-016','CTX-018'}
ACTIVE=set(PARAMS)-AUTO

INSTRUCTIONS="""你是直接按DNA字典解析图片的视觉模型。只看附图和给定字典，不调用工具、不联网、不写代码、不启动代理。不做先自由识别再找表达的阶段。只输出紧凑单行JSON。
业务用途：图片资产跨人群复用、按DNA聚类、按局部特征裁剪。必须保留对象及重要局部的准确对应关系。中性命名可见外形，不以产品知识猜测功能。
本轮照片研究范围固定：无BOM/工艺资料、实物接触、视频、真实用户反馈。程序已按这些明确条件处理65项非视觉/任务/文件字段：MAT、FIN的资料性判断、MOT/TOU研究开关与未激活分支、未启用SEM、CTX-015/016/018。它们仍在最终216项结果内。你完整判断剩余151项，不能漏项，也不能把未检查项默认记unknown。
每个可见实体/载体一个对象，frame为O19，primary为O01。主要部件、显著独立操控件、不同光学/色彩区域要能分别定位；不要把一个小操控件与它周围的大显示组件合并。bbox应贴近该对象的可见外廓，是归一化[x0,y0,x1,y1]粗定位，最多3位小数。
避免为同一承载面重复建立“几何体/表面/纹理”节点；纹理通常直接赋给实体承载面。对象O类型要与其全部属性的允许类型相容，例如在面板载体上同时记录结构和纹理，而不要把纹理类型对象直接当结构件。重要对象不能为压缩而省掉。
输出对象结构：
i=短ID,t=原字典O类型,n=中性名称,p=父ID或null,b=bbox,
proof=仅描述这个对象的短视觉证据，不借用其他对象的排他位置/数量描述，
d=该对象的known属性列表，每项{k:参数ID,r:参照对象ID或"$self",v:字典合法值,s:"o"或"e",note:必要补充或null}。
s中o是图像观察，e是图像估计。note补充关系/数值的特殊证据，否则null；不重复proof。
remaining列表记录所有没有任何known实例的151项：每组{k:参数ID数组,s:"u"或"n",why:短原因}。u=适用但证据不足，n=当前对象/研究范围不适用。每个ACTIVE参数必须出现在d或remaining的一侧；重要对象可有同参数的多个实例。
规则：
1 不确认实际基材/工艺/真实功能；可见材料表现记OPT。不能把光照渐变记成设计配色渐变。真实触感和人群偏好由程序标记研究未启用。
2 非关系属性通常r="$self"。纹理覆盖/面积/主辅关系必须明确r的分母/参照；相对面板与相对整机可分条。位置值里的reference_id必须与r一致。
3 轮廓/曲率默认主体整体外轮廓，不临时换成圆盘。连续圆角如何计转折若无明确口径就unknown。
4 主体、局部控件、符号、纹理不能错绑定；文字抄录可辨主字标和显著数字，不猜缺失字符。各操控件的位置需要独立保留。
5 每个known必须有视觉证据；实体尺度不可从照片当实测，图像估计标e并声明参照。光泽边界不能可靠区分时unknown。
6 CTX观察条件只放frame对象；GEO/STR/TEX等放适用实体，不把画面条件当产品DNA。
7 参考值是开放候选。尽量用合适的短值，复杂解释留proof/note，不为“known更多”而填值。
8 完成前核对151项覆盖、各对象O类型与参数允许类型、所有父/参照ID、对象bbox及proof的对应。只输出JSON。
"""

REVISION_5="""
本版补充视觉分区核对，仍在同一次字典直接解析内完成：
1 对象划分以可见设计属性的承载范围为准。一个物理主体上若同时存在面积明显的不同光学外观、配色或纹理区域，应独立给出对应表面对象和DNA；不能只列功能部件，或把大面积覆盖面吞并到主体中。透射区域、强反射区域、哑光区域若同时存在，不能共用一个OPT结论。仅光照变化不分成真实配色区。
2 输出前对照整图检查：每个显著大区域、视觉点缀、局部控件是否有恰当的DNA承载对象；遮挡面和包覆面不能遗漏。bbox可能彼此重叠，proof必须指明实际描述的可见部分，不将包围框内其他区域的属性混入。
3 高光外观不能自动确认玻璃或金属外观；透射需要在该实体内辨认后方内容的证据。把手或环内部的空隙露出背景，不等于环带材料本身透明。不确定则unknown，保留能观察到的反射与高光表现。
4 文字逐字抄录，包括原有标点；不得把小数逗号自动规范化为小数点。不能辨清就说明不确定，不补全。
5 CTX-006的分母是整幅画面，r必须指向frame。其数值为粗估，不等于精确抠图面积。关系字段只因无法测量而unknown时，检查其本来是否仅要求可见类别或现有对象引用，不以缺少真实尺寸否定已有视觉关系。
6 轮廓曲率若“直边连接圆角”的类别存在口径歧义，可用短开放表达描述，不勉强选会暗示尖锐转折的标签。属性和证据可复用简短对象proof，note仅补充参照或确有必要的限制，不重复通用声明。
"""

def validate(result,width,height):
    errors=[];rows=[];ids=set();known=set();groups=set()
    objects={o['i']:o for o in result['objects']}
    if len(objects)!=len(result['objects']):errors.append('duplicate object IDs')
    frames=[o for o in objects.values() if o['t']=='O19']
    if len(frames)!=1:errors.append('requires one frame')
    frame=frames[0]['i'] if frames else next(iter(objects),'')
    primary=next((o['i'] for o in objects.values() if o['t']=='O01'),frame)
    for o in objects.values():
        b=o['b']
        if not(0<=b[0]<b[2]<=1 and 0<=b[1]<b[3]<=1):errors.append(o['i']+': invalid region')
        if o['p'] is not None and o['p'] not in objects:errors.append(o['i']+': invalid parent')
        lineage=set();node=o
        while node.get('p') in objects:
            if node['i'] in lineage:errors.append(o['i']+': parent cycle');break
            lineage.add(node['i']);node=objects[node['p']]
        local=set()
        for a in o['d']:
            pid=a['k'];ref=o['i'] if a['r']=='$self' else a['r']
            if pid not in ACTIVE:errors.append('non-active field '+pid);continue
            p=PARAMS[pid];known.add(pid);ids.add(pid)
            if (pid,ref) in local:errors.append(pid+': duplicate same scope')
            local.add((pid,ref))
            if ref not in objects:errors.append(pid+': missing reference')
            if o['t'] not in p['applicable_object_types']:errors.append(pid+': incompatible object '+o['i']+' '+o['t'])
            value=a['v']
            if p['value_schema'].get('type')=='integer' and isinstance(value,float) and value.is_integer():value=int(value)
            errors+=t.check_value(value,p['value_schema'],pid)
            if pid=='REL-003' and isinstance(value,dict) and value.get('reference_id')!=ref:errors.append(pid+': reference mismatch')
            rows.append({'parameter_id':pid,'parameter_name':p['name'],'object_id':o['i'],'reference_object_id':ref,
              'value_status':'known','value':value,'source_kind':'image_observation' if a['s']=='o' else 'image_estimate',
              'evidence':o['proof']+('；'+a['note'] if a['note'] else ''),'unit':p['unit'],'resolved_by':'vision_model'})
    for g in result['remaining']:
        for pid in g['k']:
            if pid not in ACTIVE:errors.append('non-active unresolved '+pid);continue
            if pid in known or pid in groups:errors.append('duplicate/conflicting state '+pid)
            groups.add(pid);ids.add(pid);p=PARAMS[pid]
            rows.append({'parameter_id':pid,'parameter_name':p['name'],'object_id':primary,'reference_object_id':primary,
               'value_status':'unknown' if g['s']=='u' else 'not_applicable','value':None,'source_kind':'image_observation',
               'evidence':g['why'],'unit':p['unit'],'resolved_by':'vision_model'})
    if ids!=ACTIVE:errors.append('missing active: '+','.join(sorted(ACTIVE-ids)))
    def put(pid,status,value,oid,why):
        p=PARAMS[pid]
        if status=='known':
            errors.extend(t.check_value(value,p['value_schema'],pid))
            if objects[oid]['t'] not in p['applicable_object_types']:errors.append(pid+': rule target type')
        rows.append({'parameter_id':pid,'parameter_name':p['name'],'object_id':oid,'reference_object_id':oid,
          'value_status':status,'value':value,'source_kind':'document' if pid=='CTX-016' else 'design_setting',
          'evidence':why,'unit':p['unit'],'resolved_by':'declared_input_rule'})
    surface=next((o['i'] for o in objects.values() if o['t'] in PARAMS['MAT-016']['applicable_object_types']),None)
    for pid in sorted(AUTO):
        if pid=='MOT-001':put(pid,'known','静态',frame,'输入协议明确为单张静态图。')
        elif pid=='TOU-001' and surface:put(pid,'known','不研究',surface,'输入协议明确无实物接触研究。')
        elif pid=='MAT-016' and surface:put(pid,'known','图片外观推测',surface,'仅照片证据；真实材料身份没有BOM或实物确认。')
        elif pid.startswith(('MAT-','FIN-')):put(pid,'unknown',None,surface or primary,'photo-only输入没有真实材料/工艺资料；视觉表现由OPT/TEX等记录。')
        elif pid=='CTX-016':put(pid,'known',f'{width}×{height}px',frame,'程序读取原始图片文件像素尺寸。')
        elif pid=='CTX-018':put(pid,'known','单图',frame,'本次输入契约为单张完整图，非情绪板拼贴。')
        else:put(pid,'not_applicable',None,frame,'该研究分支或真实前测显示条件未启用，依据明确输入协议。')
    normal_objects=[{'object_id':o['i'],'object_type_id':o['t'],'name':o['n'],'parent':o['p'],'region':o['b'],'evidence':o['proof']} for o in objects.values()]
    result['objects']=normal_objects
    result['scope']='photo-only direct DNA parsing; 65 deterministic source/scope fields + 151 vision fields.'
    result['visual_summary']=result.get('summary',[])
    rows.sort(key=lambda x:list(PARAMS).index(x['parameter_id']))
    statuses={pid:next(r['value_status'] for r in rows if r['parameter_id']==pid) for pid in {r['parameter_id'] for r in rows}}
    if set(statuses)!=set(PARAMS):errors.append('incomplete final coverage')
    return {'passed':not errors,'errors':errors,'covered_parameters':len(statuses),'statuses':dict(Counter(statuses.values())),
      'observation_rows':len(rows),'object_count':len(objects),'rule_resolved_parameters':len(AUTO),
      'vision_reviewed_parameters':len(ACTIVE),'physical_claims_requiring_review':[]},rows

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('mode',choices=['prepare','run'])
    ap.add_argument('--case',default='radio')
    ap.add_argument('--image',type=Path,help='Optional original static photo; overrides the built-in test fixture.')
    ap.add_argument('--trial',required=True)
    ap.add_argument('--model',default='gpt-6-sol')
    ap.add_argument('--effort',default='medium')
    ap.add_argument('--variant',choices=['r4','r5'],default='r4')
    args=ap.parse_args()
    if not re.fullmatch('[a-z0-9_-]+',args.trial):raise SystemExit('Bad trial')
    fixtures={'radio':m.OUT/'dna-timing-test-20260925/test-photo.jpg','switch':ROOT/'cases/switch.jpg','teapot':ROOT/'cases/teapot.jpg'}
    photo=args.image.resolve() if args.image else fixtures[args.case]
    with Image.open(photo) as photo_file:width,height=photo_file.size
    trial=ROOT/'trials'/args.trial;trial.mkdir(parents=True,exist_ok=True)
    m.dictionary['parameters']=[p for p in D['parameters'] if p['parameter_id'] in ACTIVE]
    runtime=m.runtime_dictionary()
    prompt=INSTRUCTIONS+(REVISION_5 if args.variant=='r5' else '')+f'\n图片文件尺寸{width}×{height}px。以下为需要视觉判断的151项原参数，未改变其定义或取值约束：\n'+runtime
    value=m.schema()['$defs']['known']['properties']['v']
    schema=t.obj({'objects':t.array(t.obj({'i':t.S,'t':{'type':'string','enum':[o['object_type_id'] for o in D['object_types']]},
      'n':t.S,'p':{'type':['string','null']},'b':t.array({'type':'number','minimum':0,'maximum':1},minItems=4,maxItems=4),'proof':t.S,
      'd':t.array(t.obj({'k':{'type':'string','enum':sorted(ACTIVE)},'r':t.S,'v':value,'s':{'type':'string','enum':['o','e']},'note':{'type':['string','null']}}))})),
      'remaining':t.array(t.obj({'k':t.array({'type':'string','enum':sorted(ACTIVE)}),'s':{'type':'string','enum':['u','n']},'why':t.S})),
      'summary':t.array(t.S)})
    def prepare():
        t.dump(trial/'output-schema.json',schema);(trial/'prompt.txt').write_text(prompt,encoding='utf-8')
        manifest={'prepared_at':datetime.now(timezone.utc).isoformat(),'algorithm':'direct-object-local-dna-'+args.variant,
          'dictionary_version':D['schema_version'],'parameter_count':216,'vision_parameter_count':151,'rule_parameter_count':65,
          'rule_parameter_ids':sorted(AUTO),'dictionary_sha256':t.sha(m.DICT.read_bytes()),'photo_sha256':t.sha(photo.read_bytes()),
          'prompt_bytes':len(prompt.encode('utf-8')),'prompt_sha256':t.sha(prompt.encode('utf-8')),
          'photo_original_pixels':[width,height],'case_id':'asset' if args.image else args.case,'previous_answer_included':False,'reference_checklist_included':False,
          'scope':'All216 fields checked by declared evidence/scope rules or direct dictionary-constrained vision. No free feature-to-word mapping stage.'}
        t.dump(trial/'input-manifest.json',manifest);return prompt,manifest
    t.HERE=trial;t.PHOTO=photo;t.prepare=prepare;t.validate=lambda r:validate(r,width,height)
    sys.argv=[str(__file__),args.mode,'--model',args.model,'--effort',args.effort,'--http-only','--respect-system-proxy'];t.main()
if __name__=='__main__':main()
