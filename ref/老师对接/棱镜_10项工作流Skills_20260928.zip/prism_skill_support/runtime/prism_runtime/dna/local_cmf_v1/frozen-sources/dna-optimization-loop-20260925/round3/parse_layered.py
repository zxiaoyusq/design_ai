"""R9/R10: same dictionary, explicit within-carrier composition and controlled granularity.

R9 = full-asset granularity plus layer rules. R10 = the same layer rules with
moodboard-neutral granularity. Both assess all216 fields without a free-description
then mapping stage. Previous parsers and original source photos remain unchanged.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,json,re,sys
from PIL import Image

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'round2'))
import parse_packed as old

t=old.t
STRUCTURAL_CARRIERS={'O01','O02','O03','O04','O07','O08','O10','O14'}
prior_core=old.base.core_ids
def core_ids(typ):
    result=list(prior_core(typ))
    if typ in STRUCTURAL_CARRIERS and 'REL-009' not in result:result.append('REL-009')
    return result
old.base.core_ids=core_ids
old.base.c.core_ids=core_ids

LAYER_RULES="""
本版明确区分记录作用域，原参数定义不变：
1 core增加REL-009，专门检查当前载体内部可见构成单元的重复方式。例如框架内部的窗格、面板上的孔阵、对象组内的重复实体。ref仍为当前载体自身。不能因为上一级记录过重复，就漏掉局部结构的重复；没有适用构成单元时用n并解释。
2 GEO/STR/REL记录形态和构成关系；TEX记录表面图案、纹理或可见状态；OPT/CTX记录反光、透射、投影与取景条件。同一载体可以同时具有规则构成和不规则表面，两项分别按对应原参数记录，不能让一个结论覆盖另一个。
3 光照阴影、环境倒影和透过透明实体看到的后方纹理，不自动成为该实体自身的TEX纹理。可见倒影仍保留在OPT/CTX。若无法区分真实表面纹理与成像影响，TEX用unknown，并保留看得见的光学线索。
4 表面斑驳或磨损可作为可见状态记录，不据此断言是故意设计、制造工艺或真实材料。重复结构与表面状态可以共用一个真实载体，不需为了分层将每个实体复制成两套对象。
5 当一件物体有明显不同的可见表面，仍分开实例；不把覆盖在透明主体外的反光表层混进透明区域。透视造成的形变记录为观察条件，不当成产品实际形变。
6 构成重复与表面重复的范围要明确：REL-009描述本载体内的构成单元；TEX的重复描述表面单元。不把照片背景的格影附会为主体结构。
7 所有148个视觉字段仍需按固定槽位审阅。记录作用域与解析粒度是本次协议，不能更改原字典定义或把未检查字段默认写unknown。
"""

MOODBOARD_RULES="""
本次采用“情绪板中性粒度”，不输入某个国家、用户画像或主观喜好：
目标是保留能区别主要视觉方向、解释组合方式和定位关键裁剪区域的DNA，而非枚举所有微小部件。通常约8至14个前景对象足够，但这是软目标；不能为凑数量遗漏明显不同的区域。
必须保留：整体轮廓；主要色区和光学/纹理分区；有辨识度的构成重复与负空间；显著点缀；主体上的可辨字标；彼此外形或布局不同的重要操控件。即使面积小，只要构成明显的设计特征就保留。
同类且相邻的重复单元可用一个明确对象组表达，并记录其重复方式和布局。不要逐孔、逐网格、逐字符或逐个同类小紧固件重复相同属性。需要单独比较、定位或形态明显不同的单元仍单列。
细小阴影点、不可辨小端帽、与大面同外观的窄边，不必独立建节点；其明显形态信息可记在承载对象中。不能因此漏掉独立操控件、重要红色点缀、可辨字标或大面积覆盖面。
背景与拍摄条件优先统一记在O19的CTX中；只有清楚且会与主体混淆的道具/背景区域才独立建对象。道具说明牌不是主体字标，不需要逐字抄录与设计外观无关的长说明。
这个粒度只限定对象实例范围，216项字典不删减，关键特征不删。输出中的scope由程序标明，后续如果要微小结构细节，应按更细粒度重新解析，而不能把本结果冒充全细节资产。
"""

GROUPING_GUARD="""
合并边界：每个(参数ID,对象ID,参照ID)只能有一条判断。若两个区域需要不同文本内容、不同可见状态或相反光学结论，就不能仅靠note把它们塞进同一个对象；应分开对象或保留一个明确的代表范围。
同样文字/字形重复出现时，情绪板粒度优先保留一个清晰的代表并记录重复存在；不必每次出现都完整抄录。不同内容的主要字标仍分别保留。若选择记录裁切的文字实例，只抄可辨部分，并让该实例与完整字标的对象范围分开。
除core的必填检查外，d中的每个参数优先选择最能表达本图的主要实例；只有其他对象存在明显不同的值、对比或组合关系时再追加。不要给同类对象机械复制同一组闭合、方向、对齐等附加记录。未单独展开的局部不由程序自动继承为已观察事实。
"""

def instructions(profile,revision='b'):
    base=old.INSTRUCTIONS
    if profile=='moodboard':
        base=base.replace('压缩只去重复，不省略对象、字段、可辨文字、明显局部或证据边界；不能为了短而把多种表面合并。',
                          '压缩保留本次粒度下的关键对象、全部原字段及证据边界；明显不同的表面不能合并。')
    return base+LAYER_RULES+(MOODBOARD_RULES+(GROUPING_GUARD if revision=='b' else '') if profile=='moodboard' else '\n本次保持完整资产粒度；仅调整结构/表面/观察条件的作用域，不主动减少已有的细节层级。')

def feature_layer(pid):
    family=pid.split('-')[0]
    return {'GEO':'structure_composition','STR':'structure_composition','REL':'structure_composition',
      'COL':'color_appearance','TEX':'surface_pattern_or_state','OPT':'optical_appearance','CTX':'presentation',
      'TXT':'graphic_expression','EMI':'light_expression','MAT':'physical_evidence','FIN':'physical_evidence',
      'MOT':'declared_study_scope','TOU':'declared_study_scope','SEM':'declared_study_scope'}[family]

def validate(raw,w,h,profile):
    types={o['i']:o['t'] for o in raw['objects']}
    report,rows=old.validate(raw,w,h)
    for row in rows:
        row['feature_layer']=feature_layer(row['parameter_id'])
        if row['parameter_id']=='REL-009' and types.get(row['object_id']) in STRUCTURAL_CARRIERS:
            row['observation_scope']='within_carrier_composition'
        elif row['parameter_id'].startswith('TEX-'):
            row['observation_scope']='visible_surface_pattern_or_state'
    raw['scope']+=f' Granularity={profile}; composition, surface and presentation scopes kept distinct.'
    report['granularity_profile']=profile
    report['internal_composition_checks']=sum(o['object_type_id'] in STRUCTURAL_CARRIERS for o in raw['objects'])
    return report,rows

def build_inputs(photo,profile,revision='b'):
    with Image.open(photo) as im:w,h=im.size
    slots='\ncoverage家族固定槽位（从左至右，每项都须审阅）：\n'+json.dumps(old.base.FAMILIES,ensure_ascii=False,separators=(',',':'))
    prompt=instructions(profile,revision)+'\n148项视觉判断原参数：\n'+old.base.c.runtime_dictionary()+slots+f'\n本次图片文件尺寸：{w}×{h}px。'
    return prompt,old.make_schema(),w,h

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','run']);ap.add_argument('--trial',required=True)
    ap.add_argument('--case',choices=['radio','teapot','switch','chair','phoneboxes','facade'],default='phoneboxes')
    ap.add_argument('--image',type=Path);ap.add_argument('--profile',choices=['full','moodboard'],default='moodboard')
    ap.add_argument('--revision',choices=['a','b'],default='b')
    ap.add_argument('--model',default='gpt-6-astra');ap.add_argument('--effort',default='low');args=ap.parse_args()
    if not re.fullmatch('[a-z0-9_-]+',args.trial):raise SystemExit('Bad trial name')
    photos={'radio':ROOT.parent.parent/'dna-timing-test-20260925/test-photo.jpg','teapot':ROOT.parent/'cases/teapot.jpg',
       'switch':ROOT.parent/'cases/switch.jpg','chair':ROOT.parent/'round2/cases/chair.jpg',
       'phoneboxes':ROOT.parent/'round2/cases/phoneboxes.jpg','facade':ROOT/'cases/facade.jpg'}
    photo=args.image.resolve() if args.image else photos[args.case]
    trial=ROOT/'trials'/args.trial;trial.mkdir(parents=True,exist_ok=True)
    if (trial/'events-timed.jsonl').exists():raise SystemExit('Refusing to overwrite prior inference')
    prompt,schema,w,h=build_inputs(photo,args.profile,args.revision)
    def prepare():
        (trial/'prompt.txt').write_text(prompt,encoding='utf-8');t.dump(trial/'output-schema.json',schema)
        manifest={'prepared_at':datetime.now(timezone.utc).isoformat(),'algorithm':'layered-dna-r9' if args.profile=='full' else 'layered-moodboard-dna-r10'+args.revision,
          'parameter_count':216,'contract_parameter_count':65,'calculated_parameter_count':3,'vision_parameter_count':148,
          'dictionary_version':old.base.c.D['schema_version'],'dictionary_sha256':t.sha(old.base.c.prev.m.DICT.read_bytes()),
          'photo_sha256':t.sha(photo.read_bytes()),'photo_original_pixels':[w,h],
          'prompt_sha256':t.sha(prompt.encode('utf-8')),'prompt_bytes':len(prompt.encode('utf-8')),
          'output_schema_sha256':t.sha((trial/'output-schema.json').read_bytes()),'profile':args.profile,'revision':args.revision,
          'case_id':'asset' if args.image else args.case,'previous_answer_included':False,'reference_checklist_included':False,
          'image_preprocessing':'original bytes unchanged','new_layer_dictionary_parameters':False}
        t.dump(trial/'input-manifest.json',manifest);return prompt,manifest
    t.HERE=trial;t.PHOTO=photo;t.prepare=prepare;t.validate=lambda raw:validate(raw,w,h,args.profile)
    sys.argv=[str(__file__),args.mode,'--model',args.model,'--effort',args.effort,'--http-only','--respect-system-proxy'];t.main()
if __name__=='__main__':main()
