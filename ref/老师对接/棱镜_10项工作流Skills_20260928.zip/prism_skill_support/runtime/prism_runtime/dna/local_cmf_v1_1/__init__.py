"""Versioned, bounded error isolation around the frozen local CMF v1."""

VERSION = "r17-local-cmf-v1.1"
