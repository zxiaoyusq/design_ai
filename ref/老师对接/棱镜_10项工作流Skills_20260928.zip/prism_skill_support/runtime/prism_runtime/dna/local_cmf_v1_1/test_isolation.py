"""Read-only actual-error replay and synthetic counterexamples; zero inference."""
import copy
from pathlib import Path
import tempfile
import unittest

from ..local_cmf_v1 import audit as old_audit, pipeline as old_pipeline
from . import audit, pipeline, common as c
from ..local_cmf_v1.test_boundaries import supported

ROOT_RUN = c.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/closure-20260927"


class IsolationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root = ROOT_RUN / "images/TR001"
        cls.original_n = c.read(root / "normalized.json")
        cls.original_b = c.read(root / "declared-bindings.json")
        cls.original_r = c.read(root / "original-r17-validation.json")

    def setUp(self):
        self.n = copy.deepcopy(self.original_n)
        self.b = copy.deepcopy(self.original_b)
        self.r = copy.deepcopy(self.original_r)

    def run_audit(self):
        return audit.audit_units(self.n, self.b, "TR001", self.r)

    def bad_row(self):
        return next(x for x in self.n["assessments"] if x["parameter_id"] == "GEO-020" and x["object_id"] == "o2")

    def test_actual_seven_errors_localize_without_value_or_report_change(self):
        before = c.canonical([self.n, self.b, self.r])
        result = self.run_audit()
        proof = result["original_error_isolation"]
        self.assertEqual(proof["isolated_count"], 7)
        self.assertEqual(proof["unresolved_count"], 0)
        self.assertTrue(proof["all_original_errors_accounted_for"])
        self.assertEqual(proof["original_errors_unchanged"], self.r["errors"])
        self.assertFalse(result["original_full_216_pass"])
        self.assertTrue(result["ready_for_review"])
        self.assertFalse(result["useful"])
        self.assertEqual(len(result["candidates"]), 119)
        self.assertEqual(c.canonical([self.n, self.b, self.r]), before)
        isolated = [u for u in result["units"] if u.get("original_error_indices")]
        self.assertTrue(all(not u["program_eligible"] and not u["in_cmf_scope"] for u in isolated))
        self.assertEqual(next(u for u in isolated if u["object_id"] == "o2")["value"], [2, 3])

    def test_v1_remains_blocked_on_same_input(self):
        result = old_audit.audit_units(self.n, self.b, "TR001", self.r)
        self.assertEqual(len(result["global_errors"]), 7)
        self.assertEqual(result["candidates"], [])
        self.assertIsNot(pipeline._engine, old_pipeline)
        self.assertIsNot(pipeline._engine._project, old_pipeline._project)
        self.assertEqual(old_pipeline.VERSION, "r17-local-cmf-v1")

    def test_unknown_error_source_keeps_global_block(self):
        self.r["errors"].append("opaque validator problem")
        result = self.run_audit()
        self.assertFalse(result["ready_for_review"])
        self.assertEqual(result["original_error_isolation"]["unresolved_count"], 1)

    def test_nonexistent_carrier_in_error_is_not_guessed(self):
        self.r["errors"].append("GEO-020@o999: incorrect type")
        self.assertFalse(self.run_audit()["ready_for_review"])

    def test_multiple_references_on_same_parameter_carrier_are_ambiguous(self):
        duplicate = copy.deepcopy(self.bad_row())
        duplicate["reference_object_id"] = "o1"
        self.n["assessments"].append(duplicate)
        self.b.append(["GEO-020", "o2", "o1"])
        result = self.run_audit()
        self.assertFalse(result["ready_for_review"])
        item = result["original_error_isolation"]["decisions"][0]
        self.assertIn("Ambiguous", item["reason"])

    def test_repeated_original_error_not_silently_deduplicated(self):
        self.r["errors"].append(self.r["errors"][0])
        result = self.run_audit()
        self.assertFalse(result["ready_for_review"])
        self.assertEqual(len(result["original_error_isolation"]["decisions"]), 8)

    def test_broken_parent_prevents_isolation_and_candidates(self):
        self.n["objects"][2]["parent"] = "absent"
        result = self.run_audit()
        self.assertEqual(result["original_error_isolation"]["isolated_count"], 0)
        self.assertFalse(result["ready_for_review"])

    def test_invalid_region_prevents_isolation_and_candidates(self):
        self.n["objects"][2]["region"] = [1, 0, 0, 1]
        result = self.run_audit()
        self.assertEqual(result["original_error_isolation"]["isolated_count"], 0)
        self.assertFalse(result["ready_for_review"])

    def test_actual_cmf_parameter_error_is_not_in_non_cmf_registry(self):
        row = next(r for r in self.n["assessments"] if r["parameter_id"] == "TEX-002" and r["value_status"] == "known")
        row["value"] = ["invalid-string-field-array"]
        self.r["errors"].append("TEX-002@" + row["object_id"] + ": incorrect type")
        result = self.run_audit()
        self.assertFalse(result["ready_for_review"])
        self.assertIn("not explicitly approved", result["original_error_isolation"]["decisions"][-1]["reason"])

    def test_transitive_cmf_dependency_on_bad_field_keeps_block(self):
        baseline = old_audit.audit_units(self.n, self.b, "TR001", self.r)
        target = next(u for u in baseline["units"] if u["parameter_id"] == "GEO-020" and u["object_id"] == "o2")
        cmf = next(u for u in baseline["units"] if u["in_cmf_scope"] and u["value_status"] == "known")
        cmf["dependency_observation_ids"].append(target["observation_id"])
        result = audit.isolate_errors(baseline, self.n, self.b, self.r)
        self.assertFalse(result["ready_for_review"])
        decision = result["original_error_isolation"]["decisions"][0]
        self.assertIn(cmf["observation_id"], decision["CMF_dependency_observation_ids"])

    def test_error_must_be_independently_reproduced(self):
        self.bad_row()["value"] = "synthetic valid string, not a real correction"
        result = self.run_audit()
        self.assertFalse(result["ready_for_review"])

    def test_missing_explicit_wire_binding_prevents_isolation(self):
        self.b.remove(["GEO-020", "o2", "o2"])
        self.assertFalse(self.run_audit()["ready_for_review"])

    def test_missing_dependency_graph_node_keeps_block(self):
        baseline = old_audit.audit_units(self.n, self.b, "TR001", self.r)
        next(u for u in baseline["units"] if u["in_cmf_scope"])["dependency_observation_ids"] = ["absent"]
        result = audit.isolate_errors(baseline, self.n, self.b, self.r)
        self.assertFalse(result["ready_for_review"])

    def test_existing_three_real_v1_projections_still_verify_both_routes(self):
        for cid, expected in [("R002", 33), ("R005", 43), ("R009", 43)]:
            path = ROOT_RUN / "images" / cid / "cmf.image-dna.json"
            old = old_pipeline.verify_projection(path)
            new = pipeline.verify_projection(path)
            self.assertEqual(old, new)
            self.assertTrue(new["passed"])
            self.assertEqual(new["accepted_count"], expected)

    def test_new_persisted_projection_keeps_false_full_check_and_all_errors(self):
        # Protocol-only fixture, never a real visual verdict for TR001.
        scratch = c.HERE / ".test-scratch"
        scratch.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as tmp:
            root = Path(tmp)
            original_prep = c.read(ROOT_RUN / "images/TR001/preparation.json")
            photo = Path(original_prep["image"]["path"])
            raw = ROOT_RUN / "calls/P-TR001/answer.json"
            source = c.write_new(root / "synthetic-source.json", {"records": [{"image_id": "synthetic-isolation",
                "sha256": c.file_hash(photo), "source_kind": "synthetic", "basis": "Protocol-only fixture using existing bytes; no image judgment"}]})
            folder = root / "prepared"
            pipeline.prepare(photo, "synthetic-isolation", "synthetic", source, folder)
            def receipt(stage, output):
                return c.write_new(root / (stage + ".record.json"), {"stage": stage, "model": "gpt-6-astra",
                    "service_tier": "default", "image_sha256": c.file_hash(photo),
                    "prompt_sha256": c.file_hash(folder / (stage + ".prompt.txt")),
                    "schema_sha256": c.file_hash(folder / (stage + ".schema.json")),
                    "schema_ref": str(folder / (stage + ".schema.json")), "raw_output_sha256": c.file_hash(output),
                    "call_id": "synthetic-" + stage, "source_ref": str(source), "execution_kind": "synthetic_fixture"})
            result = pipeline.accept(folder, raw, receipt("primary", raw))
            self.assertTrue(result["ready_for_review"])
            self.assertFalse(result["original_full_216_pass"])
            proposal = c.read(folder / "review.proposal.json")
            response = c.write_new(root / "synthetic-review.json", supported(proposal))
            final = pipeline.accept_review(folder, response, receipt("review", response))
            self.assertTrue(final["useful_local_cmf"])
            path = Path(final["projection_ref"])
            checked = pipeline.verify_projection(path)
            self.assertTrue(checked["passed"])
            document = c.read(path)
            self.assertFalse(document["source_validation"]["original_full_216_pass"])
            self.assertEqual(len(document["cmf_admission"]["isolated_non_cmf_units"]), 7)
            self.assertEqual(document["cmf_admission"]["original_error_isolation"]["original_errors_unchanged"], self.r["errors"])
            self.assertFalse(document["cmf_admission"]["complete_216_visual_qualified"])
            document["cmf_admission"]["original_error_isolation"]["original_errors_unchanged"] = []
            path.write_text(c.canonical(document), encoding="utf-8")
            with self.assertRaises(ValueError): pipeline.verify_projection(path)


if __name__ == "__main__":
    unittest.main()
