"""Reuse immutable v1 utilities, but freeze both versions' source identities."""
from pathlib import Path
from ..local_cmf_v1 import common as frozen_common
from ..local_cmf_v1.common import *
from . import VERSION

HERE = Path(__file__).resolve().parent


def module_sources():
    records = frozen_common.module_sources() + [file_identity(p) for p in sorted(HERE.glob("*.py"))]
    return sorted(records, key=lambda x: x["path"])
