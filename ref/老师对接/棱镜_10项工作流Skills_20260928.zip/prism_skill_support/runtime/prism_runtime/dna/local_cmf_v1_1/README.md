# R17 local CMF v1.1：受限字段错误隔离

任务CLOSURE-DNA-002。新增独立版本，不修改已冻结的local_cmf_v1、原R17、原字典或历史结果。只执行本地验收，推理由Root负责，仍禁止Fast/priority。

TR001原始R17稿的7个错误都是`GEO-020@对象: incorrect type`。原GEO-020是“柔性形变形态”，要求字符串；实际7行是数字列表。本版本不把列表拼成词、不改unknown/NA、不删除错误。原完整R17校验保持false。

隔离注册表当前**仅允许GEO-020的这一种类型错误**。每项必须同时满足：原错误字符串唯一；PID/载体只能对应一条原观察（多参照不猜）；明确known实例且原始wire绑定唯一；独立重现原根值类型错误；除该类型错外没有其他载体/引用问题；载体/区域/父级与依赖图有效；任何CMF观察的传递依赖闭包都不使用这个错误字段。错误字段仍被阻塞，其原值/状态/位置/错误索引完整留下。

“CMF使用了同一个对象”不等于“CMF数值依赖该对象的每个字段”。这里仍保留并验证该对象的类型、区域、父级、参照、纹理来源；GEO-020描述值没有参与这些元数据或当前CMF计数/分母计算。若发现真正的字段依赖，则保持全局blocked。未知来源错误、其他PID、重复错误/多参照、坏父级/区域、CMF关键字段错误不在本次豁免范围。

## 入口与冻结方式

```text
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_1 prepare --image PATH --image-id TR001 --source-kind trend --source-provenance-ref MANIFEST --output-dir NEW_DIR
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_1 accept --prepared-dir NEW_DIR --raw-output EXISTING_ANSWER --run-record EXISTING_RECORD
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_1 accept-review --prepared-dir NEW_DIR --raw-output REVIEW_ANSWER --run-record REVIEW_RECORD
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_1 verify --path NEW_DIR/cmf.image-dna.json
```

Python入口为`pipeline.prepare/accept/accept_review/verify_projection`，参数与v1相同。运行记录与标准档检查也不变。复用已存在的P-TR001原输出，不重新提取；新准备目录会产生新的提案身份，使用对应review.prompt/schema。

冻结v1的pipeline源文件在独立模块命名空间中加载，使用v1.1的审计和版本信息。没有修改冻结文件或v1模块的运行全局变量。v1.1只增加精确字段隔离与审计输出；原schema/复核协议不变。新准备清单同时记录v1和v1.1代码哈希。

`verify_projection`按持久化parser_version路由：旧v1继续走旧验证器；v1.1从原始模型bytes重新decode，再重算隔离、程序依赖、审核及投影。三份已存在的v1实图投影经旧入口和新路由均通过，准入数保持33/43/43。

## 审计与下游

`cmf-program-audit.json.original_error_isolation`包含原报告全部错误、v1全部全局否决、逐错误判定、唯一行/对象/参照/原值、依赖检查及隔离/未解决计数。原normalized和original-r17-validation完全不变。只有119条独立CMF已知项重新获得**进入同图复核**的资格，不是已可用或视觉正确。

未来实际review通过后，投影的`cmf_admission`额外保留：

- `original_error_isolation`：完整错误去向和判断证据。
- `isolated_non_cmf_units`：被隔离的原7行，原值和错误保持。
- 继承v1全部对象、CMF状态、未准入项与依赖信息；整图负向条件仍未获资格。

`source_validation.original_full_216_pass`仍为false，`complete_216_visual_qualified`也为false。下游不能因此声称整图216通过，也不能把未投影当不存在。范围守卫须使用支持v1.1的官方验证路由，不改变旧聚类器标准。

## 验证和边界

新增15项离线测试：真实7错误保留、119候选恢复、原v1仍阻断同稿、错误来源不明、多参照/重复歧义、坏父级/区域、CMF错误、传递依赖、无法重现类型错、缺wire绑定、缺依赖节点、旧3图验证路由，以及明确synthetic持久化投影/错误审计篡改检测。synthetic测试不是TR001的视觉答案，不计模型调用或准确率。

整个版本仍为待Root独立预检及真实同图review的候选。未新增模型/API调用。注册表不自动扩大到其他非CMF错误；无法准确隔离时继续blocked。这是部分CMF的消费策略版本，不重启已停止的Qwen三轮提示词实验。
