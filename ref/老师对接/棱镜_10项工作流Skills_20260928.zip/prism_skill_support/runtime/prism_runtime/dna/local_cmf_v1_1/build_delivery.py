"""Offline handoff for CLOSURE-DNA-002, reusing the real existing TR001 draft."""
from datetime import datetime, timezone
import io
from pathlib import Path
import unittest

from . import VERSION, common as c, pipeline

LOOP = c.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
RUN = LOOP / "closure-20260927"
OUT = c.PROJECT / "outputs/prism-algorithm-loop-20260926/modules/dna/repairs/CLOSURE-DNA-002/v1.1"


def main():
    c.require(not (OUT / "handoff.json").exists(), "Frozen delivery already exists")
    OUT.mkdir(parents=True, exist_ok=True)
    old_delivery = c.PROJECT / "outputs/prism-algorithm-loop-20260926/modules/dna/repairs/CLOSURE-DNA-001/v1"
    preserved = c.read(old_delivery / "source-hashes.json") + c.read(old_delivery / "delivery-hashes.json")["files"]
    for item in preserved:
        c.verify_identity(item)
    c.verify_freeze()
    root_folder = RUN / "images/TR001"
    prep = c.read(root_folder / "preparation.json")
    raw = Path(c.read(root_folder / "acceptance.json")["raw_source_identity"]["path"])
    record = Path(c.read(root_folder / "primary.run-audit.json")["record_ref"]["path"])
    inputs = [c.file_identity(LOOP / "dispatches/CLOSURE-DNA-002.md"), c.file_identity(raw), c.file_identity(record)]
    inputs.extend(c.file_identity(root_folder / name) for name in ["preparation.json", "acceptance.json", "normalized.json",
        "declared-bindings.json", "original-r17-validation.json", "cmf-program-audit.json"])
    destination = OUT / "TR001-local-replay"
    pipeline.prepare(prep["image"]["path"], "TR001", prep["source_kind"], prep["source_provenance"]["path"], destination)
    result = pipeline.accept(destination, raw, record)
    c.require(result["ready_for_review"] and not result["original_full_216_pass"], str(result))
    local = c.read(destination / "cmf-program-audit.json")
    proof = local["original_error_isolation"]
    c.require(proof["isolated_count"] == 7 and proof["unresolved_count"] == 0, "Unexpected error isolation")
    for name in ["normalized.json", "declared-bindings.json", "original-r17-validation.json"]:
        c.require(c.canonical(c.read(destination / name)) == c.canonical(c.read(root_folder / name)), "Changed original " + name)
    schemas_equal = c.canonical(c.read(destination / "primary.schema.json")) == c.canonical(c.read(root_folder / "primary.schema.json"))
    c.require(schemas_equal, "Producer schema changed")
    old_projections = []
    for cid in ["R002", "R005", "R009"]:
        path = RUN / "images" / cid / "cmf.image-dna.json"
        old_projections.append({"image_id": cid, "projection_identity": c.file_identity(path),
                               "verification": pipeline.verify_projection(path)})
        inputs.append(c.file_identity(path))
    stream = io.StringIO()
    names = ["prism_runtime.dna.local_cmf_v1_1.test_isolation", "prism_runtime.dna.local_cmf_v1.test_boundaries"]
    tests = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names))
    c.write_new(OUT / "offline-tests.txt", stream.getvalue(), text=True)
    c.require(tests.wasSuccessful(), "Offline boundary failure")
    for item in preserved + inputs:
        c.verify_identity(item)
    sources = c.module_sources() + [c.file_identity(c.HERE / "README.md")]
    c.write_new(OUT / "source-hashes.json", sources)
    c.write_new(OUT / "input-hashes.json", inputs)
    c.write_new(OUT / "preserved-v1-hashes.json", preserved)
    c.write_new(OUT / "verification.json", {"version": VERSION, "checked_utc": datetime.now(timezone.utc).isoformat(),
        "tests": tests.testsRun, "new_tests": 15, "v1_regressions": tests.testsRun - 15,
        "failures": len(tests.failures), "errors": len(tests.errors), "owner_model_calls": 0,
        "original_complete_R17_pass": False, "original_errors_preserved": proof["original_errors_unchanged"],
        "isolated_errors": proof["isolated_count"], "CMF_candidates_for_review": len(local["candidates"]),
        "root_raw_output_reused_unchanged": True, "normalized_rows_and_regions_unchanged": True,
        "new_model_review_performed": False, "producer_schema_unchanged": schemas_equal,
        "old_v1_projections": old_projections})
    c.write_new(OUT / "self-assessment.json", {"module": "dna", "issue_id": "CLOSURE-DNA-002", "version": VERSION,
        "status": "partial_ready_for_independent_review", "qualified": False,
        "qualified_scope": "Offline unique GEO-020 incorrect-type isolation outside CMF observation dependency closure; unmodified original failure audit and old-version compatibility",
        "ready_for_existing_TR001_same_image_review": True, "production_qualified": False,
        "original_full_R17_pass": False, "visual_accuracy_established": False, "owner_model_calls": 0,
        "known_limits": ["Only GEO-020 incorrect-type is registered; other errors remain blocked.",
            "119 candidates have not yet received real same-image review.",
            "Dependence means declared/program CMF value dependencies and carrier metadata; unseen visual mistakes still require the same-image reviewer.",
            "Whole-image negative conditions remain unqualified."],
        "old_Qwen_issue_status": "stopped_after3_cycles_not_reopened"})
    c.write_new(OUT / "handoff.json", {"module": "dna", "issue_id": "CLOSURE-DNA-002", "version": VERSION,
        "status": "partial_ready_for_independent_review", "source_entrypoint": str(c.HERE / "pipeline.py"),
        "cli": "python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_1",
        "operations": ["prepare", "accept", "accept-review", "verify"],
        "readme_ref": str(c.HERE / "README.md"), "source_hashes_ref": str(OUT / "source-hashes.json"),
        "self_assessment_ref": str(OUT / "self-assessment.json"), "verification_ref": str(OUT / "verification.json"),
        "local_replay": str(destination), "review_schema_ref": result["review_schema_ref"], "review_prompt_ref": result["review_prompt_ref"],
        "isolation_ref": str(destination / "cmf-program-audit.json"), "candidate_CMF_observations": len(local["candidates"]),
        "original_full_R17_pass": False, "isolated_errors_retained": 7, "owner_model_calls": 0,
        "root_next_step": "Independently inspect and prepare/accept TR001 in a new Root-owned v1.1 directory using existing P-TR001 answer and record, then if qualified perform its same-image review only. Never redo primary or overwrite the old v1 TR001 failure.",
        "compatibility": "verify_projection routes original v1 artifacts to original v1 verifier; v1.1 reconstructs errors, dependency proof, review and projection. Old files and globals unchanged.",
        "export_changes": ["cmf_admission.original_error_isolation", "cmf_admission.isolated_non_cmf_units"],
        "new_success_claim": "none; machine eligibility only, no new semantic value or visual PASS",
        "rollback": "Keep the new module unused; old v1 behavior and all33/43/43 projections remain unchanged."})
    c.write_new(OUT / "delivery-hashes.json", {"version": VERSION,
        "files": [c.file_identity(p) for p in sorted(OUT.rglob("*")) if p.is_file() and p.name != "delivery-hashes.json"]})
    print(c.canonical({"handoff": str(OUT / "handoff.json"), "tests": tests.testsRun,
        "candidates": len(local["candidates"]), "original_R17_pass": False, "owner_model_calls": 0}))


if __name__ == "__main__":
    main()
