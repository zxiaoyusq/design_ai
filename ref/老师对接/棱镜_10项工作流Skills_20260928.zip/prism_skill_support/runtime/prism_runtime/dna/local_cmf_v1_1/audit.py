"""Isolate only proven, uniquely located GEO-020 type errors, never fix values."""
from collections import Counter
import copy
import re

from ..local_cmf_v1 import audit as frozen_audit
from ..local_cmf_v1.audit import PARAMETERS, CMF_PIDS, review_schema, resolve_review
from .common import canonical, jsonschema

# A reviewed permission registry, not 'ignore every out-of-scope error'.
# GEO-020 is a scalar visual description; it is not a layout ID, parent,
# bbox, reference, texture origin or current CMF counting/colour denominator.
ISOLATION_REGISTRY = {
    "GEO-020": {"error_kind": "incorrect type", "original_value_schema": {"type": "string"},
        "reason": "Non-CMF flexible-deformation description; never used to construct carrier/region metadata or current CMF value dependencies"}}
ERROR = re.compile(r"^([A-Z]{3}-[0-9]{3})@(o(?:0|[1-9][0-9]*)): incorrect type$")
PREFIX = "Unisolated original validation failure: "


def _dependency_reach(units, start):
    """Return transitive observation dependencies, or fail on an unsafe graph."""
    reached, active = set(), set()
    def visit(oid):
        if oid not in units:
            raise ValueError("Missing dependency observation: " + str(oid))
        if oid in active:
            raise ValueError("Cyclic observation dependency: " + str(oid))
        if oid in reached:
            return
        active.add(oid)
        for dependency in units[oid]["dependency_observation_ids"]:
            visit(dependency)
        active.remove(oid)
        reached.add(oid)
    visit(start)
    reached.discard(start)
    return reached


def isolate_errors(base_result, normalized, declared_bindings, original_report):
    """Pure audit transformation; retains the unmodified original audit/report.

    Removing a global veto is permitted only when that exact error remains on
    a unique known row and is outside every CMF observation dependency closure.
    """
    result = copy.deepcopy(base_result)
    errors = list((original_report or {}).get("errors", []))
    counts = Counter(errors)
    declared = Counter(tuple(x) for x in declared_bindings)
    object_map = {o["object_id"]: o for o in normalized["objects"]}
    unit_map = {u["observation_id"]: u for u in result["units"]}
    # An independent carrier/layout failure cannot be masked by field isolation.
    context_errors = [e for e in base_result["global_errors"] if not e.startswith(PREFIX)]
    closures, closure_errors = {}, []
    for u in result["units"]:
        if not u["in_cmf_scope"]:
            continue
        try:
            closures[u["observation_id"]] = _dependency_reach(unit_map, u["observation_id"])
        except ValueError as exc:
            closure_errors.append(str(exc))
    decisions = []
    for position, error in enumerate(errors):
        decision = {"original_error_index": position, "original_error": error,
            "status": "unresolved_global", "observation_id": None, "reason": None,
            "CMF_dependency_observation_ids": [], "original_value_changed": False}
        match = ERROR.fullmatch(error) if isinstance(error, str) else None
        if match is None:
            decision["reason"] = "Error format/source is not in the bounded registry"
        else:
            pid, oid = match.groups()
            candidates = [u for u in result["units"] if u["parameter_id"] == pid and u["object_id"] == oid]
            if pid not in ISOLATION_REGISTRY or pid in CMF_PIDS:
                decision["reason"] = "Parameter not explicitly approved for this isolation version"
            elif counts[error] != 1 or len(candidates) != 1:
                decision["reason"] = "Ambiguous error or multiple observations/references for this PID/carrier"
            else:
                u = candidates[0]
                decision.update(observation_id=u["observation_id"], parameter_id=pid, object_id=oid,
                    reference_object_id=u["reference_object_id"], row_index=u["row_index"],
                    original_value=copy.deepcopy(u["value"]), original_state=u["value_status"])
                schema = PARAMETERS[pid]["value_schema"]
                violations = list(jsonschema.Draft202012Validator(schema).iter_errors(u["value"]))
                dependents = [key for key, deps in closures.items() if u["observation_id"] in deps]
                decision["CMF_dependency_observation_ids"] = dependents
                identity = (pid, oid, u["reference_object_id"])
                if canonical(schema) != canonical(ISOLATION_REGISTRY[pid]["original_value_schema"]):
                    decision["reason"] = "Original parameter schema differs from reviewed registry"
                elif u["value_status"] != "known" or u["is_global_fallback"] or declared[identity] != 1:
                    decision["reason"] = "Not a unique explicitly declared known observation"
                elif oid not in object_map or u["reference_object_id"] not in object_map:
                    decision["reason"] = "Carrier or reference missing"
                elif u["program_errors"] != ["Known value violates original value schema"]:
                    decision["reason"] = "Other carrier/value/reference failures prevent isolation"
                elif not any(v.validator == "type" and list(v.path) == [] for v in violations):
                    decision["reason"] = "Original root value-type error was not independently reproduced"
                elif context_errors or closure_errors:
                    decision["reason"] = "Carrier/region or dependency context is unsafe"
                elif dependents:
                    decision["reason"] = "A CMF observation depends on this invalid field"
                elif result["global_errors"].count(PREFIX + error) != 1:
                    decision["reason"] = "Original veto cannot be uniquely located"
                else:
                    decision["status"] = "isolated_non_cmf_invalid_observation"
                    decision["reason"] = ISOLATION_REGISTRY[pid]["reason"]
                    result["global_errors"].remove(PREFIX + error)
                    u["original_error_indices"] = [position]
                    u["program_errors"].append("Original R17 error retained on this isolated row: " + error)
                    u["isolation_disposition"] = decision["status"]
        decisions.append(decision)
    # Never erase a newly detected dependency problem merely because the old
    # global validator did not know this version's observation dependency graph.
    result["global_errors"].extend("Unsafe CMF dependency graph: " + e for e in closure_errors)
    candidates = []
    for u in result["units"]:
        u["program_eligible"] = bool(u["in_cmf_scope"] and u["value_status"] == "known"
                                     and not u["program_errors"] and not result["global_errors"])
        if u["program_eligible"]:
            candidates.append(u["observation_id"])
    result["candidates"] = candidates
    result["ready_for_review"] = bool(candidates) and not result["global_errors"]
    result["useful"] = False
    result["original_error_isolation"] = {"version": "r17-local-cmf-v1.1",
        "registry": copy.deepcopy(ISOLATION_REGISTRY), "original_full_validation_pass": bool((original_report or {}).get("passed")),
        "original_errors_unchanged": errors, "v1_global_errors_unchanged": copy.deepcopy(base_result["global_errors"]),
        "all_original_errors_accounted_for": len(decisions) == len(errors), "decisions": decisions,
        "isolated_count": sum(d["status"] == "isolated_non_cmf_invalid_observation" for d in decisions),
        "unresolved_count": sum(d["status"] == "unresolved_global" for d in decisions),
        "original_values_or_states_changed": False, "carrier_metadata_changed": False,
        "CMF_values_depend_on_carrier_metadata_not_every_property_of_that_carrier": True,
        "does_not_qualify_visual_correctness": True}
    return result


def audit_units(normalized, declared_bindings, image_id, original_report=None):
    original = frozen_audit.audit_units(normalized, declared_bindings, image_id, original_report)
    return isolate_errors(original, normalized, declared_bindings, original_report)
