"""Run frozen v1 engine in a separate module namespace with v1.1 audit only.

No frozen source or shared module globals are patched. Old projections continue
to use their original verifier. The primary producer and review wire are intact.
"""
import copy
import importlib.util
from pathlib import Path

from ..local_cmf_v1 import pipeline as frozen_pipeline
from . import VERSION
from .common import read, require

_spec = importlib.util.spec_from_file_location(__package__ + "._frozen_engine", Path(frozen_pipeline.__file__))
_engine = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_engine)
_frozen_project = _engine._project


def _project_with_isolation(folder, manifest, normalized, units, proposal, response, resolution, review_call):
    document = _frozen_project(folder, manifest, normalized, units, proposal, response, resolution, review_call)
    document["cmf_admission"]["original_error_isolation"] = copy.deepcopy(units["original_error_isolation"])
    document["cmf_admission"]["isolated_non_cmf_units"] = [copy.deepcopy(u) for u in units["units"]
        if u.get("isolation_disposition") == "isolated_non_cmf_invalid_observation"]
    return document


# This engine has its own globals; frozen_pipeline._project remains untouched.
_engine._project = _project_with_isolation
prepare = _engine.prepare
accept = _engine.accept
accept_review = _engine.accept_review


def verify_projection(path):
    document = read(path)
    version = document.get("provenance", {}).get("parser_version")
    if version == "r17-local-cmf-v1":
        return frozen_pipeline.verify_projection(path)
    require(version == VERSION, "Unsupported CMF projection version")
    return _engine.verify_projection(path)
