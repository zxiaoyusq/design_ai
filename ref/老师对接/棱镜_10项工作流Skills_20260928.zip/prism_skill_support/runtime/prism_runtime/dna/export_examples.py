"""Re-export three frozen R70 calibration examples; offline only."""
from pathlib import Path
import json
from prism_runtime.dna.adapter import PROJECT, adapt_normalized, verify_export

def main():
    dataset=PROJECT/'outputs/01a0c2a0-b850-7fd1-a032-78e192743557/dna-optimization-loop-20260925/pdf-cmf-ee1-r70-20260926'
    output=PROJECT/'outputs/prism-algorithm-loop-20260926/modules/dna'
    (output/'examples-v0.2').mkdir(parents=True,exist_ok=True)
    result=[]
    for aid in ['u012','u051','u132']:
        trial=dataset/'trials'/aid
        document=adapt_normalized(trial/'normalized-analysis.json',image_id='cmf-ee1-calibration:'+aid,
            source_kind='calibration',image_path=dataset/'images'/f'{aid}.png',
            source_provenance_ref=dataset/'manifest.json',
            source_kind_basis='User-supplied CMF PDF used for frozen parser validation. This is not an asserted trend or user-research sample.',
            parser_version='R70 / qwen3.8-flash / original DNA v0.3',
            validation_ref=trial/'benchmark-result.json',raw_output_ref=trial/'final-wire.json')
        dest=output/'examples-v0.2'/f'{aid}.image-dna.json'
        dest.write_text(json.dumps(document,ensure_ascii=False,indent=2),encoding='utf-8')
        result.append({'image_id':document['image_id'],'path':dest.as_posix(),'source_kind':document['source_kind'],**verify_export(document)})
    (output/'examples-index-v0.2.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'examples':result,'new_paid_calls':0},ensure_ascii=False))

if __name__=='__main__':main()
