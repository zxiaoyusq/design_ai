"""Bounded offline protocol tests; never supplies corrected visual answers."""
from pathlib import Path
import copy
import hashlib
import json
import re
import subprocess
import sys
import unittest

from prism_runtime.dna import r70_review_contract_patch as patch
import jsonschema

RUN = patch.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/qwen-cli-20260927/runs/full120-qwen-v1-20260927"

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def digest(data):
    return hashlib.sha256(patch.compact(data).encode()).hexdigest()

class ReviewContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = {}
        for case in ["R002", "R005"]:
            folder = RUN / "jobs" / case / "dna" / case
            raw = read(folder / "initial-wire.json")
            meta = read(folder / "input-manifest.json")
            v, n = patch.validate(raw, *meta["photo_original_pixels"])
            cls.data[case] = {"raw": raw, "scope": patch.review_scope(raw, n),
                "old_scope": read(folder / "visual-review-scope.json"),
                "reply": read(RUN / "jobs" / case / "calls" / (case + "-visual-review") / "output.json")}

    def setUp(self):
        self.raw = copy.deepcopy(self.data["R005"]["raw"])
        self.scope = copy.deepcopy(self.data["R005"]["scope"])

    def preflight(self, dna=None, review=None, metadata=None, new=None):
        # Grammar-only fragments; no visual output is applied or certified.
        response = {"dna_edits": dna or [], "review_edits": review or [], "object_edits": metadata or [], "new_objects": new or []}
        return patch.review_reply_preflight(self.raw, response, self.scope)["diagnostics"]

    def test_scope_never_expands_v1_allowed_pids(self):
        for d in self.data.values():
            self.assertEqual(d["scope"]["allowed_pids"], d["old_scope"]["allowed_pids"])

    def test_r002_original_field_is_explicitly_read_only(self):
        contract = self.data["R002"]["scope"]["edit_contract"]
        row = next(x for x in contract["read_only_existing_fields"] if x["object_id"] == 5 and x["field_key"] == "STR-007")
        self.assertEqual(row["original_name"], "接缝路径")
        snapshot = next(x for x in contract["field_snapshots"] if x[0:2] == [5, "STR-007"])
        self.assertEqual(snapshot[3], [])
        self.assertIn("GEO-012", contract["allowed_pids_unchanged"])

    def test_r005_core_locks_are_explicit(self):
        rows = self.scope["edit_contract"]["field_snapshots"]
        for pid in ["OPT-001", "OPT-002", "OPT-007"]:
            row = next(x for x in rows if x[0:2] == [5, pid])
            self.assertTrue(row[4]); self.assertEqual(row[3], ["set"])

    def test_saved_r002_reports_scope_and_final_binding_errors(self):
        d = self.data["R002"]
        result = patch.review_reply_preflight(d["raw"], d["reply"], d["scope"])
        codes = [x["code"] for x in result["diagnostics"]]
        self.assertEqual(codes.count("pid_outside_exact_review_scope"), 1)
        self.assertEqual(codes.count("proposed_binding_incompatible"), 4)

    def test_saved_r005_reports_three_core_removals_and_true_number(self):
        d = self.data["R005"]
        result = patch.review_reply_preflight(d["raw"], d["reply"], d["scope"])
        codes = [x["code"] for x in result["diagnostics"]]
        self.assertEqual(codes.count("cannot_remove_original_core"), 3)
        self.assertEqual(codes.count("proposed_original_value_type_violation"), 1)

    def test_actual_invalid_replies_still_raise_exact_original_errors(self):
        expected = {"R002": "PID outside frozen visual-review facets", "R005": "Cannot remove required core or supply a remove value"}
        for cid, d in self.data.items():
            before = digest(d["raw"])
            with self.assertRaisesRegex(ValueError, expected[cid]):
                patch.apply_correction(d["raw"], d["reply"], d["scope"])
            self.assertEqual(digest(d["raw"]), before)

    def test_preflight_is_read_only_and_not_full_pass_certificate(self):
        for d in self.data.values():
            before = [digest(d[k]) for k in ["raw", "reply", "scope"]]
            result = patch.review_reply_preflight(d["raw"], d["reply"], d["scope"])
            self.assertEqual([digest(d[k]) for k in ["raw", "reply", "scope"]], before)
            self.assertTrue(result["not_a_complete_validator"])
            self.assertFalse(result["host_selected_or_applied_repairs"])

    def test_remove_false_is_not_json_null(self):
        diagnostics = self.preflight(dna=[{"op":"remove","object_id":3,"pid":"GEO-013","old":"内凹","value":False}])
        self.assertIn("remove_value_must_be_json_null", [d["code"] for d in diagnostics])

    def test_exact_old_type_distinguishes_false_from_zero(self):
        diagnostics = self.preflight(dna=[{"op":"set","object_id":6,"pid":"TXT-008","old":0,"value":False}])
        self.assertIn("old_value_or_key_mismatch", [d["code"] for d in diagnostics])

    def test_add_does_not_mean_overwrite(self):
        diagnostics = self.preflight(dna=[{"op":"add","object_id":6,"pid":"TXT-008","old":None,"value":False}])
        self.assertIn("add_requires_absent_key_and_null_old", [d["code"] for d in diagnostics])

    def test_core_remove_uses_old_type_even_when_new_type_proposed(self):
        diagnostics = self.preflight(dna=[{"op":"remove","object_id":5,"pid":"OPT-001","old":"其他","value":None}],
            metadata=[{"object_id":5,"field":"type","old":"O05","value":"O15"}])
        self.assertIn("cannot_remove_original_core", [d["code"] for d in diagnostics])

    def test_full_review_state_required(self):
        for state in ["u", "n", "known", None, False]:
            with self.subTest(state=state):
                result = self.preflight(review=[{"pid":"EMI-001","old_state":"not_applicable","state":state}])
                self.assertIn("review_state_requires_full_explicit_string", [d["code"] for d in result])

    def test_old_review_state_checked_against_effective_value(self):
        result = self.preflight(review=[{"pid":"EMI-001","old_state":"unknown","state":"unknown"}])
        self.assertIn("old_review_state_mismatch", [d["code"] for d in result])

    def test_known_reference_cannot_default_to_self(self):
        result = self.preflight(dna=[{"op":"add","object_id":6,"pid":"TXT-009","old":None,"value":0.05}])
        self.assertIn("known_value_requires_nonself_reference", [d["code"] for d in result])

    def test_legal_existing_reference_and_old_value_are_preserved(self):
        result = self.preflight(dna=[{"op":"set","object_id":6,"pid":"TXT-009@3","old":0.05,"value":0.05}])
        self.assertEqual(result, [])

    def test_unknown_does_not_require_inventing_nonself_reference(self):
        result = self.preflight(dna=[{"op":"add","object_id":6,"pid":"TXT-009","old":None,"value":None}])
        self.assertNotIn("known_value_requires_nonself_reference", [d["code"] for d in result])

    def test_missing_reference_rejected_even_for_unknown(self):
        result = self.preflight(dna=[{"op":"add","object_id":6,"pid":"TXT-009@999","old":None,"value":None}])
        self.assertIn("reference_id_not_declared", [d["code"] for d in result])

    def test_core_extra_reference_forbidden(self):
        result = self.preflight(dna=[{"op":"add","object_id":2,"pid":"COL-006@1","old":None,"value":"深灰金属色"}])
        self.assertIn("core_extra_reference_forbidden", [d["code"] for d in result])

    def test_malformed_new_carrier_does_not_authorize_reference(self):
        result = self.preflight(dna=[{"op":"add","object_id":6,"pid":"TXT-009@7","old":None,"value":0.05}], new=[{"id":7}])
        self.assertIn("reference_id_not_declared", [d["code"] for d in result])

    def test_detailed_schemas_are_valid_and_keep_seven_key_wire(self):
        static = patch.correction_schema()
        jsonschema.Draft202012Validator.check_schema(static)
        self.assertEqual(set(static["required"]), set(patch.prior.correction_schema()["required"]))
        for d in self.data.values():
            dynamic = patch.request_schema(d["raw"], d["scope"])
            jsonschema.Draft202012Validator.check_schema(dynamic)
            self.assertTrue(list(jsonschema.Draft202012Validator(dynamic).iter_errors(d["reply"])))

    def test_schema_allows_reference_syntax_but_not_outside_scope(self):
        dynamic = patch.request_schema(self.raw, self.scope)
        pattern = dynamic["properties"]["dna_edits"]["items"]["properties"]["pid"]["pattern"]
        self.assertTrue(re.fullmatch(pattern, "TXT-009@3"))
        self.assertFalse(re.fullmatch(pattern, "STR-007"))
        self.assertFalse(re.fullmatch(pattern, "TXT-009@o3"))

    def test_primary_validator_edit_engine_and_v1_are_unchanged(self):
        self.assertIs(patch.build_inputs, patch.prior.build_inputs)
        self.assertIs(patch.validate, patch.prior.validate)
        self.assertIs(patch.apply_correction, patch.prior.apply_correction)
        self.assertIs(patch.validate_after, patch.prior.validate_after)

    def test_model_facing_contract_contains_reference_and_read_only_rules(self):
        d = self.data["R002"]
        prompt = patch.critic_prompt(d["raw"], d["scope"])
        self.assertIn('"original_name":"接缝路径"', prompt)
        self.assertIn("不能set/add/remove", prompt)
        self.assertIn("原编辑器先处理dna_edits", prompt)
        self.assertIn("已知值必须有非自身参照", prompt)

    def test_sidecar_can_be_loaded_by_absolute_path_outside_project_cwd(self):
        code = "import importlib.util,sys;s=importlib.util.spec_from_file_location('standalone_probe',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print(m.VERSION)"
        result = subprocess.run([sys.executable, "-B", "-X", "utf8", "-c", code, str(Path(patch.__file__).resolve())],
                                cwd=patch.PROJECT.parent, capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), patch.VERSION)

if __name__ == "__main__":
    unittest.main()
