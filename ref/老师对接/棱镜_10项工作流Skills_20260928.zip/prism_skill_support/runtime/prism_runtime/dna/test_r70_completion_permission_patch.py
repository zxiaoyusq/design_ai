"""Final-cycle offline checks. Existing model failures are never repaired here."""
from pathlib import Path
import copy
import subprocess
import sys
import unittest

from prism_runtime.dna import r70_completion_permission_patch as patch
from prism_runtime.dna.test_r70_reference_edit_patch import empty_reply, synthetic_draft
import jsonschema

RUN = patch.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/qwen-cli-20260927/runs/dna-reference-v3-two-image-retest"


def read(path):
    return patch.loads(path.read_text(encoding="utf-8"))


class CompletionPermissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = {}
        for cid in ["R002", "R005"]:
            folder = RUN / "jobs" / cid / "dna" / cid
            raw = read(folder / "initial-wire.json")
            meta = read(folder / "input-manifest.json")
            v, n = patch.validate(raw, *meta["photo_original_pixels"])
            cls.cases[cid] = {"raw": raw, "meta": meta, "validation": v, "normalized": n}
        c = cls.cases["R002"]
        c["old_scope"] = read(RUN / "jobs/R002/dna/R002/visual-review-scope.json")
        c["scope"] = patch.review_scope(c["raw"], c["normalized"])
        c["reply"] = read(RUN / "jobs/R002/calls/R002-visual-review/output.txt")

    def test_r005_missing_issues_stays_unreviewable_and_rejected(self):
        c = self.cases["R005"]
        before = patch.compact(c["raw"])
        self.assertNotIn("issues", c["raw"])
        self.assertFalse(patch.can_review(c["raw"]))
        self.assertFalse(c["validation"]["passed"])
        self.assertIn("Expected objects/frame/review/issues", str(c["validation"]["errors"]))
        with self.assertRaises(ValueError):
            patch.review_scope(c["raw"], None)
        self.assertEqual(patch.compact(c["raw"]), before)

    def test_missing_issue_snapshot_uses_no_empty_list_default(self):
        p = patch.initial_issue_policy(self.cases["R005"]["raw"])
        self.assertFalse(p["issues_key_present"])
        self.assertIsNone(p["initial_issues"])
        self.assertIsNone(p["initial_issue_count"])
        self.assertFalse(p["host_filled_or_cleared_issues"])

    def test_r002_has_no_reference_diagnostics_or_extra_grants(self):
        c = self.cases["R002"]
        self.assertEqual(patch.reference_diagnostics(c["raw"]), [])
        self.assertEqual(c["scope"]["reference_repair_contract"]["extra_cell_grants"], {})

    def test_r002_str006_valid_reference_is_explicitly_readonly(self):
        table = self.cases["R002"]["scope"]["fresh_permission_table"]
        row = next(r for r in table["existing_fields"] if r[0] == 5 and r[2] == "STR-006@3")
        self.assertEqual(row, [5, "O15", "STR-006@3", 0.02, []])
        definition = next(r for r in table["read_only_original_parameters"] if r[0] == "STR-006")
        self.assertEqual(definition[2], patch.P["STR-006"]["definition"])

    def test_r002_bad_reply_retains_same_rejection_in_v3_and_v4(self):
        c = self.cases["R002"]
        before = patch.compact([c["raw"], c["reply"]])
        for algo, scope in [(patch.prior, c["old_scope"]), (patch, c["scope"])]:
            with self.assertRaisesRegex(ValueError, "Edit outside diagnosed reference cell"):
                algo.apply_correction(c["raw"], c["reply"], scope)
        self.assertEqual(patch.compact([c["raw"], c["reply"]]), before)

    def test_initial_r002_issue_is_permanent_under_frozen_protocol(self):
        c = self.cases["R002"]
        r = empty_reply()  # Synthetic no-op probe, not a real image-review answer.
        final, _ = patch.apply_correction(c["raw"], r, c["scope"])
        self.assertEqual(final["issues"], c["raw"]["issues"])
        report, _ = patch.validate_after(c["raw"], final, r, c["scope"], *c["meta"]["photo_original_pixels"])
        self.assertFalse(report["passed"])
        self.assertIn("Model or evidence issue", str(report["structure_validation"]["errors"]))
        self.assertFalse(c["scope"]["initial_issue_policy"]["original_review_can_clear_initial_issues"])

    def test_permission_and_wire_scopes_unchanged(self):
        c = self.cases["R002"]
        new = copy.deepcopy(c["scope"])
        for key in ["fresh_permission_table", "initial_issue_policy", "producer_version"]:
            del new[key]
        expected = patch.prior.review_scope(c["raw"], c["normalized"])
        self.assertEqual(new, expected)
        self.assertEqual(new["review_wire_version"], patch.prior.VERSION)

    def test_diagnosed_synthetic_cell_keeps_only_original_v3_grant(self):
        d = synthetic_draft()
        s = patch.review_scope(d, None)
        self.assertEqual(s["reference_repair_contract"]["extra_cell_grants"], {"3": {"STR-006": ["STR-006"]}})
        row = next(x for x in s["fresh_permission_table"]["existing_fields"] if x[0] == 3 and x[2] == "STR-006")
        self.assertEqual(row[-1], ["set", "remove"])

    def test_core_deletion_not_advertised(self):
        c = self.cases["R002"]
        table = c["scope"]["fresh_permission_table"]
        for oid, otype, key, old, ops in table["existing_fields"]:
            pid = patch.KEY.fullmatch(key).group(1)
            if pid in patch.CORE.get(otype, []):
                self.assertNotIn("remove", ops)

    def test_changed_permission_table_is_not_sent_to_model(self):
        c = self.cases["R002"]
        scope = copy.deepcopy(c["scope"])
        row = next(r for r in scope["fresh_permission_table"]["existing_fields"] if r[0] == 5 and r[2] == "STR-006@3")
        row[-1] = ["remove"]
        with self.assertRaisesRegex(ValueError, "Permission presentation is stale or changed"):
            patch.critic_prompt(c["raw"], scope)

    def test_changed_issue_snapshot_is_not_sent_to_model(self):
        c = self.cases["R002"]
        scope = copy.deepcopy(c["scope"])
        scope["initial_issue_policy"]["initial_issues"] = []
        with self.assertRaisesRegex(ValueError, "Issue snapshot changed"):
            patch.critic_prompt(c["raw"], scope)

    def test_raw_three_calls_were_complete_stop_not_length(self):
        for cid, stage in [("R002", "primary"), ("R002", "visual-review"), ("R005", "primary")]:
            folder = RUN / "jobs" / cid / "calls" / (cid + "-" + stage)
            p = read(folder / "provider-response.json")
            self.assertEqual(p["http_status"], 200)
            self.assertEqual(p["data"]["output"]["choices"][0]["finish_reason"], "stop")
            self.assertFalse(read(folder / "request.json")["parameters"]["enable_thinking"])

    def test_primary_schema_and_dictionary_contract_preserved(self):
        c = self.cases["R005"]
        manifest = read(Path(c["meta"]["source_manifest_ref"]))
        photo = Path(next(r for r in manifest["records"] if r["image_id"] == "R005")["path"])
        old, schema0, w0, h0, _ = patch.prior.build_inputs(photo)
        new, schema1, w1, h1, _ = patch.build_inputs(photo)
        self.assertTrue(new.startswith(old))
        self.assertEqual(schema1, schema0)
        self.assertEqual((w1, h1), (w0, h0))
        self.assertEqual(set(schema1["required"]), {"objects", "frame", "review", "issues"})
        self.assertIn("issues只记录你未完成的重要可见特征或区域错误", new)
        with self.assertRaises(jsonschema.ValidationError):
            jsonschema.validate(c["raw"], schema1)

    def test_review_prompt_keeps_original_defs_and_names_readonly(self):
        c = self.cases["R002"]
        prompt = patch.critic_prompt(c["raw"], c["scope"])
        self.assertIn('"STR-006@3",0.02,[]', prompt)
        self.assertIn("readonly字段若无需修正就原样保留", prompt)
        self.assertIn("原引擎不会删除初稿issues", prompt)
        self.assertNotIn("dna_edits每项", prompt)

    def test_existing_engine_and_acceptance_functions_exact_aliases(self):
        for name in ["validate", "can_review", "apply_correction", "validate_after", "compile_response",
                     "review_reply_preflight", "correction_schema", "request_schema", "loads"]:
            self.assertIs(getattr(patch, name), getattr(patch.prior, name), name)

    def test_runtime_plan_bounded_and_not_active(self):
        plan = patch.candidate_runtime_plan()
        self.assertEqual(plan["status"], "proposed_not_executed_by_owner")
        self.assertEqual(plan["model"], "qwen3.8-flash")
        self.assertEqual(plan["parameters"]["thinking_budget"], 2048)
        self.assertTrue(plan["parameters"]["enable_thinking"])
        self.assertEqual(plan["parameters"]["max_tokens"], 8192)
        self.assertEqual(plan["parameters"]["response_format"], {"type": "json_object"})
        self.assertEqual(plan["max_calls_per_image"], 2)
        self.assertEqual(plan["max_total_calls"], 4)
        self.assertFalse(plan["automatic_retries"])
        self.assertIn("cycle3", plan["stop_rule"])
        self.assertTrue(plan["no_third_model_stage"])

    def test_no_extra_keys_can_clear_issues(self):
        c = self.cases["R002"]
        r = empty_reply()
        r["issue_edits"] = {"0": {"old": c["raw"]["issues"][0], "value": None}}
        with self.assertRaisesRegex(ValueError, "All seven v3 review sections"):
            patch.apply_correction(c["raw"], r, c["scope"])

    def test_standalone_absolute_import_supported(self):
        code = "import importlib.util,sys;s=importlib.util.spec_from_file_location('probe',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print(m.VERSION)"
        result = subprocess.run([sys.executable, "-B", "-X", "utf8", "-c", code, str(Path(patch.__file__).resolve())],
                                cwd=patch.PROJECT.parent, capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), patch.VERSION)


if __name__ == "__main__":
    unittest.main()
