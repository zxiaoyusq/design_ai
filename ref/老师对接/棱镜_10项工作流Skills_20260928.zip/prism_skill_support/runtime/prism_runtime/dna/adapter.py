"""Lossless R70 normalized-output -> ImageDNA v0.1 adapter. No model/network calls."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
from collections import Counter

PROJECT = Path(__file__).resolve().parents[2]
DEFAULT_DICTIONARY = PROJECT / "outputs/01a0c2a0-b850-7fd1-a032-78e192743557/棱镜_DNA基础字典_AI版_v0.3.json"
STATES = {"known", "unknown", "not_applicable"}
KINDS = {"trend", "research", "generated", "calibration", "synthetic"}
EXPECTED_ROLES = {"vision_model": 148, "declared_input_rule": 65, "geometry_calculation": 3}
ADAPTER_VERSION = "r70-image-dna-v0.2"

class AdapterError(ValueError):
    """Input cannot be mapped without losing evidence or inventing a binding."""

def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise AdapterError("Duplicate JSON key: " + key)
        result[key] = value
    return result

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=_pairs)

def _absolute_file(path, label):
    result = Path(path).resolve()
    if not result.is_file():
        raise AdapterError(label + " does not exist: " + str(result))
    return result

def _hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def _same(a, b):
    return json.dumps(a, ensure_ascii=False, sort_keys=True, allow_nan=False) == json.dumps(b, ensure_ascii=False, sort_keys=True, allow_nan=False)

def _box(region):
    return (isinstance(region, list) and len(region) == 4
            and all(type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1 for v in region)
            and region[0] < region[2] and region[1] < region[3])

def _pointer(data, pointer):
    try:
        for token in pointer.lstrip("/").split("/"):
            token = token.replace("~1", "/").replace("~0", "~")
            data = data[int(token)] if isinstance(data, list) else data[token]
        return data
    except (KeyError, IndexError, ValueError, TypeError) as exc:
        raise AdapterError("Broken source JSON pointer: " + pointer) from exc

def adapt_normalized(source_ref, *, image_id, source_kind, image_path,
                     source_provenance_ref, source_kind_basis, parser_version,
                     dictionary_path=DEFAULT_DICTIONARY, validation_ref=None,
                     raw_output_ref=None):
    """Map every original assessment without changing its value or scope.

    Source kind and its documentary basis must come from the caller's real input
    provenance. A missing/invalid carrier is an error, never a fabricated region.
    This validates an interface, not the visual correctness of the source model.
    """
    if source_kind not in KINDS:
        raise AdapterError("Explicit supported source_kind is required")
    if not all(isinstance(v, str) and v.strip() for v in [image_id, source_kind_basis, parser_version]):
        raise AdapterError("Nonempty image ID, source-kind basis and parser version are required")
    source = _absolute_file(source_ref, "Normalized output")
    photo = _absolute_file(image_path, "Original image")
    provenance_file = _absolute_file(source_provenance_ref, "Source provenance")
    dictionary_file = _absolute_file(dictionary_path, "Original dictionary")
    native = read_json(source)
    dictionary = read_json(dictionary_file)
    parameters = {p["parameter_id"]: p for p in dictionary["parameters"]}
    if len(parameters) != 216:
        raise AdapterError("Expected complete original 216-parameter dictionary")
    objects = native.get("objects")
    rows = native.get("assessments")
    if not isinstance(objects, list) or not isinstance(rows, list):
        raise AdapterError("Expected complete native objects and assessments lists")
    object_index = {}
    for index, obj in enumerate(objects):
        oid = obj.get("object_id")
        if not isinstance(oid, str) or not oid or oid in object_index:
            raise AdapterError("Missing or duplicate original object ID")
        if not _box(obj.get("region")):
            raise AdapterError("Invalid original evidence region: " + oid)
        object_index[oid] = (index, obj)
    for _, obj in object_index.values():
        if obj.get("parent") is not None and obj["parent"] not in object_index:
            raise AdapterError("Missing original parent carrier")
    observations = []
    roles = {role: set() for role in EXPECTED_ROLES}
    coverage = set()
    source_str = source.as_posix()
    for index, row in enumerate(rows):
        pid, oid, state = row.get("parameter_id"), row.get("object_id"), row.get("value_status")
        value, role = row.get("value"), row.get("resolved_by")
        if pid not in parameters or role not in roles:
            raise AdapterError("Unrecognized original parameter or assessment role")
        if state not in STATES:
            raise AdapterError("Invalid or missing original value status")
        if (state == "known" and value is None) or (state != "known" and value is not None):
            raise AdapterError("State/value mismatch; adapter will not coerce evidence")
        if oid not in object_index:
            raise AdapterError("Missing carrier for assessment: " + str(oid))
        reference = row.get("reference_object_id")
        if reference is not None and reference not in object_index:
            raise AdapterError("Missing referenced carrier: " + str(reference))
        object_pos, obj = object_index[oid]
        if state == "known" and obj.get("object_type_id") not in parameters[pid]["applicable_object_types"]:
            raise AdapterError("Known value on an inapplicable original carrier: " + pid)
        if state == "known" and not row.get("evidence"):
            raise AdapterError("Known value has no original evidence")
        roles[role].add(pid)
        coverage.add(pid)
        row_ref = source_str + "#/assessments/" + str(index)
        region_ref = source_str + "#/objects/" + str(object_pos) + "/region"
        observations.append({
            "observation_id": image_id + ":a" + str(index).zfill(4),
            "parameter_id": pid,
            "object_id": oid,
            "value": copy.deepcopy(value),
            "value_status": state,
            "region_ref": {"object_id": oid, "bbox_xyxy": copy.deepcopy(obj["region"]),
                           "coordinate_space": "normalized_image", "is_segmentation_mask": False,
                           "source_ref": region_ref},
            "evidence_refs": [row_ref, region_ref],
            "reference_object_id": reference,
            "parameter_name": row.get("parameter_name"),
            "unit": row.get("unit"),
            "resolved_by": role,
            "native_source_kind": row.get("source_kind"),
            "evidence_text": row.get("evidence"),
            "native_assessment": copy.deepcopy(row),
        })
    if coverage != set(parameters):
        raise AdapterError("Missing original parameter coverage")
    if {k: len(v) for k, v in roles.items()} != EXPECTED_ROLES:
        raise AdapterError("Original 148/65/3 resolution roles are incomplete or changed")
    if sum(map(len, roles.values())) != len(set().union(*roles.values())):
        raise AdapterError("Conflicting original parameter resolution roles")
    validation = read_json(_absolute_file(validation_ref, "Validation record")) if validation_ref else None
    raw = _absolute_file(raw_output_ref, "Full raw output") if raw_output_ref else None
    output = {
        "schema_version": "prism.image_dna.v0.1",
        "image_id": image_id,
        "source_kind": source_kind,
        "image_path": photo.as_posix(),
        "source_ref": source_str,
        "observations": observations,
        "objects": copy.deepcopy(objects),
        "dictionary_contract": {
            "dictionary_ref": dictionary_file.as_posix(), "dictionary_sha256": _hash(dictionary_file),
            "parameter_count": 216, "resolution_role_counts": EXPECTED_ROLES,
            "resolution_parameter_ids": {k: sorted(v) for k, v in roles.items()},
            "original_definitions_preserved_by_reference": True,
            "assessment_rows_preserved": len(rows), "parameter_ids_covered": len(coverage),
        },
        "source_validation": {
            "ref": Path(validation_ref).resolve().as_posix() if validation_ref else None,
            "sha256": _hash(validation_ref) if validation_ref else None,
            "recorded_pipeline_pass": validation.get("pipeline_contract_passed") if validation else None,
            "visual_accuracy_established": False,
            "note": "Interface validation and prior pipeline status do not establish visual accuracy.",
        },
        "provenance": {
            "mode": "synthetic" if source_kind == "synthetic" else "existing_model_output",
            "parser_version": parser_version, "adapter_version": ADAPTER_VERSION,
            "normalized_output_sha256": _hash(source), "image_sha256": _hash(photo),
            "source_provenance_ref": provenance_file.as_posix(), "source_kind_basis": source_kind_basis,
            "raw_output_ref": raw.as_posix() if raw else None,
            "native_scope": native.get("scope"), "new_paid_calls": 0,
        },
    }
    verify_export(output)
    return output

def verify_export(document):
    """Offline checks against full source rows, bindings, values and local pointers."""
    if document.get("schema_version") != "prism.image_dna.v0.1" or document.get("source_kind") not in KINDS:
        raise AdapterError("Unsupported image DNA envelope")
    path = _absolute_file(document["source_ref"], "Full native output")
    native = read_json(path)
    if _hash(path) != document["provenance"]["normalized_output_sha256"]:
        raise AdapterError("Native source changed")
    photo = _absolute_file(document["image_path"], "Recorded source image")
    if _hash(photo) != document["provenance"]["image_sha256"]:
        raise AdapterError("Image identity differs from recorded original bytes")
    contract = document["dictionary_contract"]
    dictionary_path = _absolute_file(contract["dictionary_ref"], "Recorded original dictionary")
    if _hash(dictionary_path) != contract["dictionary_sha256"]:
        raise AdapterError("Dictionary identity differs from original field definitions")
    parameters = {p["parameter_id"] for p in read_json(dictionary_path)["parameters"]}
    if len(parameters) != 216 or contract.get("parameter_count") != 216:
        raise AdapterError("Original dictionary coverage changed")
    recorded = document.get("source_validation") or {}
    if recorded.get("ref"):
        record_path = _absolute_file(recorded["ref"], "Original validation record")
        if recorded.get("sha256") and _hash(record_path) != recorded["sha256"]:
            raise AdapterError("Original validation record changed")
        record = read_json(record_path)
        if record.get("photo_sha256") and record["photo_sha256"] != _hash(photo):
            raise AdapterError("Image does not match the actual parser input record")
        if record.get("dictionary_sha256") and record["dictionary_sha256"] != _hash(dictionary_path):
            raise AdapterError("Dictionary does not match the actual parser input record")
        if recorded.get("recorded_pipeline_pass") != record.get("pipeline_contract_passed"):
            raise AdapterError("Recorded pipeline status was changed")
    if not _same(document.get("objects"), native["objects"]):
        raise AdapterError("Exported object envelope differs from original carriers")
    obs = document["observations"]
    if len(obs) != len(native["assessments"]) or len({o["observation_id"] for o in obs}) != len(obs):
        raise AdapterError("Dropped or duplicate observations")
    for index, observation in enumerate(obs):
        original = native["assessments"][index]
        for key in ["parameter_id", "object_id", "value", "value_status", "reference_object_id", "parameter_name", "unit", "resolved_by"]:
            if not _same(observation.get(key), original.get(key)):
                raise AdapterError("Original observation was changed: " + key)
        for key, original_key in [("native_source_kind", "source_kind"), ("evidence_text", "evidence")]:
            if not _same(observation.get(key), original.get(original_key)):
                raise AdapterError("Original observation provenance was changed: " + key)
        if observation.get("native_assessment") != original:
            raise AdapterError("Native row is not preserved")
        carrier = next((o for o in native["objects"] if o["object_id"] == observation["object_id"]), None)
        region = observation.get("region_ref") or {}
        if carrier is None or region.get("bbox_xyxy") != carrier["region"] or region.get("object_id") != carrier["object_id"]:
            raise AdapterError("Region/carrier evidence mismatch")
        refs = observation.get("evidence_refs")
        if not isinstance(refs, list) or len(refs) < 2:
            raise AdapterError("Missing evidence references")
        for ref in refs:
            base, mark, pointer = ref.partition("#")
            if not mark or Path(base).resolve() != path:
                raise AdapterError("Evidence reference is not the recorded source")
            _pointer(native, pointer)
        expected_row = path.as_posix() + "#/assessments/" + str(index)
        if expected_row not in refs or region.get("source_ref") not in refs:
            raise AdapterError("Evidence references do not identify this observation")
        if _pointer(native, region["source_ref"].partition("#")[2]) != carrier["region"]:
            raise AdapterError("Evidence pointer refers to a different region")
    roles = {role: sorted({o["parameter_id"] for o in obs if o["resolved_by"] == role}) for role in EXPECTED_ROLES}
    if {o["parameter_id"] for o in obs} != parameters or {k:len(v) for k,v in roles.items()} != EXPECTED_ROLES:
        raise AdapterError("Original field IDs or assessment roles changed")
    expected_contract = {"parameter_ids_covered":216,"assessment_rows_preserved":len(obs),"resolution_role_counts":EXPECTED_ROLES,"resolution_parameter_ids":roles}
    if any(not _same(contract.get(k), v) for k,v in expected_contract.items()):
        raise AdapterError("Dictionary coverage or role declarations contradict native rows")
    return {"adapter_schema_passed": True, "observations": len(obs),
            "state_counts": dict(Counter(o["value_status"] for o in obs)),
            "new_paid_calls": 0, "visual_accuracy_established": False}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ["source-ref", "image-id", "source-kind", "image-path", "source-provenance-ref", "source-kind-basis", "parser-version", "output"]:
        ap.add_argument("--" + name, required=True)
    ap.add_argument("--dictionary-path", default=str(DEFAULT_DICTIONARY))
    ap.add_argument("--validation-ref")
    ap.add_argument("--raw-output-ref")
    args = vars(ap.parse_args())
    destination = Path(args.pop("output")).resolve()
    try:
        result = adapt_normalized(**args)
    except (AdapterError, OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc), "new_paid_calls": 0}, ensure_ascii=False))
        raise SystemExit(2)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": "exported", "output": str(destination), **verify_export(result)}, ensure_ascii=False))

if __name__ == "__main__":
    main()
