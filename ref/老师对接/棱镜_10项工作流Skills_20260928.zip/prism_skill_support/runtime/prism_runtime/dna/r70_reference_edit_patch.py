"""D01 cycle 2: bounded reference repair and a unique-key review wire.

Only model-declared edits are compiled to the frozen R70 engine. No values,
reference targets, operations or unknown states are inferred by this module.
The original dictionary, visual checks and final validator are unchanged.
"""
from __future__ import annotations

import copy
import hashlib
import importlib.util
from pathlib import Path
import re

_spec = importlib.util.spec_from_file_location(
    "prism_reference_patch_frozen_v2", Path(__file__).with_name("r70_review_contract_patch.py"))
prior = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(prior)

VERSION = "r70-reference-edit-d01-v3"
PROJECT, OPT, P, ACTIVE, CORE, DICT_PATH = (
    getattr(prior, k) for k in ["PROJECT", "OPT", "P", "ACTIVE", "CORE", "DICT_PATH"])
base = prior.base
compact, loads, require, exact, KEY = (
    getattr(prior, k) for k in ["compact", "loads", "require", "exact", "KEY"])
FACETS, HOST_FIELDS, METADATA_FIELDS = prior.FACETS, prior.HOST_FIELDS, prior.METADATA_FIELDS
validate, can_review, partial_preview = prior.validate, prior.can_review, prior.partial_preview
ID_KEY = re.compile(r"^(0|[1-9][0-9]*)$")
TOP_KEYS = {"dna_edits", "object_edits", "new_objects", "review_edits", "checks",
            "unresolved_issues", "review_complete"}

PRIMARY_RULES = '''
原字典的非自身参照规则同时适用于主解析和复核：EMI-005、EMI-013、GEO-017、STR-006、TXT-009有具体可见值时，键必须写成原PID@实际参照对象整数ID。仅写PID会被原解释器视为参照自身，不能用于这些字段的已知值。参照必须是本图实际声明的对象，不能默认父级；按原字段定义选择真实参照，程序不替你选择。unknown或not_applicable也不能引用不存在的ID。
例如接缝相对宽度STR-006的具体值需要明确它相对于哪个对象的宽度；保留原值类型，不能把reference塞进数值对象。不能只为过校验编造参照或数值；确实无法判断时由你显式给出原协议的unknown。仍须按原字典审阅全部148视觉字段，保留65项输入合同和3项派生关系。
'''

# Do not concatenate the v2 array instructions with this different wire format.
INSTRUCTIONS = '''直接查看本次唯一原图，按所列原DNA定义复核同图初稿。初稿不是图像真值。不得加入用户偏好、风格年代或其他图片的信息。
本版采用唯一键编辑表，保留七个顶层键。dna_edits、object_edits、review_edits是JSON对象；没有修改时写{}，不是数组。new_objects、checks和unresolved_issues仍是数组。禁止重复JSON键；重复键会被拒绝，程序不会保留最后一次或合并修改。
dna_edits格式为{"对象整数ID的十进制字符串":{"完整原字段键":{"op":"set或add或remove","old":精确旧值,"value":明确新值}}}。对象ID不是数组下标；只用0、1、2这样的规范字符串，不用o1、01。字段键包括已有@参照后缀。同一对象/完整字段键仅一条提案。
所有存在性和old前提都对照初稿，不对照中途结果。已有键改值必须set；不能同键先remove再add。set/remove的old必须与初稿JSON类型及内容完全一致，false、null、0、字符串不能互换。add只用于初稿不存在的完整键且old=null。remove.value必须为null。程序只展开键名为原编辑器的object_id、pid，不推断op、old、value或参照。
授权分两层：base_allowed_pids保留原视觉复核范围；reference_repair_contract的extra_cell_grants只对已诊断对象/原字段开放有限引用修复。新增权限不扩散到其他对象、new_objects或全图review状态。额外授权的set/remove只能针对列出的原错误完整键；改参照时，明确remove原非core错误键并add一个新的原PID@非自身实际ID键，且显式给出数值。新增数不得多于明确移除的原错误键数。不能把数值偷搬给不相关的对象。
HOST_FIELDS中的具体值必须带非自身参照。reference_diagnostics枚举了每个错误位置及准确旧值，必须逐一核对，不能只处理首个错误。syntactically_available_reference_ids仅表示ID存在，不表示它是正确宿主；由你根据原定义和图像选参照，程序不默认父级。未知、NA要由你显式选择，不能为了结构通过抹去看得清的特征。引用必须实际存在，core字段不得外加@。
每个原对象type对应的core_required_by_type都不能remove，即使同时改type也按原type保护。null/false不豁免字段与对象类型的适用权限。需要改真实类型时，保留旧core删除保护，并由你明确补齐新type核心；无法在协议内完成则报告未解决。不要为了容纳某字段改对象类型。所有新值遵守原value_schema和applicable_object_types。
object_edits格式为{"现有对象ID字符串":{"type或label或parent或box或origin":{"old":精确旧值,"value":明确新值}}}。不改ID、不删对象、不重新编号。框仍为原图0..1000整数坐标。父级和标签只能据原图修正。
new_objects按原格式id,type,label,parent,box,origin,dna追加，id从new_id_starts_at连续递增；所有DNA仅限base_allowed_pids且包含原类型的全部core。只为重要的可见遗漏新增，不凭空造宿主。新对象ID可被明确引用，最终仍须通过原校验器。
review_edits格式为{"允许的原PID":{"old_state":"unknown或not_applicable","state":"unknown或not_applicable"}}。只限base_allowed_pids；old_state复制effective_review。只能用完整字符串，不用u/n/null/false。它只变更无具体实例时的字段兜底，不能覆盖已有实例，也不能替代真实字段修复。
必须复核8个facet：shape_structure、colour_carriers、surface_optics、texture_pattern、controls、text_symbols、emission、regions_context。这只是组织原字段，不是新增维度。checks对每个facet恰好给一项{"facet":"名称","result":"retained或corrected或not_present或unresolved","evidence":"一句能回到原图核对的证据"}。not_present仅允许controls、text_symbols、emission确无表达时使用；其余须retained/corrected/unresolved。
重点检查主辅点缀色及载体、纹样单元与排列、表面光学和可见材质、真实文字与符号、发光与反光、操作控件、框架/面/支撑的区别、负空间/背景误作实体，以及数值/区域/父级的一致性。EMI仅能挂在原字典允许的O09。看不清印字不能凭品牌补词；不把可见外观当作真实材料BOM或已证实制造工艺。不用整族NA掩盖没有审阅。
保留正确内容，只据图修正错误或显著遗漏，不全部重写。unresolved_issues只列最终仍未解决的问题；unresolved检查面须同时列入。review_complete=true表示八面都已核对，不会覆盖未解决项或原validator失败。不得把检查说明当成实际修改。只输出七键紧凑JSON，原词表开放，原字段定义优先于参考词。
'''


def _digest(value):
    return hashlib.sha256(compact(value).encode("utf-8")).hexdigest()


def build_inputs(photo):
    prompt, schema, width, height, _ = prior.build_inputs(photo)
    prompt += "\n" + PRIMARY_RULES
    return prompt, schema, width, height, prompt


def reference_diagnostics(draft):
    """Inventory every present host-field reference; never change a value."""
    require(can_review(draft), "Stable original draft required for reference inventory")
    identifiers = [0] + [n["id"] for n in draft["objects"]]
    findings = []
    rows = [(n["id"], n["type"], n["dna"], f"/objects/{i}/dna")
            for i, n in enumerate(draft["objects"])] + [(0, "O19", draft["frame"], "/frame")]
    for oid, otype, fields, pointer in rows:
        for key, value in fields.items():
            match = KEY.fullmatch(key) if isinstance(key, str) else None
            if match is None or match.group(1) not in HOST_FIELDS:
                continue
            pid, suffix = match.groups()
            ref = int(suffix) if suffix is not None else oid
            # Value type errors remain covered by the original partial preflight.
            try:
                state = base.decode_value(pid, value, pointer + "/" + key, [])[0]
            except (ValueError, TypeError, KeyError):
                state = "invalid"
            codes = []
            if ref not in identifiers:
                codes.append("reference_id_not_declared")
            if state == "k" and ref == oid:
                codes.append("known_value_requires_nonself_reference")
            if codes:
                findings.append({"diagnostic_id": f"ref:o{oid}:{key}", "codes": codes,
                    "object_id": oid, "object_type_id": otype, "parameter_id": pid,
                    "field_key": key, "existing_value": copy.deepcopy(value),
                    "value_status": {"k": "known", "u": "unknown", "n": "not_applicable"}.get(state, state),
                    "json_pointer": pointer + "/" + key, "original_core_locked": pid in CORE.get(otype, []),
                    "syntactically_available_reference_ids": [i for i in identifiers if i != oid],
                    "semantic_reference_selected": False})
    return findings


def _reference_contract(draft, base_allowed):
    diagnostics = reference_diagnostics(draft)
    grants = {}
    for item in diagnostics:
        if item["parameter_id"] in base_allowed:
            continue
        cell = grants.setdefault(str(item["object_id"]), {})
        cell.setdefault(item["parameter_id"], []).append(item["field_key"])
    return {"version": VERSION, "draft_sha256": _digest(draft),
        "host_fields": sorted(HOST_FIELDS), "reference_diagnostics": diagnostics,
        "extra_cell_grants": grants, "model_selects_reference_and_value": True,
        "extra_permissions_for_new_objects_or_review_states": False,
        "host_default_parent_or_unknown": False}


def review_scope(draft, normalized):
    scope = copy.deepcopy(prior.review_scope(draft, normalized))
    # Replace v2's PID-global operation table: extra grants are per error cell.
    scope.pop("edit_contract", None)
    scope["base_allowed_pids"] = list(scope["allowed_pids"])
    contract = _reference_contract(draft, set(scope["base_allowed_pids"]))
    extra = {pid for row in contract["extra_cell_grants"].values() for pid in row}
    scope["allowed_pids"] = sorted(set(scope["base_allowed_pids"]) | extra)
    scope["reference_repair_contract"] = contract
    scope["structural_diagnostics"] += [
        {"code": "original_host_reference_violation", **copy.deepcopy(d)}
        for d in contract["reference_diagnostics"]]
    scope["review_wire_version"] = VERSION
    scope["host_supplied_semantic_edits"] = False
    return scope


def _scope_contract(draft, scope):
    require(scope.get("review_wire_version") == VERSION, "Fresh v3 review scope required")
    base_allowed = set(scope["base_allowed_pids"])
    require(base_allowed <= ACTIVE, "Original visual PIDs required")
    expected = _reference_contract(draft, base_allowed)
    require(exact(scope.get("reference_repair_contract"), expected), "Reference grant or draft snapshot mismatch")
    extra = {pid for row in expected["extra_cell_grants"].values() for pid in row}
    require(set(scope["allowed_pids"]) == base_allowed | extra, "Unexplained scope expansion")
    return base_allowed, expected["extra_cell_grants"]


def correction_schema():
    old = prior.correction_schema()["properties"]
    edit = {"type": "object", "additionalProperties": False,
        "required": ["op", "old", "value"], "properties": {
            "op": {"enum": ["set", "add", "remove"]}, "old": {}, "value": {}},
        "allOf": [{"if": {"properties": {"op": {"const": "add"}}},
                   "then": {"properties": {"old": {"type": "null"}}}},
                  {"if": {"properties": {"op": {"const": "remove"}}},
                   "then": {"properties": {"value": {"type": "null"}}}}]}
    metadata = {"type": "object", "additionalProperties": False,
        "required": ["old", "value"], "properties": {"old": {}, "value": {}}}
    state = {"type": "object", "additionalProperties": False,
        "required": ["old_state", "state"], "properties": {
            "old_state": {"enum": ["unknown", "not_applicable"]},
            "state": {"enum": ["unknown", "not_applicable"]}}}
    props = {
        "dna_edits": {"type": "object", "propertyNames": {"pattern": ID_KEY.pattern},
            "additionalProperties": {"type": "object", "propertyNames": {"pattern": KEY.pattern},
                                     "additionalProperties": edit}},
        "object_edits": {"type": "object", "propertyNames": {"pattern": r"^[1-9][0-9]*$"},
            "additionalProperties": {"type": "object", "propertyNames": {"enum": sorted(METADATA_FIELDS)},
                                     "additionalProperties": metadata}},
        "new_objects": copy.deepcopy(old["new_objects"]),
        "review_edits": {"type": "object", "propertyNames": {"enum": sorted(ACTIVE)}, "additionalProperties": state},
        "checks": copy.deepcopy(old["checks"]), "unresolved_issues": copy.deepcopy(old["unresolved_issues"]),
        "review_complete": {"const": True}}
    props["checks"].update({"minItems": len(FACETS), "maxItems": len(FACETS)})
    return {"type": "object", "additionalProperties": False, "required": list(props), "properties": props}


def request_schema(draft, scope):
    base_allowed, grants = _scope_contract(draft, scope)
    schema = correction_schema()
    dna = schema["properties"]["dna_edits"]
    dna["propertyNames"] = {"enum": ["0"] + [str(n["id"]) for n in draft["objects"]]}
    # Per-object grant restrictions are also enforced in the compiler. Full
    # definitions and current values are supplied separately without duplication.
    dna["properties"] = {}
    template = dna["additionalProperties"]
    for oid in dna["propertyNames"]["enum"]:
        rule = copy.deepcopy(template)
        pids = sorted(base_allowed | set(grants.get(oid, {})))
        rule["propertyNames"] = {"pattern": "^(?:" + "|".join(pids) + r")(?:@(0|[1-9][0-9]*))?$"}
        dna["properties"][oid] = rule
    dna["additionalProperties"] = False
    schema["properties"]["object_edits"]["propertyNames"] = {"enum": [str(n["id"]) for n in draft["objects"]]}
    schema["properties"]["review_edits"]["propertyNames"] = {"enum": sorted(base_allowed)}
    return schema


def critic_prompt(draft, scope):
    _scope_contract(draft, scope)
    cols = ["parameter_id", "name", "definition", "value_type", "value_schema", "reference_values",
            "unit", "applicable_object_types", "applicability"]
    pack = {"draft": draft, "review_scope": scope, "original_parameter_columns": cols,
        "original_parameters": [[P[p][k] for k in cols] for p in scope["allowed_pids"]],
        "original_object_types": [base.T[t] for t in CORE], "core_required_by_type": CORE,
        "effective_review": {p: prior._effective_review(draft, p) for p in scope["base_allowed_pids"]}}
    # A single compact schema plus per-cell scope avoids repeating the entire
    # PID pattern and edit schema for every object in the model prompt.
    return INSTRUCTIONS + "\n同图初稿与原字典复核范围：\n" + compact(pack) + "\n输出结构：\n" + compact(correction_schema())


def _id(text, allowed):
    require(isinstance(text, str) and ID_KEY.fullmatch(text) is not None, "Canonical decimal object ID key required")
    identifier = int(text)
    require(identifier in allowed, "Explicit existing target required")
    return identifier


def compile_response(draft, response, scope):
    """Lossless encoding conversion, not an algorithm for picking repairs.

    Always parse raw model text with exported strict `loads` first. Accepting
    a Python dict cannot recover duplicate keys discarded by another parser.
    """
    base_allowed, grants = _scope_contract(draft, scope)
    require(isinstance(response, dict) and set(response) == TOP_KEYS and response["review_complete"] is True,
            "All seven v3 review sections and explicit completion required")
    for name in ["dna_edits", "object_edits", "review_edits"]:
        require(isinstance(response[name], dict), "v3 unique-key object required for " + name)
    for name in ["new_objects", "checks", "unresolved_issues"]:
        require(isinstance(response[name], list), "Original list required for " + name)
    old_ids = {n["id"] for n in draft["objects"]}
    compiled = {name: copy.deepcopy(response[name]) for name in ["new_objects", "checks", "unresolved_issues", "review_complete"]}
    compiled.update({"dna_edits": [], "object_edits": [], "review_edits": []})
    extra_removes, extra_adds = {}, {}
    for oid_text, changes in response["dna_edits"].items():
        oid = _id(oid_text, {0} | old_ids)
        require(isinstance(changes, dict), "Field-key object required")
        for key, edit in changes.items():
            match = KEY.fullmatch(key) if isinstance(key, str) else None
            require(match is not None, "Original PID key required")
            require(isinstance(edit, dict) and set(edit) == {"op", "old", "value"}, "Explicit op, old and value required")
            require(edit["op"] in ["set", "add", "remove"], "Explicit original operation required")
            pid, suffix = match.groups()
            if pid not in base_allowed:
                keys = grants.get(oid_text, {}).get(pid, [])
                require(keys, "Edit outside diagnosed reference cell")
                cell = (oid, pid)
                if edit["op"] in ["set", "remove"]:
                    require(key in keys, "Extra permission only covers diagnosed original keys")
                    if edit["op"] == "remove":
                        extra_removes[cell] = extra_removes.get(cell, 0) + 1
                else:
                    require(suffix is not None and int(suffix) != oid, "Extra reference add requires explicit non-self key")
                    extra_adds[cell] = extra_adds.get(cell, 0) + 1
            compiled["dna_edits"].append({"object_id": oid, "pid": key, **copy.deepcopy(edit)})
    for cell, count in extra_adds.items():
        require(count <= extra_removes.get(cell, 0), "Extra reference add requires paired explicit removal of a diagnosed key")
    for oid_text, changes in response["object_edits"].items():
        oid = _id(oid_text, old_ids)
        require(isinstance(changes, dict), "Metadata field-key object required")
        for field, edit in changes.items():
            require(field in METADATA_FIELDS and isinstance(edit, dict) and set(edit) == {"old", "value"},
                    "Original metadata field with explicit old and value required")
            compiled["object_edits"].append({"object_id": oid, "field": field, **copy.deepcopy(edit)})
    for pid, edit in response["review_edits"].items():
        require(pid in base_allowed, "Extra reference permission does not authorize global review states")
        require(isinstance(edit, dict) and set(edit) == {"old_state", "state"}, "Explicit review states required")
        compiled["review_edits"].append({"pid": pid, **copy.deepcopy(edit)})
    for node in compiled["new_objects"]:
        require(isinstance(node, dict) and isinstance(node.get("dna"), dict), "Original new-object format required")
        for key in node["dna"]:
            match = KEY.fullmatch(key) if isinstance(key, str) else None
            require(match is not None and match.group(1) in base_allowed,
                    "Extra reference permission does not authorize new-object DNA")
    return compiled


def apply_correction(draft, response, scope):
    compiled = compile_response(draft, response, scope)
    final, audit = prior.apply_correction(draft, compiled, scope)
    audit["review_serialization"] = {"version": VERSION, "response_sha256": _digest(response),
        "compiled_legacy_sha256": _digest(compiled), "compiled_legacy_response": compiled,
        "operation_or_value_inferred": False, "reference_target_inferred": False,
        "duplicate_edits_deduplicated": False, "scope_only_extended_for_diagnosed_cells": True}
    return final, audit


def validate_after(draft, final, response, scope, width, height):
    compiled = compile_response(draft, response, scope)
    result, normalized = prior.validate_after(draft, final, compiled, scope, width, height)
    remaining = reference_diagnostics(final) if can_review(final) else None
    result["reference_preflight_after"] = {"version": VERSION, "remaining": remaining,
        "remaining_count": None if remaining is None else len(remaining),
        "read_only": True, "visual_correctness_established": False}
    result["passed"] = bool(result["passed"]) and remaining == []
    return result, normalized


def review_reply_preflight(draft, response, scope):
    """Read-only protocol diagnostics; not final or visual acceptance."""
    try:
        compiled = compile_response(draft, response, scope)
    except Exception as exc:
        return {"version": VERSION, "read_only": True, "not_a_complete_validator": True,
            "host_selected_or_applied_repairs": False, "diagnostic_count": 1,
            "diagnostics": [{"code": "v3_response_compile_rejected", "detail": type(exc).__name__ + ": " + str(exc)}]}
    result = prior.review_reply_preflight(draft, compiled, scope)
    result["version"] = VERSION
    result["compiled_legacy_sha256"] = _digest(compiled)
    return result


def association_registry():
    registry = copy.deepcopy(prior.association_registry())
    registry["reference_edit_sidecar"] = {"version": VERSION, "primary_host_rules_added": True,
        "review_wire_changed": "three edit arrays become unique-key objects; other sections unchanged",
        "reference_scope_expansion": "diagnosed object/PID cells and explicit replacement keys only",
        "original_apply_engine_and_final_validator_preserved": True, "strict_duplicate_key_loader_required": True,
        "automatic_semantic_repairs": False, "provider_schema_enforcement_assumed": False,
        "same_image_call_budget": "one full extraction plus one combined visual and reference review",
        "extra_model_stage_implemented": False}
    return registry
