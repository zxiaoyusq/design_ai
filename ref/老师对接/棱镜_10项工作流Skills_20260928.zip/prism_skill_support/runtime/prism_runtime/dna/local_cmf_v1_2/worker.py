"""Defensive isolated worker. Program shadows never become model facts."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("frozen_v1_codec", HERE.parent / "local_cmf_v1/worker.py")
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
producer = old.producer
r14 = producer.base.base
sys.path.insert(0, str(old.OPT / "round15/vendor"))
import jsonschema

INDEX_PIDS = {"GEO-012", "OPT-001", "OPT-007"}
CORE_TEXT_PIDS = {"TEX-002"}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def original_decode(raw, pixels):
    try:
        bindings = old.declared_bindings(raw)
        native = copy.deepcopy(raw)
        report, rows = producer.validate(native, *pixels)
        return {"report": report, "normalized": {"scope": native["scope"], "objects": native["objects"],
            "assessments": rows, "visual_summary": []}, "declared_bindings": bindings, "decode_error": None}
    except Exception as exc:
        return {"report": None, "normalized": None, "declared_bindings": None,
                "decode_error": type(exc).__name__ + ": " + str(exc)}


def inspect_wire(raw):
    """Identify exact slots, rejecting identity ambiguity before any shadow."""
    jsonschema.Draft202012Validator(producer.make_schema()).validate(raw)
    count = len(raw["o"])
    slots, parents, identities = [], {}, set()
    for index, node in enumerate(raw["o"], 1):
        typ, parent, x0, y0, x1, y1, ax, ay, origin = node["g"]
        require(1 <= typ <= 18 and 0 <= parent <= count and parent != index, "Unsafe object type/parent")
        require(0 <= x0 < x1 <= 1000 and 0 <= y0 < y1 <= 1000, "Unsafe source region")
        require((ax == ay == -1) or (x0 <= ax <= x1 and y0 <= ay <= y1), "Unsafe evidence anchor")
        require(origin in range(4), "Unsafe texture origin identity")
        require((index == 1 and typ == 1 and parent == 0) or (index > 1 and typ != 1), "Ambiguous product root")
        parents[index] = parent
        core = r14.base.core_ids("O" + str(typ).zfill(2))
        require(len(node["c"]) == len(core), "Core slot identity cannot be recovered")
        for position, (pid, token) in enumerate(zip(core, node["c"])):
            slots.append({"pid": pid, "oid": "o" + str(index), "ref": "o" + str(index),
                "kind": "core", "pointer": f"/o/{index-1}/c/{position}", "node_index": index-1,
                "value_position": position, "raw_token": copy.deepcopy(token)})
        require(len(node["d"]) % 2 == 0, "Odd detail stream")
        for position in range(0, len(node["d"]), 2):
            key, token = node["d"][position:position+2]
            if type(key) is int:
                code, ref = key, index
            else:
                require(isinstance(key, list) and len(key) == 2 and all(type(x) is int for x in key), "Bad field/reference identity")
                code, ref = key
                ref = index if ref == -1 else ref
            require(code in r14.ACTIVE_CODES and 0 <= ref <= count, "Unknown active PID key or reference")
            pid = r14.IDS[code]
            require(not pid.startswith("CTX-"), "Frame field on an object")
            slots.append({"pid": pid, "oid": "o" + str(index), "ref": "o" + str(ref),
                "kind": "detail", "pointer": f"/o/{index-1}/d/{position+1}", "node_index": index-1,
                "value_position": position+1, "raw_key": copy.deepcopy(key), "raw_token": copy.deepcopy(token)})
    for index in parents:
        seen, parent = {index}, parents[index]
        while parent:
            require(parent not in seen, "Cyclic carrier hierarchy")
            seen.add(parent); parent = parents[parent]
    for position, (code, token) in enumerate(raw["f"]):
        require(type(code) is int and code in r14.ACTIVE_CODES, "Unknown frame PID key")
        pid = r14.IDS[code]
        require(pid.startswith("CTX-"), "Non-frame field in frame")
        slots.append({"pid": pid, "oid": "o0", "ref": "o0", "kind": "frame",
            "pointer": f"/f/{position}/1", "value_position": position, "raw_token": copy.deepcopy(token)})
    for s in slots:
        # Core/detail duplicates and multiple reference interpretations require
        # a model decision; never select a winner or deduplicate them here.
        identity = (s["pid"], s["oid"])
        require(identity not in identities, "Ambiguous duplicate or multi-reference slot: " + str(identity))
        identities.add(identity)
    return slots


def slot_error(slot):
    pid, value = slot["pid"], slot["raw_token"]
    if slot["kind"] == "core" and value in (-1, -2):
        return None  # Original explicitly legal core states, no recovery.
    try:
        # Exactly R17's existing singleton-set shorthand, not new semantics.
        schema = r14.P[pid]["value_schema"]
        token = copy.deepcopy(value)
        if schema.get("type") == "array" and schema.get("items", {}).get("type") == "string" and isinstance(token, (str, int)) and not isinstance(token, bool):
            token = [token]
        decoded = r14.value_decode(pid, token)
        if slot["kind"] == "core" and not isinstance(decoded, str):
            raise ValueError(pid + ": core value must decode to text")
        return None
    except Exception as exc:
        error = type(exc).__name__ + ": " + str(exc)
        registered = (pid in INDEX_PIDS and str(exc).startswith(pid + ": bad candidate index ")
                      or pid in CORE_TEXT_PIDS and slot["kind"] == "core" and str(exc) == pid + ": core value must decode to text")
        require(registered, "Unregistered codec failure: " + error)
        return {**copy.deepcopy(slot), "error": error, "disposition": "invalid_encoding",
                "decoded_value_available": False}


def defensive_decode(raw, pixels):
    try:
        jsonschema.Draft202012Validator(producer.make_schema()).validate(raw)
    except Exception as exc:
        return {"report": None, "normalized": None, "declared_bindings": None,
            "decode_error": "Original schema rejected: " + str(exc),
            "codec_diagnostic": {"status": "blocked", "shadow_used": False, "reason": "original_schema_invalid"}}
    original = original_decode(raw, pixels)
    # No-error sources remain byte-value/normalized equivalent to the legacy
    # codec. No registry, additional state or shadow is introduced for them.
    if original["normalized"] is not None and original["report"].get("passed"):
        return {**original, "codec_diagnostic": {"status": "unchanged_original", "shadow_used": False}}
    try:
        slots = inspect_wire(raw)
        faults = [error for s in slots if (error := slot_error(s)) is not None]
        if not faults:
            return {**original, "codec_diagnostic": {"status": "no_registered_codec_fault", "shadow_used": False}}
        require(original["decode_error"] is not None, "Source has a report-level error, not a registered throwing codec fault")
        require(original["decode_error"] in [f["error"] for f in faults], "Original exception is not explained by located faults")
        shadow = copy.deepcopy(raw)
        removed = {}
        for fault in faults:
            if fault["kind"] == "core":
                shadow["o"][fault["node_index"]]["c"][fault["value_position"]] = -1
                fault["shadow_operation"] = "program_only_core_placeholder_minus1_removed_from_export"
            elif fault["kind"] == "detail":
                removed.setdefault(fault["node_index"], []).append(fault["value_position"] - 1)
                fault["shadow_operation"] = "program_only_detail_pair_omitted_from_shadow"
            else:
                raise ValueError("Frame recovery not authorized")
        for node_index, positions in removed.items():
            for position in sorted(positions, reverse=True):
                del shadow["o"][node_index]["d"][position:position+2]
        recovered = original_decode(shadow, pixels)
        require(recovered["decode_error"] is None, "Shadow still cannot decode: " + str(recovered["decode_error"]))
        ledger = copy.deepcopy(recovered["normalized"])
        by_id = {o["object_id"]: o for o in ledger["objects"]}
        bad_keys = {(f["pid"], f["oid"], f["ref"]) for f in faults}
        valid_slots = [s for s in slots if (s["pid"], s["oid"], s["ref"]) not in bad_keys]
        valid_pids = {s["pid"] for s in valid_slots}
        only_bad_pids = {f["pid"] for f in faults} - valid_pids
        # Remove only shadow-created unknown placeholders or newly exposed
        # fallback states for a PID whose original instances were all invalid.
        rows = [r for r in ledger["assessments"]
                if (r["parameter_id"], r["object_id"], r.get("reference_object_id")) not in bad_keys
                and not (r["parameter_id"] in only_bad_pids and r["resolved_by"] == "vision_model")]
        for f in faults:
            p = r14.P[f["pid"]]
            rows.append({"parameter_id": f["pid"], "parameter_name": p["name"], "object_id": f["oid"],
                "reference_object_id": f["ref"], "value_status": "invalid_encoding", "value": None,
                "decode_status": "not_decoded",
                "raw_token": copy.deepcopy(f["raw_token"]), "wire_pointer": f["pointer"], "encoding_error": f["error"],
                "source_kind": "invalid_model_encoding", "unit": p["unit"], "resolved_by": "vision_model",
                "evidence": "Original wire token was not decoded; no visual unknown/NA/value is asserted",
                "assessment_method": "invalid_original_encoding", "carrier_region": copy.deepcopy(by_id[f["oid"]]["region"])})
        order = {pid: i for i, pid in enumerate(r14.P)}
        rows.sort(key=lambda r: (order[r["parameter_id"]], int(r["object_id"][1:])))
        ledger["assessments"] = rows
        trace = {"status": "recovered_unaffected_observations_only", "shadow_used": True,
            "original_raw_sha256": digest(raw), "program_shadow_sha256": digest(shadow),
            "original_decode_error": original["decode_error"], "original_report": original["report"],
            "faults": faults, "shadow_validation_report": recovered["report"],
            "shadow_wire_is_not_a_model_answer": True, "shadow_placeholder_states_exported": False,
            "raw_values_changed": False, "raw_scope_or_regions_changed": False,
            "invalid_rows_are_not_unknown_or_NA": True}
        ledger.update(artifact_kind="recovered_partial_ledger", complete_original_normalization=False, codec_recovery=trace)
        ledger["scope"] = "Partial deterministic recovery of unaffected R17 observations; invalid_encoding rows retain original tokens. Not an original complete normalized result."
        failure = {"passed": False, "errors": [original["decode_error"]], "original_decode_completed": False,
            "covered_parameters": None, "artifact_kind": "original_R17_decode_failure",
            "partial_recovery_is_not_original_216_pass": True}
        bindings = [[s["pid"], s["oid"], s["ref"]] for s in slots]
        return {"report": failure, "normalized": ledger, "declared_bindings": bindings,
                "decode_error": None, "codec_diagnostic": trace}
    except Exception as exc:
        reason = type(exc).__name__ + ": " + str(exc)
        if original["normalized"] is not None:
            # Preserve the original failed report/ledger; its global veto stays.
            return {**original, "codec_diagnostic": {"status": "blocked", "reason": reason, "shadow_used": False}}
        return {**original, "decode_error": str(original["decode_error"]) + " | Recovery blocked: " + reason,
            "codec_diagnostic": {"status": "blocked", "reason": reason, "shadow_used": False}}


def main():
    payload = json.loads(sys.stdin.read())
    result = {"producer": "R17", "sources": old.sources()}
    if payload["action"] == "prepare":
        prompt, schema, width, height = producer.build_inputs(Path(payload["image"]))
        result.update(prompt=prompt, schema=schema, pixels=[width, height])
    elif payload["action"] == "decode":
        result.update(defensive_decode(payload["raw"], payload["pixels"]))
    else:
        raise ValueError("Only local prepare/decode supported")
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
