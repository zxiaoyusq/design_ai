"""Keep invalid slots distinct from unknown and block their CMF dependents."""
import copy
from ..local_cmf_v1_1 import audit as previous
from ..local_cmf_v1_1.audit import PARAMETERS, CMF_PIDS, review_schema, resolve_review
from .common import canonical, require


def audit_units(normalized, declared_bindings, image_id, original_report=None):
    trace = normalized.get("codec_recovery")
    if trace is None:
        return previous.audit_units(normalized, declared_bindings, image_id, original_report)
    require(trace["status"] == "recovered_unaffected_observations_only", "Unrecognized recovery ledger")
    require(original_report and original_report.get("passed") is False, "Recovered input cannot claim original PASS")
    require(original_report["errors"] == [trace["original_decode_error"]], "Original decoder failure changed")
    residual = copy.deepcopy(trace["shadow_validation_report"])
    # The shadow check is a deterministic check of remaining observations, not
    # a successful original decode. Its result never replaces original_report.
    residual["passed"] = False
    result = previous.audit_units(normalized, declared_bindings, image_id, residual)
    result["original_full_216_pass"] = False
    result["original_error_isolation"]["validation_source"] = "program_shadow_residuals_only_not_original_full_check"
    result["original_error_isolation"]["original_raw_R17_failure"] = copy.deepcopy(original_report)
    invalid_units = []
    for fault in trace["faults"]:
        matches = [u for u in result["units"] if (u["parameter_id"], u["object_id"], u["reference_object_id"]) ==
                   (fault["pid"], fault["oid"], fault["ref"])]
        require(len(matches) == 1, "Recovered invalid slot is not unique")
        u = matches[0]; row = u["native_assessment"]
        require(u["value_status"] == "invalid_encoding" and u["value"] is None
            and row.get("decode_status") == "not_decoded" and row.get("wire_pointer") == fault["pointer"]
            and canonical(row.get("raw_token")) == canonical(fault["raw_token"]), "Invalid token was relabelled or changed")
        u["program_errors"] = [e for e in u["program_errors"] if e != "Invalid explicit state/value pairing"]
        u["program_errors"].append("Original invalid_encoding/not_decoded slot: " + fault["pointer"])
        u["encoding_failure"] = copy.deepcopy(fault)
        invalid_units.append(u)
    bad = {u["observation_id"] for u in invalid_units}
    # A non-text base texture unit makes that carrier's texture descriptions
    # and ratios unsafe, while independently reviewed colour/optics may remain.
    for source in invalid_units:
        if source["parameter_id"] == "TEX-002":
            for target in result["units"]:
                if target["object_id"] == source["object_id"] and target["parameter_id"].startswith("TEX-"):
                    target["program_errors"].append("Texture depends on undecoded TEX-002 on this carrier")
                    if target["observation_id"] != source["observation_id"] and source["observation_id"] not in target["dependency_observation_ids"]:
                        target["dependency_observation_ids"].append(source["observation_id"])
                    bad.add(target["observation_id"])
    changed = True
    while changed:
        changed = False
        for u in result["units"]:
            if u["observation_id"] not in bad and set(u["dependency_observation_ids"]) & bad:
                u["program_errors"].append("Dependency reaches an invalid original encoding")
                bad.add(u["observation_id"]); changed = True
    candidates = []
    for u in result["units"]:
        u["program_eligible"] = bool(u["in_cmf_scope"] and u["value_status"] == "known"
                                     and not u["program_errors"] and not result["global_errors"])
        if u["program_eligible"]:
            candidates.append(u["observation_id"])
    result.update(candidates=candidates, ready_for_review=bool(candidates) and not result["global_errors"], useful=False,
        codec_recovery=copy.deepcopy(trace), source_ledger_kind="recovered_partial_ledger",
        invalid_encoding_observation_ids=sorted(u["observation_id"] for u in invalid_units),
        invalid_encoding_dependency_blocked_observation_ids=sorted(bad),
        invalid_encoding_is_not_unknown_or_NA=True, original_complete_normalization=False)
    return result
