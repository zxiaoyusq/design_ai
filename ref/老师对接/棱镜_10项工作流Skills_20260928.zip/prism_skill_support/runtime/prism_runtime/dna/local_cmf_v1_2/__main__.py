import argparse
import json
from . import pipeline


def main():
    p = argparse.ArgumentParser(description="Local defensive decoding only; no inference")
    sub = p.add_subparsers(dest="mode", required=True)
    q = sub.add_parser("prepare")
    for key in ["image", "image-id", "source-kind", "source-provenance-ref", "output-dir"]:
        q.add_argument("--" + key, required=True)
    for op in ["accept", "accept-review"]:
        q = sub.add_parser(op)
        for key in ["prepared-dir", "raw-output", "run-record"]:
            q.add_argument("--" + key, required=True)
    sub.add_parser("verify").add_argument("--path", required=True)
    args = vars(p.parse_args()); op = args.pop("mode")
    fn = {"prepare": pipeline.prepare, "accept": pipeline.accept, "accept-review": pipeline.accept_review, "verify": pipeline.verify_projection}[op]
    print(json.dumps(fn(**args), ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
