# Local CMF v1.2 · CLOSURE-DNA-002 第2轮

本版本只做精确坏编码的局部隔离，owner不调用模型/API，也不重新提取120份原始图片。v1/v1.1、原R17和字典保持冻结。原始解码失败仍为false；恢复资格只适用于不受影响的CMF观察。

## 已验证的范围

注册规则仅覆盖本轮真实反例：GEO-012、OPT-001、OPT-007的非法候选索引，以及TEX-002核心槽解码后不是字符串。首先核原始schema及稳定对象/父级/区域/锚点/字段/参照身份；坏PID、重复或多参照歧义、坏核心引用、未知错误一律不能猜。

能精确定位时，只在程序的内存影子副本上用原核心未知占位或暂时省去坏detail键值对，以运行原codec恢复其余内容。**影子不是模型输出**。保存影子哈希、操作和原槽位；导出前去掉影子占位及影子导致新增的全局fallback，把原坏槽恢复成`invalid_encoding`、`decode_status=not_decoded`、`value=null`和原`raw_token/wire_pointer/encoding_error`。这些不是视觉unknown、NA或“无”。不拼词、不猜候选、不改图像/对象身份。

为兼容旧入口，持久化文件仍名为normalized.json，但错误恢复后的内容明确标为`artifact_kind=recovered_partial_ledger`、`complete_original_normalization=false`，scope也明确不是原始完整normalized。`codec_recovery`保留原始异常和原报告、影子校验及每个坏槽。`original-r17-validation.json`仍记录原始R17解码失败，不用影子成功替代。

剩余的原GEO-020错误继续走v1.1严格注册表；该部分审计明确标为影子未受影响值的残余检查，不冒充原始完整检查。坏TEX-002使同载体纹理和纹理比例不可用；颜色/光泽等独立项还须通过同图review。所有依赖坏槽的项继续阻塞。

## 实际只读回放

| 样本 | 结果 | 可进入同图review的候选 |
|---|---|---:|
| TR002 | 精确隔离OPT-001坏detail索引 | 119 |
| TR003 | 精确隔离OPT-007坏detail索引 | 131 |
| TR007 | 精确隔离GEO-012坏索引 | 59 |
| TR011 | 两个TEX-002核心坏槽保持invalid，相关纹理被阻塞 | 99 |
| TR012 | 精确隔离GEO-012坏索引 | 66 |
| TR015 | 精确隔离GEO-012坏索引 | 75 |
| TR009 | 另有REL-012同载体多参照歧义，继续blocked | 0 |
| TR010 | OPT-007同时出现在core与extra；即使值相同也不自动去重，继续blocked | 0 |

以上全部原R17完整结果仍失败。六份恢复共549条候选，没有新增真实视觉准入结论。Root只应对过去未review且此次新增可用的样本安排必要review，不重做原提取。TR001真实review指出的多套服装被合并成一个产品父级，是图像层级问题；原0准入保持，不能用本轮类型隔离解除。

## 入口与旧版兼容

```text
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_2 prepare --image PATH --image-id ID --source-kind trend --source-provenance-ref MANIFEST --output-dir NEW_DIR
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_2 accept --prepared-dir NEW_DIR --raw-output EXISTING_RAW --run-record EXISTING_RECORD
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_2 accept-review --prepared-dir NEW_DIR --raw-output REVIEW_RAW --run-record REVIEW_RECORD
python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_2 verify --path NEW_DIR/cmf.image-dna.json
```

标准Astra、禁Fast/priority、严格原文JSON/真实运行记录和调用身份检查继承v1。生产者和primary schema不改，已完成的原输出可复用。旧版投影按其持久化版本交旧verifier；新版本重放原字节、影子隔离、无效槽、依赖和真实审核，再逐值对比投影。

CMF投影只含真实审核通过的known项，完整原载体和全部CMF状态仍保留。新增`cmf_admission.codec_recovery`、`invalid_encoding_observation_ids`和依赖阻塞ID、`source_ledger_kind`、`complete_original_normalization`。未投影不表示不存在，整图否定条件仍未获资格。下游须使用v1.2官方verify路由和范围守卫，不直接把部分账本交给旧全量适配器。

## 验证

13项有界离线检查覆盖真实坏槽原token/唯一指针、detail负一不变unknown、坏TEX不跨载体污染、坏PID/核心引用/父区域/多参照/重复继续阻断、合法输入逐值等价原codec、全unknown/invalid无用、旧33/43/43及TR001真实0准入重验，以及持久化篡改检测。

测试临时目录可由调用者指定，Root可把它放在自己的输出目录：

```powershell
$env:PRISM_LOCAL_CMF_TEST_ROOT = 'D:/Codex/传音AI创客营/outputs/你的测试目录'
python -B -X utf8 -m unittest prism_runtime.dna.local_cmf_v1_2.test_codec -v
```

合格范围仅确定性恢复/隔离及旧版兼容。测试中的synthetic审核不是实际图像判断，不计模型调用或准确率。未解码、未检查、视觉未知、不适用和程序错误继续分开；无法证明独立则保留blocked。本轮不是新编号的无限续试，不改原停止的Qwen三轮历史。
