"""Offline R2 delivery from completed standard-Astra original outputs."""
from datetime import datetime, timezone
import io
import os
from pathlib import Path
import unittest
from . import VERSION, common as c, pipeline

LOOP = c.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
RUN = LOOP / "closure-20260927"
REPAIRS = c.PROJECT / "outputs/prism-algorithm-loop-20260926/modules/dna/repairs"
OUT = REPAIRS / "CLOSURE-DNA-002/v1.2"
CASES = ["TR002", "TR003", "TR007", "TR009", "TR010", "TR011", "TR012", "TR015"]


def main():
    c.require(not (OUT / "handoff.json").exists(), "Delivery already frozen")
    OUT.mkdir(parents=True, exist_ok=True)
    preserved = []
    for folder in [REPAIRS / "CLOSURE-DNA-001/v1", REPAIRS / "CLOSURE-DNA-002/v1.1"]:
        preserved += c.read(folder / "source-hashes.json") + c.read(folder / "delivery-hashes.json")["files"]
    for item in preserved: c.verify_identity(item)
    c.verify_freeze()
    inputs = [c.file_identity(LOOP / "dispatches/CLOSURE-DNA-002-R2.md")]
    cases = []
    for cid in CASES:
        old = RUN / "images-v1_1" / cid
        prep = c.read(old / "preparation.json")
        call = c.read(old / "primary.run-audit.json")
        source_acceptance = c.read(old / "acceptance.json")
        raw = Path(source_acceptance["raw_source_identity"]["path"])
        record = Path(call["record_ref"]["path"])
        target = OUT / "replays" / cid
        pipeline.prepare(prep["image"]["path"], cid, prep["source_kind"], prep["source_provenance"]["path"], target)
        result = pipeline.accept(target, raw, record)
        diagnostic = c.read(target / "codec-diagnostic.json")
        c.require(not result["original_full_216_pass"], "Original failed extraction became a full PASS")
        item = {"image_id": cid, "raw_output": c.file_identity(raw), "ready_for_review": result["ready_for_review"],
            "candidate_count": result.get("candidate_observations", 0), "original_full_R17_pass": False,
            "useful_local_CMF_qualified": False, "codec_status": diagnostic["status"],
            "blocked_reason": diagnostic.get("reason"), "replay_dir": str(target),
            "acceptance_ref": str(target / "acceptance.json"), "codec_diagnostic_ref": str(target / "codec-diagnostic.json"),
            "review_prompt_ref": result.get("review_prompt_ref"), "review_schema_ref": result.get("review_schema_ref")}
        if result["ready_for_review"]:
            n = c.read(target / "normalized.json")
            c.require(n.get("complete_original_normalization") is False, "Partial recovery masquerades as original normalization")
            item["invalid_slots"] = [{k: f[k] for k in ["pid", "oid", "ref", "pointer", "raw_token", "error"]}
                                     for f in n["codec_recovery"]["faults"]]
        cases.append(item)
        inputs.extend([c.file_identity(raw), c.file_identity(record), c.file_identity(old / "acceptance.json")])
    c.require(sum(x["ready_for_review"] for x in cases) == 6, "Unexpected recovery scope")
    c.require(sum(x["candidate_count"] for x in cases) == 549, "Unexpected candidate count")
    os.environ.setdefault("PRISM_LOCAL_CMF_TEST_ROOT", str(OUT / "test-temp"))
    stream = io.StringIO()
    tests = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromName("prism_runtime.dna.local_cmf_v1_2.test_codec"))
    c.write_new(OUT / "offline-tests.txt", stream.getvalue(), text=True)
    c.require(tests.wasSuccessful(), "Boundary tests failed")
    old_results = []
    for base, cid in [("images", "R002"), ("images", "R005"), ("images", "R009"), ("images-v1_1", "TR001")]:
        path = RUN / base / cid / "cmf.image-dna.json"
        old_results.append({"image_id": cid, "identity": c.file_identity(path), "verification": pipeline.verify_projection(path)})
    for item in preserved + inputs: c.verify_identity(item)
    c.write_new(OUT / "source-hashes.json", c.module_sources() + [c.file_identity(c.HERE / "README.md")])
    c.write_new(OUT / "input-hashes.json", inputs)
    c.write_new(OUT / "preserved-prior-hashes.json", preserved)
    c.write_new(OUT / "verification.json", {"checked_utc": datetime.now(timezone.utc).isoformat(), "version": VERSION,
        "issue_id": "CLOSURE-DNA-002", "repair_cycle": 2, "tests": tests.testsRun,
        "failures": len(tests.failures), "errors": len(tests.errors), "owner_model_calls": 0,
        "recovered_candidates_not_visual_passes": 549, "ready_case_count": 6, "blocked_case_count": 2,
        "all_original_full_checks_remain_false": True, "prior_versions_and_sources_unchanged": True,
        "cases": cases, "old_true_projections_and_global_failure_preserved": old_results})
    c.write_new(OUT / "self-assessment.json", {"module": "dna", "issue_id": "CLOSURE-DNA-002", "repair_cycle": 2,
        "version": VERSION, "status": "partial_ready_for_independent_review", "qualified": False,
        "qualified_scope": "Bounded deterministic recovery of independently decodable observations; invalid tokens remain invalid; old source/projection verification preserved",
        "owner_model_calls": 0, "fresh_visual_review_performed": False, "new_usable_images_claimed": 0,
        "ready_for_review_ids": [r["image_id"] for r in cases if r["ready_for_review"]],
        "blocked_ids": [r["image_id"] for r in cases if not r["ready_for_review"]],
        "known_limits": ["TR009 multi-reference and TR010 core/extra duplicate remain blocked.",
            "Only registered candidate-index and TEX-002 core-text errors are recoverable.",
            "Program shadows are disclosed and discarded as semantic evidence; ledger filename normalized.json is compatibility only and explicit kind is recovered_partial_ledger.",
            "TR001 prior global visual-parent issue remains zero admitted and must not be re-reviewed as a codec repair.",
            "No new visual accuracy or complete216 qualification is established."],
        "test_scratch_environment": "PRISM_LOCAL_CMF_TEST_ROOT"})
    c.write_new(OUT / "handoff.json", {"module": "dna", "issue_id": "CLOSURE-DNA-002", "repair_cycle": 2,
        "version": VERSION, "status": "partial_ready_for_independent_review",
        "source_entrypoint": str(c.HERE / "pipeline.py"), "cli": "python -B -X utf8 -m prism_runtime.dna.local_cmf_v1_2",
        "operations": ["prepare", "accept", "accept-review", "verify"], "readme_ref": str(c.HERE / "README.md"),
        "source_hashes_ref": str(OUT / "source-hashes.json"), "self_assessment_ref": str(OUT / "self-assessment.json"),
        "verification_ref": str(OUT / "verification.json"), "cases": cases, "owner_model_calls": 0,
        "primary_prompt_and_schema_unchanged": True, "service_tier": "default", "fast_or_priority_allowed": False,
        "root_next_step": "Independently validate the new version; reuse existing P-* raw/records in new Root v1.2 preparation folders. Only review newly eligible never-reviewed six cases; do not re-extract120, reinterpret blocked TR009/TR010, or clear/re-review TR001's recorded global image issue.",
        "projection_changes": ["source_ledger_kind=recovered_partial_ledger", "complete_original_normalization=false",
            "invalid_encoding_observation_ids", "invalid_encoding_dependency_blocked_observation_ids", "codec_recovery"],
        "invalid_state_policy": "Only sidecar ledgers hold invalid_encoding/not_decoded; exported usable observations remain supported original known CMF. Unknown/NA are never substituted for an invalid token.",
        "verifier": "pipeline.verify_projection(path) dispatches prior versions unchanged and fully reconstructs v1.2 partial recovery from original model bytes.",
        "no_new_success_rate_claim": True, "test_command": "python -B -X utf8 -m unittest prism_runtime.dna.local_cmf_v1_2.test_codec -v",
        "test_scratch_env": "PRISM_LOCAL_CMF_TEST_ROOT"})
    c.write_new(OUT / "delivery-hashes.json", {"version": VERSION,
        "files": [c.file_identity(p) for p in sorted(OUT.rglob("*")) if p.is_file() and p.name != "delivery-hashes.json"]})
    print(c.canonical({"handoff": str(OUT / "handoff.json"), "tests": tests.testsRun, "owner_model_calls": 0,
        "ready_ids": [r["image_id"] for r in cases if r["ready_for_review"]], "candidates": 549}))


if __name__ == "__main__":
    main()
