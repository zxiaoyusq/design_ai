"""CLOSURE-DNA-002 round2: bounded invalid-wire isolation, no inference."""
VERSION = "r17-local-cmf-v1.2"
