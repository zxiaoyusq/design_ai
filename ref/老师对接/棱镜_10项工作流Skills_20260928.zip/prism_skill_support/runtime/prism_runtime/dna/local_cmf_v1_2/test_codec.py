"""Bounded offline codec checks; test scratch is caller-configurable."""
import copy
import os
from pathlib import Path
import tempfile
import unittest

from ..local_cmf_v1 import common as old_common
from ..local_cmf_v1.test_boundaries import supported
from . import audit, common as c, pipeline

RUN = c.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/closure-20260927"
CASES = ["TR002", "TR003", "TR007", "TR009", "TR010", "TR011", "TR012", "TR015"]


def test_root():
    root = Path(os.environ.get("PRISM_LOCAL_CMF_TEST_ROOT", str(c.HERE / "tests-output"))).resolve()
    c.require(root.is_relative_to(c.PROJECT / "outputs") or root.is_relative_to(c.HERE), "Test scratch must be in the designated project output/module directory")
    root.mkdir(parents=True, exist_ok=True)
    return root


class CodecTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = {}
        for cid in CASES:
            prep = c.read(RUN / "images-v1_1" / cid / "preparation.json")
            raw = c.read(RUN / "calls" / ("P-" + cid) / "answer.json")
            decoded = c.worker({"action": "decode", "raw": raw, "pixels": prep["pixels"]})
            cls.data[cid] = {"raw": raw, "prep": prep, "decoded": decoded}
        prompt = (RUN / "calls/P-TR011/prompt.txt").read_text(encoding="utf-8")
        cls.runtime = c.loads(prompt.split("\n原字典完整视觉部分及原ID/编码对应：\n")[1].split("\n定位以完整可见图像边界")[0])
        cls.ids = [p["parameter_id"] for p in c.read(c.DICTIONARY)["parameters"]]

    def decode(self, cid, raw=None):
        d = self.data[cid]
        return c.worker({"action": "decode", "raw": raw if raw is not None else d["raw"], "pixels": d["prep"]["pixels"]})

    def audited(self, cid):
        d = self.data[cid]["decoded"]
        return audit.audit_units(d["normalized"], d["declared_bindings"], cid, d["report"])

    def test_six_located_cases_recover_only_independent_candidates(self):
        expected = {"TR002": 119, "TR003": 131, "TR007": 59, "TR011": 99, "TR012": 66, "TR015": 75}
        for cid, count in expected.items():
            d = self.data[cid]["decoded"]
            self.assertIsNone(d["decode_error"])
            self.assertFalse(d["report"]["passed"])
            self.assertFalse(d["normalized"]["complete_original_normalization"])
            a = self.audited(cid)
            self.assertEqual(len(a["candidates"]), count)
            self.assertFalse(a["useful"])

    def test_faults_are_exact_original_tokens_not_unknown(self):
        for cid in ["TR002", "TR003", "TR007", "TR011", "TR012", "TR015"]:
            data = self.data[cid]; d = data["decoded"]
            trace = d["normalized"]["codec_recovery"]
            for f in trace["faults"]:
                value = data["raw"]
                for part in f["pointer"].strip("/").split("/"):
                    value = value[int(part)] if isinstance(value, list) else value[part]
                self.assertEqual(value, f["raw_token"])
                rows = [r for r in d["normalized"]["assessments"] if (r["parameter_id"], r["object_id"], r["reference_object_id"]) == (f["pid"], f["oid"], f["ref"])]
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["value_status"], "invalid_encoding")
                self.assertEqual(rows[0]["decode_status"], "not_decoded")
                self.assertIsNone(rows[0]["value"])
                self.assertEqual(rows[0]["raw_token"], value)
            self.assertFalse(trace["shadow_placeholder_states_exported"])

    def test_minus_one_in_detail_is_not_relabelled_legal_unknown(self):
        for cid in ["TR002", "TR003"]:
            row = next(r for r in self.data[cid]["decoded"]["normalized"]["assessments"] if r["value_status"] == "invalid_encoding")
            self.assertEqual(row["raw_token"], -1)

    def test_bad_tex_core_blocks_same_carrier_texture_but_not_other_carriers(self):
        a = self.audited("TR011")
        for oid in ["o2", "o10"]:
            tex = [u for u in a["units"] if u["object_id"] == oid and u["parameter_id"].startswith("TEX-")]
            self.assertTrue(tex)
            self.assertTrue(all(not u["program_eligible"] for u in tex))
            colours = [u for u in a["units"] if u["object_id"] == oid and u["parameter_id"].startswith("COL-")]
            self.assertTrue(any(u["program_eligible"] for u in colours))
        self.assertTrue(any(u["program_eligible"] and u["object_id"] not in ["o2", "o10"] and u["parameter_id"].startswith("TEX-") for u in a["units"]))

    def test_ambiguous_multi_reference_and_core_extra_remain_blocked(self):
        self.assertIsNone(self.data["TR009"]["decoded"]["normalized"])
        self.assertIn("Ambiguous", self.data["TR009"]["decoded"]["decode_error"])
        self.assertFalse(self.audited("TR010")["ready_for_review"])
        self.assertFalse(self.data["TR010"]["decoded"]["report"]["passed"])

    def test_bad_pid_key_blocks_recovery(self):
        raw = copy.deepcopy(self.data["TR007"]["raw"])
        raw["o"][2]["d"][0] = 999999
        d = self.decode("TR007", raw)
        self.assertIsNone(d["normalized"])

    def test_bad_core_reference_duplicate_blocks_recovery(self):
        raw = copy.deepcopy(self.data["TR007"]["raw"])
        raw["o"][0]["d"].extend([[self.ids.index("GEO-001"), 2], 1])
        d = self.decode("TR007", raw)
        self.assertIsNone(d["normalized"])
        self.assertIn("Ambiguous", d["decode_error"])

    def test_broken_parent_and_region_never_use_shadow(self):
        for change in ["parent", "region"]:
            raw = copy.deepcopy(self.data["TR007"]["raw"])
            if change == "parent": raw["o"][2]["g"][1] = 999
            else: raw["o"][2]["g"][2:6] = [900, 0, 100, 900]
            d = self.decode("TR007", raw)
            self.assertIsNone(d["normalized"])
            self.assertFalse(d["codec_diagnostic"]["shadow_used"])

    def test_unregistered_bad_core_not_silently_repaired(self):
        raw = copy.deepcopy(self.data["TR007"]["raw"])
        raw["o"][0]["c"][0] = [1, 2]
        d = self.decode("TR007", raw)
        self.assertIsNone(d["normalized"])
        self.assertIn("Unregistered", d["decode_error"])

    def test_valid_inputs_are_value_for_value_equal_to_old_codec(self):
        for cid in ["R002", "R005", "R009"]:
            prep = c.read(RUN / "images" / cid / "preparation.json")
            payload = {"action": "decode", "raw": c.read(RUN / "calls" / ("P-" + cid) / "answer.json"), "pixels": prep["pixels"]}
            old = old_common.worker(payload); new = c.worker(payload)
            for key in ["report", "normalized", "declared_bindings", "decode_error"]:
                self.assertEqual(c.canonical(old[key]), c.canonical(new[key]))
            self.assertFalse(new["codec_diagnostic"]["shadow_used"])

    def test_all_unknown_or_invalid_has_no_useful_projection(self):
        raw = copy.deepcopy(self.data["TR011"]["raw"])
        for obj in raw["o"]:
            core = self.runtime["core_original_ids"][str(obj["g"][0])]
            for i, pid in enumerate(core):
                if pid.startswith(("COL-", "OPT-", "TEX-")): obj["c"][i] = -1
            obj["d"] = [part for i in range(0, len(obj["d"]), 2)
                if not self.ids[obj["d"][i][0] if isinstance(obj["d"][i], list) else obj["d"][i]].startswith(("COL-", "OPT-", "TEX-"))
                for part in obj["d"][i:i+2]]
        core = self.runtime["core_original_ids"][str(raw["o"][1]["g"][0])]
        raw["o"][1]["c"][core.index("TEX-002")] = [3, 8]
        d = self.decode("TR011", raw)
        self.assertIsNone(d["decode_error"])
        a = audit.audit_units(d["normalized"], d["declared_bindings"], "synthetic-all-unknown", d["report"])
        self.assertFalse(a["ready_for_review"])
        self.assertEqual(a["candidates"], [])

    def test_old_v1_and_tr001_real_global_issue_still_verify_unchanged(self):
        for cid, count in [("R002", 33), ("R005", 43), ("R009", 43)]:
            self.assertEqual(pipeline.verify_projection(RUN / "images" / cid / "cmf.image-dna.json")["accepted_count"], count)
        path = RUN / "images-v1_1/TR001/cmf.image-dna.json"
        self.assertTrue(path.exists())
        result = pipeline.verify_projection(path)
        self.assertTrue(result["passed"])
        self.assertFalse(result["useful_local_cmf"])
        self.assertEqual(result["accepted_count"], 0)

    def test_persisted_partial_ledger_replays_and_cannot_clear_invalid_token(self):
        with tempfile.TemporaryDirectory(dir=test_root()) as td:
            root = Path(td); data = self.data["TR011"]
            photo = Path(data["prep"]["image"]["path"])
            source = c.write_new(root / "synthetic-source.json", {"records": [{"image_id": "synthetic-codec",
                "sha256": c.file_hash(photo), "source_kind": "synthetic", "basis": "Protocol fixture only, no new model or visual judgment"}]})
            folder = root / "prepared"
            pipeline.prepare(photo, "synthetic-codec", "synthetic", source, folder)
            raw = RUN / "calls/P-TR011/answer.json"
            def record(stage, output):
                return c.write_new(root / (stage + ".json"), {"stage": stage, "model": "gpt-6-astra", "service_tier": "default",
                    "image_sha256": c.file_hash(photo), "prompt_sha256": c.file_hash(folder / (stage + ".prompt.txt")),
                    "schema_sha256": c.file_hash(folder / (stage + ".schema.json")), "schema_ref": str(folder / (stage + ".schema.json")),
                    "raw_output_sha256": c.file_hash(output), "call_id": "synthetic-" + stage,
                    "source_ref": str(source), "execution_kind": "synthetic_fixture"})
            accepted = pipeline.accept(folder, raw, record("primary", raw))
            self.assertTrue(accepted["ready_for_review"])
            p = c.read(folder / "review.proposal.json")
            reply = c.write_new(root / "synthetic-review.json", supported(p))
            final = pipeline.accept_review(folder, reply, record("review", reply))
            self.assertTrue(final["useful_local_cmf"])
            result = pipeline.verify_projection(final["projection_ref"])
            self.assertTrue(result["passed"])
            out = c.read(final["projection_ref"])
            self.assertFalse(out["source_validation"]["original_full_216_pass"])
            self.assertFalse(out["cmf_admission"]["complete_original_normalization"])
            self.assertEqual(len(out["cmf_admission"]["invalid_encoding_observation_ids"]), 2)
            npath = folder / "normalized.json"
            n = c.read(npath)
            invalid = next(r for r in n["assessments"] if r["value_status"] == "invalid_encoding")
            invalid["value_status"] = "unknown"
            npath.write_text(c.canonical(n), encoding="utf-8")
            with self.assertRaises(ValueError): pipeline.verify_projection(final["projection_ref"])


if __name__ == "__main__":
    unittest.main()
