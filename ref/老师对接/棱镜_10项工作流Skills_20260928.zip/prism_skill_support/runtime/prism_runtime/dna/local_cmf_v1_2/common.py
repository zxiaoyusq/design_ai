from pathlib import Path
import json
import subprocess
import sys
from ..local_cmf_v1_1 import common as previous_common
from ..local_cmf_v1_1.common import *
from . import VERSION

HERE = Path(__file__).resolve().parent


def module_sources():
    return sorted(previous_common.module_sources() + [file_identity(p) for p in sorted(HERE.glob("*.py"))], key=lambda x: x["path"])


def worker(payload):
    proc = subprocess.run([sys.executable, "-B", "-X", "utf8", str(HERE / "worker.py")],
        input=json.dumps(payload, ensure_ascii=False, allow_nan=False), text=True, encoding="utf-8",
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    require(proc.returncode == 0, "Local defensive codec failed: " + proc.stderr[-3000:])
    return loads(proc.stdout)
