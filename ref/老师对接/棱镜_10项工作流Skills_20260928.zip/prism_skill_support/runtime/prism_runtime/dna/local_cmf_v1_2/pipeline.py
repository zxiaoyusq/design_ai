"""Frozen v1 engine isolated under v1.2; old verification remains untouched."""
import copy
import importlib.util
from pathlib import Path
from ..local_cmf_v1 import pipeline as base
from ..local_cmf_v1_1 import pipeline as prior
from . import VERSION
from .common import read, require, worker, write_new

spec = importlib.util.spec_from_file_location(__package__ + "._frozen_engine", Path(base.__file__))
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
engine.REVIEW_INSTRUCTIONS += '''\n本版本可能提供recovered_partial_ledger。invalid_encoding/not_decoded是原编码错误，既不是unknown也不是NA；原token和槽位已保留但不属于候选。不要把程序影子占位当图像事实，也不要在本次审核里代填错误值。原完整解析失败仍为false，当前只审核已无损恢复且独立的CMF观察。'''
original_project = engine._project


def _project(folder, manifest, normalized, units, proposal, response, resolution, review_call):
    document = original_project(folder, manifest, normalized, units, proposal, response, resolution, review_call)
    admission = document["cmf_admission"]
    admission["original_error_isolation"] = copy.deepcopy(units["original_error_isolation"])
    admission["isolated_non_cmf_units"] = [copy.deepcopy(u) for u in units["units"] if u.get("original_error_indices")]
    admission["source_ledger_kind"] = normalized.get("artifact_kind", "original_normalized_ledger")
    admission["complete_original_normalization"] = normalized.get("complete_original_normalization", True)
    if normalized.get("codec_recovery"):
        admission["codec_recovery"] = copy.deepcopy(units["codec_recovery"])
        admission["invalid_encoding_observation_ids"] = units["invalid_encoding_observation_ids"]
        admission["invalid_encoding_dependency_blocked_observation_ids"] = units["invalid_encoding_dependency_blocked_observation_ids"]
        admission["invalid_encoding_is_not_unknown_or_NA"] = True
        document["provenance"]["normalization_kind"] = "recovered_partial_ledger_not_original_complete_normalized"
    return document


engine._project = _project
prepare = engine.prepare
accept_review = engine.accept_review


def accept(prepared_dir, raw_output, run_record):
    result = engine.accept(prepared_dir, raw_output, run_record)
    folder = Path(prepared_dir).resolve()
    m = read(folder / "preparation.json")
    try:
        decoded = worker({"action": "decode", "raw": read(raw_output), "pixels": m["pixels"]})
        diagnostic = decoded.get("codec_diagnostic", {"status": "not_available"})
    except Exception as exc:
        diagnostic = {"status": "blocked", "reason": type(exc).__name__ + ": " + str(exc)}
    write_new(folder / "codec-diagnostic.json", diagnostic)
    return result


def verify_projection(path):
    version = read(path).get("provenance", {}).get("parser_version")
    if version in ["r17-local-cmf-v1", "r17-local-cmf-v1.1"]:
        return prior.verify_projection(path)
    require(version == VERSION, "Unsupported projection version")
    return engine.verify_projection(path)
