# 中性图片 DNA 离线适配器

将 R70 的 `normalized-analysis.json` 无损映射为 `prism.image_dna.v0.1`。本模块只做已有结果的接口转换，不调用模型、不重解析图片、不判断用户偏好或高级感，也不执行聚类。

## 可复跑

在 `D:/Codex/传音AI创客营` 下运行：

```powershell
& 'C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 -m prism_runtime.dna.export_examples
& 'C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 -m unittest prism_runtime.dna.test_adapter -v
```

示例输出在 `outputs/prism-algorithm-loop-20260926/modules/dna/examples-v0.2/`。三个例子来自已完成的 CMF PDF 校准批次，分别为 u012、u051、u132；其原有流程检查通过，但没有逐字段人工准确率金标准。不能把这些例子当作真实趋势资料或真实用户偏好证据。

Python 入口：

```python
from prism_runtime.dna.adapter import adapt_normalized, verify_export

result = adapt_normalized(
    source_ref='完整原 normalized-analysis.json 的绝对路径',
    image_id='业务侧稳定图片ID',
    source_kind='calibration',
    image_path='当前解析对应单图的绝对路径',
    source_provenance_ref='能够追溯该素材来源的清单文件',
    source_kind_basis='为何将该资料认定为此种来源的真实依据',
    parser_version='R70 / qwen3.8-flash / original DNA v0.3',
    validation_ref='原 benchmark-result.json 的绝对路径',
    raw_output_ref='原 final-wire.json 的绝对路径',
)
check = verify_export(result)
```

同名参数亦可通过 `python -m prism_runtime.dna.adapter --help` 查看 CLI。CLI 还要求 `--output`；错误返回码为 2。无网络依赖，仅使用 Python 标准库。

## 保留什么

- 每一条原生 assessment 都成为一条 observation；不合并、不删未知、不改值类型。
- 保留全部 216 个原字段覆盖，以及 148 项视觉、65 项输入条件、3 项区域/父级派生关系的划分和 ID 列表。完整字段定义仍引用原字典及其 SHA256。
- `known`、`unknown`、`not_applicable` 三种状态原样保留。后二者的值必须为 null，不能转为相似证据。
- 每条记录绑定真正的原对象 ID、原归一化图像区域、原 reference_object_id。区域框不是前景掩膜，不能把框内所有内容的属性都归给一个载体。
- evidence_refs 指向完整原生文件中的 assessment 和对象区域 JSON Pointer；同时保留原 evidence 文本、单位、resolver 与整行 native_assessment。
- `source_ref` 是完整标准化结果；`provenance.raw_output_ref` 指向完整原始模型结果。原始模型输出不被覆盖。

## 边界与契约差异

`source_kind` 由调用方根据真实来源显式提供，须带来源文件及说明。本模块不会因为图片外观、路径或实验需要把 calibration 改为 trend。原生每条 assessment 的 source_kind 表示 image_estimate/design_setting 等证据性质，输出为 `native_source_kind`，不与图片来源类别混用。

缺载体、缺参考对象、无效区域、未知状态带值、丢失原字段或断裂证据引用会报错；不补造值和区域。观察 ID 对同一个冻结结果稳定，不承诺在重新解析、改变行序后保持跨版本一致。

共享契约允许附加字段，因此增加了 `objects`、`dictionary_contract`、`source_validation` 及原生行信息。建议下游保留这些字段：输入条件推导、几何计算与模型视觉估计应区别使用；不能把适配成功当作解析准确或允许自动落库。若传入原流程未通过的记录，`source_validation.recorded_pipeline_pass` 会如实保留，不自动提升状态。

当前仅支持完整的 R70 标准化输出，不对失败/残缺原始 wire 格式作猜测修复。本轮没有修改共享契约、原字典、解析器或冻结实验；没有新增付费调用。


## v0.2 证据一致性修复

对应 DNA-EVAL-001/002/003：核对实际图片和原字典 SHA256，核对模型输入记录中的图片/字典身份，核对完整导出对象，以及 resolver、引用对象、单位、原始证据等行级字段。参数覆盖及148/65/3声明也与原始行逐项核对。旧版文件不覆盖；v0.2示例单独保存。20项本地测试通过，独立验收提供的9份不一致反例均被拒绝；这些仍是接口验证，不是视觉准确率证明。
