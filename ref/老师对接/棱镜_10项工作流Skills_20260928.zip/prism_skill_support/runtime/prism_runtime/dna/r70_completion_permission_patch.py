"""D01 final cycle: producer completeness and explicit existing-key permissions.

No edit permissions, engine semantics or final validation rules change. Runtime
thinking settings are a separately frozen proposal, never an API call here.
"""
from __future__ import annotations

import copy
import hashlib
import importlib.util
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "prism_completion_patch_frozen_v3", Path(__file__).with_name("r70_reference_edit_patch.py"))
prior = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(prior)

VERSION = "r70-completion-permission-d01-v4"
PROJECT, OPT, P, ACTIVE, CORE, DICT_PATH, base = (
    getattr(prior, k) for k in ["PROJECT", "OPT", "P", "ACTIVE", "CORE", "DICT_PATH", "base"])
compact, loads, require, exact, KEY, FACETS = (
    getattr(prior, k) for k in ["compact", "loads", "require", "exact", "KEY", "FACETS"])
validate, can_review, partial_preview = prior.validate, prior.can_review, prior.partial_preview
apply_correction, validate_after = prior.apply_correction, prior.validate_after
compile_response, review_reply_preflight = prior.compile_response, prior.review_reply_preflight
reference_diagnostics = prior.reference_diagnostics
correction_schema, request_schema = prior.correction_schema, prior.request_schema

PRIMARY_COMPLETION_RULES = '''
最后核对原输出合同，然后再提交JSON：顶层必须恰好有objects、frame、review、issues四个键，全部由你明确输出，一个也不能省略。输出顺序建议issues、objects、frame、review；顺序不改变原定义。不能因issues为空或觉得不重要而省掉这个键；程序不会替你补，也不会把缺键当成已完成。
先完成整图审阅再决定issues内容。沿用原定义：issues只记录你未完成的重要可见特征或区域错误。客观不可辨认的信息，在对应原字段显式unknown；缺BOM等输入条件不反复列作失败。普通光照、反光、景深描述本身不是未完成事项，可在对应原字段表达。如果它确实妨碍重要特征判断，则必须明确保留问题，不能为了通过校验隐藏。仅在你已核对没有这类未完成问题时，才由你明确输出空数组。
逐个核对：objects非空且每个对象有id/type/label/parent/box/origin/dna七键和该类型全部core；frame为对象；review恰好families和exceptions，families九族各有明确状态；issues为字符串数组。所有原字段及参照规则保持。程序不填缺失键、空数组、对象类型或字段状态。回答只保留完整四键JSON，不附自检说明。
'''

REVIEW_PERMISSION_RULES = '''
提交修改前，先检查本次fresh_permission_table。这张表来自当前初稿和已冻结授权，不是上一轮回复：existing_field_columns说明每行的对象、完整键、旧值、当前允许操作。数组为空表示只读，即使它是原字典有效字段、你怀疑其数值有误，也不能set/remove。read_only_original_parameters提供其原定义，避免把未获编辑权误当作字段无效。
特别是“已有正确语法的参照字段”不等于本轮有引用修复授权。extra_cell_grants为空时，不得自行发起新的引用修复。所有set/remove必须在精确对象/完整键的允许操作内；已有键改值只能set。需要新增键时继续遵循v3的base_allowed_pids或已诊断错误单元以及原类型/值/参照约束。不能因为另一字段允许修改而获得整族权限。
对真实但超出权限的问题，只在unresolved_issues准确报告，不得附越权编辑，也不能假称已修复。每条编辑与八个检查面的证据须对应；不要把接缝参照修复当成文字识别修复。readonly字段若无需修正就原样保留，不报告虚构问题。
initial_issue_policy说明初稿issues是否完整、已有多少项。原引擎不会删除初稿issues，复核不能以unresolved_issues=[]清除已有问题，也不能承诺该稿最终通过。若初稿已有重要未解决项，保持其证据，继续按原图报告真实状态。不要输出修改issues的额外协议键。
输出前最后比对一次七个顶层键、三个编辑映射、现有完整键权限、精确old值、全部八个facet和未解决事项。禁止重复键，禁止同键remove/add两次。该自检在本次响应内部完成，不增加调用，最终只提交规定JSON。
'''
INSTRUCTIONS = prior.INSTRUCTIONS + REVIEW_PERMISSION_RULES


def _digest(value):
    return hashlib.sha256(compact(value).encode("utf-8")).hexdigest()


def initial_issue_policy(draft):
    """Read only: state missing/locked issues explicitly, never default a key."""
    present = isinstance(draft, dict) and "issues" in draft
    issues = draft.get("issues") if present else None
    return {"issues_key_present": present, "issues_value_is_list": isinstance(issues, list),
        "initial_issues": copy.deepcopy(issues),
        "initial_issue_count": len(issues) if isinstance(issues, list) else None,
        "original_review_can_clear_initial_issues": False,
        "original_can_review": can_review(draft),
        "host_filled_or_cleared_issues": False}


def fresh_permission_table(draft, scope):
    base_allowed, grants = prior._scope_contract(draft, scope)
    rows, read_only = [], set()
    carriers = [(n["id"], n["type"], n["dna"]) for n in draft["objects"]] + [(0, "O19", draft["frame"])]
    for oid, otype, values in carriers:
        for key, old in values.items():
            match = KEY.fullmatch(key) if isinstance(key, str) else None
            pid = match.group(1) if match else None
            in_scope = pid in base_allowed or key in grants.get(str(oid), {}).get(pid, [])
            locked = pid in CORE.get(otype, [])
            ops = (["set"] + ([] if locked else ["remove"])) if in_scope else []
            rows.append([oid, otype, key, copy.deepcopy(old), ops])
            if not ops and pid in ACTIVE:
                read_only.add(pid)
    columns = ["parameter_id", "name", "definition", "value_type", "value_schema", "applicable_object_types"]
    return {"producer_version": VERSION, "draft_sha256": _digest(draft),
        "existing_field_columns": ["object_id", "original_type", "exact_field_key", "exact_old_value", "allowed_existing_key_operations"],
        "existing_fields": rows,
        "read_only_parameter_columns": columns,
        "read_only_original_parameters": [[P[pid][col] for col in columns] for pid in sorted(read_only)],
        "original_core_locks_apply_even_when_type_changes": True,
        "add_policy": "Absent full key only; explicit old=null; existing base scope or diagnosed cell grants; all original final constraints retained",
        "is_permission_presentation_not_new_authorization": True,
        "scope_expanded_after_model_reply": False}


def build_inputs(photo):
    prompt, schema, width, height, _ = prior.build_inputs(photo)
    # Repeat only the four-key envelope and state/issue contract at the end;
    # the complete original dictionary and original schema stay intact.
    prompt += "\n" + PRIMARY_COMPLETION_RULES
    return prompt, schema, width, height, prompt


def review_scope(draft, normalized):
    scope = copy.deepcopy(prior.review_scope(draft, normalized))
    scope["fresh_permission_table"] = fresh_permission_table(draft, scope)
    scope["initial_issue_policy"] = initial_issue_policy(draft)
    # Keep review_wire_version=v3, since no wire/engine authorization changes.
    scope["producer_version"] = VERSION
    return scope


def critic_prompt(draft, scope):
    require(scope.get("producer_version") == VERSION, "Fresh v4 producer scope required")
    require(exact(scope.get("fresh_permission_table"), fresh_permission_table(draft, scope)),
            "Permission presentation is stale or changed")
    require(exact(scope.get("initial_issue_policy"), initial_issue_policy(draft)), "Issue snapshot changed")
    prompt = prior.critic_prompt(draft, scope)
    require(prompt.startswith(prior.INSTRUCTIONS), "Frozen v3 prompt layout changed")
    return INSTRUCTIONS + prompt[len(prior.INSTRUCTIONS):] + "\n最后仅提交经精确键权限自检的七键JSON。只读键不进入编辑映射。"


def candidate_runtime_plan():
    """A proposal for Root to verify/freeze, not active transport settings."""
    return {"status": "proposed_not_executed_by_owner", "model": "qwen3.8-flash",
        "parameters": {"temperature": 0, "enable_thinking": True, "thinking_budget": 2048,
                       "max_tokens": 8192, "response_format": {"type": "json_object"}},
        "stages": ["primary", "visual-review"], "transport_timeout_seconds": 180,
        "max_calls_per_image": 2, "max_total_calls": 4, "max_attempts_per_call": 1,
        "image_ids": ["R002", "R005"], "automatic_retries": False,
        "output_budget_note": "Keep the existing8192 final-answer cap; the bounded reasoning budget is2048 per call. Root must verify native parameter/account support and actual reasoning usage; no promised latency or fee reduction.",
        "response_parser": "Use final content only with strict original loads; do not feed reasoning_content to JSON parser or use it as a missing-key answer",
        "unsupported_parameter_policy": "Record error and stop within4 attempts; no silent fallback or additional retries",
        "schema_enforcement": "Image inputs use JSON-object; do not claim provider-enforced JSON Schema",
        "no_third_model_stage": True,
        "official_references": [
            {"url": "https://help.aliyun.com/en/model-studio/qwen-structured-output", "consulted_on": "2026-09-27",
             "supports": "JSON Object does not guarantee key schema; image/video/audio inputs fall back from json_schema to json_object"},
            {"url": "https://help.aliyun.com/zh/model-studio/visual-reasoning", "consulted_on": "2026-09-27",
             "supports": "Qwen3.8 supports thinking_budget to bound reasoning tokens; additional reasoning can add time and usage"},
            {"url": "https://help.aliyun.com/zh/model-studio/deep-thinking", "consulted_on": "2026-09-27",
             "supports": "qwen3.8-flash mixed thinking; commercial thinking synchronous output; content and reasoning_content differ"}],
        "stop_rule": "Final cycle3 of QWEN-D01-REVIEW-002. Continued same-problem failure => stop this protocol loop, report partial and next architectural decision; do not rename for cycle4."}


def association_registry():
    registry = copy.deepcopy(prior.association_registry())
    registry["completion_permission_producer"] = {"version": VERSION,
        "primary_required_envelope_reiterated": True, "explicit_existing_key_permission_table": True,
        "read_only_original_definitions_included": True, "missing_issues_not_defaulted": True,
        "initial_issues_cannot_be_cleared": True, "scope_or_wire_changed": False,
        "apply_and_final_validator_exact_v3_aliases": True,
        "runtime_plan_sha256": _digest(candidate_runtime_plan()), "repair_cycle": 3, "max_cycles": 3}
    return registry
