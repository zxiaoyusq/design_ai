"""Offline diagnostics tests; recorded Qwen failures are never repaired by host."""
import copy
import hashlib
import json
import unittest
from pathlib import Path

from prism_runtime.dna import r70_applicability_patch as patch

RUN = patch.PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/qwen-cli-20260927/runs/provider-integration-pilot-01"
VALID = patch.OPT / "pdf-cmf-ee1-r70-20260926/trials/u012"

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def digest(value):
    return hashlib.sha256(patch.compact(value).encode()).hexdigest()

def fragment(object_type, dna, oid=1, frame=None):
    # Synthetic grammar-only input, not a manually corrected photo analysis.
    return {"objects": [{"id": oid, "type": object_type, "dna": dna}], "frame": frame or {}}

class ApplicabilityRepairTests(unittest.TestCase):
    def test_tr006_reports_all_seven_occurrences(self):
        raw = read(RUN / "dna/TR006/initial-wire.json")
        diagnostics = patch.applicability_diagnostics(raw)
        self.assertEqual(len(diagnostics), 7)
        self.assertEqual({d["object_id"] for d in diagnostics}, set(range(2, 9)))
        self.assertTrue(all(d["parameter_id"] == "EMI-001" for d in diagnostics))
        self.assertTrue(all(d["existing_value"] is False for d in diagnostics))

    def test_r001_reports_all_42_not_just_the_first(self):
        raw = read(RUN / "dna/R001/initial-wire.json")
        diagnostics = patch.applicability_diagnostics(raw)
        self.assertEqual(len(diagnostics), 42)
        self.assertEqual({d["object_id"] for d in diagnostics}, {3, 4, 5})
        self.assertEqual(len({d["diagnostic_id"] for d in diagnostics}), 42)

    def test_scope_retains_numeric_errors_and_adds_hidden_applicability_errors(self):
        raw = read(RUN / "dna/R001/initial-wire.json")
        scope = patch.review_scope(raw, None)
        codes = [d["code"] for d in scope["structural_diagnostics"]]
        self.assertEqual(codes.count("invalid_original_value"), 6)
        self.assertEqual(codes.count("original_field_object_incompatible"), 42)
        self.assertEqual(len(scope["incompatible_binding_groups"]), 14)

    def test_preflight_does_not_mutate_input(self):
        for case in ["TR006", "R001"]:
            raw = read(RUN / "dna" / case / "initial-wire.json")
            before = digest(raw)
            patch.applicability_diagnostics(raw)
            patch.review_scope(raw, None)
            self.assertEqual(digest(raw), before)

    def test_unknown_and_na_do_not_exempt_disallowed_types(self):
        for value in [None, False, "unknown", "not_applicable", "false", "null", "无"]:
            with self.subTest(value=value):
                rows = patch.applicability_diagnostics(fragment("O07", {"EMI-001": value}))
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["original_allowed_object_types"], ["O09"])

    def test_legal_emission_carrier_not_flagged(self):
        self.assertEqual(patch.applicability_diagnostics(fragment("O09", {"EMI-001": "无", "EMI-002": False})), [])

    def test_mixed_carriers_do_not_trigger_blanket_family_removal(self):
        raw = fragment("O09", {"EMI-001": "有"})
        raw["objects"].append({"id": 2, "type": "O07", "dna": {"EMI-001": False}})
        before = copy.deepcopy(raw)
        self.assertEqual([d["object_id"] for d in patch.applicability_diagnostics(raw)], [2])
        self.assertEqual(raw, before)

    def test_general_original_permissions_not_emission_only(self):
        rows = patch.applicability_diagnostics(fragment("O13", {"OPT-001": "金属外观"}))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["parameter_id"], "OPT-001")

    def test_frame_slot_contract_retained(self):
        raw = {"objects": [], "frame": {"GEO-001": "圆弧"}}
        rows = patch.applicability_diagnostics(raw)
        self.assertTrue(any(d["code"] == "original_wire_slot_mismatch" for d in rows))

    def test_invalid_pid_diagnosis_still_belongs_to_original_preflight(self):
        raw = read(VALID / "final-wire.json")
        raw["objects"][0]["dna"]["NEW-001"] = "not an original field"
        scope = patch.review_scope(raw, None)
        self.assertTrue(any(d["code"] == "invalid_original_pid" for d in scope["structural_diagnostics"]))
        self.assertNotIn("NEW-001", scope["allowed_pids"])

    def test_permission_registry_exactly_reproduces_original148(self):
        mapping = {}
        for group in patch.permission_groups():
            for pid in group["parameter_ids"]:
                self.assertNotIn(pid, mapping)
                mapping[pid] = group["original_allowed_object_types"]
        self.assertEqual(set(mapping), patch.ACTIVE)
        self.assertEqual(len(mapping), 148)
        for pid, types in mapping.items():
            self.assertEqual(types, patch.P[pid]["applicable_object_types"])

    def test_original_validator_and_edit_engine_are_not_replaced(self):
        self.assertIs(patch.validate, patch.baseline.validate)
        self.assertIs(patch.apply_correction, patch.baseline.apply_correction)
        self.assertEqual(patch.correction_schema(), patch.baseline.correction_schema())

    def test_saved_finals_still_rejected_with_original_error(self):
        for case in ["TR006", "R001"]:
            folder = RUN / "dna" / case
            raw = read(folder / "final-wire.json")
            width, height = read(folder / "input-manifest.json")["photo_original_pixels"]
            result, normalized = patch.validate(raw, width, height)
            old_result, old_normalized = patch.baseline.validate(raw, width, height)
            self.assertEqual(result, old_result)
            self.assertIsNone(normalized)
            self.assertIsNone(old_normalized)
            self.assertFalse(result["passed"])
            self.assertIn("EMI-001@o3", result["errors"][0])

    def test_real_saved_reviews_replay_without_invented_edits(self):
        for case, remaining in [("TR006", 6), ("R001", 42)]:
            folder = RUN / "dna" / case
            raw = read(folder / "initial-wire.json")
            response = read(RUN / "calls" / (case + "-visual-review") / "output.json")
            scope = patch.review_scope(raw, None)
            output, audit = patch.apply_correction(raw, response, scope)
            self.assertEqual(output, read(folder / "final-wire.json"))
            self.assertEqual(len(patch.applicability_diagnostics(output)), remaining)
            self.assertFalse(audit["host_inferred_values"])
            width, height = read(folder / "input-manifest.json")["photo_original_pixels"]
            result, normalized = patch.validate_after(raw, output, response, scope, width, height)
            self.assertFalse(result["passed"])
            self.assertEqual(result["applicability_preflight_after"]["remaining_count"], remaining)

    def test_existing_valid_full216_remains_valid(self):
        raw = read(VALID / "final-wire.json")
        result, normalized = patch.validate(raw, 347, 347)
        self.assertTrue(result["passed"])
        self.assertEqual(result["covered_parameters"], 216)
        self.assertEqual(patch.applicability_diagnostics(raw), [])

    def test_primary_and_critic_rules_do_not_embed_case_answers(self):
        photo = patch.OPT / "pdf-cmf-ee1-r70-20260926/images/u012.png"
        prompt, schema, w, h, _ = patch.build_inputs(photo)
        old, old_schema, old_w, old_h, _ = patch.baseline.build_inputs(photo)
        self.assertTrue(prompt.startswith(old))
        self.assertEqual((schema, w, h), (old_schema, old_w, old_h))
        self.assertIn("状态不会使不允许的绑定合法", prompt)
        self.assertNotIn("TR006", patch.PRIMARY_RULES + patch.REVIEW_RULES)
        self.assertNotIn("R001", patch.PRIMARY_RULES + patch.REVIEW_RULES)
        raw = read(RUN / "dna/TR006/initial-wire.json")
        text = patch.critic_prompt(raw, patch.review_scope(raw, None))
        for oid in range(2, 9):
            self.assertIn(f"app:o{oid}:EMI-001", text)

if __name__ == "__main__":
    unittest.main()
