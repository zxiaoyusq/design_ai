"""Offline behavioral checks using one immutable real model output and mutations."""
from pathlib import Path
import copy
import json
import tempfile
import unittest

from prism_runtime.dna.adapter import AdapterError, PROJECT, adapt_normalized, read_json, verify_export

DATASET = PROJECT / "outputs/01a0c2a0-b850-7fd1-a032-78e192743557/dna-optimization-loop-20260925/pdf-cmf-ee1-r70-20260926"

class AdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = DATASET / "trials/u012/normalized-analysis.json"
        cls.native = read_json(cls.source)
        cls.options = dict(image_id="cmf-calibration:u012", source_kind="calibration",
                           image_path=DATASET / "images/u012.png", source_provenance_ref=DATASET / "manifest.json",
                           source_kind_basis="User-supplied CMF PDF used for parser validation; no trend provenance asserted.",
                           parser_version="R70 / qwen3.8-flash", validation_ref=DATASET / "trials/u012/benchmark-result.json",
                           raw_output_ref=DATASET / "trials/u012/final-wire.json")

    def native_mutation(self, mutate):
        data = copy.deepcopy(self.native)
        mutate(data)
        with tempfile.TemporaryDirectory(prefix="prism-dna-test-") as temp:
            path = Path(temp) / "native.json"
            path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            with self.assertRaises(AdapterError):
                adapt_normalized(path, **self.options)

    def test_all_original_rows_and_216_fields_preserved(self):
        out = adapt_normalized(self.source, **self.options)
        self.assertEqual(len(out["observations"]), len(self.native["assessments"]))
        self.assertEqual(len({o["parameter_id"] for o in out["observations"]}), 216)
        self.assertEqual(out["dictionary_contract"]["resolution_role_counts"], {"vision_model":148,"declared_input_rule":65,"geometry_calculation":3})
        self.assertEqual(out["source_kind"], "calibration")
        self.assertFalse(out["source_validation"]["visual_accuracy_established"])

    def test_unknown_and_not_applicable_remain_distinct(self):
        out = adapt_normalized(self.source, **self.options)
        self.assertEqual({o["value_status"] for o in out["observations"]}, {"known","unknown","not_applicable"})
        for original, exported in zip(self.native["assessments"], out["observations"]):
            self.assertEqual(original["value"], exported["value"])
            self.assertEqual(original["value_status"], exported["value_status"])

    def test_missing_carrier_is_error_not_invented_region(self):
        self.native_mutation(lambda d: d["assessments"][0].update(object_id="missing"))

    def test_invalid_original_region_is_error(self):
        self.native_mutation(lambda d: d["objects"][1].update(region=[0,0,2,1]))

    def test_missing_reference_carrier_is_error(self):
        self.native_mutation(lambda d: d["assessments"][0].update(reference_object_id="missing"))

    def test_known_null_is_error(self):
        self.native_mutation(lambda d: d["assessments"][0].update(value=None))

    def test_unknown_does_not_become_known_support(self):
        def mutate(d):
            next(r for r in d["assessments"] if r["value_status"]=="unknown")["value"]="unsupported metal"
        self.native_mutation(mutate)

    def test_dropped_original_parameter_is_error(self):
        self.native_mutation(lambda d: d.update(assessments=[r for r in d["assessments"] if r["parameter_id"]!="MAT-001"]))

    def test_no_renaming_original_parameter(self):
        self.native_mutation(lambda d: d["assessments"][0].update(parameter_id="pretty"))

    def test_no_assumed_source_kind(self):
        options = dict(self.options, source_kind="unknown")
        with self.assertRaises(AdapterError):adapt_normalized(self.source, **options)

    def test_broken_evidence_pointer_rejected(self):
        out = adapt_normalized(self.source, **self.options)
        out["observations"][0]["evidence_refs"][0]=self.source.as_posix()+"#/assessments/99999"
        with self.assertRaises(AdapterError):verify_export(out)

    def test_real_but_wrong_evidence_pointer_rejected(self):
        out = adapt_normalized(self.source, **self.options)
        out["observations"][0]["evidence_refs"][0]=self.source.as_posix()+"#/assessments/1"
        with self.assertRaises(AdapterError):verify_export(out)

    def test_changed_exported_value_rejected(self):
        out = adapt_normalized(self.source, **self.options)
        out["observations"][0]["value"]="invented"
        with self.assertRaises(AdapterError):verify_export(out)

    def test_stable_observation_ids(self):
        one=adapt_normalized(self.source, **self.options)
        two=adapt_normalized(self.source, **self.options)
        self.assertEqual([o["observation_id"] for o in one["observations"]],[o["observation_id"] for o in two["observations"]])

    def test_other_real_image_rejected(self):
        out=adapt_normalized(self.source, **self.options)
        out['image_path']=(DATASET/'images/u051.png').as_posix()
        with self.assertRaises(AdapterError):verify_export(out)

    def test_wrong_image_hash_rejected(self):
        out=adapt_normalized(self.source, **self.options)
        out['provenance']['image_sha256']='0'*64
        with self.assertRaises(AdapterError):verify_export(out)

    def test_wrong_dictionary_hash_rejected(self):
        out=adapt_normalized(self.source, **self.options)
        out['dictionary_contract']['dictionary_sha256']='0'*64
        with self.assertRaises(AdapterError):verify_export(out)

    def test_changed_resolver_rejected(self):
        out=adapt_normalized(self.source, **self.options)
        out['observations'][0]['resolved_by']='geometry_calculation'
        with self.assertRaises(AdapterError):verify_export(out)

    def test_changed_object_envelope_rejected(self):
        out=adapt_normalized(self.source, **self.options)
        out['objects'][1]['region']=[0,0,0.5,0.5]
        with self.assertRaises(AdapterError):verify_export(out)

    def test_coherent_image_substitution_still_must_match_parser_input(self):
        import hashlib
        out=adapt_normalized(self.source, **self.options)
        other=DATASET/'images/u051.png'
        out['image_path']=other.as_posix();out['provenance']['image_sha256']=hashlib.sha256(other.read_bytes()).hexdigest()
        with self.assertRaises(AdapterError):verify_export(out)

if __name__=="__main__":unittest.main()
