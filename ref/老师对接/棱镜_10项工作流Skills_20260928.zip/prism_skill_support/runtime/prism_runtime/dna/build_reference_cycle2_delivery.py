"""Publish the offline cycle-2 evidence package. No provider calls."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shutil
import unittest

from prism_runtime.dna import r70_reference_edit_patch as patch

ROOT = patch.PROJECT
LOOP = ROOT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
CLI = LOOP / "qwen-cli-20260927"
RUN = CLI / "runs/dna-review-v2-two-image-retest"
OUT = ROOT / "outputs/prism-algorithm-loop-20260926/modules/dna/repairs/QWEN-D01-REVIEW-002/cycle2-v1"


def read(path):
    return patch.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def text_sha(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def prompt_text(path):
    return "".join(p["text"] for m in read(path)["input"]["messages"] for p in m["content"] if "text" in p)


def main():
    if (OUT / "handoff.json").exists():
        raise SystemExit("Frozen delivery already published; create another version rather than overwriting.")
    OUT.mkdir(parents=True, exist_ok=True)
    dispatch_path = LOOP / "dispatches/QWEN-D01-REVIEW-002-cycle2.json"
    dispatch = read(dispatch_path)
    freeze_path = CLI / "candidate-freeze-v2.json"
    freeze = read(freeze_path)
    unchanged = {}
    def preserve(path, expected):
        path = Path(path)
        assert sha(path) == expected, str(path)
        unchanged[str(path)] = expected
    for name, expected in freeze["original_R70_freeze"]["source_hashes"].items():
        preserve(patch.OPT / name, expected)
    for item in freeze["candidate_source_files"]:
        preserve(item.get("source") or item["path"], item["sha256"])
    for item in freeze["source_files"]:
        source = Path(item["source"])
        if source.parent == ROOT / "prism_runtime/dna":
            preserve(source, item["sha256"])
    preserve(patch.DICT_PATH, freeze["original_R70_freeze"]["dictionary_sha256"])
    previous_delivery = OUT.parent / "v1/delivery-hashes.json"
    preserve(previous_delivery, sha(previous_delivery))
    for item in read(previous_delivery)["files"]:
        preserve(item["path"], item["sha256"])

    inputs = {str(dispatch_path): sha(dispatch_path), str(freeze_path): sha(freeze_path)}
    cases = []
    for case in dispatch["cases"]:
        cid = case["image_id"]
        folder = Path(case["primary_wire"]).parent
        dest = OUT / "cases" / cid
        (dest / "inputs").mkdir(parents=True, exist_ok=True)
        (dest / "outputs").mkdir(exist_ok=True)
        raw = read(Path(case["primary_wire"]))
        reply = read(Path(case["review_reply"]))
        original_scope = read(Path(case["review_scope"]))
        metadata = read(folder / "input-manifest.json")
        manifest_path = Path(metadata["source_manifest_ref"])
        source = next(r for r in read(manifest_path)["records"] if r["image_id"] == cid)
        photo = Path(source["path"])
        assert sha(photo) == source["sha256"] == metadata["photo_sha256"]
        inputs.update({str(photo): sha(photo), str(manifest_path): sha(manifest_path)})
        width, height = metadata["photo_original_pixels"]
        validation, normalized = patch.validate(raw, width, height)
        scope = patch.review_scope(raw, normalized)
        scope["primary_validation_errors"] = validation.get("errors", [])
        assert scope["base_allowed_pids"] == original_scope["allowed_pids"]
        assert "STR-006" not in original_scope["allowed_pids"]
        assert set(scope["allowed_pids"]) - set(original_scope["allowed_pids"]) == {"STR-006"}
        before = patch.compact([raw, reply, original_scope])
        replay = {"input_wire_and_reply_unchanged": True, "host_created_repaired_image_wire": False,
            "old_scope_str006_repair_impossible": True, "old_v2_pipeline_passed": False}
        try:
            final, _ = patch.prior.apply_correction(raw, reply, original_scope)
        except Exception as exc:
            replay["old_v2_apply_error"] = type(exc).__name__ + ": " + str(exc)
            assert cid == "R005" and str(exc) == "Duplicate DNA edit"
        else:
            assert cid == "R002"
            result, _ = patch.prior.validate_after(raw, final, reply, original_scope, width, height)
            assert not result["passed"]
            assert any("Explicit non-self host required for STR-006" in e for e in result["structure_validation"]["errors"])
            replay["old_v2_final_validation"] = result
            # This is the unmodified historical model proposal, not a new
            # owner-selected repair. Do not publish a corrected-image wire.
        try:
            patch.apply_correction(raw, reply, scope)
        except Exception as exc:
            replay["v3_old_array_wire_rejection"] = type(exc).__name__ + ": " + str(exc)
            assert "v3 unique-key object required" in str(exc)
        else:
            raise AssertionError("v3 silently converted an obsolete/bad wire")
        assert patch.compact([raw, reply, original_scope]) == before
        transport = []
        for stage in ["primary", "visual-review"]:
            call = RUN / "jobs" / cid / "calls" / (cid + "-" + stage)
            packet = read(call / "provider-response.json")
            result = read(call / "result.json")
            finish = packet["data"]["output"]["choices"][0]["finish_reason"]
            assert packet["http_status"] == 200 and finish == "stop"
            transport.append({"stage": stage, "http_status": packet["http_status"], "finish_reason": finish,
                "provider_seconds": result["provider_seconds"], "historical_transport_timeout_seconds": result["transport_timeout_seconds"],
                "usage": result["usage"], "transcript_ref": str(call / "provider-response.json")})
            for name in ["request.json", "provider-response.json", "output.json", "output.txt", "result.json"]:
                path = call / name
                inputs[str(path)] = sha(path)
                if name != "request.json":
                    # Keep raw provider text, without copying image data URLs.
                    target = dest / "inputs" / stage / name
                    target.parent.mkdir(exist_ok=True)
                    shutil.copyfile(path, target)
        for name in ["initial-wire.json", "final-wire.json", "input-manifest.json", "primary-validation.json", "visual-review-scope.json", "benchmark-result.json"]:
            path = folder / name
            if path.exists():
                inputs[str(path)] = sha(path)
                shutil.copyfile(path, dest / "inputs" / name)
        old_primary_path = RUN / "jobs" / cid / "calls" / (cid + "-primary") / "request.json"
        old_review_path = RUN / "jobs" / cid / "calls" / (cid + "-visual-review") / "request.json"
        old_primary = prompt_text(old_primary_path)
        assert patch.prior.build_inputs(photo)[0] == old_primary
        candidate_primary, primary_schema, _, _, _ = patch.build_inputs(photo)
        candidate_review = patch.critic_prompt(raw, scope)
        old_review = prompt_text(old_review_path)
        costs = {"measurement": "UTF-8 prompt bytes only, not provider tokens or price",
            "primary_v2": len(old_primary.encode()), "primary_v3": len(candidate_primary.encode()),
            "review_v2": len(old_review.encode()), "review_v3": len(candidate_review.encode())}
        costs["review_byte_change_percent"] = round((costs["review_v3"] / costs["review_v2"] - 1) * 100, 2)
        costs["combined_byte_change_percent"] = round(((costs["primary_v3"] + costs["review_v3"]) /
            (costs["primary_v2"] + costs["review_v2"]) - 1) * 100, 2)
        dump(dest / "outputs/reference-diagnostics.json", patch.reference_diagnostics(raw))
        dump(dest / "outputs/candidate-scope.json", scope)
        dump(dest / "outputs/candidate-request-schema.json", patch.request_schema(raw, scope))
        dump(dest / "outputs/unchanged-invalid-replay.json", replay)
        dump(dest / "outputs/old-reply-protocol-diagnostics.json", patch.prior.review_reply_preflight(raw, reply, original_scope))
        dump(dest / "outputs/transport-evidence.json", transport)
        dump(dest / "outputs/prompt-byte-comparison.json", costs)
        (dest / "outputs/candidate-primary.prompt.txt").write_text(candidate_primary, encoding="utf-8")
        (dest / "outputs/candidate-review-from-recorded-draft.prompt.txt").write_text(candidate_review, encoding="utf-8")
        cases.append({"image_id": cid, "source_kind": metadata["source_kind"], "image_sha256": sha(photo),
            "image_ref": str(photo), "original_reply_rejected_unchanged": True,
            "old_scope_could_not_repair_known_host_field": True,
            "reference_diagnostic_count": len(patch.reference_diagnostics(raw)),
            "extra_cell_grants": scope["reference_repair_contract"]["extra_cell_grants"],
            "transport": transport, "prompt_bytes": costs, "prior_primary_prompt_sha256": text_sha(old_primary),
            "candidate_primary_prompt_sha256": text_sha(candidate_primary),
            "prior_review_prompt_sha256": text_sha(old_review), "candidate_review_prompt_sha256": text_sha(candidate_review),
            "primary_schema_unchanged": primary_schema == patch.prior.build_inputs(photo)[1],
            "fresh_v3_qwen_effectiveness_tested": False})

    stream = io.StringIO()
    names = ["prism_runtime.dna.test_r70_reference_edit_patch", "prism_runtime.dna.test_r70_review_contract_patch",
             "prism_runtime.dna.test_r70_applicability_patch"]
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
    tests = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (OUT / "offline-tests.txt").write_text(stream.getvalue(), encoding="utf-8")
    assert tests.wasSuccessful()
    for path, expected in {**inputs, **unchanged}.items():
        assert sha(Path(path)) == expected, path
    files = [Path(patch.__file__).resolve(), ROOT / "prism_runtime/dna/test_r70_reference_edit_patch.py", Path(__file__).resolve()]
    dump(OUT / "source-hashes.json", [{"path": str(p), "sha256": sha(p)} for p in files])
    dump(OUT / "input-hashes.json", [{"path": p, "sha256": value} for p, value in sorted(inputs.items())])
    dump(OUT / "unchanged-v1-v2-and-baseline-hashes.json", [{"path": p, "sha256": value} for p, value in sorted(unchanged.items())])
    dump(OUT / "rules/static-response-schema.json", patch.correction_schema())
    dump(OUT / "rules/association-registry.json", patch.association_registry())
    (OUT / "rules/review-instructions.txt").write_text(patch.INSTRUCTIONS, encoding="utf-8")
    (OUT / "rules/primary-addendum.txt").write_text(patch.PRIMARY_RULES, encoding="utf-8")
    now = datetime.now(timezone.utc).isoformat()
    verification = {"issue_id": "QWEN-D01-REVIEW-002", "repair_cycle": 2, "version": patch.VERSION,
        "checked_utc": now, "tests": tests.testsRun, "failures": len(tests.failures), "errors": len(tests.errors),
        "new_tests": 36, "existing_protocol_regression_tests": tests.testsRun - 36,
        "new_paid_calls": 0, "fresh_v3_model_effectiveness_tested": False,
        "original_final_validator_exact_alias": patch.validate is patch.prior.validate,
        "original_edit_engine_called_after_lossless_compile": True, "dictionary_and_frozen_sources_unchanged": True,
        "strict_original_loads_exact_alias": patch.loads is patch.prior.loads,
        "original_bad_replies_rejected_unchanged": 2, "manual_repaired_image_answers_created": 0,
        "no_extra_inference_stage_implemented": True, "cases": cases}
    dump(OUT / "verification.json", verification)
    dump(OUT / "self-assessment.json", {"module": "dna", "issue_id": "QWEN-D01-REVIEW-002", "repair_cycle": 2,
        "status": "partial", "algorithm_version": patch.VERSION, "qualified": False,
        "qualified_scope": "Offline diagnosed-reference permissions, lossless unique-key encoding, rejection preservation only",
        "ready_for_independent_two_image_retest": True, "fresh_model_effectiveness_qualified": False,
        "visual_accuracy_qualified": False, "actual_results": {"offline_tests_passed": tests.testsRun,
            "actual_fresh_invalid_replies_kept_invalid": 2, "model_chosen_reference_success_examples": 0, "new_paid_calls": 0},
        "known_failures": ["Recorded v2 R002/R005 remain 0/2 complete; no v3 model responses exist in this package.",
            "Unique-key encoding cannot ensure that a syntactically valid reference matches the image.",
            "The second call still combines visual review and reference repair; adherence and latency require independent testing."],
        "holdout_description": "Two supplied failure examples plus clearly synthetic wire tests, not a held-out accuracy benchmark",
        "stop_rule": "Root max3 repair cycles; if third targeted candidate fails, stop and state next decision rather than loop indefinitely"})
    (OUT / "README.md").write_text(README, encoding="utf-8")
    handoff = {"module": "dna", "issue_id": "QWEN-D01-REVIEW-002", "repair_cycle": 2, "max_cycles": 3,
        "status": "partial", "algorithm_version": patch.VERSION, "contract_version": "0.1",
        "entrypoint": "import prism_runtime.dna.r70_reference_edit_patch as algo",
        "source_entrypoint": str(Path(patch.__file__).resolve()), "ready_for_two_image_qwen_retest": True,
        "production_qualified": False, "qualified_scope": "Offline protocol/permission handling only, not new model/visual accuracy",
        "files": [str(p) for p in files] + [str(OUT / n) for n in ["README.md", "verification.json", "self-assessment.json",
            "source-hashes.json", "input-hashes.json", "unchanged-v1-v2-and-baseline-hashes.json"]],
        "verification": {"command": "python -B -X utf8 -m unittest " + " ".join(names) + " -v",
            "result": f"offline_pass:{tests.testsRun} tests; actual bad v2 replies stay invalid; no manual repaired image answers",
            "record": str(OUT / "verification.json")}, "new_paid_calls": 0,
        "scope_change": "Original PID scope plus only diagnosed existing object/field reference cells; not a global host-field permission",
        "integration": {
            "primary_prompt_changed": True, "primary_schema_changed": False,
            "review_wire": "Same7top keys; dna_edits/object_edits/review_edits now objects, not arrays; incompatible old replies fail",
            "parser_required": "Parse original provider content text with algo.loads or equivalent strict duplicate-key/nonfinite rejection BEFORE any normal json.loads; dumping a lossy dict then reparsing is insufficient",
            "engine": "apply_correction losslessly compiles explicit model entries to the frozen original R70 engine; audit carries compiled_legacy_response and hashes",
            "full_validation": "Call validate_after plus downstream original export gate; no acceptance based only on preflight or review_complete",
            "fresh_scope": "Regenerate review_scope and critic_prompt from the fresh primary; recorded example prompts are never live answers",
            "freeze": "Freeze new sidecar+unchanged v2/v1+original dependencies and new primary/review/schema/registry hashes in a new candidate freeze",
            "retest": "Root independently preflight, then at most R002 and R005, fresh Qwen primary plus one same-image review each",
            "timeouts": "Root transport owns180s future image timeout; historical120s records unchanged"},
        "call_cost": {"implemented_calls_per_image": 2, "implemented_extra_model_calls": 0,
            "two_image_full_retest_calls": 4, "latency_or_token_price_measured": False,
            "alternative_unimplemented": "A separate model-only reference repair plus retained full review would raise total to3/image (6 for2images); only consider after this bounded retest fails; never substitute host repairs",
            "prompt_byte_evidence": [c["prompt_bytes"] for c in cases]},
        "limitations": ["No fresh v3 Qwen calls, accuracy or end-to-end timing demonstrated.",
            "UTF-8 byte reductions are not measured token/price savings.",
            "Strict structure and references do not establish correct visible features or downstream cluster utility.",
            "Original120 complete baseline13/120 and old candidate results are not overwritten."]}
    dump(OUT / "handoff.json", handoff)
    dump(OUT / "delivery-hashes.json", {"version": patch.VERSION, "generated_utc": now,
        "files": [{"path": str(p), "sha256": sha(p)} for p in sorted(OUT.rglob("*"))
                  if p.is_file() and p.name != "delivery-hashes.json"]})
    print(json.dumps({"status": "partial_ready_for_independent_retest", "tests": tests.testsRun,
        "new_paid_calls": 0, "handoff": str(OUT / "handoff.json"),
        "prompt_bytes": {c["image_id"]: c["prompt_bytes"] for c in cases}}, ensure_ascii=False))


README = '''# QWEN-D01-REVIEW-002 · Cycle 2

候选版本：r70-reference-edit-d01-v3。状态partial，仅离线协议与授权边界合格；没有新鲜Qwen结果或视觉准确率结论。

## 为什么值得修，以及这次能证明什么

R002/R005上一轮四次请求均HTTP200、finish_reason=stop，耗时8.53–30.85秒。不是120秒等待不足或输出截断。R002三个接缝对象、R005一个接缝对象写了具体STR-006数值却没有非自身参照；这个字段又不在当次复核allowed_pids内，旧范围无法合法修正。R005额外对同一个EMI-001先remove再add，违反初稿快照前提及每键一次规则。

这些是会直接阻断入库和后续聚类的可复现问题，有限修复具有明确价值。本轮仍为每图最多两次模型请求，新增机器诊断和格式编译不调用模型。最终性价比仍需看独立新鲜复测，不以单元测试替代准确率。

## 本轮变更

1. 全量原字典主解析增加五项已知值非自身参照的明确说明。仍直接依据原216字典、148视觉项解析；用户偏好留在后续聚类，不加入本步骤。主输出结构不变。
2. 主解析后本地枚举所有已出现的原宿主字段参照错误。诊断给出准确旧键和值、语法可用ID列表，不选择父级或真实宿主。
3. 新版本只对已诊断的对象/原字段开放额外引用修复。修改额外字段的已存键必须是列出的错误键；添加新的@引用键须配对明确移除的错误旧键。该权限不扩散至其他对象、新对象DNA或全图兜底状态。
4. 模型复核响应的dna_edits、object_edits、review_edits改为唯一键映射。已有键改值只能set；参照改名仍是两条不同完整键的显式remove/add。程序只翻译序列化格式并把模型明确的操作、旧值和新值交给原R70引擎，不补值、不去重、不自动迁移。
5. 仍保留八个同图视觉复核面。语法过关后仍须调用原最终validator和原语义审查，不能用review_complete自称完成代替它们。

原v1、v2、R70、字典、最终validator、旧交付包和原120结果保持冻结。新代码位于prism_runtime/dna/r70_reference_edit_patch.py；测试和本包构建器也仅新增在DNA模块。

## 离线验证与诚实边界

36项新增协议测试，以及40项v1/v2回归，共76项通过。包括实际两例不变回放、全错误位置枚举、局部权限、精确old值、核心删除保护、已存键禁止add、严格重复键/非有限数拒绝、原编辑器结果一致性、独立路径加载。

原R002坏回复经过原v2应用后，原最终校验器仍拒绝STR-006参照；R005仍由原编辑器报Duplicate DNA edit。v3拒绝它们的旧数组格式，不自动改写成“成功”结果。测试中的显式参照提案仅为人工构造的无图协议片段，没有制作修好的真实R002/R005视觉答案。

原120基线仍13/120完整通过。这不代表13/120视觉准确率；本包也不提高这个历史数字。没有新增API调用、没有重跑120或EE1、没有恢复计时器/重试。外观识别、真实宿主选择和后续聚类效用仍须新模型结果及独立评价。

## Root接入要求

- 保持现有build_inputs、validate、can_review、review_scope、critic_prompt、apply_correction、validate_after接口，换用新sidecar绝对路径。原最终validate是同一函数别名，apply只在原引擎前增加无损编译。
- 必须直接对供应商原始content文本调用algo.loads，或等效的每层重复JSON键及NaN/Infinity拒绝器。先普通json.loads再序列化会丢失重复键证据，不合格。Root已说明增加了等效严格入口，独立复测时还需确认。
- 新回复的三个编辑段是对象，不能继续使用旧数组或适配器自动去重。空编辑写{}。新对象、八项检查、未解决问题仍为数组。
- 从新鲜主解析生成scope和prompt；cases中的prompt只是旧失败稿的离线演示，不用于替代模型主解析或参照答案。
- 冻结新sidecar、原v2/v1及原依赖；新主提示、复核说明、schema、registry的hash均重新登记。勿覆盖旧candidate-freeze或交付。
- 仅R002/R005做独立预检，然后每图一次全量解析、一次合并复核；共最多4次新调用。新180秒等待属于Root输运配置，历史120秒不改。

## 成本与停止边界

已实现流程：一次全量解析 → 本地诊断 → 一次同图视觉及引用合并复核 → 本地编译与原校验。没有第三次模型调用。

记录的两个旧失败主稿上，新复核提示的UTF-8字节下降约19%–22%；主提示因新增通用参照说明略增。完整数值见各例prompt-byte-comparison.json。字节数不是供应商token计数或实际费用，不承诺同比价格或时延下降。

如本轮仍失败，可评估独立的模型引用修复阶段；若仍保留完整视觉复核，会从每图2次增加到3次，两图由4次增至6次。本轮未实现、未执行这条替代路径。它不会自动更准，需明确错误原因再判断。最多3个定点修复周期，第三次仍失败时记录停止与下一决策，不无限改提示词。

复现离线检查（项目根目录）：

```powershell
& 'C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B -X utf8 -m unittest prism_runtime.dna.test_r70_reference_edit_patch prism_runtime.dna.test_r70_review_contract_patch prism_runtime.dna.test_r70_applicability_patch -v
```

各例保留输入图身份、原始回复、提供方终止原因、原错误回放、候选范围、编码schema及提示。source/input/unchanged/delivery四组hash可检查来源和冻结边界。整体自评仍为partial，合格范围仅离线结构协议与约束。
'''


if __name__ == "__main__":
    main()
