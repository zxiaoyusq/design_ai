"""Final bounded D01 repair package, offline only. Never calls a provider."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shutil
import unittest

from prism_runtime.dna import r70_completion_permission_patch as patch

ROOT = patch.PROJECT
LOOP = ROOT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
CLI = LOOP / "qwen-cli-20260927"
RUN = CLI / "runs/dna-reference-v3-two-image-retest"
OUT = ROOT / "outputs/prism-algorithm-loop-20260926/modules/dna/repairs/QWEN-D01-REVIEW-002/cycle3-v1"


def read(path):
    return patch.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def text_sha(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def prompt_text(path):
    return "".join(part["text"] for m in read(path)["input"]["messages"] for part in m["content"] if "text" in part)


def main():
    if (OUT / "handoff.json").exists():
        raise SystemExit("Final-cycle delivery is frozen; do not overwrite it or invent a fourth repair cycle.")
    OUT.mkdir(parents=True, exist_ok=True)
    dispatch_path = LOOP / "dispatches/QWEN-D01-REVIEW-002-cycle3.json"
    dispatch = read(dispatch_path)
    freeze_path = CLI / "candidate-freeze-v3.json"
    freeze = read(freeze_path)
    unchanged = {}
    external_source_drift = []
    def preserve(path, expected):
        path = Path(path)
        assert sha(path) == expected, str(path)
        unchanged[str(path)] = expected
    for name, expected in freeze["original_R70_freeze"]["source_hashes"].items():
        preserve(patch.OPT / name, expected)
    for item in freeze["candidate_source_files"]:
        source = Path(item.get("source") or item["path"])
        if source == CLI / "prism_qwen_cli.py" and sha(source) != item["sha256"]:
            # Root owns its concurrently evolving runner. Preserve/verify the
            # historical snapshot, and expose drift instead of modifying it.
            preserve(item["snapshot"], item["sha256"])
            external_source_drift.append({"source": str(source), "frozen_sha256": item["sha256"],
                "observed_live_sha256": sha(source), "snapshot": item["snapshot"],
                "owner_modified_this_external_file": False, "root_must_freeze_current_runner_independently": True})
        else:
            preserve(source, item["sha256"])
    for item in freeze["source_files"]:
        path = Path(item["source"])
        if path.parent == ROOT / "prism_runtime/dna":
            preserve(path, item["sha256"])
    preserve(patch.DICT_PATH, freeze["original_R70_freeze"]["dictionary_sha256"])
    previous = OUT.parent / "cycle2-v1"
    for name in ["delivery-hashes.json", "source-hashes.json", "unchanged-v1-v2-and-baseline-hashes.json"]:
        path = previous / name
        preserve(path, sha(path))
        entries = read(path)
        if isinstance(entries, dict):
            entries = entries["files"]
        for item in entries:
            preserve(item["path"], item["sha256"])

    inputs = {str(dispatch_path): sha(dispatch_path), str(freeze_path): sha(freeze_path)}
    cases = []
    for case in dispatch["cases"]:
        cid = case["image_id"]
        folder = RUN / "jobs" / cid / "dna" / cid
        dest = OUT / "cases" / cid
        (dest / "inputs").mkdir(parents=True, exist_ok=True)
        (dest / "outputs").mkdir(exist_ok=True)
        raw = read(folder / "initial-wire.json")
        metadata = read(folder / "input-manifest.json")
        manifest_path = Path(metadata["source_manifest_ref"])
        record = next(r for r in read(manifest_path)["records"] if r["image_id"] == cid)
        photo = Path(record["path"])
        assert sha(photo) == record["sha256"] == metadata["photo_sha256"]
        inputs[str(photo)] = sha(photo)
        inputs[str(manifest_path)] = sha(manifest_path)
        original = patch.compact(raw)
        validation, normalized = patch.validate(raw, *metadata["photo_original_pixels"])
        primary, schema, _, _, _ = patch.build_inputs(photo)
        old_primary = prompt_text(RUN / "jobs" / cid / "calls" / (cid + "-primary") / "request.json")
        assert patch.prior.build_inputs(photo)[0] == old_primary
        (dest / "outputs/candidate-primary.prompt.txt").write_text(primary, encoding="utf-8")
        dump(dest / "outputs/original-issue-policy.json", patch.initial_issue_policy(raw))
        replay = {"old_failure_preserved": True, "host_filled_missing_issues": False,
            "host_cleared_initial_issues": False, "host_removed_illegal_edit": False,
            "unchanged_primary_validation": validation, "fresh_v4_model_calls": 0}
        scopes_unchanged = None
        review_byte_measure = None
        if cid == "R005":
            assert not patch.can_review(raw) and "issues" not in raw
            assert not validation["passed"]
            assert "Expected objects/frame/review/issues" in str(validation["errors"])
            try:
                patch.review_scope(raw, normalized)
            except Exception as exc:
                replay["scope_rejected"] = type(exc).__name__ + ": " + str(exc)
            else:
                raise AssertionError("Missing issues was implicitly accepted")
            replay["candidate_review_not_generated"] = "Original can_review is false; no host-supplied issues[]"
        else:
            reply = read(Path(case["review"]))
            old_scope = read(folder / "visual-review-scope.json")
            scope = patch.review_scope(raw, normalized)
            scope["primary_validation_errors"] = validation.get("errors", [])
            original_parts = {k: v for k, v in scope.items() if k not in ["fresh_permission_table", "initial_issue_policy", "producer_version"]}
            scopes_unchanged = original_parts == old_scope
            assert scopes_unchanged
            assert patch.reference_diagnostics(raw) == []
            assert scope["reference_repair_contract"]["extra_cell_grants"] == {}
            errors = {}
            for label, algo, s in [("v3", patch.prior, old_scope), ("v4", patch, scope)]:
                try:
                    algo.apply_correction(raw, reply, s)
                except Exception as exc:
                    errors[label] = type(exc).__name__ + ": " + str(exc)
                else:
                    raise AssertionError("Illegal edit accepted")
            assert errors["v3"] == errors["v4"] == "ValueError: Edit outside diagnosed reference cell"
            replay["unchanged_review_rejection"] = errors
            replay["second_independent_blocker"] = {
                "initial_issues": raw["issues"], "original_engine_appends_but_cannot_clear": True,
                "important_limit": "Even a legal empty reply cannot clear this initial issue under the frozen two-call protocol"}
            candidate_review = patch.critic_prompt(raw, scope)
            old_review = prompt_text(RUN / "jobs" / cid / "calls" / (cid + "-visual-review") / "request.json")
            (dest / "outputs/candidate-review-from-recorded-draft.prompt.txt").write_text(candidate_review, encoding="utf-8")
            dump(dest / "outputs/candidate-scope.json", scope)
            dump(dest / "outputs/fresh-permission-table.json", scope["fresh_permission_table"])
            dump(dest / "outputs/candidate-request-schema.json", patch.request_schema(raw, scope))
            review_byte_measure = {"v3_utf8_bytes": len(old_review.encode()), "v4_utf8_bytes": len(candidate_review.encode()),
                "v3_prompt_sha256": text_sha(old_review), "v4_prompt_sha256": text_sha(candidate_review),
                "not_a_token_or_price_measurement": True}
        assert patch.compact(raw) == original
        transport = []
        stages = ["primary", "visual-review"] if cid == "R002" else ["primary"]
        for stage in stages:
            call = RUN / "jobs" / cid / "calls" / (cid + "-" + stage)
            packet = read(call / "provider-response.json")
            result = read(call / "result.json")
            params = read(call / "request.json")["parameters"]
            finish = packet["data"]["output"]["choices"][0]["finish_reason"]
            assert packet["http_status"] == 200 and finish == "stop" and params["enable_thinking"] is False
            transport.append({"stage": stage, "http_status": packet["http_status"], "finish_reason": finish,
                "provider_seconds": result["provider_seconds"], "usage": result["usage"], "parameters": params})
            for name in ["request.json", "provider-response.json", "output.json", "output.txt", "result.json"]:
                path = call / name
                inputs[str(path)] = sha(path)
                if name != "request.json":
                    target = dest / "inputs" / stage / name
                    target.parent.mkdir(exist_ok=True)
                    shutil.copyfile(path, target)
        for name in ["initial-wire.json", "final-wire.json", "input-manifest.json", "primary-validation.json", "visual-review-scope.json", "benchmark-result.json"]:
            path = folder / name
            if path.exists():
                inputs[str(path)] = sha(path)
                shutil.copyfile(path, dest / "inputs" / name)
        dump(dest / "outputs/unchanged-failure-replay.json", replay)
        dump(dest / "outputs/transport-evidence.json", transport)
        measurement = {"primary_v3_utf8_bytes": len(old_primary.encode()), "primary_v4_utf8_bytes": len(primary.encode()),
            "review": review_byte_measure, "not_a_token_or_price_measurement": True}
        dump(dest / "outputs/prompt-byte-comparison.json", measurement)
        cases.append({"image_id": cid, "source_kind": metadata["source_kind"], "image_ref": str(photo), "image_sha256": sha(photo),
            "initial_issues_policy": patch.initial_issue_policy(raw), "input_unchanged": True,
            "old_failure_preserved": True, "old_review_scope_unchanged": scopes_unchanged,
            "transport": transport, "prompt_bytes": measurement,
            "primary_schema_unchanged": schema == patch.prior.build_inputs(photo)[1],
            "candidate_primary_prompt_sha256": text_sha(primary)})

    names = ["prism_runtime.dna.test_r70_completion_permission_patch", "prism_runtime.dna.test_r70_reference_edit_patch",
             "prism_runtime.dna.test_r70_review_contract_patch", "prism_runtime.dna.test_r70_applicability_patch"]
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
    stream = io.StringIO()
    tests = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (OUT / "offline-tests.txt").write_text(stream.getvalue(), encoding="utf-8")
    assert tests.wasSuccessful()
    for path, expected in {**inputs, **unchanged}.items():
        assert sha(Path(path)) == expected, path
    files = [Path(patch.__file__).resolve(), ROOT / "prism_runtime/dna/test_r70_completion_permission_patch.py", Path(__file__).resolve()]
    dump(OUT / "source-hashes.json", [{"path": str(p), "sha256": sha(p)} for p in files])
    dump(OUT / "input-hashes.json", [{"path": p, "sha256": v} for p, v in sorted(inputs.items())])
    dump(OUT / "unchanged-v1-v3-and-baseline-hashes.json", [{"path": p, "sha256": v} for p, v in sorted(unchanged.items())])
    dump(OUT / "external-runner-drift.json", external_source_drift)
    runtime = patch.candidate_runtime_plan()
    dump(OUT / "candidate-runtime-plan.json", runtime)
    dump(OUT / "rules/association-registry.json", patch.association_registry())
    dump(OUT / "rules/unchanged-v3-response-schema.json", patch.correction_schema())
    (OUT / "rules/primary-completion-rules.txt").write_text(patch.PRIMARY_COMPLETION_RULES, encoding="utf-8")
    (OUT / "rules/review-permission-rules.txt").write_text(patch.REVIEW_PERMISSION_RULES, encoding="utf-8")
    now = datetime.now(timezone.utc).isoformat()
    verification = {"version": patch.VERSION, "repair_cycle": 3, "max_cycles": 3, "checked_utc": now,
        "tests": tests.testsRun, "new_tests": 18, "regression_tests": tests.testsRun - 18,
        "failures": len(tests.failures), "errors": len(tests.errors), "new_paid_calls": 0,
        "original_two_failures_preserved": True, "v4_scope_not_expanded": True,
        "apply_and_final_validator_exact_v3_aliases": True, "frozen_sources_and_raw_inputs_unchanged": True,
        "fresh_v4_model_effectiveness_tested": False, "external_root_runner_drift": external_source_drift, "cases": cases}
    dump(OUT / "verification.json", verification)
    dump(OUT / "self-assessment.json", {"module": "dna", "issue_id": "QWEN-D01-REVIEW-002", "repair_cycle": 3,
        "max_cycles": 3, "status": "partial", "qualified": False, "algorithm_version": patch.VERSION,
        "qualified_scope": "Offline completeness instructions, exact permission presentation, rejection preservation and bounded runtime proposal only",
        "ready_for_final_two_image_retest": True, "production_qualified": False, "visual_accuracy_qualified": False,
        "actual_results": {"offline_tests_passed": tests.testsRun, "old_v3_complete_passes": "0/2", "owner_new_model_calls": 0},
        "known_limits": ["Missing issues remains unreviewable; no host default is permitted.",
            "Initial issues are immutable under the frozen review engine, so some safe-to-review drafts can never achieve final pass.",
            "Prompt and reasoning-budget changes cannot guarantee provider field completeness or edit adherence.",
            "The two-image repair set is not an independent broad accuracy test."],
        "stop_rule": runtime["stop_rule"]})
    (OUT / "README.md").write_text(README, encoding="utf-8")
    handoff = {"module": "dna", "issue_id": "QWEN-D01-REVIEW-002", "repair_cycle": 3, "max_cycles": 3,
        "status": "partial", "algorithm_version": patch.VERSION, "contract_version": "0.1",
        "entrypoint": "import prism_runtime.dna.r70_completion_permission_patch as algo",
        "source_entrypoint": str(Path(patch.__file__).resolve()), "ready_for_two_image_qwen_retest": True,
        "production_qualified": False, "qualified_scope": "Offline producer instructions and permission presentation, not live effectiveness",
        "files": [str(p) for p in files] + [str(OUT / n) for n in ["README.md", "candidate-runtime-plan.json", "verification.json",
            "self-assessment.json", "source-hashes.json", "input-hashes.json", "unchanged-v1-v3-and-baseline-hashes.json"]],
        "verification": {"command": "python -B -X utf8 -m unittest " + " ".join(names) + " -v",
            "result": f"offline_pass:{tests.testsRun}; all actual bad replies remain rejected, no repaired image wires",
            "record": str(OUT / "verification.json")}, "new_paid_calls": 0,
        "scope_or_wire_changed": False, "apply_and_validate_exact_prior_aliases": True,
        "integration": {"freeze_new_primary_review_registry_hashes": True,
            "review_schema_same_as_v3": True, "fresh_scope_from_new_primary_only": True,
            "raw_model_content_strict_decoder_required": True, "never_parse_reasoning_as_final_json": True,
            "runtime_proposal_ref": str(OUT / "candidate-runtime-plan.json"),
            "configuration_is_not_active_until_root_verifies_and_freezes": True,
            "external_root_runner_drift_ref": str(OUT / "external-runner-drift.json"),
            "at_most_same_two_images_four_calls": True, "automatic_retries": False,
            "no_full120_or_ee1_rerun": True},
        "remaining_architectural_limit": "Frozen review cannot clear any primary issues or rescue a primary missing issues; a legal review need not mean recoverable final pass.",
        "next_decision_if_failed": "Stop this issue aftercycle3. Decide a separate versioned model-authored full-wire repair or explicit issue-resolution contract. Preserve same image, original dictionary/final validator; potentially3calls/image (+1,+50%calls), not executed here.",
        "thinking_tradeoff": "Same model, up to2048 reasoning tokens per call; same8192 final-answer cap and180s transport. Additional latency/usage possible, no measured accuracy/price benefit yet.",
        "not_an_ablation": "Producer prompts and runtime configuration change together; success would qualify the candidate only, not attribute gain to thinking alone.",
        "stop_rule": runtime["stop_rule"]}
    dump(OUT / "handoff.json", handoff)
    dump(OUT / "delivery-hashes.json", {"version": patch.VERSION, "generated_utc": now,
        "files": [{"path": str(p), "sha256": sha(p)} for p in sorted(OUT.rglob("*"))
                  if p.is_file() and p.name != "delivery-hashes.json"]})
    print(json.dumps({"status": "partial_ready_for_final_retest", "tests": tests.testsRun,
        "owner_new_calls": 0, "handoff": str(OUT / "handoff.json"),
        "runtime_plan": str(OUT / "candidate-runtime-plan.json")}, ensure_ascii=False))


README = '''# QWEN-D01-REVIEW-002 · 最后第3轮

候选：r70-completion-permission-d01-v4。整体partial，只有离线协议呈现/失败保留/参数方案范围合格；没有新增API调用，没有新鲜v4准确率或时延结论。

## 实际复测说明了什么

上一版v3两图仍0/2完整通过，只发生3次调用。全部HTTP200、finish_reason=stop，初提取输出分别2911和3662 tokens，均未用完8192额度，不是网络等待或截断。

- R005返回完整JSON，但缺原合同必需的issues键。can_review=false，所以没有复核调用。系统不能补issues=[]；旧输出保持失败。
- R002主稿已经没有旧的STR-006自引用问题。object5的STR-006@3=0.02是语法完整的旧键，本轮没有相关修复授权。模型仍要求remove，v3按原范围正确拒绝。本轮v4不扩大它的权限，不删掉这条提案。
- R002还有独立阻塞：初稿issues记录了“左侧纵向文字…略显模糊，但内容仍可辨识”。原编辑器只会保留初稿issues并追加问题，没有清除协议；即使不发生越权，空复核也不能让此稿通过。这里没有重新判定图像，而是说明数据流的硬限制。

## 最后一轮做了什么

主解析仍沿原216字典直接识图，148视觉项完整审阅。只在末尾强化原有的四键输出合同，建议先整体核对再输出issues、objects、frame、review。issues必须由模型明确判断；原定义是未完成的重要可见特征或区域错误。普通客观看不清应对相应字段显式unknown，缺BOM不是反复失败理由；若确实阻碍重要判断仍必须报告，不能为了通过而隐藏问题。

复核重新加入紧凑的精确旧键权限表：每个对象/完整键的原old及可执行操作，[]清晰表示只读。只读字段仍提供原字典定义，避免模型把“没有编辑权”误认为“不应存在”。新增权限、引用修复、全部核心删除锁、三映射响应格式全部沿用v3；v4的apply、can_review、validate、validate_after都是原函数别名。

输出前要求模型核对四键/七键、精确权限、old值和八项facet。程序没有语义补值、自动删除、自动去重或越权放行。原v1/v2/v3、旧交付、R70、字典、最终validator和原120基线均保留。

## 有界Qwen参数方案

candidate-runtime-plan.json是供Root独立确认并冻结的新候选配置，不会自动执行。仍是qwen3.8-flash；两个阶段都建议enable_thinking=true、thinking_budget=2048，max_tokens继续8192，temperature=0、response_format=json_object、每次等待180秒。每图最多首次+复核2次，两图最多4次，单次仅1次尝试，不自动重试或静默换模型/模式。

参数依据：阿里云[视觉推理说明](https://help.aliyun.com/zh/model-studio/visual-reasoning)列明Qwen3.8支持thinking_budget；[深度思考说明](https://help.aliyun.com/zh/model-studio/deep-thinking)列明qwen3.8-flash混合思考、商业模型同步返回及content/reasoning_content的区分。2048是本轮试验上限，由我们选择，不是官方推荐值。思考可能增加耗时和用量，不能承诺准确率增益。Root核对实际端点、账户和参数支持，只严格解析最终content，保留真实用量、finish_reason及reasoning token统计。

没有使用json_schema作为结构保证。官方[结构化输出英文说明](https://help.aliyun.com/en/model-studio/qwen-structured-output)明确：多模态输入会退回json_object，schema约束不生效；JSON对象模式也不保证必需字段齐全。提示中的schema仍是说明，原本地校验器仍是放行门槛。以上页面于2026-09-27核对。

本轮提示和运行参数同时变化，属于一个最终候选，不能把成功单独归因于thinking。案例里记录了提示字节变化，它不是token或费用实测。

## 验证及Root接入

新增18项离线测试及76项先前版本回归，共94项通过。R005仍缺键且不可复核；R002仍精确报Edit outside diagnosed reference cell。另用无图的空提案协议探针确认初稿issues不能清除；这不是人为补写真实图片的视觉答案。没有发布修好的真实wire。

入口：prism_runtime/dna/r70_completion_permission_patch.py。保持v3响应格式、原函数签名及严格原文JSON解析。新鲜主解析之后重新生成scope与prompt；cases里的prompt仅是历史失败稿的离线展示，不是新测试答案。v4候选需重新冻结主/复核提示、registry以及独立运行参数；旧版本都不覆盖。

在项目根执行：

```powershell
& 'C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B -X utf8 -m unittest prism_runtime.dna.test_r70_completion_permission_patch prism_runtime.dna.test_r70_reference_edit_patch prism_runtime.dna.test_r70_review_contract_patch prism_runtime.dna.test_r70_applicability_patch -v
```

Root独立预检后，仅R002/R005最多4次新鲜Qwen调用。任何实际拒绝都保留；不能补键、清issues、删越权编辑或把reasoning内容当最终JSON补丁。原120的13/120完整通过基线不改，它不是视觉准确率。

## 若最后复测仍失败

停止此问题的提示协议循环，不改名开启第4轮。现有证据已经说明：严格编辑范围与不可清除初稿问题，使两调用方案存在无法恢复的稿件；“可送复核”不等于“可被复核救回”。增加thinking是否有价值必须由本轮真实结果判断。

下一决策应评估独立版本的模型完整结果修复或显式问题处置协议，由同图模型决定每项变更并继续通过原字典和最终validator，程序仍不能默认issues为空。若保留现有全量提取和视觉复核、再增加一个修复阶段，会变为每图最多3次，调用数上限增加50%；实际费用和用时不能按50%直接推定。这个新架构本轮未实现、未运行、未自动授权扩批。即使本次两图都通过，也只证明小范围可用，不能宣称全面准确率提升。
'''


if __name__ == "__main__":
    main()
