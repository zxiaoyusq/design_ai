"""Independent semantic-review handoff, with trusted caller metadata separated from model output.

This validates the review protocol, not the correctness of a reviewer's judgment.
It is not an identity-authentication or signature system.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime
import hashlib
import json
from prism_runtime.contracts import require, index_by
from .validation import attitude, fingerprint, validate_bundle, validate_quote

POLICY_VERSION = "prism.preference_semantic_review.v0.1"
CHECKED_ASPECTS = {"attitude", "attribution", "conditions", "summary", "user_scope"}
RESERVED = {
    "reviewed","reviewed_by","semantic_review","semantic_assessment","semantic_review_status",
    "confirmed_user_support","support_eligibility","user_attitude_verified","review_ids",
}
CLAIM_FIELDS = (
    "preference_id","level","topic_key","title","summary","attitude","user_ids","evidence_refs",
    "quotes","record_refs","features","image_ids","conditions","source_roles","source_contexts",
    "feature_validation","input_binding",
)

def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def strip_review_claims(value):
    result=deepcopy(value)
    removed={k:result.pop(k) for k in list(result) if k in RESERVED}
    if removed:
        result["untrusted_review_claims"]=removed
    return result

def extraction_identity(context):
    if context is None:
        return {"status":"unbound","producer_id":None,"independence_group":None,"run_id":None}
    require(isinstance(context,dict),"extraction_context must be trusted caller metadata")
    for key in ("producer_id","independence_group","run_id"):
        require(isinstance(context.get(key),str) and context[key].strip(),f"extraction_context.{key} required")
    return {**deepcopy(context),"status":"bound_by_caller"}

def candidate_digest(preference,input_digest,extraction_context):
    return _digest({"input_digest":input_digest,"extraction_context":extraction_context,
                    "claim":{k:preference.get(k) for k in CLAIM_FIELDS}})

def initialize_assessment(preference,rows,input_digest,context):
    recorded=[{"evidence_id":r["evidence_id"],"recorded_attitude":attitude(r.get("recorded_attitude")),
               "evidence_role":r.get("evidence_role","unclassified")} for r in rows if r.get("recorded_attitude") is not None]
    preference["attitude_origin"]={
        "kind":"source_recorded" if len(recorded)==len(rows) else "model_interpreted",
        "source_records":recorded,
        "note":"原记录中的态度与模型对对象、条件、理由的解释分开；有态度标签不等于整条语义已经核对。",
    }
    preference["semantic_assessment"]={
        "policy_version":POLICY_VERSION,"status":"pending_independent_review",
        "candidate_digest":candidate_digest(preference,input_digest,context),
        "support_eligibility":"candidate_only","confirmed_user_support":False,"review_ids":[],
    }
    preference["confirmed_user_support"]=False
    preference["semantic_status"]="candidate_unreviewed"
    return preference

def _eligibility(preference,status):
    if status!="supported":
        return "candidate_only" if status=="pending_independent_review" else "not_confirmed"
    if preference["attitude"]=="dislike":
        return "reviewed_negative"
    if preference["attitude"]=="conditional" or (preference["attitude"]=="like" and preference.get("conditions")):
        return "reviewed_conditional"
    if preference["attitude"]=="like":
        return "reviewed_positive"
    return "reviewed_not_positive"

def _derive_review_state(profile,receipts):
    """Internal: rebuild every derived field from a previously validated receipt ledger."""
    preferences=profile.get("preferences",[])
    byid=index_by(preferences,"preference_id")
    histories={pid:[] for pid in byid}
    for receipt in receipts:
        for item in receipt["items"]:
            histories[item["preference_id"]].append((receipt["review_id"],item))
    for f in preferences:
        old=f.get("semantic_assessment",{})
        candidate_hash=old.get("candidate_digest")
        require(isinstance(candidate_hash,str) and candidate_hash,"candidate must be compiled before deriving review state")
        state="pending_independent_review"
        assessment={"policy_version":POLICY_VERSION,"candidate_digest":candidate_hash,"review_ids":[]}
        for rid,item in histories[f["preference_id"]]:
            verdict=item["verdict"]
            state=verdict if state in {"pending_independent_review",verdict} else "disputed"
            assessment["review_ids"].append(rid)
            assessment["latest_review_reason"]=item["reason"]
            if "corrected_attitude" in item:
                assessment["suggested_correction"]={"attitude":item["corrected_attitude"],"review_id":rid}
        assessment["status"]=state
        f["semantic_assessment"]=assessment
    counts={}
    for f in preferences:
        assessment=f["semantic_assessment"]
        status=assessment["status"]
        counts[status]=counts.get(status,0)+1
        eligibility=_eligibility(f,status)
        assessment["support_eligibility"]=eligibility
        # Conditional support must still be checked against the intended use context downstream.
        f["confirmed_user_support"]=assessment["confirmed_user_support"]=(eligibility=="reviewed_positive")
        f["semantic_status"]="independently_reviewed" if status=="supported" else "candidate_"+status
    for key in ("semantic_clusters","semantic_groups"):
        for group in profile.get(key,[]):
            members=[byid[x] for x in group.get("preference_ids",[]) if x in byid]
            group["semantic_assessment"]={
                "status":"all_members_supported" if members and all(f["semantic_assessment"]["status"]=="supported" for f in members)
                         else "contains_unconfirmed_interpretations",
                "confirmed_positive_preference_ids":[f["preference_id"] for f in members if f["confirmed_user_support"]],
                "reviewed_conditional_preference_ids":[f["preference_id"] for f in members if f["semantic_assessment"]["support_eligibility"]=="reviewed_conditional"],
                "reviewed_negative_preference_ids":[f["preference_id"] for f in members if f["semantic_assessment"]["support_eligibility"]=="reviewed_negative"],
                "summary_review_status":"not_reviewed_by_atomic_preference_review",
            }
            group["confirmed_user_support"]=False  # Atomic review does not approve a new group summary.
    profile["semantic_review"]={
        "policy_version":POLICY_VERSION,"status_counts":counts,
        "confirmed_positive_preference_ids":[f["preference_id"] for f in preferences if f["confirmed_user_support"]],
        "reviewed_conditional_preference_ids":[f["preference_id"] for f in preferences if f["semantic_assessment"]["support_eligibility"]=="reviewed_conditional"],
        "reviewed_negative_preference_ids":[f["preference_id"] for f in preferences if f["semantic_assessment"]["support_eligibility"]=="reviewed_negative"],
        "unconfirmed_preference_ids":[f["preference_id"] for f in preferences if f["semantic_assessment"]["status"]!="supported"],
        "review_scope":"synthetic_fixture_only" if profile.get("provenance",{}).get("mode")=="synthetic" else "declared_source_snapshot",
        "real_user_effect_validated":False,
    }
    profile["semantic_review_status"]=(
        "no_preferences" if not preferences else
        "all_atomic_preferences_reviewed_supported" if counts.get("supported")==len(preferences) else
        "partially_reviewed" if any(k!="pending_independent_review" for k in counts) else "pending_independent_review"
    )
    return profile

def refresh_profile_review_state(profile):
    """Safe unreviewed-state initializer, never an authority for serialized review claims.

    Receipt-bearing profiles must use validate_reviewed_profile with original sources
    and a trusted registry; an arbitrary cached status cannot be promoted here.
    """
    require(not profile.get("semantic_review_receipts"),
            "receipt-bearing profile requires validate_reviewed_profile(bundle, profile, reviewer_registry=...)")
    return _derive_review_state(profile,[])

def _validate_binding(bundle,profile):
    _,evidence,_=validate_bundle(bundle)
    selection=profile.get("selection",{})
    current=fingerprint(bundle,selection.get("selected_user_ids",[]),selection.get("eligible_evidence_ids",[]))
    require(profile.get("input_digest")==current,"review source snapshot no longer matches profile")
    context=profile.get("extraction_context",{})
    require(context.get("status")=="bound_by_caller","independent review needs a caller-bound extraction identity")
    for f in profile.get("preferences",[]):
        require(f.get("input_binding")=="verified_snapshot","unbound candidate must be reaccepted against the source snapshot")
        assessment=f.get("semantic_assessment",{})
        require(assessment.get("candidate_digest")==candidate_digest(f,current,context),"candidate changed since compilation")
        require(set(f.get("evidence_refs",[])).issubset(evidence),"candidate evidence missing")
    return evidence

def prepare_semantic_review(bundle,profile,preference_ids=None):
    evidence=_validate_binding(bundle,profile)
    # Hide cached approval from the independent reader. This does not mutate the supplied profile.
    candidate_view=_derive_review_state(deepcopy(profile),[])
    prefs=index_by(candidate_view["preferences"],"preference_id")
    ids=list(prefs) if preference_ids is None else preference_ids
    require(isinstance(ids,list) and ids and len(ids)==len(set(ids)) and set(ids).issubset(prefs),"invalid review preference scope")
    data={"input_digest":profile["input_digest"],"extraction_context":profile["extraction_context"],
          "candidates":[prefs[x] for x in ids],
          "source_evidence":[evidence[x] for x in sorted({r for pid in ids for r in prefs[pid]["evidence_refs"]})],
          "image_dna":[im for im in bundle.get("images",[]) if im["image_id"] in {
              evidence[r].get("image_id") for pid in ids for r in prefs[pid]["evidence_refs"]}],
          "required_checked_aspects":sorted(CHECKED_ASPECTS)}
    return {
        "schema_version":POLICY_VERSION,"input_digest":profile["input_digest"],"preference_ids":ids,
        "messages":[{"role":"system","content":
          "独立核对候选偏好与原始资料。引用存在不等于理解正确。分别核对态度、对象/特征归因、条件、摘要及用户范围。"
          "不得因为候选写like就沿用；先看完整原文、选择记录和相关上下文。"
          "每项输出preference_id,candidate_digest,verdict(supported/contradicted/insufficient),reason,"
          "quotes(逐字原文),record_refs(无文字选择),checked_aspects；不确定时输出insufficient。"
          "contradicted可以附corrected_attitude建议，但不得覆盖原始候选。"
          "响应不填reviewed=true或冒充人工；审阅身份、时间、来源记录由独立执行者外部登记。"
          "不得把合成示例当真实用户，也不得把原子审核当作语义聚类摘要已通过。"},
          {"role":"user","content":json.dumps(data,ensure_ascii=False)}],
        "provenance":profile["provenance"],"execution":"independent_host_or_model_required; no provider call",
    }

def _validate_envelope(bundle,profile,envelope,*,reviewer_registry,evidence=None):
    """Validate one envelope, without trusting or changing any cached approval status."""
    if evidence is None:
        evidence=_validate_binding(bundle,profile)
    require(envelope.get("schema_version")==POLICY_VERSION,"invalid review schema")
    require(envelope.get("input_digest")==profile["input_digest"],"review uses a different source version")
    require(isinstance(reviewer_registry,dict),"trusted reviewer registry required")
    for field in ("registry_id","registry_version","issued_by"):
        require(isinstance(reviewer_registry.get(field),str) and reviewer_registry[field].strip(),"review registry metadata missing")
    reviewers=index_by(reviewer_registry.get("reviewers",[]),"reviewer_id")
    reviewer_id=envelope.get("reviewer_id")
    require(reviewer_id in reviewers,"reviewer is not registered by the trusted caller")
    reviewer=reviewers[reviewer_id]
    require(reviewer.get("actor_type") in {"human","host","model","synthetic_fixture"},"invalid reviewer actor type")
    require(reviewer.get("independence_group"),"reviewer independence group required")
    extraction=profile["extraction_context"]
    require(reviewer_id!=extraction["producer_id"] and reviewer["independence_group"]!=extraction["independence_group"],
            "review cannot be performed by the same declared producer or independence group")
    dataset=profile["provenance"]["mode"]
    require(dataset in reviewer.get("allowed_dataset_modes",[]),"reviewer not registered for this dataset mode")
    require(not(dataset!="synthetic" and reviewer["actor_type"]=="synthetic_fixture"),"fixture review cannot confirm real evidence")
    for field in ("review_id","reviewed_at","review_artifact_ref"):
        require(isinstance(envelope.get(field),str) and envelope[field].strip(),f"{field} required")
    try:
        moment=datetime.fromisoformat(envelope["reviewed_at"].replace("Z","+00:00"))
        require(moment.tzinfo is not None,"reviewed_at must include timezone")
    except ValueError as exc:
        require(False,"invalid review timestamp")
    prefs=index_by(profile["preferences"],"preference_id")
    items=envelope.get("items",[])
    require(isinstance(items,list) and bool(items),"review items required")
    index_by(items,"preference_id")
    items_by_id={}
    for item in items:
        pid=item["preference_id"]
        require(pid in prefs,"review refers to unknown preference")
        f=prefs[pid]
        require(item.get("candidate_digest")==f["semantic_assessment"]["candidate_digest"],"review does not bind the exact candidate")
        verdict=item.get("verdict")
        require(verdict in {"supported","contradicted","insufficient"},"invalid review verdict")
        require(isinstance(item.get("reason"),str) and item["reason"].strip(),"review reason required")
        require(set(item.get("checked_aspects",[]))==CHECKED_ASPECTS,"review must address every semantic aspect")
        quotes=item.get("quotes",[])
        require(isinstance(quotes,list),"review quotes must be a list")
        for quote in quotes:
            require(quote.get("evidence_id") in f["evidence_refs"],"review quote outside candidate sources")
            validate_quote(quote,evidence)
        quoted={q["evidence_id"] for q in quotes}
        record_refs=set(item.get("record_refs",[]))
        require(record_refs.issubset(f["evidence_refs"]),"review record_ref outside candidate")
        for ref in f["evidence_refs"]:
            row=evidence[ref]
            if row.get("text","").strip():
                require(ref in quoted,"review must cite each textual source")
            else:
                require(ref in record_refs,"review must reference each textless selection record")
        if "corrected_attitude" in item:
            corrected=attitude(item["corrected_attitude"])
            require(verdict!="supported" or corrected==f["attitude"],"supported review cannot silently change attitude")
        items_by_id[pid]=deepcopy(item)
    return {"reviewer":reviewer,"dataset":dataset,"items_by_id":items_by_id,"body_hash":_digest(envelope)}

def _receipt_envelope(receipt):
    """New receipts retain the original envelope; exact legacy receipts can be reconstructed."""
    if "review_envelope" in receipt:
        envelope=deepcopy(receipt["review_envelope"])
    else:
        envelope={
            "schema_version":POLICY_VERSION,"review_id":receipt.get("review_id"),
            "reviewer_id":receipt.get("reviewer",{}).get("reviewer_id"),
            "input_digest":receipt.get("input_digest"),"reviewed_at":receipt.get("reviewed_at"),
            "review_artifact_ref":receipt.get("review_artifact_ref"),"items":deepcopy(receipt.get("items",[])),
        }
    require(_digest(envelope)==receipt.get("review_sha256"),"stored receipt does not match its original envelope")
    require(envelope.get("review_id")==receipt.get("review_id"),"receipt/envelope identity mismatch")
    require(envelope.get("input_digest")==receipt.get("input_digest"),"receipt/envelope source version mismatch")
    require(envelope.get("items")==receipt.get("items"),"receipt/envelope item mismatch")
    require(envelope.get("reviewed_at")==receipt.get("reviewed_at")
            and envelope.get("review_artifact_ref")==receipt.get("review_artifact_ref"),
            "receipt/envelope provenance mismatch")
    return envelope

def validate_reviewed_profile(bundle,profile,*,reviewer_registry):
    """Revalidate every stored receipt and rebuild all derived state on a copy.

    This is the consumer entrypoint for H01/H02. Cached supported/true fields are not
    authoritative. The caller still owns registry authenticity; no signatures are claimed.
    """
    evidence=_validate_binding(bundle,profile)
    receipts=profile.get("semantic_review_receipts",[])
    require(isinstance(receipts,list),"receipt ledger must be a list")
    index_by(receipts,"review_id")
    valid=[]
    for receipt in receipts:
        envelope=_receipt_envelope(receipt)
        require(receipt.get("registry_sha256")==_digest(reviewer_registry),
                "historical receipt requires its exact trusted registry snapshot")
        require(receipt.get("registry_id")==reviewer_registry.get("registry_id")
                and receipt.get("registry_version")==reviewer_registry.get("registry_version")
                and receipt.get("registry_issued_by")==reviewer_registry.get("issued_by"),
                "stored registry provenance mismatch")
        checked=_validate_envelope(bundle,profile,envelope,reviewer_registry=reviewer_registry,evidence=evidence)
        require(receipt.get("reviewer")==checked["reviewer"],"stored reviewer metadata differs from trusted registry")
        require(receipt.get("dataset_mode")==checked["dataset"],"stored receipt dataset mismatch")
        scope="synthetic_fixture_only" if checked["dataset"]=="synthetic" else "declared_source_snapshot"
        require(receipt.get("review_scope")==scope,"stored review scope mismatch")
        valid.append(deepcopy(receipt))
    result=_derive_review_state(deepcopy(profile),valid)
    changes=[]
    for old,new in zip(profile["preferences"],result["preferences"]):
        if (old.get("semantic_assessment")!=new.get("semantic_assessment")
            or old.get("confirmed_user_support")!=new.get("confirmed_user_support")
            or old.get("semantic_status")!=new.get("semantic_status")):
            changes.append(old["preference_id"])
    result["review_state_integrity"]={
        "authority":"source-and-registry-validated-receipt-ledger",
        "validated_receipt_ids":[r["review_id"] for r in valid],
        "cached_state_changed_preference_ids":changes,
        "cache_is_authoritative":False,
        "identity_assurance":"trusted caller registry; no cryptographic authentication",
    }
    return result

def apply_semantic_reviews(bundle,profile,envelope,*,reviewer_registry):
    """Revalidate the entire ledger before accepting a new independently produced review."""
    result=validate_reviewed_profile(bundle,profile,reviewer_registry=reviewer_registry)
    checked=_validate_envelope(bundle,result,envelope,reviewer_registry=reviewer_registry)
    reviewer,dataset=checked["reviewer"],checked["dataset"]
    items_by_id,body_hash=checked["items_by_id"],checked["body_hash"]
    receipts=result.setdefault("semantic_review_receipts",[])
    previous=next((r for r in receipts if r["review_id"]==envelope["review_id"]),None)
    if previous:
        require(previous["review_sha256"]==body_hash,"review ID reused with modified contents")
        return result  # Already sanitized, including unreviewed preferences unrelated to this receipt.
    receipt={
        "review_id":envelope["review_id"],"review_sha256":body_hash,
        "input_digest":profile["input_digest"],"reviewer":deepcopy(reviewer),
        "registry_id":reviewer_registry["registry_id"],"registry_version":reviewer_registry["registry_version"],
        "registry_issued_by":reviewer_registry["issued_by"],"registry_sha256":_digest(reviewer_registry),
        "reviewed_at":envelope["reviewed_at"],"review_artifact_ref":envelope["review_artifact_ref"],
        "dataset_mode":dataset,"review_scope":"synthetic_fixture_only" if dataset=="synthetic" else "declared_source_snapshot",
        "items":list(items_by_id.values()),
        "review_envelope":deepcopy(envelope),
        "identity_assurance":"trusted_caller_registry; no cryptographic identity verification",
    }
    receipts.append(receipt)
    result["review_state_integrity"]["validated_receipt_ids"]=[r["review_id"] for r in receipts]
    return _derive_review_state(result,receipts)
