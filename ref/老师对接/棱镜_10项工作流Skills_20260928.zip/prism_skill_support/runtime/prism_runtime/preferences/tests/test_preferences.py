from copy import deepcopy
import unittest
from prism_runtime.contracts import ContractError
from prism_runtime.preferences import (
    compile_preferences,prepare_requests,select_users,accept_batches,
    compile_semantic_groups,prepare_semantic_groups,
    prepare_tag_mapping,compile_tag_mapping,
)
from prism_runtime.preferences.demo import build_fixture

class PreferenceCases(unittest.TestCase):
    def setUp(self):
        self.bundle,self.findings=build_fixture()
    def compile(self):
        return compile_preferences(self.bundle,self.findings,require_input_digest=True)
    def bind(self):
        self.findings["input_digest"]=prepare_requests(self.bundle)["input_digest"]
    def test_alias_selection_and_unknown_tag_are_explained(self):
        s=select_users(self.bundle)
        self.assertEqual(s["selected_user_ids"],["u1","u2","u5"])
        self.assertEqual(s["excluded_users"][1]["missing_tags"],["segment"])
        self.assertEqual(s["user_decisions"][1]["tag_results"][0]["match_method"],"declared_alias")
    def test_string_tag_criteria_not_silently_iterated(self):
        self.bundle["brief"]["target_tags"]["segment"]="young_professional"
        with self.assertRaises(ContractError): select_users(self.bundle)
    def test_complete_coverage_and_unique_people(self):
        p=self.compile()
        self.assertEqual(p["coverage"]["status"],"complete")
        self.assertEqual(p["population_count"],3)
        self.assertEqual(p["users_analyzed_count"],3)
        round_group=next(g for g in p["semantic_clusters"] if g["topic_key"]=="round-contour")
        self.assertEqual(round_group["unique_user_count"],2)
        self.assertEqual(len(round_group["preference_ids"]),3)
    def test_textless_selection_is_valid_without_invented_quote(self):
        p=next(f for f in self.compile()["preferences"] if f["preference_id"]=="p5")
        self.assertEqual(p["features"],[])
        self.assertEqual(p["attitude"],"like")
        self.assertEqual(p["record_refs"],["e5"])
    def test_whole_image_choice_cannot_become_color_preference(self):
        f=self.findings["findings"][4]
        f["level"]="element"
        f["features"]=[{"parameter_id":"fixture.color","value":"绿色","attribution":"pointed_image_feature",
                        "evidence_refs":["e5"],"observation_refs":[{"image_id":"research-r1","observation_id":"o-color"}]}]
        with self.assertRaises(ContractError): self.compile()
    def test_pointed_feature_must_match_carrier(self):
        self.bundle["evidence"][5]["target_object_id"]="background"
        self.bundle["evidence"][5]["target_region_ref"]={"fixture_region":"background"}
        self.bind()
        with self.assertRaises(ContractError): self.compile()
    def test_textual_whole_image_like_cannot_be_mislabelled_explicit_color(self):
        e=self.bundle["evidence"][4]
        e["evidence_role"]="user_statement";e["text"]="这张我喜欢。"
        f=self.findings["findings"][4]
        f["level"]="element"
        f["quotes"]=[{"evidence_id":"e5","text":"这张我喜欢。"}]
        f["features"]=[{"parameter_id":"fixture.color","value":"绿色","attribution":"explicit_text","evidence_refs":["e5"]}]
        self.bind()
        with self.assertRaises(ContractError): self.compile()
    def test_atomic_findings_do_not_inherit_other_users_attitude(self):
        f=self.findings["findings"][0]
        f["evidence_refs"].append("e6");f["user_ids"].append("u2")
        f["quotes"].append({"evidence_id":"e6","text":"我喜欢这里的圆润边角。"})
        with self.assertRaises(ContractError): self.compile()
    def test_unknown_dna_does_not_support_attribution(self):
        o=self.bundle["images"][0]["observations"][0]
        o["value_status"]="unknown";o["value"]=None
        self.bind()
        with self.assertRaises(ContractError): self.compile()
    def test_recorded_dislike_cannot_flip_to_like(self):
        self.findings["findings"][1]["attitude"]="like"
        with self.assertRaises(ContractError): self.compile()
    def test_recorded_condition_cannot_be_dropped(self):
        self.findings["findings"][6]["conditions"]=[]
        with self.assertRaises(ContractError): self.compile()
    def test_interviewer_question_is_not_user_evidence(self):
        f=self.findings["findings"][3]
        f["evidence_refs"]=["e11"];f["quotes"]=[{"evidence_id":"e11","text":"你是不是喜欢蓝色？"}]
        with self.assertRaises(ContractError): self.compile()
    def test_quote_fabrication_rejected(self):
        self.findings["findings"][0]["quotes"][0]["text"]="我喜欢绿色"
        with self.assertRaises(ContractError): self.compile()
    def test_stale_input_snapshot_rejected(self):
        self.bundle["evidence"][0]["text"]+="新增资料"
        with self.assertRaises(ContractError): self.compile()
    def test_changed_profile_metadata_invalidates_snapshot(self):
        self.bundle["users"][0]["occupation"]="new metadata"
        with self.assertRaises(ContractError): self.compile()
    def test_partial_processing_not_marked_complete(self):
        self.findings["findings"]=self.findings["findings"][:-1]
        p=self.compile()
        self.assertEqual(p["status"],"partial")
        self.assertEqual(p["coverage"]["uncovered_evidence_ids"],["e13"])
    def test_secondary_summary_keeps_warning(self):
        p=self.compile()
        self.assertTrue(any(w["type"]=="secondary_or_unclassified_source" for w in p["warnings"]))
        self.assertEqual(next(f for f in p["preferences"] if f["preference_id"]=="p8")["source_roles"],["researcher_summary"])
    def test_research_images_ignore_quality_status(self):
        baseline=self.compile()
        self.bundle["images"][0]["quality_decision"]="FAIL"
        self.bind()
        result=self.compile()
        self.assertEqual(len(result["preferences"]),len(baseline["preferences"]))
    def test_model_messages_are_strings_and_trend_images_not_sent(self):
        self.bundle["images"].append({"image_id":"trend-x","source_kind":"trend","observations":[]})
        reqs=prepare_requests(self.bundle)
        self.assertTrue(all(isinstance(m["content"],str) for r in reqs["requests"] for m in r["messages"]))
        self.assertNotIn("trend-x",str(reqs["requests"]))
    def test_no_target_users_returns_empty(self):
        self.bundle["brief"]["target_tags"]={"segment":["unavailable"]}
        self.assertEqual(prepare_requests(self.bundle)["status"],"empty")
    def test_batch_responses_cannot_reference_other_batch(self):
        prepared=prepare_requests(self.bundle,max_chars=4000)
        self.assertGreater(len(prepared["requests"]),1)
        responses=[]
        for req in prepared["requests"]:
            ids=set(req["evidence_ids"])
            responses.append({"request_id":req["request_id"],"input_digest":req["input_digest"],
                "findings":[deepcopy(f) for f in self.findings["findings"] if set(f["evidence_refs"]).issubset(ids)],
                "dispositions":[deepcopy(d) for d in self.findings["dispositions"] if d["evidence_id"] in ids]})
        good=accept_batches(self.bundle,prepared,responses)
        self.assertEqual(good["coverage"]["status"],"complete")
        foreign=next(f for f in self.findings["findings"] if not set(f["evidence_refs"]).issubset(prepared["requests"][0]["evidence_ids"]))
        responses[0]["findings"].append(deepcopy(foreign))
        with self.assertRaises(ContractError): accept_batches(self.bundle,prepared,responses)
    def test_semantic_group_preserves_differing_attitudes(self):
        p=self.compile()
        group={"input_digest":p["input_digest"],"groups":[{"group_id":"g","title":"全部示例",
               "design_question":"仅用于测试分解保留","summary":"没有效果含义",
               "preference_ids":[f["preference_id"] for f in p["preferences"]]}]}
        result=compile_semantic_groups(p,group)
        self.assertEqual({b["attitude"] for b in result["semantic_groups"][0]["attitude_breakdown"]},
                         {"like","dislike","conditional"})
    def test_semantic_group_cannot_drop_preferences(self):
        p=self.compile()
        with self.assertRaises(ContractError):
            compile_semantic_groups(p,{"input_digest":p["input_digest"],"groups":[]})
    def mapping(self,relation="explicit"):
        self.bundle["brief"]["persona_text"]="产品面向年轻职场人。"
        req=prepare_tag_mapping(self.bundle)
        return {"input_digest":req["input_digest"],"mappings":[{"tag":"segment","allowed_values":["young_professional"],
            "persona_quote":"年轻职场人","reason":"演示标签映射","relation":relation}]}
    def test_semantic_tag_mapping_does_not_silently_apply(self):
        result=compile_tag_mapping(self.bundle,self.mapping())
        self.assertFalse(result["applied"])
    def test_invented_library_tag_value_rejected(self):
        response=self.mapping()
        response["mappings"][0]["allowed_values"]=["invented_group"]
        with self.assertRaises(ContractError): compile_tag_mapping(self.bundle,response)
    def test_related_tag_never_becomes_hard_filter(self):
        response=self.mapping("related")
        with self.assertRaises(ContractError): compile_tag_mapping(self.bundle,response,apply=True,allow_equivalent=True)
    def test_equivalent_tag_requires_explicit_policy(self):
        response=self.mapping("equivalent")
        with self.assertRaises(ContractError): compile_tag_mapping(self.bundle,response,apply=True)
        result=compile_tag_mapping(self.bundle,response,apply=True,allow_equivalent=True)
        self.assertTrue(result["applied"])

if __name__=="__main__":
    unittest.main()
