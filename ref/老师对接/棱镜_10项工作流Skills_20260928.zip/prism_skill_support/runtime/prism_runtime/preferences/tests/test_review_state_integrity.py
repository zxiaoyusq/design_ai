from copy import deepcopy
import unittest
from prism_runtime.contracts import ContractError
from prism_runtime.preferences import (
    apply_semantic_reviews,validate_reviewed_profile,compile_semantic_groups,prepare_semantic_review,
)
from prism_runtime.preferences.review import refresh_profile_review_state
from prism_runtime.preferences.tests.test_semantic_review import case,envelope,REGISTRY

def item(profile,pid):
    return next(p for p in profile["preferences"] if p["preference_id"]==pid)

class ReviewStateIntegrityCases(unittest.TestCase):
    def setUp(self):
        self.bundle,_,self.profile=case(wrong_like=True)
        self.review=envelope(self.profile,verdict="contradicted")
    def inject_p1(self,profile):
        p=item(profile,"p1")
        p["semantic_assessment"]["status"]="supported"
        p["semantic_assessment"]["support_eligibility"]="reviewed_positive"
        p["semantic_assessment"]["confirmed_user_support"]=True
        p["semantic_assessment"]["review_ids"]=["review-r1"]
        p["confirmed_user_support"]=True
        profile["semantic_review"]["confirmed_positive_preference_ids"]=["p1"]
        return profile
    def assert_pending(self,result):
        p=item(result,"p1")
        self.assertEqual(p["semantic_assessment"]["status"],"pending_independent_review")
        self.assertEqual(p["semantic_assessment"]["support_eligibility"],"candidate_only")
        self.assertEqual(p["semantic_assessment"]["review_ids"],[])
        self.assertFalse(p["confirmed_user_support"])
        self.assertNotIn("p1",result["semantic_review"]["confirmed_positive_preference_ids"])
    def test_unrelated_valid_review_cannot_launder_cached_status(self):
        edited=self.inject_p1(deepcopy(self.profile))
        result=apply_semantic_reviews(self.bundle,edited,self.review,reviewer_registry=REGISTRY)
        self.assert_pending(result)
        self.assertEqual(item(result,"p2")["semantic_assessment"]["status"],"contradicted")
        self.assertIn("p1",result["review_state_integrity"]["cached_state_changed_preference_ids"])
        self.assertTrue(item(edited,"p1")["confirmed_user_support"])  # Input retained for forensics.
    def test_direct_refresh_never_treats_cached_status_as_authority(self):
        result=refresh_profile_review_state(self.inject_p1(deepcopy(self.profile)))
        self.assert_pending(result)
    def test_idempotent_replay_also_sanitizes_unrelated_item(self):
        once=apply_semantic_reviews(self.bundle,self.profile,self.review,reviewer_registry=REGISTRY)
        result=apply_semantic_reviews(self.bundle,self.inject_p1(once),self.review,reviewer_registry=REGISTRY)
        self.assert_pending(result)
        self.assertEqual(len(result["semantic_review_receipts"]),1)
    def test_receipt_bearing_profile_requires_verified_consumer_entrypoint(self):
        reviewed=apply_semantic_reviews(self.bundle,self.profile,self.review,reviewer_registry=REGISTRY)
        with self.assertRaises(ContractError): refresh_profile_review_state(reviewed)
        validated=validate_reviewed_profile(self.bundle,reviewed,reviewer_registry=REGISTRY)
        self.assertEqual(item(validated,"p2")["semantic_assessment"]["status"],"contradicted")
    def test_altered_receipt_item_is_rejected_before_another_review(self):
        reviewed=apply_semantic_reviews(self.bundle,self.profile,self.review,reviewer_registry=REGISTRY)
        reviewed["semantic_review_receipts"][0]["items"][0]["verdict"]="supported"
        with self.assertRaises(ContractError):
            apply_semantic_reviews(self.bundle,reviewed,self.review,reviewer_registry=REGISTRY)
    def test_altered_original_envelope_is_rejected(self):
        reviewed=apply_semantic_reviews(self.bundle,self.profile,self.review,reviewer_registry=REGISTRY)
        reviewed["semantic_review_receipts"][0]["review_envelope"]["items"][0]["verdict"]="supported"
        with self.assertRaises(ContractError):
            validate_reviewed_profile(self.bundle,reviewed,reviewer_registry=REGISTRY)
    def test_registry_change_cannot_silently_revalidate_history(self):
        reviewed=apply_semantic_reviews(self.bundle,self.profile,self.review,reviewer_registry=REGISTRY)
        changed=deepcopy(REGISTRY);changed["registry_version"]="2"
        with self.assertRaises(ContractError):
            validate_reviewed_profile(self.bundle,reviewed,reviewer_registry=changed)
    def test_removing_receipt_removes_cached_positive_eligibility(self):
        positive=envelope(self.profile,pid="p1")
        positive["items"][0]["reason"]="Synthetic faithful positive control."
        reviewed=apply_semantic_reviews(self.bundle,self.profile,positive,reviewer_registry=REGISTRY)
        self.assertTrue(item(reviewed,"p1")["confirmed_user_support"])
        reviewed["semantic_review_receipts"]=[]
        validated=validate_reviewed_profile(self.bundle,reviewed,reviewer_registry=REGISTRY)
        self.assert_pending(validated)
    def test_legacy_exact_receipt_can_still_be_verified(self):
        reviewed=apply_semantic_reviews(self.bundle,self.profile,self.review,reviewer_registry=REGISTRY)
        reviewed["semantic_review_receipts"][0].pop("review_envelope")
        validated=validate_reviewed_profile(self.bundle,reviewed,reviewer_registry=REGISTRY)
        self.assertEqual(item(validated,"p2")["semantic_assessment"]["status"],"contradicted")
    def test_grouping_cannot_use_serialized_review_flags_without_sources(self):
        reviewed=apply_semantic_reviews(self.bundle,self.profile,self.review,reviewer_registry=REGISTRY)
        groups={"input_digest":reviewed["input_digest"],"groups":[{
            "group_id":"g","title":"测试","design_question":"测试","summary":"测试",
            "preference_ids":[p["preference_id"] for p in reviewed["preferences"]]}]}
        with self.assertRaises(ContractError): compile_semantic_groups(reviewed,groups)
        grouped=compile_semantic_groups(reviewed,groups,bundle=self.bundle,reviewer_registry=REGISTRY)
        self.assertFalse(grouped["semantic_groups"][0]["confirmed_user_support"])
        self.assertEqual(item(grouped,"p2")["semantic_assessment"]["status"],"contradicted")
    def test_review_request_hides_edited_cache_from_independent_reader(self):
        import json
        edited=self.inject_p1(deepcopy(self.profile))
        request=prepare_semantic_review(self.bundle,edited,["p1"])
        payload=json.loads(request["messages"][1]["content"])
        self.assertFalse(payload["candidates"][0]["confirmed_user_support"])
        self.assertEqual(payload["candidates"][0]["semantic_assessment"]["status"],"pending_independent_review")

if __name__=="__main__":
    unittest.main()
