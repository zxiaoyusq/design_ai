from copy import deepcopy
import unittest
from prism_runtime.contracts import ContractError
from prism_runtime.preferences import (
    compile_preferences, prepare_requests, prepare_semantic_review,
    apply_semantic_reviews, compile_semantic_groups,
)
from prism_runtime.preferences.demo import build_fixture
from prism_runtime.preferences.review import POLICY_VERSION, CHECKED_ASPECTS

CONTEXT={"producer_id":"fixture-extractor","independence_group":"fixture-extraction-stage","run_id":"extract-r1"}
REGISTRY={"registry_id":"fixture-registry","registry_version":"1","issued_by":"synthetic-test-harness",
          "reviewers":[{"reviewer_id":"fixture-reviewer","actor_type":"synthetic_fixture",
                        "independence_group":"fixture-review-stage","allowed_dataset_modes":["synthetic"]}]}

def case(wrong_like=False):
    bundle,findings=build_fixture()
    bundle["evidence"][1].pop("recorded_attitude")
    findings["input_digest"]=prepare_requests(bundle)["input_digest"]
    findings["provenance"]={"producer_id":"untrusted-reply-cannot-bind-identity","reviewed":True}
    if wrong_like:
        findings["findings"][1]["attitude"]="like"
        findings["findings"][1]["summary"]="错误候选：喜欢满版图案"
    profile=compile_preferences(bundle,findings,require_input_digest=True,extraction_context=CONTEXT)
    return bundle,findings,profile

def envelope(profile,pid="p2",verdict="supported",review_id="review-r1"):
    f=next(x for x in profile["preferences"] if x["preference_id"]==pid)
    item={"preference_id":pid,"candidate_digest":f["semantic_assessment"]["candidate_digest"],
          "verdict":verdict,"reason":"合成协议夹具：逐字原话明确排斥满版图案；只测试协议，不冒充真实独立审阅。",
          "quotes":deepcopy(f["quotes"]),"record_refs":f.get("record_refs",[]),
          "checked_aspects":sorted(CHECKED_ASPECTS)}
    if verdict=="contradicted": item["corrected_attitude"]="dislike"
    return {"schema_version":POLICY_VERSION,"input_digest":profile["input_digest"],
            "review_id":review_id,"reviewer_id":"fixture-reviewer","reviewed_at":"2026-09-26T10:00:00Z",
            "review_artifact_ref":"fixture://semantic-review-protocol-test","items":[item]}

class SemanticReviewCases(unittest.TestCase):
    def setUp(self):
        self.bundle,self.findings,self.profile=case()
    def test_reproduced_wrong_like_is_candidate_never_confirmed_support(self):
        _,_,profile=case(wrong_like=True)
        f=next(x for x in profile["preferences"] if x["preference_id"]=="p2")
        self.assertEqual(f["attitude"],"like")  # Candidate is preserved, not rewritten by a keyword rule.
        self.assertEqual(f["attitude_origin"]["kind"],"model_interpreted")
        self.assertEqual(f["semantic_assessment"]["status"],"pending_independent_review")
        self.assertEqual(f["semantic_assessment"]["support_eligibility"],"candidate_only")
        self.assertFalse(f["confirmed_user_support"])
        self.assertEqual(profile["semantic_review"]["confirmed_positive_preference_ids"],[])
    def test_correct_negative_control_is_preserved_after_review(self):
        result=apply_semantic_reviews(self.bundle,self.profile,envelope(self.profile),reviewer_registry=REGISTRY)
        f=next(x for x in result["preferences"] if x["preference_id"]=="p2")
        self.assertEqual(f["attitude"],"dislike")
        self.assertEqual(f["semantic_assessment"]["support_eligibility"],"reviewed_negative")
        self.assertFalse(f["confirmed_user_support"])
    def test_wrong_like_can_be_rejected_without_overwriting_candidate(self):
        b,_,p=case(wrong_like=True)
        result=apply_semantic_reviews(b,p,envelope(p,verdict="contradicted"),reviewer_registry=REGISTRY)
        f=next(x for x in result["preferences"] if x["preference_id"]=="p2")
        self.assertEqual(f["attitude"],"like")
        self.assertEqual(f["semantic_assessment"]["status"],"contradicted")
        self.assertEqual(f["semantic_assessment"]["suggested_correction"]["attitude"],"dislike")
        self.assertFalse(f["confirmed_user_support"])
        self.assertEqual(result["semantic_review_receipts"][0]["review_scope"],"synthetic_fixture_only")
    def test_inline_review_claims_cannot_promote_candidate(self):
        f=self.findings["findings"][1]
        f["reviewed"]=True
        f["confirmed_user_support"]=True
        f["semantic_assessment"]={"status":"supported","review_ids":["made-up"]}
        p=compile_preferences(self.bundle,self.findings,require_input_digest=True,extraction_context=CONTEXT)
        item=next(x for x in p["preferences"] if x["preference_id"]=="p2")
        self.assertFalse(item["confirmed_user_support"])
        self.assertEqual(item["semantic_assessment"]["review_ids"],[])
        self.assertTrue(item["untrusted_review_claims"]["reviewed"])
    def test_provenance_reply_cannot_supply_trusted_extraction_identity(self):
        p=compile_preferences(self.bundle,self.findings,require_input_digest=True)
        with self.assertRaises(ContractError): prepare_semantic_review(self.bundle,p)
    def test_unregistered_reviewer_is_rejected(self):
        r=envelope(self.profile);r["reviewer_id"]="self-claimed-human"
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
    def test_same_independence_group_is_rejected(self):
        registry=deepcopy(REGISTRY)
        registry["reviewers"][0]["independence_group"]=CONTEXT["independence_group"]
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,self.profile,envelope(self.profile),reviewer_registry=registry)
    def test_same_producer_under_new_group_is_rejected(self):
        registry=deepcopy(REGISTRY);registry["reviewers"][0]["reviewer_id"]=CONTEXT["producer_id"]
        r=envelope(self.profile);r["reviewer_id"]=CONTEXT["producer_id"]
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=registry)
    def test_wrong_candidate_digest_is_rejected(self):
        r=envelope(self.profile);r["items"][0]["candidate_digest"]="bad"
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
    def test_changed_summary_after_review_preparation_is_rejected(self):
        r=envelope(self.profile)
        self.profile["preferences"][1]["summary"]="changed after extraction"
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
    def test_changed_source_version_is_rejected(self):
        r=envelope(self.profile)
        self.bundle["evidence"][1]["text"]+="新条件"
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
    def test_review_must_cite_source_and_check_all_aspects(self):
        r=envelope(self.profile);r["items"][0]["quotes"]=[]
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
        r=envelope(self.profile);r["items"][0]["checked_aspects"]=["attitude"]
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
    def test_different_reviews_mark_disputed_not_latest_wins(self):
        supported=apply_semantic_reviews(self.bundle,self.profile,envelope(self.profile),reviewer_registry=REGISTRY)
        result=apply_semantic_reviews(self.bundle,supported,envelope(self.profile,verdict="contradicted",review_id="review-r2"),reviewer_registry=REGISTRY)
        item=next(x for x in result["preferences"] if x["preference_id"]=="p2")
        self.assertEqual(item["semantic_assessment"]["status"],"disputed")
        self.assertFalse(item["confirmed_user_support"])
        self.assertEqual(len(item["semantic_assessment"]["review_ids"]),2)
    def test_idempotent_receipt_cannot_be_rewritten(self):
        r=envelope(self.profile)
        result=apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
        repeated=apply_semantic_reviews(self.bundle,result,r,reviewer_registry=REGISTRY)
        self.assertEqual(len(repeated["semantic_review_receipts"]),1)
        r["items"][0]["reason"]="rewritten"
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,result,r,reviewer_registry=REGISTRY)
    def test_partial_review_does_not_confirm_unreviewed_positive(self):
        result=apply_semantic_reviews(self.bundle,self.profile,envelope(self.profile),reviewer_registry=REGISTRY)
        p1=next(x for x in result["preferences"] if x["preference_id"]=="p1")
        self.assertEqual(p1["attitude_origin"]["kind"],"source_recorded")
        self.assertFalse(p1["confirmed_user_support"])
        self.assertEqual(result["semantic_review_status"],"partially_reviewed")
    def test_reviewed_conditional_never_becomes_unconditional_support(self):
        r=envelope(self.profile,pid="p3")
        result=apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
        item=next(x for x in result["preferences"] if x["preference_id"]=="p3")
        self.assertEqual(item["semantic_assessment"]["support_eligibility"],"reviewed_conditional")
        self.assertFalse(item["confirmed_user_support"])
        self.assertEqual(item["conditions"],["办公室场景"])
    def test_supported_positive_requires_the_registered_review_path(self):
        r=envelope(self.profile,pid="p1")
        r["items"][0]["reason"]="合成协议对照：原话明确喜欢圆润轮廓，候选保留对象、态度和原因。"
        result=apply_semantic_reviews(self.bundle,self.profile,r,reviewer_registry=REGISTRY)
        item=next(x for x in result["preferences"] if x["preference_id"]=="p1")
        self.assertTrue(item["confirmed_user_support"])
        self.assertEqual(item["semantic_assessment"]["support_eligibility"],"reviewed_positive")
        self.assertEqual(result["semantic_review"]["review_scope"],"synthetic_fixture_only")
        self.assertFalse(result["semantic_review"]["real_user_effect_validated"])
    def test_unbound_compatibility_candidate_cannot_be_review_promoted(self):
        self.findings.pop("input_digest")
        p=compile_preferences(self.bundle,self.findings,extraction_context=CONTEXT)
        with self.assertRaises(ContractError): prepare_semantic_review(self.bundle,p)
    def test_fixture_reviewer_cannot_confirm_real_source_mode(self):
        self.bundle["provenance"]["mode"]="real_evidence"  # Adversarial protocol fixture, not actual real material.
        self.findings["input_digest"]=prepare_requests(self.bundle)["input_digest"]
        p=compile_preferences(self.bundle,self.findings,require_input_digest=True,extraction_context=CONTEXT)
        registry=deepcopy(REGISTRY)
        registry["reviewers"][0]["allowed_dataset_modes"].append("real_evidence")
        with self.assertRaises(ContractError): apply_semantic_reviews(self.bundle,p,envelope(p),reviewer_registry=registry)
    def test_group_model_cannot_self_confirm_group_summary(self):
        grouped=compile_semantic_groups(self.profile,{"input_digest":self.profile["input_digest"],"groups":[{
            "group_id":"g","title":"测试","design_question":"测试问题","summary":"测试总结",
            "preference_ids":[f["preference_id"] for f in self.profile["preferences"]],
            "reviewed":True,"confirmed_user_support":True,
        }]})
        self.assertFalse(grouped["semantic_groups"][0]["confirmed_user_support"])
        self.assertEqual(grouped["semantic_groups"][0]["semantic_assessment"]["summary_review_status"],
                         "not_reviewed_by_atomic_preference_review")

if __name__=="__main__":
    unittest.main()
