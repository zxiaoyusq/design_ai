import argparse
from prism_runtime.contracts import read_json, write_json
from .api import (prepare_requests, compile_preferences, accept_batches,
                  prepare_semantic_groups, compile_semantic_groups)
from .tag_mapping import prepare_tag_mapping, compile_tag_mapping
from .review import prepare_semantic_review, apply_semantic_reviews, validate_reviewed_profile

p=argparse.ArgumentParser(description="Prepare semantic preference extraction or accept source-linked findings.")
p.add_argument("action",choices=["prepare","accept","accept-batches","prepare-groups","accept-groups","prepare-tags","accept-tags","prepare-review","accept-review","validate-review-state"])
p.add_argument("--bundle")
p.add_argument("--findings")
p.add_argument("--prepared")
p.add_argument("--profile")
p.add_argument("--extraction-context",help="Trusted caller extraction identity JSON, not model output.")
p.add_argument("--reviewer-registry",help="Trusted coordinator-owned reviewer registry JSON.")
p.add_argument("--output",required=True)
p.add_argument("--max-chars",type=int,default=32000)
p.add_argument("--allow-unbound",action="store_true",help="Compatibility only: missing input_digest is marked partial.")
p.add_argument("--apply-tags",action="store_true",help="Explicitly apply eligible proposed tag criteria.")
p.add_argument("--allow-equivalent-tags",action="store_true",help="Allow declared semantic equivalence as a filter criterion.")
a=p.parse_args()
if a.action in {"prepare","accept","accept-batches","prepare-tags","accept-tags","prepare-review","accept-review","validate-review-state"} and not a.bundle: p.error("--bundle required")
if a.action in {"accept","accept-batches","accept-groups","accept-tags","accept-review"} and not a.findings: p.error("--findings required")
if a.action=="accept-batches" and not a.prepared: p.error("--prepared required")
if a.action in {"prepare-groups","accept-groups","prepare-review","accept-review","validate-review-state"} and not a.profile: p.error("--profile required")
if a.action in {"accept-review","validate-review-state"} and not a.reviewer_registry: p.error("--reviewer-registry required")
context=read_json(a.extraction_context) if a.extraction_context else None
if a.action=="prepare": result=prepare_requests(read_json(a.bundle),a.max_chars)
elif a.action=="accept": result=compile_preferences(read_json(a.bundle),read_json(a.findings),require_input_digest=not a.allow_unbound,extraction_context=context)
elif a.action=="accept-batches": result=accept_batches(read_json(a.bundle),read_json(a.prepared),read_json(a.findings),extraction_context=context)
elif a.action=="prepare-groups": result=prepare_semantic_groups(read_json(a.profile))
elif a.action=="accept-groups": result=compile_semantic_groups(read_json(a.profile),read_json(a.findings),
    bundle=read_json(a.bundle) if a.bundle else None,reviewer_registry=read_json(a.reviewer_registry) if a.reviewer_registry else None)
elif a.action=="prepare-tags": result=prepare_tag_mapping(read_json(a.bundle))
elif a.action=="accept-tags": result=compile_tag_mapping(read_json(a.bundle),read_json(a.findings),apply=a.apply_tags,allow_equivalent=a.allow_equivalent_tags)
elif a.action=="prepare-review": result=prepare_semantic_review(read_json(a.bundle),read_json(a.profile))
elif a.action=="accept-review": result=apply_semantic_reviews(read_json(a.bundle),read_json(a.profile),read_json(a.findings),reviewer_registry=read_json(a.reviewer_registry))
else: result=validate_reviewed_profile(read_json(a.bundle),read_json(a.profile),reviewer_registry=read_json(a.reviewer_registry))
write_json(a.output,result)
print(a.output)
