"""Preference-specific source validation, independent of trend image quality."""
from __future__ import annotations
import hashlib
import json
from prism_runtime.contracts import require, index_by, bundle_indexes, value_key

DIRECT_ROLES = {"user_statement", "transcript", "selection_record"}
NON_PREFERENCE_ROLES = {"interviewer_question", "image_observation", "project_description"}
SECONDARY_ROLES = {"researcher_summary", "model_summary", "unclassified"}
ATTITUDES = {"like", "dislike", "conditional", "neutral", "unknown"}
ALIASES = {"LIKE":"like","ENJOY":"like","DISLIKE":"dislike","NEUTRAL":"neutral","UNKNOWN":"unknown","CONDITIONAL":"conditional"}

def attitude(value):
    if value is None:
        return None
    require(isinstance(value,str), "attitude must be a string")
    result = ALIASES.get(value, value.lower())
    require(result in ATTITUDES, "invalid source attitude")
    return result

def source_role(row):
    role = row.get("evidence_role","unclassified")
    require(role in DIRECT_ROLES | SECONDARY_ROLES | NON_PREFERENCE_ROLES, "invalid evidence_role")
    return role

def canonical_features(features):
    return sorted(
        ({"parameter_id":x["parameter_id"],"value":x["value"]} for x in features),
        key=lambda x:(x["parameter_id"],value_key(x["value"])),
    )

def validate_bundle(bundle):
    require(isinstance(bundle,dict), "bundle must be an object")
    users,evidence,images=bundle_indexes(bundle)
    brief=bundle.get("brief",{})
    require(isinstance(brief.get("brief_id"),str) and brief["brief_id"], "brief_id required")
    require(isinstance(brief.get("target_tags",{}),dict), "target_tags must be an object")
    for values in brief.get("target_tags",{}).values():
        require(isinstance(values,list) and bool(values), "each target tag needs a nonempty allowed-value list")
    for row in evidence.values():
        if row.get("source_kind")!="research":
            continue
        require(row.get("user_id") in users, "research evidence must belong to a known user")
        source_role(row)
        if "recorded_attitude" in row:
            attitude(row["recorded_attitude"])
        require(isinstance(row.get("text",""),str), "evidence text must be a string")
        require(isinstance(row.get("recorded_conditions",[]),list), "recorded_conditions must be a list")
        if row.get("image_id") is not None:
            require(row["image_id"] in images, "research evidence references an unknown image")
    for image in images.values():
        index_by(image.get("observations",[]),"observation_id")
    return users,evidence,images

def fingerprint(bundle, selected_user_ids, eligible_evidence_ids):
    users,evidence,images=validate_bundle(bundle)
    refs=[evidence[x] for x in eligible_evidence_ids]
    image_ids=sorted({r["image_id"] for r in refs if r.get("image_id")})
    payload={"brief":bundle["brief"],"selected_users":[users[u] for u in selected_user_ids],
             "evidence":refs,"images":[images[x] for x in image_ids],"provenance":bundle["provenance"]}
    raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(",",":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

def validate_quote(q,evidence):
    ref=q.get("evidence_id")
    require(ref in evidence, "unknown quote source")
    text=q.get("text")
    require(isinstance(text,str) and bool(text.strip()), "empty quote")
    raw=evidence[ref].get("text","")
    require(text in raw, "quote not found verbatim")
    if "start" in q or "end" in q:
        start,end=q.get("start"),q.get("end")
        require(type(start) is int and type(end) is int and 0<=start<end<=len(raw), "invalid quote span")
        require(raw[start:end]==text, "quote span does not match")

def validate_feature(feature,findings_refs,rows,images):
    field=feature.get("parameter_id")
    require(isinstance(field,str) and field and "value" in feature and feature["value"] is not None, "invalid feature")
    method=feature.get("attribution","legacy_unspecified")
    require(method in {"explicit_text","pointed_image_feature","legacy_unspecified"}, "invalid attribution method")
    bindings=feature.get("evidence_refs",findings_refs)
    require(isinstance(bindings,list) and bool(bindings) and set(bindings).issubset(findings_refs), "feature evidence outside finding")
    bound=[r for r in rows if r["evidence_id"] in bindings]
    if method=="explicit_text":
        require(any(r.get("text","").strip() and source_role(r)!="selection_record" for r in bound),
                "explicit_text attribution needs actual user language, not only an image choice")
        require(not all(r.get("target_scope")=="image" for r in bound),
                "a source explicitly scoped to whole-image reaction cannot prove a specific feature")
    observation_refs=feature.get("observation_refs",[])
    require(isinstance(observation_refs,list), "observation_refs must be a list")
    if method=="pointed_image_feature":
        require(bool(observation_refs), "pointed image feature requires a DNA observation reference")
    resolved=[]
    for ref in observation_refs:
        iid=ref.get("image_id")
        oid=ref.get("observation_id")
        require(iid in images, "unknown feature image")
        observations=index_by(images[iid].get("observations",[]),"observation_id")
        require(oid in observations, "unknown DNA observation")
        o=observations[oid]
        require(o.get("parameter_id")==field and o.get("value_status")=="known"
                and value_key(o.get("value"))==value_key(feature["value"]), "feature conflicts with referenced DNA")
        require(o.get("object_id") not in {None,"","unknown"} and o.get("region_ref") is not None,
                "DNA reference has no reliable object/region")
        associated=[r for r in bound if r.get("image_id")==iid]
        require(bool(associated), "feature image is not associated with quoted evidence")
        if method=="pointed_image_feature":
            pointed=[r for r in associated if r.get("target_scope") in {"object","region"}]
            require(bool(pointed), "whole-image Like cannot be converted to element attribution")
            require(any((r.get("target_object_id")==o["object_id"]) or
                        (r.get("target_region_ref") is not None and value_key(r["target_region_ref"])==value_key(o["region_ref"]))
                        for r in pointed), "pointed user target does not match DNA carrier")
        resolved.append({"image_id":iid,"observation_id":oid,"object_id":o["object_id"],"region_ref":o["region_ref"]})
    return {"status":"attribution_needs_review" if method=="legacy_unspecified" else "source_linked_model_interpretation",
            "method":method,"resolved_observations":resolved}
