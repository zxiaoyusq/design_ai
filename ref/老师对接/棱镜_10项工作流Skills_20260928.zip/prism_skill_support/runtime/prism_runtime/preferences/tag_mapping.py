"""Semantic persona-to-tag proposals, separate from factual preference extraction."""
import hashlib
import json
from copy import deepcopy
from prism_runtime.contracts import require, value_key
from .validation import validate_bundle

def _context(bundle):
    users,_,_=validate_bundle(bundle)
    persona=bundle["brief"].get("persona_text")
    require(isinstance(persona,str) and persona.strip(),"brief.persona_text is required for semantic tag mapping")
    inventory={}
    for user in users.values():
        for key,value in user.get("tags",{}).items():
            vals=value if isinstance(value,list) else [value]
            for v in vals:
                inventory.setdefault(key,{})[value_key(v)]=v
    data={"brief_id":bundle["brief"]["brief_id"],"persona_text":persona,
          "tag_inventory":{k:list(v.values()) for k,v in sorted(inventory.items())}}
    digest=hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    return data,digest

def prepare_tag_mapping(bundle):
    data,digest=_context(bundle)
    return {"schema_version":"prism.persona_tag_request.v0.1","input_digest":digest,
        "messages":[{"role":"system","content":
          "把产品目标用户画像映射到提供的现有用户标签。只使用tag_inventory中的字段和值，不发明库标签。"
          "每条mapping含tag,allowed_values,persona_quote,reason,relation(explicit/equivalent/related)。"
          "persona_quote必须逐字来自persona_text。明确筛选要求标explicit，同义映射标equivalent，"
          "仅可能相关但并非明确要求标related。不要根据年龄/职业刻板推断审美，不把产品想卖的风格当用户已经喜欢。"
          "返回mappings及input_digest；缺少可用标签可输出空列表，解释unmapped。"},
          {"role":"user","content":json.dumps({**data,"input_digest":digest},ensure_ascii=False)}],
        "provenance":bundle["provenance"]}

def compile_tag_mapping(bundle,response,*,apply=False,allow_equivalent=False):
    data,digest=_context(bundle)
    require(response.get("input_digest")==digest,"tag mapping uses a stale persona or tag inventory")
    mappings=response.get("mappings",[])
    require(isinstance(mappings,list),"mappings must be a list")
    seen=set()
    accepted,proposals=[],[]
    for m in mappings:
        key=m.get("tag")
        require(key in data["tag_inventory"] and key not in seen,"unknown or duplicate mapped tag")
        seen.add(key)
        values=m.get("allowed_values",[])
        require(isinstance(values,list) and bool(values),"mapped values required")
        require({value_key(v) for v in values}.issubset(value_key(v) for v in data["tag_inventory"][key]),
                "mapping invented a value not present in the library")
        quote=m.get("persona_quote")
        require(isinstance(quote,str) and quote.strip() and quote in data["persona_text"],"persona quote not found")
        require(isinstance(m.get("reason"),str) and m["reason"].strip(),"mapping explanation required")
        relation=m.get("relation")
        require(relation in {"explicit","equivalent","related"},"invalid mapping relation")
        applicable=relation=="explicit" or (relation=="equivalent" and allow_equivalent)
        item={**deepcopy(m),"eligible_for_filter":applicable,"semantic_status":"model_mapping_not_independently_validated"}
        proposals.append(item)
        if applicable: accepted.append(item)
    result={"schema_version":"prism.persona_tag_mapping.v0.1","brief_id":data["brief_id"],
            "input_digest":digest,"mappings":proposals,"unmapped":response.get("unmapped",[]),
            "status":"proposal_only","applied":False,"provenance":bundle["provenance"]}
    if apply:
        require(bool(accepted),"no supported filtering criteria; will not silently select the whole library")
        updated=deepcopy(bundle)
        updated["brief"]["target_tags"]={m["tag"]:m["allowed_values"] for m in accepted}
        updated["brief"]["tag_mapping_provenance"]={"input_digest":digest,"allow_equivalent":allow_equivalent,
                                                    "mappings":accepted}
        result.update({"applied":True,"status":"criteria_applied_not_semantically_validated","bundle":updated})
    return result
