# 用研偏好算法 v0.3.1

只负责目标用户筛选、研究证据提取和偏好语义归纳。输入可来自已标注图库、项目说明、原始访谈的转写／整理结果；图片DNA由公共解析模块提供。本模块不解码录音、不重新解析图片，不调用高级感判标，不产生趋势握手或图片聚类方向。

当前交付是可运行的provider-independent原型。语义提取与主题合并仍需要LLM／宿主完成；代码准备带来源的请求、校验接收结果、合并批次并保留差异，不能把程序通过理解为语义准确。

v0.3增加[独立语义复核交接](SEMANTIC_REVIEW.md)：所有模型解释默认candidate_only。仅经绑定原文、资料／候选版本、可信身份登记的独立核对，才可提供已核对的支持或负向约束。模型自填reviewed=true不能升级；尚未解决自动语义理解的准确率问题。

v0.3.1进一步将profile中的审核字段全部视为缓存，接收／消费时以经来源和登记验证的回执重建状态，修复未审条目可借另一条合法review升级的问题。握手模块使用validate_reviewed_profile返回值，不直接信任保存文件里的supported字段。

## 处理流程

1. 将自然语言产品画像与库内标签交给语义模型提出映射，校验引用和真实库值后形成候选条件；或直接接收已经明确的target_tags。精确值、同义映射和仅相关线索分别处理。映射默认不自动变成筛选条件，equivalent需明确启用，related不能充当硬过滤。
2. 选取目标项目的研究记录。题干、图片观察、项目说明不充当用户意见；空记录不当“没有偏好”。
3. 按字符预算准备模型请求。只带选中研究记录及其关联图片DNA，保留全文，不静默截断。请求和回复绑定资料快照。
4. 接收每位用户的原子偏好：theme、element、image。逐字引用、选图记录、态度、条件、对象／区域与DNA关系分别校验。
5. 归并同议题且相同态度、条件和特征的记录，按用户去重。可再做一次全局语义归纳，把相同设计问题整理成主题，同时保存所有态度分支与原始记录。
6. 输出PreferenceProfile供独立H01／H02握手模块使用；三档对齐属于握手模块，不改变偏好事实。

## 最低输入

bundle为UTF-8 JSON，公共字段沿用prism_runtime/CONTRACT.md。

- brief：brief_id、target_tags（每个键对应非空允许值数组）；可选tag_aliases、research_project_ids。
- users：user_id与已有tags。不从人口标签推导喜欢／不喜欢。
- evidence：evidence_id、source_kind=research、user_id、project_id、text、evidence_role；可选recorded_attitude、recorded_conditions、image_id、target_scope、target_object_id／target_region_ref。
- images：公共ImageDNA。用研选图若暂未解析，可保留image_id和空observations；没有DNA不得创建视觉特征归因。
- provenance.mode：synthetic或real_evidence，不能省略。

evidence_role支持user_statement、transcript、selection_record、researcher_summary、model_summary、interviewer_question、image_observation、project_description、unclassified。未知分类保留告警，不自动提升为原始访谈。

无文字的选图记录必须有图片身份与明确态度。LIKE／ENJOY统一为like。整图选择只产生image级记录；对特征的归因需明确文字，或用户实际指向的对象／区域与DNA观察一致。

## 可复跑命令

从工程根目录执行（python指向可用Python 3.10+，只依赖标准库）：

    python -m prism_runtime.preferences.demo --output outputs/prism-algorithm-loop-20260926/modules/preferences/examples
    python -m unittest prism_runtime.preferences.tests.test_preferences -v

准备提取请求：

    python -m prism_runtime.preferences prepare --bundle INPUT.json --output REQUESTS.json --max-chars 32000

如果只有自然语言画像，先在brief.persona_text中提供画像，再准备标签映射：

    python -m prism_runtime.preferences prepare-tags --bundle INPUT.json --output TAG_REQUEST.json
    python -m prism_runtime.preferences accept-tags --bundle INPUT.json --findings TAG_RESPONSE.json --output TAG_PROPOSAL.json

接受映射后可显式加--apply-tags，将满足条件的字段写入输出bundle；同义映射另外需--allow-equivalent-tags。输出保留语义判断尚未独立验证的状态，相关线索不会自动变成硬筛选。

由模型或宿主处理请求，将findings、dispositions与input_digest保存为回复。单批：

    python -m prism_runtime.preferences accept --bundle INPUT.json --findings RESPONSE.json --output PROFILE.json

多批：回复文件为数组，每项包含request_id、input_digest、findings、dispositions。不能给某批回复引用另一批的来源。

    python -m prism_runtime.preferences accept-batches --bundle INPUT.json --prepared REQUESTS.json --findings RESPONSES.json --output PROFILE.json

全局语义议题合并：

    python -m prism_runtime.preferences prepare-groups --profile PROFILE.json --output GROUP_REQUEST.json
    python -m prism_runtime.preferences accept-groups --profile PROFILE.json --findings GROUP_RESPONSE.json --output GROUPED_PROFILE.json

CLI默认要求快照绑定。早期无digest调用只能使用显式--allow-unbound，输出标记partial；不建议正式使用。

## 公共函数

from prism_runtime.preferences import select_users, prepare_request, prepare_requests, compile_preferences, accept_batches, prepare_semantic_groups, compile_semantic_groups

compile_preferences(bundle, findings)兼容早期调用；生产接收建议require_input_digest=True。每条原子finding限一位用户，跨用户合并在semantic_clusters／semantic_groups进行。

## 输出与下游使用

PreferenceProfile保留原schema_version=prism.preference_profile.v0.1，新提取algorithm_version=0.3.1。旧提取profile的算法版本保留，复核处理版本与代码哈希记录在交接材料中。关键字段：

- preferences：原子偏好，保留用户、态度、条件、引用、图像身份和特征归因验证。theme/image的features始终为空。
- theme_preferences、element_preferences、whole_image_preferences：分层索引。
- semantic_clusters：代码按已有topic_key及具体条件分组，不宣称代码自动理解语义。
- semantic_groups：可选全局模型归纳，每组含design_question、summary、attitude_breakdown和来源；原子态度永不改写。
- selection、coverage、warnings：入选／排除理由、分析覆盖和证据边界。
- input_digest、source_contexts、source_roles：原始资料快照、语境和来源层次。
- attitude_origin、semantic_assessment、semantic_review_receipts：原始态度来源、候选资格与独立核对记录。H01/H02必须按SEMANTIC_REVIEW.md消费，不能仅凭attitude=like认定支持。

recorded_conditions始终保留。握手模块需结合source_contexts和用户范围判断排斥条件是否适用，不能把条件性Dislike升为全局禁令。

人口分母、实际有研究记录用户数和已处理用户数分别给出。提及人数不是市场占比或经过标定的偏好概率。

## 实际验证边界

本版样例的用户、原话、DNA、语义标注均为合成夹具；报告明确标注。它们用于开发和回归，不是独立保留集。当前没有可以确认归属和授权范围的真实用研资料，也没有新增付费调用。

代码可验证身份、原文片段、态度元数据、对象／区域绑定和覆盖，但不能证明一段语义摘要准确解释了原话。来源没有独立态度标注时，模型可能仍理解错否定；v0.3确保这类未核对解释只保留为候选。它没有通过关键词规则或自填标记宣称自动语义理解已解决。

尚未验证：真实多语种访谈、录音转写误差、自然语言画像到库标签映射的准确率、大规模上下文、模型间稳定性、不同研究项目的同义议题合并。真实数据与设计师／研究人员标定到位后再做独立效果评估。
