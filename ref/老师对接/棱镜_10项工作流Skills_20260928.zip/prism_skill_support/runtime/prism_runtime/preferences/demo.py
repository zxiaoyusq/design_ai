"""Synthetic demonstration only. Annotations are fixtures, not a live model accuracy test."""
from __future__ import annotations
import argparse
from pathlib import Path
from .api import prepare_requests, compile_preferences, compile_semantic_groups
from prism_runtime.contracts import write_json

def build_fixture():
    users=[
        {"user_id":"u1","tags":{"segment":"young_professional"}},
        {"user_id":"u2","tags":{"segment":"初职场"}},
        {"user_id":"u3","tags":{"segment":"student"}},
        {"user_id":"u4","tags":{}},
        {"user_id":"u5","tags":{"segment":"young_professional"}},
    ]
    image={"schema_version":"prism.image_dna.v0.1","image_id":"research-r1","source_kind":"synthetic",
           "image_path":None,"source_ref":"synthetic fixture; no physical image",
           "observations":[
               {"observation_id":"o-contour","parameter_id":"GEO-001","object_id":"body",
                "value":"圆弧","value_status":"known","region_ref":{"fixture_region":"body-edge"},
                "evidence_refs":["synthetic-dna-r1"]},
               {"observation_id":"o-color","parameter_id":"fixture.color","object_id":"body",
                "value":"绿色","value_status":"known","region_ref":{"fixture_region":"body-surface"},
                "evidence_refs":["synthetic-dna-r1"]}],
           "provenance":{"mode":"synthetic","parser_version":"fixture-not-a-visual-test"}}
    def e(eid,uid,text,recorded=None,role="user_statement",**extra):
        r={"evidence_id":eid,"source_kind":"research","user_id":uid,"project_id":"synthetic-project",
           "evidence_role":role,"text":text,"context":{"project":"演示场景"}}
        if recorded is not None: r["recorded_attitude"]=recorded
        return {**r,**extra}
    evidence=[
        e("e1","u1","我喜欢圆润的轮廓，看起来柔和。","like"),
        e("e2","u1","我不喜欢满版图案，信息太杂。","dislike"),
        e("e3","u2","在办公室我只接受低亮度的灯效。","conditional",recorded_conditions=["办公室场景"]),
        e("e4","u2","我希望有自己的特点，但不要太张扬。","like"),
        e("e5","u1","","LIKE",role="selection_record",image_id="research-r1",target_scope="image"),
        e("e6","u2","我喜欢这里的圆润边角。","like",image_id="research-r1",target_scope="region",
          target_object_id="body",target_region_ref={"fixture_region":"body-edge"}),
        e("e7","u1","在车里我不喜欢高亮度灯效，晚上会刺眼。","dislike",recorded_conditions=["车内夜间场景"]),
        e("e8","u2","研究者整理：用户更接受轻松随性的风格。",role="researcher_summary"),
        e("e9","u5","我还没有考虑过颜色。","unknown"),
        e("e10","u3","我喜欢大面积图案。","like"),
        e("e11","u2","你是不是喜欢蓝色？",role="interviewer_question"),
        e("e12","u4","我更看重耐用。","like"),
        e("e13","u1","我还是倾向圆润轮廓。","like"),
    ]
    bundle={"brief":{"brief_id":"synthetic-preference-demo","target_tags":{"segment":["young_professional"]},
                    "tag_aliases":{"segment":{"初职场":"young_professional"}},
                    "research_project_ids":["synthetic-project"],
                    "purpose":"接口与证据边界演示，非真实用户研究"},
            "users":users,"evidence":evidence,"images":[image],
            "provenance":{"mode":"synthetic","description":"All people, statements and DNA are invented test fixtures."}}
    byid={r["evidence_id"]:r for r in evidence}
    def finding(pid,eid,level,topic,summary,att,features=None,conditions=None,images=None,**extra):
        r=byid[eid]
        return {"preference_id":pid,"level":level,"topic_key":topic,"title":summary,"summary":summary,
                "attitude":att,"user_ids":[r["user_id"]],"evidence_refs":[eid],
                "quotes":[{"evidence_id":eid,"text":r["text"]}] if r["text"] else [],
                "features":features or [],"image_ids":images or [],"conditions":conditions or [],**extra}
    def feature(field,value,eid,**extra):
        return {"parameter_id":field,"value":value,"attribution":"explicit_text","evidence_refs":[eid],**extra}
    findings=[
        finding("p1","e1","element","round-contour","圆润轮廓带来的柔和感","like",[feature("GEO-001","圆弧","e1")]),
        finding("p2","e2","element","pattern-coverage","排斥满版图案造成的信息负担","dislike",[feature("fixture.pattern_coverage","all_over","e2")]),
        finding("p3","e3","element","light-intensity","办公室场景下只接受低亮度灯效","conditional",
                [feature("fixture.light_level","low","e3")],["办公室场景"]),
        finding("p4","e4","theme","restrained-identity","希望体现个性，同时保持克制","like"),
        finding("p5","e5","image","whole-image-selection","喜欢这张图，具体原因未知","like",images=["research-r1"],record_refs=["e5"]),
        finding("p6","e6","element","round-contour","圆润边角偏好","like",
                [feature("GEO-001","圆弧","e6",attribution="pointed_image_feature",
                         observation_refs=[{"image_id":"research-r1","observation_id":"o-contour"}])],images=["research-r1"]),
        finding("p7","e7","element","light-intensity","车内夜间排斥高亮度灯效","dislike",
                [feature("fixture.light_level","high","e7")],["车内夜间场景"]),
        finding("p8","e8","theme","relaxed-style","研究者总结中的轻松随性风格倾向","like"),
        finding("p9","e13","element","round-contour","再次表达圆润轮廓偏好","like",[feature("GEO-001","圆弧","e13")]),
    ]
    annotations={"input_digest":prepare_requests(bundle)["input_digest"],"findings":findings,
                 "dispositions":[{"evidence_id":"e9","reason":"unmentioned"}],
                 "provenance":{"mode":"synthetic_annotations","author":"fixture","live_model_call":False}}
    return bundle,annotations

def demo(output):
    root=Path(output)
    bundle,findings=build_fixture()
    prepared=prepare_requests(bundle)
    profile=compile_preferences(bundle,findings,require_input_digest=True)
    group_specs=[
        ("g1","柔和的轮廓语言","轮廓怎样表达柔和感？","两位示例用户表达圆润轮廓偏好；同一用户重复表达只计一人。",["p1","p6","p9"]),
        ("g2","装饰信息的控制","图案覆盖多少范围可接受？","一位示例用户明确排斥满版图案。",["p2"]),
        ("g3","情境约束下的灯效","不同使用情境中如何控制灯效亮度？","办公室只接受低亮度；车内夜间排斥高亮度，两种条件分别保留。",["p3","p7"]),
        ("g4","克制的个性表达","如何表达个性而不过度张扬？","该诉求来自一条明确示例陈述。",["p4"]),
        ("g5","未归因的整图选择","用户喜欢了哪张图？","只记录整图选择，未推导对绿色或圆弧的喜好。",["p5"]),
        ("g6","二手总结中的风格线索","研究者总结提供了什么风格线索？","轻松随性的倾向来自研究者整理，需要回查原始访谈。",["p8"]),
    ]
    groups={"input_digest":profile["input_digest"],"groups":[
        {"group_id":gid,"title":title,"design_question":question,"summary":summary,"preference_ids":ids}
        for gid,title,question,summary,ids in group_specs]}
    result=compile_semantic_groups(profile,groups)
    for name,data in [("bundle.json",bundle),("semantic-findings.json",findings),("requests.json",prepared),
                      ("group-findings.json",groups),("profile.json",result)]:
        write_json(root/name,data)
    lines=["# 用研偏好模块：合成接口示例","",
           "**全部用户、原话和DNA均为合成夹具。本报告不代表真实用户偏好，也未运行外部语义模型。**","",
           f"选中用户 {result['population_count']} 人；有研究记录 {result['users_with_eligible_evidence']} 人；"
           f"已分析 {result['users_analyzed_count']} 人；{len(result['preferences'])} 条偏好记录；"
           f"{len(result['semantic_groups'])} 个语义议题。","",
           "图库未调用高级感判标。三档握手策略由独立握手模块消费本结果。",""]
    for g in result["semantic_groups"]:
        lines += ["## "+g["title"],"",g["summary"],"",
                  "议题："+g["design_question"],
                  "去重用户："+str(g["unique_user_count"]),
                  "证据："+", ".join(g["evidence_refs"]),"",
                  "| 态度 | 用户 | 条件 |","| --- | --- | --- |"]
        for b in g["attitude_breakdown"]:
            conditions=[c for p in b["conditions"] for c in p["conditions"]]
            lines.append("| "+b["attitude"]+" | "+", ".join(b["user_ids"])+" | "+("；".join(conditions) or "原始记录未给额外条件")+" |")
        lines.append("")
    lines += ["## 局限","",
              "- 语义标注和议题归纳由预置示例提供；本次验证程序行为，不验证自动提取准确率。",
              "- 二手总结有独立来源告警，不能冒充受访者逐字原话。",
              "- 字段归因与语义摘要仍需真实材料及独立复核；引用存在并不证明解释必然正确。",
              "- 尚未对真实多语种访谈、录音转写误差和跨研究项目表现做效果验证。",""]
    (root/"report.md").write_text("\n".join(lines),encoding="utf-8")
    return result

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--output",required=True)
    args=p.parse_args()
    result=demo(args.output)
    print({"status":result["status"],"preferences":len(result["preferences"]),"groups":len(result["semantic_groups"])})
