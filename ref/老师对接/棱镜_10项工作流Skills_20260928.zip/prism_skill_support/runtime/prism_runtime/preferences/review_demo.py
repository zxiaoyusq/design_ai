"""PREF-SEM-R1 protocol replay using explicitly synthetic review fixtures."""
from pathlib import Path
import argparse
from prism_runtime.contracts import write_json
from .review import prepare_semantic_review, apply_semantic_reviews
from .tests.test_semantic_review import case, envelope, CONTEXT, REGISTRY

def run(output):
    root=Path(output)
    bundle,wrong_findings,wrong=case(wrong_like=True)
    _,correct_findings,correct=case(wrong_like=False)
    rejection=envelope(wrong,verdict="contradicted")
    negative_confirmation=envelope(correct,review_id="review-negative-control")
    rejected=apply_semantic_reviews(bundle,wrong,rejection,reviewer_registry=REGISTRY)
    control=apply_semantic_reviews(bundle,correct,negative_confirmation,reviewer_registry=REGISTRY)
    data={
        "bundle.json":bundle,
        "wrong-findings.json":wrong_findings,"correct-findings.json":correct_findings,
        "extraction-context.fixture.json":CONTEXT,"reviewer-registry.fixture.json":REGISTRY,
        "wrong-candidate-profile.json":wrong,"negative-control-profile.json":correct,
        "review-request.json":prepare_semantic_review(bundle,wrong,["p2"]),
        "review-reject.fixture.json":rejection,"review-negative-control.fixture.json":negative_confirmation,
        "wrong-after-review.json":rejected,"negative-control-after-review.json":control,
    }
    for name,obj in data.items(): write_json(root/name,obj)
    pick=lambda p:next(x for x in p["preferences"] if x["preference_id"]=="p2")
    cases=[]
    for label,p in [("错误like／未复核",wrong),("错误like／矛盾复核",rejected),
                    ("正确dislike／未复核",correct),("正确dislike／保留否定的复核",control)]:
        item=pick(p)
        cases.append({"case":label,"candidate_attitude":item["attitude"],
                      "review_status":item["semantic_assessment"]["status"],
                      "support_eligibility":item["semantic_assessment"]["support_eligibility"],
                      "confirmed_user_support":item["confirmed_user_support"]})
    checks={
        "wrong_unreviewed_like_is_not_confirmed":not pick(wrong)["confirmed_user_support"],
        "wrong_candidate_preserved_after_contradiction":pick(rejected)["attitude"]=="like",
        "contradicted_like_not_confirmed":not pick(rejected)["confirmed_user_support"],
        "faithful_negative_control_preserved":pick(control)["attitude"]=="dislike",
        "negative_is_never_positive":pick(control)["semantic_assessment"]["support_eligibility"]=="reviewed_negative",
    }
    summary={"dispatch":"PREF-SEM-R1","algorithm_version":"0.3.0","checks":checks,
             "all_passed":all(checks.values()),"cases":cases,
             "dataset":"original owner synthetic failure fixture","review_execution":"synthetic protocol fixture, not independent human/model review",
             "new_paid_calls":0}
    write_json(root/"replay.json",summary)
    lines=["# PREF-SEM-R1：候选解释与已核验支持分离","",
        "原话：我不喜欢满版图案，信息太杂。","",
        "**本例沿用作者原先披露的合成反例。审阅者登记和审阅结果也是协议测试夹具，不冒充实际独立人工／模型审阅。**","",
        "| 情况 | 保留的候选态度 | 语义状态 | 下游资格 | 已确认正向支持 |",
        "| --- | --- | --- | --- | --- |"]
    for c in cases:
        lines.append("| "+" | ".join(str(c[k]) for k in ("case","candidate_attitude","review_status","support_eligibility","confirmed_user_support"))+" |")
    lines += ["","错误候选不会被关键词规则重写。独立审阅接口可以把它标为contradicted，并保存dislike纠正建议；原候选、原文、资料摘要和审阅记录都保留。",
              "正确dislike对照经协议复核后仍为负向约束，不能升级为正向支持。",
              "",
              "本轮验证了交接保护及复核协议，不证明独立审阅者一定判断正确。真正的宿主内容核对由上层loop执行；身份登记仍是可信调用方配置，不是密码学认证。",
              ""]
    root.mkdir(parents=True,exist_ok=True)
    (root/"report.md").write_text("\n".join(lines),encoding="utf-8")
    return summary

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",required=True)
    args=parser.parse_args()
    print(run(args.output))
