# PREF-SEM-R1 语义复核交接协议

版本：preferences 0.3.1；协议：prism.preference_semantic_review.v0.1。

PREF-SEM-R2更新：profile中的status、confirmed_user_support、review_ids及汇总索引全部是缓存，不能作为权威。接收新review、幂等重放以及下游消费时，须从已验证回执重新计算所有偏好的状态。一个条目的合法review不能“洗白”另一个未审条目的被改状态。

## 默认状态

程序接收一条偏好，不再意味着这条模型解释已经成为用户事实。compile_preferences会生成：

- attitude_origin：态度来自原记录标签，还是模型解释；保留具体记录ID、原标签和来源角色。
- semantic_assessment：候选摘要、复核状态、可供下游使用的资格及审阅记录ID。
- confirmed_user_support：未经独立复核始终为false；模型回复中的同名字段、reviewed=true和自填审核元数据会隔离到untrusted_review_claims。

即使原记录有Like/Dislike标签，摘要、特征归因和条件解释也仍需核对；原标签独立保留，不能自动提升整条解释。

## 下游字段

| semantic_assessment.status | support_eligibility | H01/H02可如何使用 |
| --- | --- | --- |
| pending_independent_review | candidate_only | 可形成候选／待核验关系，不能称已确认支持 |
| supported + like且无额外条件 | reviewed_positive | 可引用为已核对的正向解释；仍须检查本次人群、设计问题与载体是否适用 |
| supported + conditional或带条件的like | reviewed_conditional | 先判断条件；不能扩展成无条件共识 |
| supported + dislike | reviewed_negative | 保留负向及条件范围，不能翻转成支持 |
| supported + neutral/unknown | reviewed_not_positive | 不是正向偏好依据 |
| contradicted / insufficient / disputed | not_confirmed | 保留问题／冲突／不足，不能进入已确认支持 |

缺少新字段的旧偏好也应按待核验处理。三档握手只控制方向延展，不改变以上资格。CT-001的模式／关系允许范围、candidate_bindings载体限制继续有效；本模块没有放宽或改写它。

语义议题可能汇总多个原子偏好，但原子复核不等于新写的群组摘要已经获审。群组保留各类已核对记录ID，同时summary_review_status保持未复核。

## 独立身份来自调用方

提取时调用：

    compile_preferences(bundle, findings, require_input_digest=True, extraction_context=context)

context由可信调用方提供producer_id、independence_group、run_id，不能从模型回复的provenance照抄。旧接口没有context仍能产候选，但不能进入独立复核接收。

审阅登记表由上层协调任务或其他可信执行方管理，包括registry_id、registry_version、issued_by、reviewers。每个reviewer包含reviewer_id、actor_type（human/host/model/synthetic_fixture）、independence_group、allowed_dataset_modes。

审阅者ID和independence_group都必须与提取者不同。synthetic_fixture不能用于核验real_evidence。

**信任边界：** 本模块核对独立身份登记、源版本和候选绑定，不实现登录、数字签名或实际人员身份认证。登记表真实性由调用方负责。不能把提取模型自产的“另一审阅者”字符串和登记表当成真实独立复核。

## 审阅接口

    prepare_semantic_review(bundle, profile, preference_ids=None)
    apply_semantic_reviews(bundle, profile, envelope, reviewer_registry=registry)
    validate_reviewed_profile(bundle, profile, reviewer_registry=registry)

prepare输出原文、语境、候选及相关DNA。独立宿主／模型实际读取后，接收envelope：

    {
      "schema_version": "prism.preference_semantic_review.v0.1",
      "review_id": "unique-id",
      "reviewer_id": "registered-id",
      "input_digest": "source-snapshot",
      "reviewed_at": "ISO date-time with timezone",
      "review_artifact_ref": "actual review record location",
      "items": [{
        "preference_id": "candidate-id",
        "candidate_digest": "exact candidate snapshot",
        "verdict": "supported | contradicted | insufficient",
        "reason": "grounded explanation",
        "quotes": [{"evidence_id": "id", "text": "verbatim quote"}],
        "record_refs": [],
        "checked_aspects": ["attitude","attribution","conditions","summary","user_scope"]
      }]
    }

有文字的每份来源都需原话引用，无文字选择记录需record_refs。input_digest及candidate_digest必须同时一致；摘要、条件、态度或源资料被修改后，旧审阅不能复用。

contradicted可以携带corrected_attitude建议，但不会静默覆盖原候选。不同审阅意见有分歧时标disputed；相同review_id重复接收幂等，同ID内容变化被拒绝。

## 保存后再次使用

H01/H02读取profile文件后，不应直接信任其中的supported或true。调用validate_reviewed_profile，使用其返回的副本。该入口：

1. 核对原始资料快照、提取身份和所有候选摘要。
2. 核对每份回执与原始review envelope的内容摘要、来源、候选、审阅者独立性、引文和检查范围。
3. 按回执实际覆盖的preference_id重新推导状态；无回执的条目回到pending_independent_review，伪造的review_ids也不会赋予资格。
4. 重建原子记录、分组资格和汇总索引；review_state_integrity记录哪些缓存值被改正，传入对象保持原样。

目前历史回执要求其确切的可信登记表快照。登记版本变更时明确拒绝，需由调用方处理迁移或重新接收，不能自行猜测兼容关系。v0.3原始envelope可完整重建的旧回执继续可校验；新回执直接保留完整envelope。

refresh_profile_review_state只用于没有回执的初始候选，始终清为待核验。带回执profile不能用这个低级函数直接提升状态；必须走上述含来源和登记验证的入口。

对已复核profile再次做compile_semantic_groups时，需要显式传bundle和reviewer_registry，否则拒绝；不会从传入缓存猜审核身份。无旧回执的语义归纳接口保持原样。

未知来源、旧资料没有提取身份、缺登记表或无法验证回执时，下游可保留候选／待核验，但不能借旧字段当已确认支持。

## CLI

    python -m prism_runtime.preferences accept --bundle INPUT.json --findings FINDINGS.json --extraction-context EXTRACTION.json --output PROFILE.json
    python -m prism_runtime.preferences prepare-review --bundle INPUT.json --profile PROFILE.json --output REVIEW_REQUEST.json
    python -m prism_runtime.preferences accept-review --bundle INPUT.json --profile PROFILE.json --findings REVIEW.json --reviewer-registry REGISTRY.json --output REVIEWED_PROFILE.json
    python -m prism_runtime.preferences validate-review-state --bundle INPUT.json --profile SAVED_PROFILE.json --reviewer-registry REGISTRY.json --output VALIDATED_PROFILE.json

## 验收与未解决部分

复现：python -m prism_runtime.preferences.review_demo --output OUTPUT_DIR。

这套演示含错误like、原意保持dislike的对照、假审核元数据、旧源版本、候选变更、同一审阅主体、部分核对、条件偏好和相互矛盾的复核记录。

示例均为明确标记的合成协议测试，不是真实用户或独立模型效果证明。仍需上层loop真实执行独立宿主内容核对，并联调握手模块确实遵守字段。审阅者仍可能判断错误，当前没有语义准确率或业务效果结论。
