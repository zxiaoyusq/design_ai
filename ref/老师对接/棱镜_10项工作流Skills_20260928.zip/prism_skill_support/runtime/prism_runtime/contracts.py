"""Shared, provider-independent validation and IO. Coordinator-owned."""
from __future__ import annotations
import json
from pathlib import Path

class ContractError(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise ContractError(message)

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def index_by(rows, key):
    result = {}
    for row in rows:
        require(isinstance(row, dict) and isinstance(row.get(key), str) and row[key], f"missing {key}")
        require(row[key] not in result, f"duplicate {key}: {row[key]}")
        result[row[key]] = row
    return result

def value_key(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def known_feature(image, parameter_id, allowed):
    allowed_keys = {value_key(v) for v in allowed}
    return [
        o for o in image.get("observations", [])
        if o.get("parameter_id") == parameter_id
        and o.get("value_status") == "known"
        and value_key(o.get("value")) in allowed_keys
        and o.get("object_id") not in {None, "", "unknown"}
        and o.get("region_ref") is not None
    ]

def bundle_indexes(bundle):
    require(bundle.get("provenance", {}).get("mode") in {"synthetic", "real_evidence"}, "explicit dataset provenance required")
    return (
        index_by(bundle.get("users", []), "user_id"),
        index_by(bundle.get("evidence", []), "evidence_id"),
        index_by(bundle.get("images", []), "image_id"),
    )
