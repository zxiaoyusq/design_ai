# matrix_state_bridge_v1 · CLOSURE-H01-002

新消费身份 `handshake-matrix-state-bridge-v1.0.0`。不改 compact_context_v1、任何原请求/回复或旧验收记录。
只从已有四组引用集合派生矩阵显示标签：disputed > pending > 正反并存 mixed > positive > opposing > no_evidence。
返回原 model_state 与逐格差异审计；原分组、顺序、reason、trend_refs、match_ids、proposals 完整保持。

每次接收仍走冻结 compact v1 的全部来源/审阅/哈希/slot/引用角色资格/原 H01 闸口。
同一 claim 多角色、错误态度/场景、元素冒充主题正向、未知 ID、遗漏负向或 slot、无正向却声称 positive 等仍拒绝。
若原 pending 没有对应 pending 引用，不能机械消除其未归因的不确定性，拒绝而不是升级成正向/反向/无证据。
显示状态不是新的语义判断，不表示旧 v1 通过或实际关系正确。

```python
from prism_runtime.handshake.matrix_state_bridge_v1 import accept_response_file, inspect_response_file

result = accept_response_file(bundle, profile, request, side_table, actual_response_path,
    review_context=review_context, execution_scope_context=execution_scope,
    design_intent_context=design_intent, admission_context=admission_context, mode="consensus")
```

accept 遇到任何剩余语义/协议冲突直接抛错。
inspect_response_file 用于明确区分“角色校验通过”和“完整 H01 被拒绝”；其 diagnostic 不能作为主题选择结果。
它保留 accepted=false 与原错误，不替换 proposal 的 relation_basis、transfer_scope 等字段。
文件入口严格拒绝重复 JSON 键，绑定并复查原文件 SHA256；交付保留源回复字节副本。

实际 `H01-S01-t2` 有 9 个 opposing+pending 显示格可派生为 pending，全部 60 格角色资格通过。
但随后唯一 proposal 的 `relation_basis=anchored_extension` 与 `transfer_scope=cross_category` 违反原三档规则，
三档均仍拒绝 `extension must remain in declared same-category scope`。
该问题超出无语义变更的显示桥接范围，不改为 exploration、不改成同品类、不删 proposal，也不重跑模型。

测试是明确 synthetic 协议反例；交付模块不发模型/API请求。
