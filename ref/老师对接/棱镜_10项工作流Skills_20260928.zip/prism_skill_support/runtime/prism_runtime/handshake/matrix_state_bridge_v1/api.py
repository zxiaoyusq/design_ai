"""Read-only response adapter: derive display labels, never evidence roles."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from prism_runtime.contracts import require
from ..common import fingerprint
from ..compact_context_v1.api import (accept_theme_response as frozen_accept, prepare_theme_request,
                                     MATRIX_STATES, _matrix)
from ..compact_context_v1.normalize import unpack_record_columns

VERSION = "handshake-matrix-state-bridge-v1.0.0"
GROUPS = ("positive_preference_ids", "opposing_preference_ids", "disputed_preference_ids", "pending_preference_ids")


def read_response(path):
    """Keep exact raw bytes and reject ambiguous duplicate-key JSON."""
    path = Path(path).resolve()
    raw = path.read_bytes()
    def pairs(items):
        value = {}
        for k, v in items:
            require(k not in value, "duplicate JSON key in original response: " + k)
            value[k] = v
        return value
    def constant(value):
        raise ValueError("nonfinite JSON in original response: " + value)
    doc = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=pairs, parse_constant=constant)
    return doc, {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}, raw


def derive_display_states(response):
    """Tentative normalization; usable only after original role/snapshot guards."""
    require(isinstance(response, dict), "response object required")
    adapted, audit = deepcopy(response), []
    require(isinstance(adapted.get("axis_assessments"), list), "axis assessments required")
    for ai, axis in enumerate(adapted["axis_assessments"]):
        require(isinstance(axis.get("theme_assessments"), list), "theme assessment slots required")
        for ci, cell in enumerate(axis["theme_assessments"]):
            raw_state = cell.get("state")
            require(raw_state in MATRIX_STATES, "unknown original model state")
            for name in GROUPS:
                refs = cell.get(name)
                require(isinstance(refs, list) and all(isinstance(r, str) for r in refs)
                        and len(refs) == len(set(refs)), "explicit unique evidence-role arrays required")
            positive, opposing, disputed, pending = [bool(cell[k]) for k in GROUPS]
            # An unfounded original claim is not repaired into a weaker result.
            if raw_state in {"positive", "mixed"}:
                require(positive, "original positive claim has no positive references")
            if raw_state in {"opposing", "mixed"}:
                require(opposing, "original opposition claim has no opposing references")
            if raw_state == "disputed":
                require(disputed, "original disputed claim has no disputed references")
            if raw_state == "no_evidence":
                require(not (positive or opposing or disputed or pending), "no_evidence conflicts with explicit evidence roles")
            derived = ("disputed" if disputed else "pending" if pending else "mixed" if positive and opposing
                       else "positive" if positive else "opposing" if opposing else "no_evidence")
            require(raw_state != "pending" or derived in {"pending", "disputed"},
                    "unattributed model uncertainty cannot be downgraded by the display bridge")
            preserved = {k: deepcopy(v) for k, v in cell.items() if k != "state"}
            cell["state"] = derived
            audit.append({"axis_id": axis.get("axis_id"), "theme_id": cell.get("theme_id"),
                "source_pointer": f"/axis_assessments/{ai}/theme_assessments/{ci}/state",
                "model_state": raw_state, "derived_display_state": derived, "changed": raw_state != derived,
                "evidence_role_counts": {k: len(cell[k]) for k in GROUPS},
                "preserved_cell_except_state_sha256": fingerprint(preserved),
                "rule": "disputed > pending > positive+opposing > positive > opposing > no_evidence",
                "reference_qualification": "not_yet_validated"})
    return adapted, audit


def accept_theme_response(bundle, profile, request, side_table, response, *, review_context,
                          execution_scope_context=None, design_intent_context, admission_context=None, mode="consensus"):
    before = fingerprint(response)
    adapted, audit = derive_display_states(response)
    # This replays exactly the frozen source/registry/request/role/slot checks.
    # Role eligibility is checked for every group, regardless of display state.
    result = frozen_accept(bundle, profile, request, side_table, adapted,
        review_context=review_context, execution_scope_context=execution_scope_context,
        design_intent_context=design_intent_context, admission_context=admission_context, mode=mode)
    restored = deepcopy(adapted)
    for a, orig in zip(restored["axis_assessments"], response["axis_assessments"]):
        for cell, source in zip(a["theme_assessments"], orig["theme_assessments"]):
            cell["state"] = source["state"]
    require(restored == response and fingerprint(response) == before, "adapter changed more than the display state")
    require(adapted.get("proposals") == response.get("proposals"), "proposal JSON values must be unchanged")
    for row in audit:
        row["reference_qualification"] = "frozen_compact_v1_role_and_source_checks_passed"
    result["algorithm_version"] = VERSION
    result["matrix_state_bridge"] = {
        "version": VERSION, "source_response_schema": response.get("schema_version"),
        "original_response_snapshot": before, "derived_validation_view_snapshot": fingerprint(adapted),
        "original_v1_acceptance_claimed": False, "semantic_relation_verified": False,
        "reference_groups_or_reasons_changed": False, "proposals_changed": False,
        "display_state_audit": audit, "changed_cells": sum(r["changed"] for r in audit),
    }
    result["compact_context"]["source_model_response_snapshot"] = before
    result["compact_context"]["derived_response_snapshot"] = result["compact_context"].pop("response_snapshot")
    by_slot = {(a["axis_id"], a["theme_id"]): a for a in audit}
    for axis in result["axis_assessments"]:
        for cell in axis["theme_assessments"]:
            cell["model_state"] = by_slot[(axis["axis_id"], cell["theme_id"])]["model_state"]
    return result


def accept_response_file(bundle, profile, request, side_table, response_path, **options):
    response, identity, raw = read_response(response_path)
    result = accept_theme_response(bundle, profile, request, side_table, response, **options)
    require(Path(identity["path"]).read_bytes() == raw, "original response changed during acceptance")
    result["matrix_state_bridge"]["original_response_file"] = identity
    return result


def inspect_response_file(bundle, profile, request, side_table, response_path, **options):
    """A partial diagnostic is not an accepted H01 result; failures stay failures."""
    response, identity, raw = read_response(response_path)
    adapted, audit = derive_display_states(response)
    prepare_options = {k: v for k, v in options.items() if k != "mode"}
    rebuilt = prepare_theme_request(bundle, profile, request_id=request["request_id"], **prepare_options)
    require(rebuilt["request"] == request and rebuilt["side_table"] == side_table, "diagnostic input is not bound to current sources")
    payload = json.loads(request["messages"][-1]["content"])
    _matrix(adapted, unpack_record_columns(payload["tables"], payload["record_schemas"]),
            prepare_options["design_intent_context"]["approved_broad_style_axes"])
    diagnostic = {"schema_version": "prism.matrix_state_diagnostic.v1", "algorithm_version": VERSION,
                  "original_response_file": identity, "reference_role_checks_passed": True,
                  "display_state_audit": audit, "changed_cells": sum(a["changed"] for a in audit),
                  "original_model_response_snapshot": fingerprint(response), "proposals_snapshot": fingerprint(response.get("proposals")),
                  "original_v1_acceptance_claimed": False, "semantic_relation_verified": False}
    try:
        result = accept_theme_response(bundle, profile, request, side_table, response, **options)
        diagnostic.update(accepted=True, result=result)
    except ValueError as exc:
        diagnostic.update(accepted=False, status="rejected_after_display_state_derivation", error=type(exc).__name__ + ": " + str(exc))
    require(Path(identity["path"]).read_bytes() == raw, "original response changed during diagnostic")
    return diagnostic
