"""Independent synthetic protocol counterexamples; no model calls."""
from copy import deepcopy
import unittest
from prism_runtime.contracts import ContractError
from ..compact_context_v1.tests import CompactTests, response_fixture
from ..compact_context_v1.api import accept_theme_response as old_accept
from .api import accept_theme_response, derive_display_states, VERSION


class BridgeTests(unittest.TestCase):
    def setUp(self):
        helper = CompactTests()
        helper.setUp()
        self.h = helper

    def response(self):
        r = response_fixture(self.h.package)
        cell = r["axis_assessments"][0]["theme_assessments"][0]
        cell.update(state="opposing", opposing_preference_ids=["P3"], pending_preference_ids=["P2"], trend_refs=["T1"])
        return r

    def accept(self, r, **options):
        return accept_theme_response(self.h.b, self.h.p, self.h.package["request"], self.h.package["side_table"], r,
                                     **{**self.h.options, **options})

    def test_old_failure_preserved_new_consumption_labels_uncertainty(self):
        r = self.response()
        before = deepcopy(r)
        with self.assertRaisesRegex(ContractError, "opposing-only"):
            self.h.accept(r)
        result = self.accept(r)
        self.assertEqual(result["algorithm_version"], VERSION)
        self.assertEqual(r, before)
        cell = result["axis_assessments"][0]["theme_assessments"][0]
        self.assertEqual((cell["state"], cell["model_state"]), ("pending", "opposing"))
        self.assertEqual(cell["opposing_preference_ids"], ["P3"])
        self.assertEqual(cell["pending_preference_ids"], ["P2"])
        self.assertFalse(result["matrix_state_bridge"]["original_v1_acceptance_claimed"])

    def test_proposal_and_all_nonstate_fields_are_unchanged(self):
        r = response_fixture(self.h.package, self.h.t["proposals"])
        for axis in r["axis_assessments"]:
            axis["theme_assessments"][0].update(opposing_preference_ids=["P3"])
        adapted, audit = derive_display_states(r)
        self.assertEqual(adapted["proposals"], r["proposals"])
        self.assertTrue(all(x["derived_display_state"] == "mixed" for x in audit))
        self.assertEqual(len(self.accept(r)["theme_candidates"]), 1)

    def test_disputed_takes_priority_without_deleting_pending(self):
        r = self.response()
        c = r["axis_assessments"][0]["theme_assessments"][0]
        c.update(state="disputed", disputed_preference_ids=["not-supported"], opposing_preference_ids=[])
        adapted, _ = derive_display_states(r)
        self.assertEqual(adapted["axis_assessments"][0]["theme_assessments"][0]["state"], "disputed")
        with self.assertRaises(ContractError):
            self.accept(r)  # Missing or ineligible reference must still fail.

    def test_no_positive_evidence_cannot_be_repaired_into_pending(self):
        r = self.response()
        r["axis_assessments"][0]["theme_assessments"][0]["state"] = "positive"
        with self.assertRaisesRegex(ContractError, "no positive"):
            self.accept(r)

    def test_no_evidence_with_any_group_is_rejected(self):
        r = self.response()
        r["axis_assessments"][0]["theme_assessments"][0]["state"] = "no_evidence"
        with self.assertRaises(ContractError):
            self.accept(r)

    def test_role_attitude_scope_and_multiple_roles_remain_guarded(self):
        for case in ("unknown", "wrong_attitude", "same_claim", "element_positive"):
            r = self.response()
            c = r["axis_assessments"][0]["theme_assessments"][0]
            if case == "unknown": c["pending_preference_ids"] = ["unknown-id"]
            elif case == "wrong_attitude": c["opposing_preference_ids"] = ["P1"]
            elif case == "same_claim": c["pending_preference_ids"] = ["P3"]
            else: c.update(state="positive", positive_preference_ids=["P2"], opposing_preference_ids=[])
            with self.subTest(case=case), self.assertRaises(ContractError):
                self.accept(r)

    def test_negative_omission_and_slot_omission_still_fail(self):
        for key in ("negative_audit_ids", "axis_assessments"):
            r = self.response()
            r[key] = []
            with self.subTest(key=key), self.assertRaises(ContractError):
                self.accept(r)

    def test_pending_without_role_attribution_is_not_upgraded(self):
        r = response_fixture(self.h.package, self.h.t["proposals"])
        r["axis_assessments"][0]["theme_assessments"][0]["state"] = "pending"
        with self.assertRaisesRegex(ContractError, "cannot be downgraded"):
            self.accept(r)

    def test_snapshot_and_all_three_mode_negative_guards_survive(self):
        r = self.response()
        audit = [self.accept(r, mode=m)["complete_negative_audit"] for m in ("consensus", "extension", "exploration")]
        self.assertEqual(audit[0], audit[1])
        self.assertEqual(audit[1], audit[2])
        r["compact_snapshot"] = "stale"
        with self.assertRaises(ContractError):
            self.accept(r)

    def test_cross_category_anchored_extension_is_not_repaired(self):
        proposals = deepcopy(self.h.t["proposals"])
        proposals[0].update(relation_basis="anchored_extension", transfer_scope="cross_category", hypotheses=[{"reason": "protocol counterexample"}])
        r = response_fixture(self.h.package, proposals)
        for mode in ("consensus", "extension", "exploration"):
            with self.subTest(mode=mode), self.assertRaisesRegex(ContractError, "same-category"):
                self.accept(r, mode=mode)


if __name__ == "__main__":
    unittest.main()
