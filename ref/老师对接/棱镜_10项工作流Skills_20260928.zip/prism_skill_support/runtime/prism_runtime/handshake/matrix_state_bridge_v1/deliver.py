"""Offline bounded inspection; current actual H01 failure remains a failure."""
import argparse
import hashlib
import io
from pathlib import Path
import unittest
from prism_runtime.contracts import read_json, write_json, require
from .api import inspect_response_file, VERSION, read_response
from .tests import BridgeTests

PROJECT = Path(__file__).resolve().parents[3]
CLOSURE = PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/closure-20260927"
OUTPUT = PROJECT / "outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/CLOSURE-H01-002"


def digest(path):
    return {"path": str(Path(path).resolve()), "sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest()}


def main(output=OUTPUT):
    output = Path(output)
    require(not (output / "self-assessment.json").exists(), "use a new versioned output directory")
    output.mkdir(parents=True, exist_ok=True)
    response_path = CLOSURE / "calls/H01-S01-t2/answer.json"
    request_path = CLOSURE / "h01/scene01/request.json"
    side_path = CLOSURE / "h01/scene01/side-table.json"
    old_failure = CLOSURE / "h01/scene01/acceptance-H01-S01-t2.json"
    paths = [response_path, request_path, side_path, old_failure]
    for folder in ("compact_context_v1", "context_sidecar_v1"):
        paths.extend((PROJECT / "prism_runtime/handshake" / folder).glob("*.*"))
    paths.extend((PROJECT / "prism_runtime/handshake").glob("*.py"))
    before = [digest(p) for p in paths]
    stream = io.StringIO()
    tested = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BridgeTests))
    (output / "unit-tests.txt").write_text(stream.getvalue(), encoding="utf-8")
    request, side = read_json(request_path), read_json(side_path)
    inputs = side["inputs"]
    options = {k: inputs[k] for k in ("review_context", "execution_scope_context", "design_intent_context", "admission_context")}
    rows = []
    for mode in ("consensus", "extension", "exploration"):
        report = inspect_response_file(inputs["bundle"], inputs["saved_profile"], request, side, response_path, mode=mode, **options)
        write_json(output / (mode + "-diagnostic.json"), report)
        rows.append({"mode": mode, "matrix_role_checks_passed": report["reference_role_checks_passed"],
                     "accepted": report["accepted"], "changed_cells": report["changed_cells"], "error": report.get("error")})
    _, _, raw = read_response(response_path)
    (output / "original-response.bytecopy.json").write_bytes(raw)
    after = [digest(p) for p in paths]
    require(before == after, "protected input/source changed")
    write_json(output / "source-manifest.json", {"protected_before": before, "protected_after": after, "all_unchanged": True,
        "new_module_files": [digest(p) for p in sorted(Path(__file__).parent.iterdir()) if p.is_file()]})
    passed = tested.wasSuccessful() and all(r["matrix_role_checks_passed"] and r["changed_cells"] == 9
        and not r["accepted"] and "same-category" in r["error"] for r in rows)
    report = {"issue_id": "CLOSURE-H01-002", "version": VERSION, "status": "owner_display_bridge_protocol_qualified" if passed else "needs_repair",
        "actual_H01_status": "rejected_cross_category_anchored_extension", "original_v1_failure_preserved": True,
        "unit_tests": {"run": tested.testsRun, "failures": len(tested.failures), "errors": len(tested.errors)},
        "actual_modes": rows, "proposals_changed": False, "reference_roles_changed": False, "new_model_calls": 0,
        "independent_holdout": False, "root_independent_retest_required": True, "protected_file_count": len(before)}
    write_json(output / "self-assessment.json", report)
    print(report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(OUTPUT))
    args = parser.parse_args()
    report = main(args.output)
    raise SystemExit(0 if report["status"] == "owner_display_bridge_protocol_qualified" else 1)
