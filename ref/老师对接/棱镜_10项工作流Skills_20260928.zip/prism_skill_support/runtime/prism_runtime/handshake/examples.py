"""Small synthetic, non-calibration examples; no model or network calls."""
from copy import deepcopy
from pathlib import Path
import argparse
from prism_runtime.contracts import write_json
from prism_runtime.preferences.api import compile_preferences
from .api import (POLICIES, prepare_theme_request, compile_theme_handshake,
                  select_themes, prepare_request, compile_directions)
from .common import snapshot, fingerprint
from .negative_scopes import RESOLUTION_SCHEMA
from .admission import prepare_fixture_admission


def reviewed_fixture_context(bundle, profile, preference_ids=None, *, real_protocol_simulation=False):
    """Protocol fixture only: never evidence of an actual independent review."""
    mode = bundle["provenance"]["mode"]
    if mode != "synthetic" and not real_protocol_simulation:
        raise ValueError("fixture reviewer is synthetic-only")
    extraction = {"producer_id": "handshake-fixture-extractor", "independence_group": "fixture-producer", "run_id": "fixture-run"}
    candidate = compile_preferences(bundle, {"findings": profile["preferences"]}, extraction_context=extraction)
    candidate = compile_preferences(bundle, {"findings": profile["preferences"], "input_digest": candidate["input_digest"]},
                                    require_input_digest=True, extraction_context=extraction)
    sources = {r["evidence_id"]: r for r in bundle["evidence"]}
    ids = preference_ids if preference_ids is not None else [p["preference_id"] for p in candidate["preferences"]
            if all(sources[r].get("recorded_attitude") is not None for r in p["evidence_refs"])]
    registry = {"registry_id": "handshake-fixture-registry", "registry_version": "1", "issued_by": "synthetic-test-author",
                "reviewers": [{"reviewer_id": "handshake-fixture-reviewer", "actor_type": "host" if real_protocol_simulation else "synthetic_fixture",
                               "independence_group": "fixture-reviewer", "allowed_dataset_modes": [mode]}]}
    items = [{"preference_id": p["preference_id"], "candidate_digest": p["semantic_assessment"]["candidate_digest"],
              "verdict": "supported", "reason": "Synthetic protocol fixture verdict, not real independent research.",
              "quotes": deepcopy(p["quotes"]), "record_refs": p.get("record_refs", []),
              "checked_aspects": ["attitude", "attribution", "conditions", "summary", "user_scope"]}
             for p in candidate["preferences"] if p["preference_id"] in ids]
    envelope = {"schema_version": "prism.preference_semantic_review.v0.1", "review_id": "fixture-review-1",
                "reviewer_id": "handshake-fixture-reviewer", "input_digest": candidate["input_digest"],
                "reviewed_at": "2026-09-26T00:00:00+00:00", "review_artifact_ref": "synthetic:handshake-fixture-review", "items": items}
    if items:
        from prism_runtime.preferences import apply_semantic_reviews
        candidate = apply_semantic_reviews(bundle, candidate, envelope, reviewer_registry=registry)
    context = {"reviewer_registry": registry, "fixture_only": True}
    return candidate, context


def negative_scope_fixture(bundle, profile, selection, proposals):
    """Explicit synthetic scope decisions, separate from model proposals."""
    resolutions = []
    expected_carriers = {"D1": ["I1", "I2"], "D2": ["I2"], "D3": ["I1", "I2", "I3"]}
    for direction in proposals["proposals"]:
        pairs = direction.get("candidate_bindings", [{"image_id": iid, "object_id": "shell"} for iid in expected_carriers.get(direction["direction_id"], direction["candidate_image_ids"])])
        pairs = [{"image_id": p["image_id"], "object_id": p["object_id"]} for p in pairs]
        for pref in profile["preferences"]:
            if pref["attitude"] != "dislike":
                continue
            for i, feature in enumerate(pref["features"]):
                resolutions.append({"resolution_id": direction["direction_id"] + "-" + pref["preference_id"] + "-" + str(i),
                    "direction_ids": [direction["direction_id"]], "preference_id": pref["preference_id"],
                    "parameter_id": feature["parameter_id"], "forbidden_values": [feature["value"]],
                    "evidence_refs": pref["evidence_refs"], "quotes": pref["quotes"],
                    "confirmation": {"status": "confirmed", "confirmed_by": "synthetic_scope_fixture_author", "source_ref": "synthetic:explicit-scope-decision"},
                    "scope": {"kind": "candidate_bindings", "status": "resolved", "bindings": pairs, "evidence_refs": pref["evidence_refs"]}})
        hard = bundle["brief"].get("hard_constraints", {})
        if isinstance(hard, dict):
            for i, feature in enumerate(hard.get("forbidden_features", [])):
                resolutions.append({"resolution_id": direction["direction_id"] + "-brief-" + str(i),
                    "direction_ids": [direction["direction_id"]], "preference_id": "brief:" + bundle["brief"]["brief_id"] + ":negative:" + str(i),
                    "parameter_id": feature["parameter_id"], "forbidden_values": feature["forbidden_values"],
                    "evidence_refs": feature["evidence_refs"], "quotes": [],
                    "confirmation": {"status": "confirmed", "confirmed_by": "synthetic_scope_fixture_author", "source_ref": "synthetic:brief-constraint"},
                    "scope": {"kind": "image", "status": "resolved", "image_ids": direction["candidate_image_ids"], "evidence_refs": feature["evidence_refs"]}})
    return {"schema_version": RESOLUTION_SCHEMA, "input_snapshot": snapshot(bundle, profile),
            "selection_snapshot": fingerprint(selection), "resolutions": resolutions}


def fixture():
    provenance = {"mode": "synthetic", "note": "Invented input for interface tests, not actual consumer evidence."}
    bundle = {"brief": {"brief_id": "SYNTHETIC-B01", "target_tags": {"region": ["test-region"]},
                        "context": {"product_category": "phone", "scene": "office"}},
              "users": [{"user_id": "U1", "tags": {"region": "test-region"}}],
              "evidence": [
                  {"evidence_id": "T1", "source_kind": "trend", "text": "合成案例：圆弧轮廓、哑光表面，以及半透明外壳共同探索克制的设备表达。", "image_ids": ["I1", "I2", "I3"]},
                  {"evidence_id": "R1", "source_kind": "research", "user_id": "U1", "text": "办公手机我希望它看起来安静克制。", "recorded_attitude": "like"},
                  {"evidence_id": "R2", "source_kind": "research", "user_id": "U1", "text": "手机后壳我喜欢哑光表面。", "recorded_attitude": "like"},
                  {"evidence_id": "R3", "source_kind": "research", "user_id": "U1", "text": "在办公室使用手机时，我不接受镜面表面。", "recorded_attitude": "dislike"}],
              "themes": [{"theme_id": "TH1", "title": "克制的设备外观", "summary": "合成趋势主题。",
                          "evidence_refs": ["T1"], "image_ids": ["I1", "I2", "I3"],
                          "reference_image_ids": ["I1", "I2", "I3"], "evidence_only_image_ids": [],
                          "source_group_ids": ["synthetic-source-1"]}],
              "images": [], "provenance": provenance}
    for iid, gloss, transparency in [("I1", "哑光", "不透明"), ("I2", "哑光", "半透明"), ("I3", "半光", "不透明")]:
        observations = []
        for field, value in [("GEO-001", "圆弧"), ("OPT-002", gloss), ("OPT-007", transparency)]:
            observations.append({"observation_id": iid + "-" + field, "parameter_id": field, "object_id": "shell",
                                 "value": value, "value_status": "known", "region_ref": {"object_id": "shell", "bbox_xyxy": [0.1, 0.1, 0.9, 0.9]},
                                 "evidence_refs": ["synthetic:" + iid + ":" + field]})
        bundle["images"].append({"schema_version": "prism.image_dna.v0.1", "image_id": iid, "source_kind": "synthetic",
                                 "image_path": None, "source_ref": "synthetic:" + iid, "observations": observations,
                                 "provenance": provenance})
    findings = []
    for pid, ref, level, attitude, features in [
        ("P1", "R1", "theme", "like", []),
        ("P2", "R2", "element", "like", [{"parameter_id": "OPT-002", "value": "哑光"}]),
        ("P3", "R3", "element", "dislike", [{"parameter_id": "OPT-002", "value": "镜面外观"}])]:
        text = next(e["text"] for e in bundle["evidence"] if e["evidence_id"] == ref)
        findings.append({"preference_id": pid, "level": level, "topic_key": "restrained_device",
                         "summary": text, "attitude": attitude, "user_ids": ["U1"], "evidence_refs": [ref],
                         "quotes": [{"evidence_id": ref, "text": text}], "features": features, "image_ids": [],
                         "conditions": ["在办公室使用手机时"] if attitude == "dislike" else []})
        for feature in features:
            feature.update({"attribution": "explicit_text", "evidence_refs": [ref]})
        if attitude == "dislike":
            findings[-1]["condition_bindings"] = [{"source_condition": "在办公室使用手机时", "evidence_refs": [ref],
                                                   "predicates": [{"field": "scene", "operator": "eq", "value": "office"}],
                                                   "review_status": "reviewed", "reviewer": "synthetic_fixture_author"}]
    for row in bundle["evidence"]:
        if row["source_kind"] == "research":
            row["evidence_role"] = "user_statement"
    profile = compile_preferences(bundle, {"findings": findings, "provenance": provenance})
    theme_doc = {"proposals": [{"match_id": "M1", "theme_id": "TH1", "title": "办公设备的克制表达",
                                "preference_ids": ["P1"], "trend_refs": ["T1"], "relation_basis": "direct_support",
                                "shared_principle": "克制的设备外观", "hypotheses": [], "transfer_scope": "same_category"}]}
    base = {"theme_id": "TH1", "trend_refs": ["T1"], "candidate_image_ids": ["I1", "I2", "I3"],
            "shared_principle": "让办公手机呈现克制外观", "comparison_features": ["OPT-007"], "transfer_scope": "same_category"}
    directions = [
        {**base, "direction_id": "D1", "title": "哑光后壳", "design_axis": "CMF", "preference_ids": ["P2"],
         "relation_basis": "direct_support", "required_features": [{"parameter_id": "OPT-002", "allowed_values": ["哑光"]}], "hypotheses": []},
        {**base, "direction_id": "D2", "title": "保留哑光，尝试半透明外壳", "design_axis": "CMF", "preference_ids": ["P2"],
         "relation_basis": "anchored_extension", "required_features": [{"parameter_id": "OPT-002", "allowed_values": ["哑光"]}, {"parameter_id": "OPT-007", "allowed_values": ["半透明"]}],
         "hypotheses": [{"parameter_id": "OPT-007", "value": "半透明", "reason": "同品类保留哑光锚点；半透明接受度尚未验证。"}]},
        {**base, "direction_id": "D3", "title": "以圆弧轮廓探索克制感", "design_axis": "ID", "preference_ids": ["P1"],
         "relation_basis": "exploratory_hypothesis", "required_features": [{"parameter_id": "GEO-001", "allowed_values": ["圆弧"]}],
         "hypotheses": [{"parameter_id": "GEO-001", "value": "圆弧", "reason": "从克制诉求推到圆弧表达，是设计假设，未获元素级认可。"}]}]
    return deepcopy(bundle), deepcopy(profile), deepcopy(theme_doc), {"proposals": deepcopy(directions)}


def export(destination):
    out = Path(destination)
    bundle, profile, themes, directions = fixture()
    profile, review_context = reviewed_fixture_context(bundle, profile)
    themes["input_snapshot"] = snapshot(bundle, profile)
    themes["review_context_snapshot"] = fingerprint(review_context)
    result = compile_theme_handshake(bundle, profile, themes, review_context=review_context)
    admission_context = prepare_fixture_admission(bundle)
    selection = select_themes(bundle, profile, result, ["TH1"], selection_id="SYNTHETIC-S1", synthetic_assumption=True,
                              review_context=review_context, admission_context=admission_context)
    directions["input_snapshot"] = snapshot(bundle, profile)
    directions["selection_snapshot"] = fingerprint(selection)
    directions["review_context_snapshot"] = fingerprint(review_context)
    negative_scopes = negative_scope_fixture(bundle, profile, selection, directions)
    files = {"bundle.json": bundle, "profile.json": profile, "h01-proposals.json": themes,
             "review-context.fixture.json": review_context,
             "negative-scopes.fixture.json": negative_scopes,
             "reference-admission.fixture.json": admission_context,
             "h01-request.json": prepare_theme_request(bundle, profile, review_context=review_context), "h01-result.json": result,
             "theme-selection.json": selection, "h02-request.json": prepare_request(bundle, profile, selection, review_context=review_context),
             "h02-proposals.json": directions}
    summary = {"provenance": bundle["provenance"], "new_paid_calls": 0, "modes": {}}
    for mode in POLICIES:
        value = compile_directions(bundle, profile, directions, mode, selection, review_context=review_context, negative_scope_resolutions=negative_scopes)
        files["h02-" + mode + ".json"] = value
        summary["modes"][mode] = {"label": POLICIES[mode]["label"],
                                  "direction_ids": [r["direction_id"] for r in value["grouping_requests"]],
                                  "negative_constraint_count": [len(r["forbidden_features"]) for r in value["grouping_requests"]],
                                  "pending_count": len(value["pending_directions"])}
    files["summary.json"] = summary
    for name, value in files.items():
        write_json(out / name, value)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(export(args.output))
