"""Keep source-recorded attitudes distinct from unreviewed interpretations.

No keyword sentiment classifier and no self-declared review flag can release a
candidate. A separate review request is exported for the independent loop.
"""
def attitude_lineage(preference, evidence):
    refs = preference["evidence_refs"]
    recorded = [r for r in refs if evidence[r].get("recorded_attitude") is not None]
    unrecorded = [r for r in refs if r not in recorded]
    assessment = preference.get("semantic_assessment", {})
    replayed = preference.get("_handshake_review_replayed") is True
    reviewed = replayed and assessment.get("status") == "supported"
    return {"preference_id": preference["preference_id"], "proposed_attitude": preference["attitude"],
            "origin": "source_recorded" if not unrecorded else "model_or_host_interpreted" if not recorded else "partially_source_recorded",
            "recorded_source_ids": recorded, "unrecorded_source_ids": unrecorded,
            "source_annotations": [{"evidence_id": r, "recorded_attitude": evidence[r].get("recorded_attitude")} for r in refs],
            "independent_semantic_review": assessment.get("status", "pending_independent_review") if replayed else "pending_independent_review",
            "support_eligibility": assessment.get("support_eligibility", "candidate_only") if replayed else "candidate_only",
            "review_ids": assessment.get("review_ids", []) if replayed else [],
            "trusted_review_context_replayed": replayed,
            "review_validation_authority": "preferences.validate_reviewed_profile" if replayed else None,
            "interpretation_requires_review": not reviewed,
            "self_declared_review_flags_are_not_authorization": True}


def prepare_support_review(bundle, profile, preference_ids=None):
    from prism_runtime.preferences import prepare_semantic_review
    return prepare_semantic_review(bundle, profile, preference_ids)
