# 棱镜：两次独立握手

版本 `handshake-0.3.2`。本模块拥有 `prism_runtime/handshake/`；交付在 `outputs/prism-algorithm-loop-20260926/modules/handshake/`。本版保留 preferences v0.3.1 受信消费与 CT-002，并修复 FULLCHAIN-POOL-001 参考池资格。使用 Python 标准库，无网络调用或模型适配器的隐藏调用。

H01 输出主题机会与案例池。H02 消费明确主题选择、偏好和 DNA，输出设计命题及 `GroupingRequest`。两者不依赖条件聚类先完成；聚类后由编排器核对结果是否兑现请求。裁剪、排板、生图在后续流程。

## 入口

从工程根目录运行：

```powershell
$env:PYTHONUTF8 = '1'
py -3.13 -m prism_runtime.handshake.verify --output outputs/prism-algorithm-loop-20260926/modules/handshake
```

此命令导出完整合成输入/输出、运行作者测试和 7 次 CLI/函数输出对照，并调用可用的下游聚类入口做只读兼容检查。`verification.json` 分开报告模块接口、下游交接和真实效果。退出码 0 只表示模块测试和 CLI 对照通过，不代表下游或真实效果通过。

```python
from prism_runtime.handshake import (
    prepare_theme_request, compile_theme_handshake, select_themes,
    prepare_request, compile_directions,
    prepare_reference_admission,
)

review_context = {"reviewer_registry": trusted_caller_registry}
h01_request = prepare_theme_request(bundle, profile, review_context=review_context)
# 模型或宿主自行执行 messages，返回语义 proposals；本模块不调用模型。
h01 = compile_theme_handshake(bundle, profile, theme_proposals, mode="consensus", review_context=review_context)
admission_context = prepare_reference_admission(bundle, trends_result_path, material_manifest_path)
selection = select_themes(
    bundle, profile, h01, ["theme-id"], selection_id="selection-id",
    designer_confirmed=True, confirmed_by="实际确认者标识", review_context=review_context,
    admission_context=admission_context,
)
h02_request = prepare_request(bundle, profile, selection, review_context=review_context)
h02 = compile_directions(
    bundle, profile, direction_proposals, mode="extension", selection=selection,
    review_context=review_context, negative_scope_resolutions=caller_confirmed_scopes,
)
```

真实数据只在设计师实际完成选择后记录 `designer_confirmed=True`。该函数保存调用方传入的确认，并不提供身份认证或审批界面。合成演示使用 `synthetic_assumption=True`，同时 `designer_confirmed=False`，不能迁移为真实确认。

CLI 子命令：`prepare-theme`、`accept-theme`、`select`、`prepare`、`accept`、`prepare-review`。共同参数为 `--bundle --profile --output`；accept 类命令另需 `--proposals`；H02 另需 `--selection`；`--review-context` 是独立的可信调用方登记表上下文；H02 的 `--negative-scopes` 是独立的范围确认文件。select 另需 `--theme-result --theme-id --selection-id`，真实确认用 `--confirmed-by`，合成用 `--synthetic-assumption`。完整可读命令和产物可从 `verify.py` 复现。

选择图片还需 `--admission-context`。先用 `prepare-admission --bundle BUNDLE --trends-result T01 --material-manifest MANIFEST --output CONTEXT` 生成；该动作无需 profile。只读核对已有文件，不重跑判标。详细契约及 C07 复现见 [REFERENCE_ADMISSION.md](D:/Codex/传音AI创客营/prism_runtime/handshake/REFERENCE_ADMISSION.md)。旧选择缺资格快照时必须重新选择，不能把冻结旧结果默认为新版本已验收。

## 输入及输出

上游 `PreferenceProfile` 仍为 `prism.preference_profile.v0.1`。保留用户原话、`source_roles`、`source_contexts`、`feature_validation`、条件和原子用户关系；重新调用用研模块的证据校验，不重新抽取偏好。已存在的 `input_digest` 必须仍与当前资料匹配。

| 阶段 | 语义回复最小字段 | 输出 |
|---|---|---|
| H01 | `input_snapshot`、`proposals[]`；每项 `match_id/theme_id/preference_ids/trend_refs/relation_basis/shared_principle` | `prism.theme_handshake.v0.2`：候选主题、反对及范围、待处理、缺口、案例池、人工选择状态 |
| 选择 | H01 结果、主题 ID、选择 ID、用户/图片可选子集、真实确认或合成假设 | `prism.theme_selection.v0.2`；冻结主题证据和 DNA 快照 |
| H02 | `input_snapshot/selection_snapshot`、`proposals[]`；另含 `direction_id/title/design_axis/candidate_image_ids/required_features` | `prism.design_handshake.v0.2`；设计命题、可执行聚类请求、pending/排除/视觉缺口 |

真实语义回复必须回传 prepare 提供的 input_snapshot、review_context_snapshot，以及 H02 的 selection_snapshot。合成回复可省略快照用于单项反例，但完整示例也保留快照。H01 不绑定 DNA；可在 H01 后补齐 DNA，再选择冻结。H02 绑定完整选择及其 DNA，防止旧条件应用于新图片结果。

H02 的 `required_features` 每项包含 `parameter_id/allowed_values`，采用现有字典的原始类型和值。尚无元素偏好支持的每个值须对应 `hypotheses[{parameter_id,value,reason}]`；不能只写一段泛泛的创新说明。

所有输出保持 `semantic_status=source_linked_not_independently_verified`。程序检查引用和结构、已记录的态度、条件及已给定视觉观察；没有独立语义审核或真实消费者结果。上游错误 Like 若没有独立态度标注，本模块不能仅凭引用识别它。

### PREF-SEM-R1：未经核对的态度不升级为支持

`attitude_lineage` 逐条区分原记录提供态度、模型/宿主解释及两者混合。0.3.1 只通过上游 `validate_reviewed_profile(bundle, profile, reviewer_registry=...)` 重验保存的 profile，再使用它返回的副本。握手不建立第二套审核账本，不直接读取 supported/confirmed/review_ids 缓存作为权威。即使源记录有 Like 标签，尚未复核的完整解释仍是候选；未核验负向也保持待核验条件。

`candidate_support_user_ids`、`source_recorded_support_user_ids` 与 `independently_verified_support_user_ids` 分开。最后一项只统计受信验证后的 reviewed_positive 原子记录；带条件的 Like 仍是 reviewed_conditional，继续检查当前场景。原子通过不等于新设计命题已验证，因此方向/请求仍保持 `independently_verified_user_support=false`，另用 `atomic_preference_review_passed` 描述原子资格。模型自填审核字段不能解除门控。

原话“我不喜欢满版图案，信息太杂。”的错误 Like 反例，以及正确保留 Dislike 的对照均可复跑：

```powershell
py -3.13 -m prism_runtime.handshake.semantic_cases --output outputs/prism-algorithm-loop-20260926/modules/handshake/semantic-regression
```

这证明错误解释没有被升级为可执行支持，不代表算法自动理解了否定。引文来自独立 loop 已复现的反例；用户身份、场景和图片观察仍为合成夹具。

`prepare_support_review(bundle, profile, preference_ids=None)` 或 CLI `prepare-review` 直接转交上游 `prepare_semantic_review`。复核接收由用研模块负责，握手仅消费其唯一受信验证入口。登记表须由可信调用方独立提供，不能来自模型的 profile；登记版本变化、源/候选变化、缺回执和审阅分歧均不能提升为支持。该协议不提供密码学身份认证，也不证明审阅判断一定正确。

## 三档策略

| 档位 | 允许关系 | 当前工程边界 |
|---|---|---|
| 共识优先 `consensus` | `direct_support` | H01 有主题诉求支持；H02 核心元素有直接态度支持 |
| 适度延展 `extension` | 上述 + `anchored_extension` | H02 保留至少一个不变的元素支持锚点；显式 `transfer_scope=same_category`；新值逐项标为假设 |
| 创新探索 `exploration` | 上述 + `exploratory_hypothesis` | 可从有来源的主题诉求提出新视觉表达；保留全部假设、排斥和缺失状态 |

不使用草稿中的 0/1/3 个新字段作为已获验证的延展尺度。共识方向在更开放的档位仍可保留，其关系类型不升级为假设。各档位都不能制造未知 DNA、解除排斥或突破主题选择。

## 条件与人群

用研条件原文保存在 `conditions: list[str]`。可在偏好记录中增加以下经复核的映射；未映射、未复核或缺当前场景值均为 pending：

```json
{
  "condition_bindings": [{
    "source_condition": "在办公室使用手机时",
    "evidence_refs": ["R3"],
    "predicates": [{"field": "scene", "operator": "eq", "value": "office"}],
    "review_status": "reviewed",
    "reviewer": "实际完成语义核对者"
  }]
}
```

原文必须出现在对应引用中；映射不是新的原始事实。真实数据的条件映射还需可信调用方在 `review_context.approved_condition_binding_hashes` 中按 preference_id 声明实际核对过的完整 mapping SHA256（以本模块 fingerprint 的规范 JSON 为准）；仅自填 reviewed/reviewer 不放行。合成例子明确为作者协议夹具。支持 eq/ne/in/not_in；自由文本及未知操作符保持 unknown。源 `context_scope/source_contexts` 也纳入条件检查；多个不同源情境要求先拆分。

适用条件为假时保留原排斥和不适用理由；条件不明时进入 `pending_directions`。排斥仅来自目标人群中的部分人时，保留其用户范围并要求分群或缩小本次目标，不能变成全体否定。未确定对象映射、负向特征归因待复核，也不会产生可执行请求。

`brief.hard_constraints` 支持 `required_features/forbidden_features`；须带证据引用。非结构化硬约束或尚未解释的条件/对象作用域使方向 pending，不静默忽略。模型在方向里自称 `basis=product_hard_constraint` 不具有绕过证据的效力。

## candidate_bindings 最小约定

H02 请求的非空 `candidate_bindings` 是明确载体范围：

```json
{"image_id":"I1","object_id":"shell","observation_ids":["I1-OPT-002"],"region_refs":[{"object_id":"shell","bbox_xyxy":[0.1,0.1,0.9,0.9]}]}
```

`image_id/object_id` 定义允许参与本命题的载体；观察 ID 和区域来自该载体真实输入。每个载体必须同时满足全部核心条件。语义回复可提供该字段进一步缩小范围；空、未知、重复、伪造观察或区域均不视为无限制。

下游仍检查被选载体的全部相关观察，特别是禁用特征，不能只检查清单里用于证明核心的 observation_ids。无绑定的旧请求按旧行为处理；提供了绑定的请求不得默默忽略。见 loop 的 CT-001 决议。图像整体、目标对象、局部禁用之间的作用域若不明确，下游保留边界，不擅自放行或全局排除。

CT-002 将禁用范围进一步明确为 `scope.kind=image` 或 `scope.kind=candidate_bindings`，并要求原负向审计和执行约束逐字段/值双向关联。详见 [NEGATIVE_SCOPES.md](D:/Codex/传音AI创客营/prism_runtime/handshake/NEGATIVE_SCOPES.md)；完整输入/输出在交付目录 `examples/CT-002/`。没有范围映射时，H02 保留原审计并返回 pending，不把 candidate_bindings 自动当成排斥范围。

## 状态和验证范围

`grouping_requests` 只含条件可解析且至少有一个共同载体的请求；pending 方向保存在独立列表，调用方不能把它们直接送聚类。每条请求仍是待设计师评审的设计候选，主题已确认不等于命题已确认。

作者测试和合成演示都用于开发，不是独立留出集。没有目标用户效果验证，不报告语义准确率、偏好概率和生产延迟。上游负责高级感判标；本模块强制核验它与 T01 参考池、图片及原始调用的绑定，用研图不参与该入库判断。FULLCHAIN-POOL-001 另对真实历史图/质量和已有独立偏好回执做边界回放，不重跑模型，不把假设简报改称真实市场验证。

完整结论、源材料索引、实际测试和下游问题见交付目录的 `算法规划.md`、`verification.json`、`source-manifest.json`、`handoff.json`。
