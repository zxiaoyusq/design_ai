import argparse
from prism_runtime.contracts import read_json, write_json
from .api import (POLICIES, prepare_request, compile_directions,
                  prepare_theme_request, compile_theme_handshake, select_themes, prepare_support_review, prepare_reference_admission)


def main():
    parser = argparse.ArgumentParser(description="Independent H01/H02 handshake; no network calls.")
    parser.add_argument("action", choices=["prepare-theme", "accept-theme", "select", "prepare", "accept", "prepare-review", "prepare-admission"])
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--profile")
    parser.add_argument("--trends-result")
    parser.add_argument("--material-manifest")
    parser.add_argument("--proposals")
    parser.add_argument("--selection")
    parser.add_argument("--review-context", help="Trusted caller metadata and actual independent review envelopes; never model-produced authority")
    parser.add_argument("--negative-scopes", help="Explicit caller-confirmed negative scope resolutions")
    parser.add_argument("--admission-context", help="Bound T01/quality/material reference qualification, required for image selection")
    parser.add_argument("--theme-result")
    parser.add_argument("--theme-id", action="append")
    parser.add_argument("--selection-id")
    parser.add_argument("--confirmed-by")
    parser.add_argument("--synthetic-assumption", action="store_true")
    parser.add_argument("--mode", choices=list(POLICIES), default="consensus")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    bundle = read_json(args.bundle)
    if args.action == "prepare-admission":
        if not args.trends_result or not args.material_manifest:
            parser.error("prepare-admission requires --trends-result and --material-manifest")
        result = prepare_reference_admission(bundle, args.trends_result, args.material_manifest)
        write_json(args.output, result)
        print(args.output)
        return
    if not args.profile:
        parser.error("--profile is required for handshake and selection actions")
    profile = read_json(args.profile)
    review_context = read_json(args.review_context) if args.review_context else None
    if args.action.startswith("accept") and not args.proposals:
        parser.error("accept requires --proposals")
    if args.action == "prepare-review":
        result = prepare_support_review(bundle, profile)
    elif args.action == "prepare-theme":
        result = prepare_theme_request(bundle, profile, review_context=review_context)
    elif args.action == "accept-theme":
        result = compile_theme_handshake(bundle, profile, read_json(args.proposals), args.mode, review_context=review_context)
    elif args.action == "select":
        if not (args.theme_result and args.theme_id and args.selection_id):
            parser.error("select requires --theme-result, --theme-id and --selection-id")
        result = select_themes(bundle, profile, read_json(args.theme_result), args.theme_id,
                               selection_id=args.selection_id, designer_confirmed=bool(args.confirmed_by),
                               confirmed_by=args.confirmed_by, synthetic_assumption=args.synthetic_assumption, review_context=review_context,
                               admission_context=read_json(args.admission_context) if args.admission_context else None)
    elif args.action == "prepare":
        result = prepare_request(bundle, profile, read_json(args.selection) if args.selection else None, review_context=review_context)
    else:
        result = compile_directions(bundle, profile, read_json(args.proposals), args.mode,
                                    read_json(args.selection) if args.selection else None, review_context=review_context,
                                    negative_scope_resolutions=read_json(args.negative_scopes) if args.negative_scopes else None)
    write_json(args.output, result)
    print(args.output)


if __name__ == "__main__":
    main()
