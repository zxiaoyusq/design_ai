"""H01: thematic opportunities and an explicit selection, independent of DNA."""
from copy import deepcopy

from prism_runtime.contracts import require, index_by
from .common import (POLICIES, SEMANTIC_STATUS, ALGORITHM_VERSION, validate_inputs, snapshot, fingerprint,
                     target_users, context_of, positive_anchors, preference_scope,
                     validate_trend_refs, validate_relation, prepare_payload, validate_proposal_snapshot)
from .semantic import attitude_lineage
from .admission import reference_pool


def prepare_theme_request(bundle, profile, *, review_context=None):
    return prepare_payload("H01", bundle, profile, review_context=review_context)


def compile_theme_handshake(bundle, profile, proposals_document, mode="consensus", *, review_context=None):
    evidence, _, prefs, themes, selected = validate_inputs(bundle, profile, review_context)
    validate_proposal_snapshot(bundle, profile, proposals_document, review_context)
    require(mode in POLICIES, "unknown alignment mode")
    proposals = proposals_document.get("proposals", [])
    index_by(proposals, "match_id")
    candidates, outside_policy, pending = [], [], []
    context = context_of(bundle)
    for p in proposals:
        require(p.get("theme_id") in themes, "unknown trend theme")
        users = target_users(p, selected)
        anchors, unresolved = positive_anchors(p, prefs, users, context, theme_only=True)
        lineages = [attitude_lineage(a, evidence) for a in anchors]
        unresolved.extend({"preference_id": a["preference_id"], "reason": "unreviewed_attitude_interpretation", "attitude_lineage": a}
                          for a in lineages if a["interpretation_requires_review"])
        refs = validate_trend_refs(p, themes[p["theme_id"]], evidence)
        allowed = validate_relation(p, mode)
        constraints = [preference_scope(f, users, context) for f in prefs.values() if f["attitude"] == "dislike"]
        constraints = [f for f in constraints if f["user_ids"]]
        opposing = p.get("opposition_preference_ids", [])
        require(all(x in prefs and prefs[x]["attitude"] == "dislike" for x in opposing), "invalid opposition preference")
        conflicts = [c for c in constraints if c["preference_id"] in opposing]
        item = {"match_id": p["match_id"], "theme_id": p["theme_id"], "title": p.get("title", themes[p["theme_id"]]["title"]),
                "shared_principle": p["shared_principle"], "relation_basis": p["relation_basis"],
                "target_user_ids": users, "preference_refs": p["preference_ids"], "trend_refs": refs,
                "candidate_support_user_ids": sorted({u for a in anchors for u in a["user_ids"] if u in users}),
                "source_recorded_support_user_ids": sorted({u for a, lineage in zip(anchors, lineages) if lineage["origin"] == "source_recorded" for u in a["user_ids"] if u in users}),
                "independently_verified_support_user_ids": sorted({u for a, lineage in zip(anchors, lineages) if not lineage["interpretation_requires_review"] and lineage["support_eligibility"] == "reviewed_positive" for u in a["user_ids"] if u in users}), "attitude_lineage": lineages,
                "support_status": "pending_semantic_review" if any(a["interpretation_requires_review"] for a in lineages) else "reviewed_atomic_preferences_with_unverified_relation",
                "conflicts": conflicts, "scoped_constraints": constraints,
                "pending_context_constraints": unresolved, "case_pool_image_ids": deepcopy(themes[p["theme_id"]].get("image_ids", [])),
                "evidence_image_ids": deepcopy(themes[p["theme_id"]].get("image_ids", [])),
                "reference_image_ids": deepcopy(themes[p["theme_id"]].get("reference_image_ids")),
                "evidence_only_image_ids": deepcopy(themes[p["theme_id"]].get("evidence_only_image_ids")),
                "reference_admission_status": "not_yet_validated; selection must verify qualification",
                "hypotheses": deepcopy(p.get("hypotheses", [])), "explanation": p.get("explanation", ""),
                "semantic_status": SEMANTIC_STATUS, "designer_confirmed": False}
        if not allowed:
            outside_policy.append({**item, "reason": "outside_alignment_policy"})
        elif unresolved:
            pending.append({**item, "reason": "positive_context_or_semantics_unresolved"})
        else:
            candidates.append(item)
    used = {pid for c in candidates for pid in c["preference_refs"]}
    proposed = {pid for p in proposals for pid in p.get("preference_ids", [])}
    gaps = [{"preference_id": f["preference_id"], "evidence_refs": f["evidence_refs"],
             "kind": "unmatched_user_need", "reason": "proposal_not_admitted" if f["preference_id"] in proposed else "no_theme_relation_proposed",
             "trend_absence_verified": False}
            for f in prefs.values() if f["level"] == "theme" and f["attitude"] in {"like", "conditional"} and f["preference_id"] not in used]
    # An empty intersection is not proof of a market gap. Optional full-pool
    # absence review remains a semantic claim with its own coverage trail.
    for review in proposals_document.get("gap_reviews", []):
        pid = review.get("preference_id")
        require(any(g["preference_id"] == pid for g in gaps), "gap review must refer to an unmatched need")
        coverage = index_by(review.get("theme_coverage", []), "theme_id")
        require(set(coverage) == set(themes), "gap review must cover every current theme")
        require(all(c.get("state") in {"absent", "present", "unknown"} and c.get("reason") for c in coverage.values()), "invalid gap coverage")
        gap = next(g for g in gaps if g["preference_id"] == pid)
        gap.update({"theme_coverage": list(coverage.values()), "semantic_status": SEMANTIC_STATUS,
                    "kind": "reported_current_pool_gap" if coverage and all(c["state"] == "absent" for c in coverage.values()) else "unmatched_user_need"})
    return {"schema_version": "prism.theme_handshake.v0.2", "algorithm_version": ALGORITHM_VERSION, "stage": "H01", "brief_id": bundle["brief"]["brief_id"],
            "input_snapshot": snapshot(bundle, profile), "alignment_mode": mode, "policy": deepcopy(POLICIES[mode]),
            "review_context_snapshot": fingerprint(review_context),
            "theme_candidates": candidates, "pending_candidates": pending, "outside_policy": outside_policy, "user_gaps": gaps,
            "unmatched_theme_ids": sorted(set(themes) - {c["theme_id"] for c in candidates}),
            "status": "needs_designer_review" if candidates else "needs_input", "designer_confirmed": False,
            "counts_note": "仅当前范围内去重用户；非市场偏好率。主题先按证据展示，不生成未标定高潜分数。",
            "semantic_status": SEMANTIC_STATUS, "provenance": deepcopy(bundle["provenance"])}


def select_themes(bundle, profile, result, theme_ids, *, selection_id,
                  designer_confirmed=False, confirmed_by=None, synthetic_assumption=False,
                  selected_user_ids=None, candidate_image_ids=None, review_context=None, admission_context=None):
    """Record caller-supplied selection; never impersonate a designer."""
    _, _, _, themes, population = validate_inputs(bundle, profile, review_context)
    require(result.get("schema_version") == "prism.theme_handshake.v0.2", "H01 result required")
    require(result.get("input_snapshot") == snapshot(bundle, profile), "stale H01 evidence")
    require(result.get("review_context_snapshot") == fingerprint(review_context), "stale H01 review context")
    require(bool(selection_id), "theme_selection_id required")
    require(bool(theme_ids) and len(theme_ids) == len(set(theme_ids)), "unique selected themes required")
    eligible = {c["theme_id"] for c in result["theme_candidates"]}
    require(set(theme_ids).issubset(eligible), "selection outside admitted H01 candidates")
    require(not (designer_confirmed and synthetic_assumption), "synthetic assumption is not designer approval")
    if synthetic_assumption:
        require(bundle["provenance"]["mode"] == "synthetic", "real selection cannot use synthetic assumption")
    if designer_confirmed:
        require(isinstance(confirmed_by, str) and bool(confirmed_by.strip()), "confirmed_by required")
    users = target_users({"target_user_ids": selected_user_ids if selected_user_ids is not None else population}, population)
    relations = [deepcopy(c) for c in result["theme_candidates"] if c["theme_id"] in theme_ids]
    for tid in theme_ids:
        require(any(c["theme_id"] == tid and set(users).issubset(c["target_user_ids"]) for c in relations), "selection broadens H01 target scope")
    admission = reference_pool(bundle, theme_ids, admission_context)
    pool = list(admission["eligible_image_ids"])
    if candidate_image_ids is not None:
        require(isinstance(candidate_image_ids, list) and len(candidate_image_ids) == len(set(candidate_image_ids)) and set(candidate_image_ids).issubset(pool), "selection image is outside currently qualified reference pool")
        pool = sorted(candidate_image_ids)
    return {"schema_version": "prism.theme_selection.v0.2", "algorithm_version": ALGORITHM_VERSION, "theme_selection_id": selection_id,
            "brief_id": bundle["brief"]["brief_id"], "input_snapshot": snapshot(bundle, profile),
            "dna_snapshot": fingerprint(bundle.get("images", [])), "alignment_mode": result["alignment_mode"],
            "review_context_snapshot": fingerprint(review_context),
            "theme_ids": sorted(theme_ids), "theme_relations": relations, "candidate_image_ids": pool,
            "evidence_image_ids": list(admission["evidence_image_ids"]), "reference_admission": deepcopy(admission),
            "admission_context": deepcopy(admission_context), "admission_snapshot": admission["admission_snapshot"],
            "target_user_ids": users, "context": context_of(bundle), "designer_confirmed": designer_confirmed,
            "confirmed_by": confirmed_by, "synthetic_assumption": synthetic_assumption,
            "status": "confirmed" if designer_confirmed else "synthetic_assumption" if synthetic_assumption else "needs_designer_review",
            "provenance": deepcopy(bundle["provenance"])}


def validate_selection(bundle, profile, selection, review_context=None):
    require(isinstance(selection, dict) and selection.get("schema_version") == "prism.theme_selection.v0.2", "explicit H01 theme selection required")
    require(selection.get("brief_id") == bundle["brief"]["brief_id"], "selection brief mismatch")
    require(selection.get("input_snapshot") == snapshot(bundle, profile), "stale theme selection evidence")
    require(selection.get("review_context_snapshot") == fingerprint(review_context), "stale selection review context")
    require(selection.get("dna_snapshot") == fingerprint(bundle.get("images", [])), "stale theme selection DNA")
    require(selection.get("context") == context_of(bundle), "selection context mismatch")
    synthetic = bundle["provenance"]["mode"] == "synthetic"
    confirmed = selection.get("designer_confirmed") is True and bool(selection.get("confirmed_by"))
    assumed = synthetic and selection.get("synthetic_assumption") is True and selection.get("designer_confirmed") is False
    require(confirmed or assumed, "theme selection needs explicit designer confirmation")
    require(not (selection.get("synthetic_assumption") and not synthetic), "synthetic approval cannot authorize real evidence")
    require(bool(selection.get("theme_selection_id")) and bool(selection.get("theme_relations")), "selection lacks H01 linkage")
    _, _, _, themes, population = validate_inputs(bundle, profile, review_context)
    users = target_users(selection, population)
    require(set(selection.get("theme_ids", [])).issubset(themes), "unknown selected theme")
    admission = reference_pool(bundle, selection["theme_ids"], selection.get("admission_context"))
    require(selection.get("admission_snapshot") == admission["admission_snapshot"], "stale or modified reference admission snapshot")
    require(selection.get("reference_admission") == admission, "selection admission audit was modified")
    require(set(selection.get("candidate_image_ids", [])).issubset(admission["eligible_image_ids"]), "selected pool includes an unqualified reference image")
    for tid in selection["theme_ids"]:
        require(any(c["theme_id"] == tid and set(users).issubset(c["target_user_ids"]) for c in selection["theme_relations"]), "selection does not preserve H01 population")
    return selection
