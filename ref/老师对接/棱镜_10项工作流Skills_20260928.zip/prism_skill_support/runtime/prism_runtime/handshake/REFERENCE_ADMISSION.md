# FULLCHAIN-POOL-001：证据池与参考池

版本 `handshake-0.3.2`，修复轮次 1。原 0.3.1 冻结结果和 Root 本轮旧报告保持原样。

## 两个池

- `TrendTheme.image_ids` 是语义证据全集，可以包含 FAIL、未知或暂不适用的图。文章、原图关系和排除原因保留。
- `reference_image_ids` 是 T01 声明的参考候选范围；还需核对实际质量来源和图片身份，不能单凭这个列表获得执行资格。
- `evidence_only_image_ids` 与 reference 列表应不重叠，合起来覆盖 image_ids。非空图片主题缺这两个字段时明确报错，不回退全集。
- H01 可以纯文字运行，纯文字主题可选择空参考池。H02 不会由空池生成可执行图片组。

默认选择使用“本轮所选主题 reference_image_ids ∩ 当前核验合格图”。显式 `candidate_image_ids` 也只能是该集合子集；请求中混入 FAIL 等图会直接拒绝，不静默把错误请求改成另一份确认。

H02 再核对当前资格、选择快照和本条命题的 theme_id。某图在主题 A 可用，不代表它在仅将该图作为证据的主题 B 也能执行。

## 强制入口

```python
from prism_runtime.handshake import prepare_reference_admission, select_themes

admission = prepare_reference_admission(bundle, trends_result_path, material_manifest_path)
selection = select_themes(
    bundle, profile, h01_result, theme_ids,
    selection_id="actual-selection-id",
    designer_confirmed=True, confirmed_by="实际确认者",
    review_context=trusted_review_context,
    admission_context=admission,
)
```

```powershell
py -3.13 -B -m prism_runtime.handshake prepare-admission --bundle BUNDLE.json --trends-result T01.json --material-manifest MATERIAL.json --output ADMISSION.json
py -3.13 -B -m prism_runtime.handshake select --bundle BUNDLE.json --profile PROFILE.json --theme-result H01.json --theme-id THEME --selection-id SELECTION --confirmed-by ACTOR --review-context REVIEW_CONTEXT.json --admission-context ADMISSION.json --output SELECTION.json
```

以上参数占位仅示意。完整实际路径及可用输入见本次修复目录的 `actual-replay/reference-admission.json` 和 `replay.json`。源码路径、quality 和调用输入由可信调用方提供；模型提案自带 eligible/production 标志不能替代此入口。

## 资格及来源绑定

context 保存 T01 原文件、材料清单的路径及 SHA256，并绑定主题和图片身份快照。选择时和 H02 消费时均重验，不直接信任 selection 里可编辑的资格缓存。

对实际图片逐项验证：

1. ImageDNA、材料清单和质量回执均声明 trend；图片及质量 provenance 为既有真实输出。calibration、research、generated、未知或合成质量不能成为正式参考资格。
2. 当前原图 bytes SHA256、ImageDNA.image_sha256 和材料清单 original_sha256 一致。
3. quality.source_ref/source_sha256 对应清单中的原始结果文件，文件当前内容未变。
4. 原结果和相邻保存 input.json 的 image_id/call_id 一致；输入记录的 input_sha256 与材料清单及实际质量输入图片一致。原图与处理后输入的关系来自保存的清单，不重新变换图片。
5. 使用现有质量 adapter 只读导出原判定，与 T01 保存回执的 decision/status/rubric/production 等字段一致。只有完成的 PASS 且 production_admission 明确为布尔 true 才可执行。
6. 质量回执、T01 或图片来源变化，使已存选择资格快照失效。已报告 FAIL 保留为 FAIL；技术错误/未知/缺失不会改写成审美 FAIL，也不会获得 PASS 资格。

本版支持当前保存的单次质量调用材料结构：material-manifest 含 records、original_manifest_record 和 files（frozen 路径及 sha256），质量结果与 input.json 共同保留。缺少原图→质量输入关系、复合回执不能提供明确绑定或其他格式未经适配时，保持无资格并说明缺项，不自行猜测。它不认证清单提供者身份，也不证明旧审美判定一定正确；实际来源真实性由可信调用方和原始存档负责。

旧判标不因时间过去被偷偷重评。这里的陈旧检查针对绑定文件、图片身份、调用输入和规则回执不一致；未自行发明判标有效期。

## 输出和审计

selection 新增 `evidence_image_ids`、`reference_admission`、`admission_context` 和 `admission_snapshot`。audit 按图片保留资格、来源 SHA、quality call_id、rubric、参考主题/仅证据主题及排除原因。某个参考候选缺少资格时从执行池排除，并以 partial/needs_input 标记参考池完整性；主题选择状态与质量完整性分开。

GroupingRequest 携带 admission_snapshot、reference_admission_purpose 和本请求图片的资格审计。上游强制入口已拦截不合格图，无需修改后聚类代码或更改 C07 原判标。CT-001 三档/载体白名单、CT-002 负向范围与审计保持。

## 假设项目与协议夹具

project/bundle 标记 synthetic 只说明简报/选择可能是假设，不豁免真实历史图片的资格。Root 本次真实六图即走 source_bound_reference，C07 仍被排除。

纯程序夹具可显式调用 `prepare_fixture_admission`。它只接受整个图片集合均为 source_kind=synthetic、provenance.mode=synthetic 的协议输入，绑定完整图片记录，所有 production_admission 始终 false。该 context 不能用于实际 trend、校准或用研图片，也不能用于 real_evidence 项目。它不是只看 bundle.synthetic 就放行的后门。

## 本轮可复跑验证

```powershell
py -3.13 -B -m prism_runtime.handshake.verify --output outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/FULLCHAIN-POOL-001 --admission-source outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/fullchain-20260926
```

此次验证包含原有相关接口/CT 回归、21 个资格及陈旧/冲突反例，以及 C07 实际输入的 8 项边界回放。额外测试只复制 JSON 回执到本模块的临时目录并在其中构造反例；Root 的原图、判标和报告均只读。

实际修复回放：证据池保留 C07/C08/T01；默认与显式合法参考池只含 C08/T01；显式加回 C07 和 H02 提案加回均被拒绝；最终实际后聚类只含 C08/T01。检查 C07 旧文件哈希未变，无新判标、DNA 解析或付费 API。语义/审美真实效果仍未由这些程序检查证明，交 Root 下一轮独立复验。
