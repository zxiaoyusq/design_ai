# exploratory_reference_v1 · CLOSURE-REF-001

新版本 `handshake-exploratory-reference-v1.0.0`，0 模型/API调用。保留旧 T01、原9图、H01/P01及全部冻结模块。
这是独立的设计探索输入，唯一新增角色为 `user_delegated_ai_selected_exploratory_reference`，不生成文章视觉证据或受访者认可。

## 最小调用

```python
from prism_runtime.handshake.exploratory_reference_v1 import (
    prepare_request, accept_proposal, compile_confirmed, verify_context)

prepared = prepare_request(config)
# Root 只把 messages + response_schema 交给既定 H02 标准 Astra 调用。
draft = accept_proposal(config, prepared, actual_response_path)
# Root 查看存储提案，另存明确的母库/方向/范围代理决定，再执行：
registered = compile_confirmed(config_path, prepared_path, draft_path,
                              Root_confirmation_path, output_dir=new_output_dir)
receipt = verify_context(context_path, request=exact_grouping_request,
                         inventory_path=original_inventory_path)
```

config 沿用 Root `h02/final-inputs/scene01.config.json` / scene04 / combined：frames、delegation_path、inventory_path、projection_index_path、ledger_path、carrier_rule。
H01 每次从实际模型回复经原接收器重放；原D03调用/输入/原图字节沿冻结 admission._qualified_image 重验。
projection 通过聚类 owner 新的固定注册 loader 调用官方 v1/v1.1/v1.2 verifier，不按自报版本 fallback。
编码失败、复核无有用特征、D03典型质量失败分别记录，不把解析失败当素材不典型。

## 母库不是示例，也不是预分组

母库严格为该固定原120版本中的 trend + 原D03成功 + 官方双审核有用CMF 的交集。
Root必须明确批准完整具体ID清单、library_snapshot与载体规则；不因图已解析自动注册，不含60校准图。
`candidate_pool_kind=approved_closed_exploration_library`。
`carrier_rule={kind:all_original_objects_with_reviewed_local_cmf, exclude_object_type_ids:[O19]}` 必须原样批准。
O19只退出正向候选载体枚举，完整objects、其他positive和所有unknown/background始终保留做负向检查。

模型 `example_bindings` / `feature_anchor_observations` 只解释典型原值，不是候选池白名单。
最终request.candidate_image_ids精确等于完整批准母库，carrier bindings按批准规则展开，**不按required特征预筛**。
原聚类算法才在全部候选中判断同载体匹配、排除、单例及边界；不凑组数，不新增相似度/容差。

## 无损输入

完整源数据、资格、39图等具体数量以当前library-audit为准；不以缩小上下文为理由删图/对象/未知/负向。
模型输入采用显式记录列、共享节点、路径前缀和材料行编码：

```python
from prism_runtime.handshake.compact_context_v1.normalize import unpack_record_columns
from prism_runtime.handshake.exploratory_reference_v1.codec import expand, expand_material_rows
original_data = expand_material_rows(expand(unpack_record_columns(
    payload['lossless_data'], payload['record_schemas'])))
```

known_rows依次为观察ID后缀/原字符串、field_ref、object_id、reference_object_id、原value、region_ref。
material_encoding把原PID/name/unit、区域和未知状态/error存一次。
数字观察ID仅按显式image_id+:a前缀+四位后缀还原；不据ID推理场景/身份。原字符串、None、False、0/0.0、顺序、原值均不改。
prepare自动全量展开并逐值校验，也记录原值fingerprint。旁表保留所有官方原文及完整审核文件内容。
schema不再重复列几千个observation枚举，accept仍严格验证实际ID成员、尺度PID/单位/参照和原值。

## Root确认文件

```json
{
  "schema_version": "prism.exploratory_library_confirmation.v1",
  "authority_kind": "user_delegated_ai",
  "human_designer_actually_reviewed": false,
  "authority_ref": {"path": "原user-delegation.json", "sha256": "原字节SHA"},
  "recorded_by": "Root",
  "recorder_thread_id": "授权文件source_thread_id",
  "reason": "Root根据存储算法提案作出的设计探索决定",
  "draft_snapshot": "草案精确值",
  "library_snapshot": "当前库精确值",
  "candidate_pool_kind": "approved_closed_exploration_library",
  "approved_library_image_ids": ["完整库清单，不能只放2–4示例"],
  "carrier_rule": {"kind":"all_original_objects_with_reviewed_local_cmf","exclude_object_type_ids":["O19"]},
  "selected_directions": [{"direction_id":"...","manifest_snapshot":"...","alignment_mode":"exploration"}]
}
```

新增/更换投影与母库产生新snapshot和明确决定，不能给旧批准静默重签。
低两档和无新context仍用旧9图入口；新增context永远不授权低两档。
负向范围规则覆盖整个批准库或其全部批准载体，不是仅示例图。未知范围/P01条件保持pending，无法编译时不生成可执行request。

## 编译与叶子验证

运行时复用 frozen directions 的相同函数code object和原匹配/语义/CT002代码，在会话私有globals中替换两个输入边界：
独立设计库的池身份与selection验证、按明确母库规则枚举载体。只读兼容资格字段不回写/不导出为T01；原bundle.themes不变。
所有P01负向、条件、假设/原值、未知保护保持；可匹配性最终交原engine，不把模型示例当答案。

每个实际GroupingRequest对应新context文件。request仅含context_id，context绑定整个最终request hash（不略过CT002字段），无hash循环。
verify_context是无写入、无consumer回调的叶子：重新读取固定H01/来源/资格/模型草案/Root决定，再纯编译并比对整个request。
它返回CONTEXT.md字段、实际权威身份及全母库selected_references；不信context自报passed。
编译不自行聚类。Root/聚类owner随后调用新 `exploratory_cmf_bridge_v1.prepare_request_views`，完整正/负/比较PID再守卫，之后原0.2.0筛选。

旧gate对未解析/未知条件仍可返回pending。通过接口测试或D03/局部审核不表示语义效果、真实用户偏好或视觉金标准确率。
Root实际H02与决定尚未发生时，不提供伪造actual context。测试中的in-memory confirmation只测协议，不是实际Root决定。
