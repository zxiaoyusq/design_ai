"""Read-only intersection of original trend identity, D03 and official CMF."""
from copy import deepcopy
from pathlib import Path
from prism_runtime.contracts import require, read_json
from ..common import fingerprint
from ..admission import _read_bound, _qualified_image
from ..proposal_gate_v1.sources import identity

ROLE = "user_delegated_ai_selected_exploratory_reference"
POOL_KIND = "approved_closed_exploration_library"
CARRIER_RULE = {"kind": "all_original_objects_with_reviewed_local_cmf", "exclude_object_type_ids": ["O19"]}


def carriers(document, rule):
    require(rule == CARRIER_RULE, "unsupported or unapproved carrier rule")
    objects = {o["object_id"]: o for o in document["objects"]}
    ids = sorted({o["object_id"] for o in document["observations"] if o.get("value_status") == "known"
                  and objects[o["object_id"]].get("object_type_id") not in rule["exclude_object_type_ids"]})
    # The empty observation list is deliberate: these are candidate carriers,
    # not a claim that they already meet the H02 conjunction.
    return [{"image_id": document["image_id"], "object_id": oid} for oid in ids]


def qualify(config, frame):
    from prism_runtime.clustering.local_cmf_bridge_v1.bridge import _inventory_data, _match_corpus_identity
    from prism_runtime.clustering.exploratory_cmf_bridge_v1 import load_verified_projection
    inventory, originals, original_pool = _inventory_data(config["inventory_path"])
    base_bundle = read_json(inventory["sources"]["bundle"]["path"])
    require(fingerprint(base_bundle) == fingerprint(frame["inputs"]["bundle"]), "exploration and H01 use different original corpora")
    admission = frame["inputs"]["admission_context"]
    trends = _read_bound(admission["trends_result"])
    materials = _read_bound(admission["material_manifest"])
    routes = {r["image_id"]: r for r in trends["quality_routes"]}
    material_rows = {r["image_id"]: r for r in materials["records"]}
    index = read_json(config["projection_index_path"])
    ledger = read_json(config["ledger_path"])
    require(isinstance(index, dict) and set(index).issubset(originals), "projection mapping is outside original120")
    require(len(ledger["records"]) == 120 and {r["image_id"] for r in ledger["records"]} == set(originals), "complete original120 ledger required")
    require(all(r["source_kind"] == originals[r["image_id"]]["source_kind"] for r in ledger["records"]), "ledger source kind changed")
    documents, rows = {}, []
    for iid, original in sorted(originals.items()):
        row = {"image_id": iid, "source_kind": original["source_kind"], "qualified": False,
               "D03_status": "not_applicable" if original["source_kind"] != "trend" else "not_replayed",
               "projection_status": "not_replayed", "parse_failure_is_not_a_typicality_failure": True,
               "original_T01_reference_role": {"globally_registered": iid in original_pool["eligible_image_ids"],
                    "theme_ids": sorted(t["theme_id"] for t in base_bundle["themes"] if iid in t.get("reference_image_ids", []))}}
        if original["source_kind"] != "trend":
            row["reason"] = "not_original_trend_source"
        else:
            try:
                # Identity-only view of the SAVED D03 chain, not an ImageDNA or
                # a claim of parse success. Verify D03 independently so absent
                # CMF cannot be misreported as material/typicality failure.
                identity_view = {"schema_version": "prism.saved_D03_image_identity.v1", "image_id": iid,
                    "source_kind": original["source_kind"], "image_path": original["path"],
                    "provenance": {"mode": routes[iid]["quality_record"].get("provenance", {}).get("mode"), "image_sha256": original["sha256"]}}
                quality = _qualified_image(identity_view, routes[iid], material_rows[iid])
                row.update(D03_status=quality["decision"], d03_verification=quality, image_identity=identity(original["path"]))
                if not quality["eligible"]:
                    row["reason"] = "original_D03_did_not_pass"
                    rows.append(row)
                    continue
                if not index.get(iid):
                    row.update(reason="official_projection_not_provided", projection_status="not_provided")
                    rows.append(row)
                    continue
                doc, receipt = load_verified_projection(index[iid])
                _match_corpus_identity(doc, originals)
                require(doc["image_id"] == iid, "projection index identity mismatch")
                row.update(projection_identity=receipt["projection_identity"], projection_verification=receipt,
                           projection_status="official_replay_passed")
                if not doc["observations"] or not receipt.get("useful_local_cmf"):
                    row["reason"] = "no_official_reviewed_useful_local_CMF"
                else:
                    row.update(qualified=True, reason="D03_and_official_local_CMF_passed; selection_not_yet_granted")
                    documents[iid] = doc
            except (ValueError, OSError, KeyError) as exc:
                row["reason"] = "qualification_rejected"
                row["rejection_stage"] = "local_CMF_or_source_identity" if row["D03_status"] == "PASS" else "D03_source_replay"
                row["error"] = type(exc).__name__ + ": " + str(exc)
        rows.append(row)
    source_ids = {k: identity(config[k]) for k in ("inventory_path", "projection_index_path", "ledger_path")}
    source_ids.update(original_quality_routes=deepcopy(admission["trends_result"]), original_quality_materials=deepcopy(admission["material_manifest"]))
    pool = {"schema_version": "prism.exploratory_material_library.v1", "candidate_pool_kind": POOL_KIND,
        "status": "qualified_for_proposal_only_not_selected", "qualified_image_ids": sorted(documents),
        "carrier_rule": deepcopy(CARRIER_RULE), "original_reference_image_ids": original_pool["eligible_image_ids"],
        "records": rows, "source_identities": source_ids, "new_model_calls": 0,
        "T01_visual_evidence_created": False, "user_preference_support_created": False}
    pool["library_snapshot"] = fingerprint(pool)
    return pool, documents
