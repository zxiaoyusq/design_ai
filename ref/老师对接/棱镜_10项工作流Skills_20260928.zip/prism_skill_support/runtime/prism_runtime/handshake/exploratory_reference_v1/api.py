"""Closed-library registration and leaf replay; no consumer callbacks."""
from copy import deepcopy
from pathlib import Path
from prism_runtime.contracts import require, read_json, write_json
from ..common import fingerprint
from ..proposal_gate_v1.sources import identity
from .prepare import prepare_request, VERSION
from .draft import accept_proposal
from .runtime import validate_confirmation, compile_direction
from .qualification import ROLE, POOL_KIND, CARRIER_RULE

CONTEXT_SCHEMA = "prism.exploratory_reference_context.v1"


def _read_inputs(inputs):
    require(all(identity(ref["path"]) == ref for ref in inputs.values()), "registered input file changed")
    return {key: read_json(ref["path"]) for key, ref in inputs.items()}


def _replay(inputs, direction_id=None):
    data = _read_inputs(inputs)
    config, prepared, draft, confirmation = (data[k] for k in ("config", "prepared", "draft", "confirmation"))
    # accept_proposal reconstructs current H01/source/quality/DNA state. It does
    # not issue grouping requests or delegate confirmation to a model.
    require(accept_proposal(config, prepared, draft["source_response"]["path"]) == draft, "stored draft differs from actual proposal replay")
    choices = validate_confirmation(prepared, draft, confirmation)
    if direction_id is not None:
        choices = [c for c in choices if c["direction_id"] == direction_id]
        require(len(choices) == 1, "context direction absent from delegated decision")
    results = [compile_direction(prepared, draft, confirmation, inputs["confirmation"], c) for c in choices]
    return prepared, draft, confirmation, results


def _selected_references(prepared, result, confirmation_identity):
    pool = prepared["side_table"]["library"]
    by_image = {r["image_id"]: r for r in pool["records"]}
    refs = []
    for iid in pool["qualified_image_ids"]:
        source = by_image[iid]
        refs.append({"image_id": iid, "role": ROLE,
            "projection_identity": deepcopy(source["projection_identity"]),
            "bindings": [{k: deepcopy(v) for k, v in b.items() if k != "image_id"} for b in result["library_bindings"] if b["image_id"] == iid],
            "original_T01_reference_role": deepcopy(source["original_T01_reference_role"]),
            "image_identity": deepcopy(source["image_identity"]), "d03_verification": deepcopy(source["d03_verification"]),
            "projection_verification": deepcopy(source["projection_verification"]), "delegated_selection_identity": deepcopy(confirmation_identity)})
    return refs


def compile_confirmed(config_path, prepared_path, draft_path, confirmation_path, *, output_dir):
    inputs = {k: identity(p) for k, p in (("config", config_path), ("prepared", prepared_path), ("draft", draft_path), ("confirmation", confirmation_path))}
    prepared, draft, receipt, results = _replay(inputs)
    out = Path(output_dir).resolve()
    require(not out.exists(), "registration output must be a new directory")
    out.mkdir(parents=True)
    contexts, requests, pending = [], [], []
    for item in results:
        emitted = item["h02_result"]["grouping_requests"]
        write_json(out / (item["context_id"] + "-compilation.json"), item)
        if not emitted:
            pending.append({"context_id": item["context_id"], "result": item["h02_result"]})
            continue
        require(len(emitted) == 1, "one direction context must bind exactly one request")
        request = emitted[0]
        context = {"schema_version": CONTEXT_SCHEMA, "algorithm_version": VERSION,
            "context_id": item["context_id"], "inputs": inputs, "direction_id": item["core_proposal"]["direction_id"],
            "request": request, "request_snapshot": fingerprint(request),
            "candidate_pool_kind": POOL_KIND, "carrier_rule": CARRIER_RULE,
            "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False,
            "library_snapshot": prepared["side_table"]["library"]["library_snapshot"],
            "selected_references": _selected_references(prepared, item, inputs["confirmation"]),
            "original_reference_image_ids": prepared["side_table"]["library"]["original_reference_image_ids"],
            "example_bindings": item["examples"], "feature_anchor_observations": item["feature_anchor_observations"],
            "feature_contract": {"required_features": request["required_features"], "comparison_features": request["comparison_features"]},
            "original_T01_files_modified": False, "original_H01_response_modified": False, "model_calls": 0}
        path = out / (item["context_id"] + ".context.json")
        write_json(path, context)
        write_json(out / (item["context_id"] + ".request.json"), request)
        contexts.append({"path": str(path), "sha256": identity(path)["sha256"], "request_id": request["request_id"]})
        requests.append(request)
    result = {"schema_version": "prism.exploratory_registration.v1", "algorithm_version": VERSION,
        "status": "registered" if requests else "pending_original_scope_or_feature_constraints",
        "contexts": contexts, "grouping_requests": requests, "pending": pending, "new_model_calls": 0,
        "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False, "clustering_executed": False}
    write_json(out / "registration.json", result)
    return result


def verify_context(context_path, *, request, inventory_path):
    before = identity(context_path)
    context = read_json(context_path)
    require(context.get("schema_version") == CONTEXT_SCHEMA and context.get("algorithm_version") == VERSION, "unsupported supplemental context")
    require(request.get("alignment_mode") == "exploration" and request.get("candidate_pool_kind") == POOL_KIND, "supplemental context is exploration-only")
    require(context.get("request") == request and context.get("request_snapshot") == fingerprint(request)
        and context.get("context_id") == request.get("exploration_context_id"), "entire request/context binding changed")
    prepared, draft, receipt, results = _replay(context["inputs"], context["direction_id"])
    require(Path(prepared["side_table"]["config"]["inventory_path"]).resolve() == Path(inventory_path).resolve(), "consumer inventory differs from approved original corpus")
    item = results[0]
    requests = item["h02_result"]["grouping_requests"]
    require(len(requests) == 1 and requests[0] == request and item["context_id"] == context["context_id"], "pure compilation no longer reproduces complete request")
    selected = _selected_references(prepared, item, context["inputs"]["confirmation"])
    original_refs = prepared["side_table"]["library"]["original_reference_image_ids"]
    require(context.get("selected_references") == selected and context.get("original_reference_image_ids") == original_refs,
            "approved library, carrier or original T01 role changed")
    require(context.get("library_snapshot") == prepared["side_table"]["library"]["library_snapshot"]
        and context.get("carrier_rule") == CARRIER_RULE and context.get("authority_kind") == "user_delegated_ai"
        and context.get("human_designer_actually_reviewed") is False, "library/authority context was altered")
    require(identity(context_path) == before, "context changed during replay")
    return {"passed": True, "model_calls": 0, "context_identity": before, "context_id": context["context_id"],
        "request_snapshot": fingerprint(request), "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False,
        "candidate_pool_kind": POOL_KIND, "carrier_rule": deepcopy(CARRIER_RULE), "selected_references": selected,
        "original_reference_image_ids": original_refs,
        "feature_contract": {"required_features": request["required_features"], "comparison_features": request["comparison_features"]},
        "example_bindings": deepcopy(item["examples"]), "feature_anchor_observations": deepcopy(item["feature_anchor_observations"])}
