# CLOSURE-REF-001 context contract (implementation in progress)

Consumer entrypoint: `verify_context(context_path, *, request, inventory_path)`.
It is a leaf verifier: it never invokes the clustering consumer, does not write,
and does not perform model inference. It replays qualification, source/H01/draft,
the separate Root delegated selection and pure request compilation.

Return fields:

```json
{
  "passed": true,
  "model_calls": 0,
  "context_identity": {"path": "...", "sha256": "..."},
  "context_id": "...",
  "request_snapshot": "fingerprint of the entire unchanged supplied request",
  "authority_kind": "user_delegated_ai",
  "human_designer_actually_reviewed": false,
  "candidate_pool_kind": "approved_closed_exploration_library",
  "original_reference_image_ids": ["original global nine IDs"],
  "selected_references": [{
    "image_id": "original trend ID",
    "role": "user_delegated_ai_selected_exploratory_reference",
    "projection_identity": {"path": "...", "sha256": "..."},
    "bindings": [{"object_id": "...", "observation_ids": []}],
    "original_T01_reference_role": {"globally_registered": false, "theme_ids": []},
    "image_identity": {"path": "...", "sha256": "..."},
    "d03_verification": {},
    "projection_verification": {},
    "delegated_selection_identity": {"path": "...", "sha256": "..."}
  }],
  "feature_contract": {"required_features": [], "comparison_features": []}
}
```

`selected_references` is the entire Root-approved closed material library, not
the model's 2–4 examples. Candidate image IDs equal this full list. Bindings are
the deterministic expansion of the explicitly approved carrier rule, without
filtering for required feature matches. `example_bindings` and
`feature_anchor_observations` are separate source-explanation fields.

Selected example observation IDs bind required/scale/comparison anchors, not a
deletion whitelist. The complete image's official positive observations and all
unknown/background coverage guards remain available for CT002. Comparison uses
the frozen algorithm over the selected carriers and request PIDs. Additional
verified observations are not promoted into claims of user approval.

The request contains only `exploration_context_id`, not its context file hash;
the context stores the complete final request and its fingerprint. No CT002 or
provenance fields are dropped from that fingerprint. One context covers one
final GroupingRequest. The verifier compares against a fresh pure compilation.

Without a valid new context, consumers continue to use the old nine-image path.
The supplemental context is only valid at `alignment_mode=exploration` with a
real `user_delegated_ai` selection. It does not modify or replace T01 evidence,
the original reference pools, old H01 tokens, P01 reviews or source identities.
