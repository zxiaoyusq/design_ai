import argparse
from pathlib import Path
from prism_runtime.contracts import read_json, write_json, require
from . import prepare_request, accept_proposal, compile_confirmed, verify_context

p = argparse.ArgumentParser(description="Explicit exploratory-library H02; no model calls.")
p.add_argument("action", choices=["prepare", "accept-proposal", "compile-confirmed", "verify"])
for name in ("config", "prepared", "response", "draft", "confirmation", "context", "request", "inventory"):
    p.add_argument("--" + name)
p.add_argument("--output", required=True)
a = p.parse_args()
if a.action == "compile-confirmed":
    result = compile_confirmed(a.config, a.prepared, a.draft, a.confirmation, output_dir=a.output)
else:
    require(not Path(a.output).exists(), "use a new output file")
    if a.action == "prepare": result = prepare_request(read_json(a.config))
    elif a.action == "accept-proposal": result = accept_proposal(read_json(a.config), read_json(a.prepared), a.response)
    else: result = verify_context(a.context, request=read_json(a.request), inventory_path=a.inventory)
    write_json(a.output, result)
print(a.output)
