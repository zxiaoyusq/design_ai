"""Small boundary tests; in-memory fixtures are not actual Root decisions."""
from copy import deepcopy
import unittest
from prism_runtime.contracts import ContractError
from ..common import fingerprint
from .. import directions
from .qualification import carriers, CARRIER_RULE, POOL_KIND
from .runtime import validate_confirmation, _namespace, CONFIRM_SCHEMA

class ReferenceTests(unittest.TestCase):
    def test_lossless_paths_nodes_and_reserved_literals(self):
        from .codec import compact, expand
        original = {"items": [{"path": "D:/" + "root/" * 25 + "image/normalized.json#/objects/1/region", "value": [0.125, "原话不截断"]} for _ in range(5)],
                    "literal": {"$node": "original user value"}, "null": None, "false": False}
        encoded = compact(original)
        self.assertEqual(expand(encoded), original)

    def fixture(self):
        prepared = {"side_table": {"authority": {"identity": {"path": "synthetic-fixture", "sha256": "a"}, "record": {"source_thread_id": "synthetic-root"}},
                                  "library": {"library_snapshot": "library", "qualified_image_ids": ["A", "B", "C"]}}}
        draft = {"draft_snapshot": "draft", "cards": [{"direction_id": "D", "manifest_snapshot": "manifest"}]}
        receipt = {"schema_version": CONFIRM_SCHEMA, "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False,
            "authority_ref": {"path": "synthetic-fixture", "sha256": "a"}, "recorded_by": "Root", "recorder_thread_id": "synthetic-root", "reason": "IN-MEMORY PROTOCOL FIXTURE ONLY",
            "draft_snapshot": "draft", "library_snapshot": "library", "candidate_pool_kind": POOL_KIND,
            "approved_library_image_ids": ["A", "B", "C"], "carrier_rule": deepcopy(CARRIER_RULE),
            "selected_directions": [{"direction_id": "D", "manifest_snapshot": "manifest", "alignment_mode": "exploration"}]}
        return prepared, draft, receipt

    def test_approved_full_library_is_not_examples(self):
        p, d, r = self.fixture()
        self.assertEqual(len(validate_confirmation(p, d, r)), 1)
        r["approved_library_image_ids"] = ["A"]
        with self.assertRaises(ContractError): validate_confirmation(p, d, r)

    def test_lower_modes_cannot_use_supplement(self):
        for mode in ("consensus", "extension"):
            p, d, r = self.fixture(); r["selected_directions"][0]["alignment_mode"] = mode
            with self.subTest(mode=mode), self.assertRaises(ContractError): validate_confirmation(p, d, r)

    def test_all_approval_and_snapshot_fields_bound(self):
        for key in ("draft_snapshot", "library_snapshot", "authority_ref", "carrier_rule", "candidate_pool_kind"):
            p, d, r = self.fixture(); r[key] = "tampered"
            with self.subTest(key=key), self.assertRaises(ContractError): validate_confirmation(p, d, r)

    def test_human_claim_or_unauthorized_actor_rejected(self):
        for key, val in (("human_designer_actually_reviewed", True), ("recorded_by", "model"), ("recorder_thread_id", "another")):
            p, d, r = self.fixture(); r[key] = val
            with self.subTest(key=key), self.assertRaises(ContractError): validate_confirmation(p, d, r)

    def test_carriers_not_prefiltered_by_requested_feature(self):
        doc = {"image_id": "SYNTHETIC", "objects": [{"object_id": "frame", "object_type_id": "O19"}, {"object_id": "red", "object_type_id": "O02"}, {"object_id": "texture", "object_type_id": "O10"}],
            "observations": [{"object_id": "frame", "parameter_id": "COL-006", "value_status": "known"},
                             {"object_id": "red", "parameter_id": "COL-006", "value_status": "known"},
                             {"object_id": "texture", "parameter_id": "TEX-002", "value_status": "known"}]}
        before = fingerprint(doc)
        self.assertEqual([b["object_id"] for b in carriers(doc, CARRIER_RULE)], ["red", "texture"])
        self.assertEqual(fingerprint(doc), before)
        self.assertEqual(len(doc["objects"]), 3)  # O19 still exists for negative coverage.

    def test_carrier_rule_change_cannot_silently_shrink_library(self):
        doc = {"image_id": "x", "objects": [], "observations": []}
        with self.assertRaises(ContractError): carriers(doc, {"kind": "only_matched_examples"})

    def test_private_engine_reuses_code_and_leaves_original_globals(self):
        before = {k: id(v) for k, v in vars(directions).items()}
        ns = _namespace()
        self.assertIs(ns["compile_directions"].__code__, directions.compile_directions.__code__)
        ns["_bindings"] = lambda *args: []
        self.assertEqual(before, {k: id(v) for k, v in vars(directions).items()})

if __name__ == "__main__": unittest.main()
