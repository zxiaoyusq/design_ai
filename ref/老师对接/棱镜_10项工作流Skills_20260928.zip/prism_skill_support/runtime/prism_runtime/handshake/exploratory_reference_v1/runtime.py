"""Isolated H02 transport: approved library enumeration, unchanged match rules."""
from copy import deepcopy
from types import FunctionType
import inspect
from prism_runtime.contracts import require, index_by, value_key
from .. import directions as frozen_directions
from ..common import fingerprint
from ..context_sidecar_v1 import ContextSession
from ..proposal_gate_v1.api import _core
from ..negative_scopes import RESOLUTION_SCHEMA
from .qualification import carriers, CARRIER_RULE, POOL_KIND, ROLE
from .draft import observation_index
from .prepare import VERSION

CONFIRM_SCHEMA = "prism.exploratory_library_confirmation.v1"


def validate_confirmation(prepared, draft, receipt):
    side = prepared["side_table"]
    auth = side["authority"]
    require(receipt.get("schema_version") == CONFIRM_SCHEMA and receipt.get("authority_kind") == "user_delegated_ai"
        and receipt.get("human_designer_actually_reviewed") is False, "delegated AI confirmation required; no human approval inference")
    require(receipt.get("authority_ref") == auth["identity"] and receipt.get("recorded_by") == "Root"
        and receipt.get("recorder_thread_id") == auth["record"].get("source_thread_id") and receipt.get("reason"), "confirmation is not the authorized Root decision")
    require(receipt.get("draft_snapshot") == draft["draft_snapshot"] and receipt.get("library_snapshot") == side["library"]["library_snapshot"], "stale draft/library decision")
    require(receipt.get("candidate_pool_kind") == POOL_KIND and receipt.get("approved_library_image_ids") == side["library"]["qualified_image_ids"], "Root must approve the complete closed library, not selected examples")
    require(receipt.get("carrier_rule") == CARRIER_RULE, "carrier enumeration rule was not explicitly approved")
    choices = receipt.get("selected_directions", [])
    require(isinstance(choices, list) and choices, "specific direction decisions required")
    index_by(choices, "direction_id")
    cards = index_by(draft["cards"], "direction_id")
    for choice in choices:
        require(choice.get("direction_id") in cards and choice.get("manifest_snapshot") == cards[choice["direction_id"]]["manifest_snapshot"], "direction/feature/scale/negative scope changed")
        require(choice.get("alignment_mode") == "exploration", "supplemental references are exploration-only")
    return choices


def _namespace():
    ns = dict(vars(frozen_directions))
    for name, fn in vars(frozen_directions).items():
        if inspect.isfunction(fn) and fn.__module__ == frozen_directions.__name__:
            copied = FunctionType(fn.__code__, ns, fn.__name__, fn.__defaults__, fn.__closure__)
            copied.__kwdefaults__ = deepcopy(fn.__kwdefaults__)
            ns[name] = copied
    ns["ALGORITHM_VERSION"] = VERSION
    return ns


def compile_direction(prepared, draft, receipt, confirmation_identity, choice):
    from prism_runtime.clustering.exploratory_cmf_bridge_v1 import prepare_pid_view
    side = prepared["side_table"]
    card = next(c for c in draft["cards"] if c["direction_id"] == choice["direction_id"])
    manifest = card["manifest"]
    d = manifest["direction"]
    frame = next(f for f in side["frames"] if f["frame_id"] == d["frame_id"])
    documents, pool = side["documents"], side["library"]
    original = frame["inputs"]["bundle"]
    prefs = frame["side_table"]["validated_profile"]
    observations = observation_index(documents)
    legacy = deepcopy(d); legacy["candidate_bindings"] = legacy.pop("example_bindings")
    core = _core(legacy, frame, observations)
    full_bindings = [b for iid in pool["qualified_image_ids"] for b in carriers(documents[iid], CARRIER_RULE)]
    core["candidate_image_ids"] = deepcopy(pool["qualified_image_ids"])
    core["candidate_bindings"] = deepcopy(full_bindings)
    require(core["candidate_image_ids"] == receipt["approved_library_image_ids"], "mother library was filtered before matching")
    context_id = "exploratory-" + fingerprint({"draft": draft["draft_snapshot"], "library": pool["library_snapshot"],
        "confirmation": confirmation_identity, "choice": choice})[:32]
    all_pids = sorted({f["parameter_id"] for f in core["required_features"]} | set(core["comparison_features"]) |
        {f["parameter_id"] for p in prefs["preferences"] if p["attitude"] == "dislike" for f in p["features"]})
    effective = deepcopy(original)
    projection_index = {r["image_id"]: r["projection_identity"]["path"] for r in pool["records"] if r["qualified"]}
    for image in effective["images"]:
        iid = image["image_id"]
        if iid in documents:
            view = prepare_pid_view(projection_index[iid], all_pids)
            image["observations"] = view["image_dna"]["observations"]
            image["objects"] = view["image_dna"]["objects"]
    opts = frame["options"]
    session = ContextSession(effective, frame["inputs"]["saved_profile"], review_context=opts["review_context"], execution_scope_context=opts["execution_scope_context"])
    # This is a NEW design-selection schema, not a fabricated H01 result or
    # a modified T01 pool. Its authority is the separately replayed decision.
    selection = {"schema_version": "prism.exploratory_design_selection.v1", "theme_selection_id": context_id,
        "input_snapshot": session.view["original_handshake_input_snapshot"], "review_context_snapshot": session.view["review_context_snapshot"],
        "theme_ids": [d["theme_id"]], "target_user_ids": d["target_user_ids"], "candidate_image_ids": core["candidate_image_ids"],
        "context": session.view["execution_scope"]["values"], "alignment_mode": "exploration",
        "designer_confirmed": False, "synthetic_assumption": False,
        "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False,
        "source_H01_result_snapshot": frame["result_snapshot"], "library_snapshot": pool["library_snapshot"],
        "reference_admission": {"purpose": ROLE, "audit": [r for r in pool["records"] if r["qualified"]]},
        "admission_snapshot": fingerprint({"library": pool["library_snapshot"], "confirmation": confirmation_identity})}
    ns = _namespace()
    # Original scope/semantic/CT002 routines and exact matcher are reused.
    ns.update(preference_scope=session._common["preference_scope"], positive_anchors=session._common["positive_anchors"])
    original_validate = ns["validate_inputs"]
    def validated_inputs(b, p, review_context=None):
        evidence, images, checked, themes, population = original_validate(b, p, review_context)
        runtime_pools = deepcopy(themes)
        # Compatibility-only eligibility slots for the private H02 code. This
        # dictionary is never emitted as T01 and never mutates bundle.themes.
        runtime_pools[d["theme_id"]]["image_ids"] = deepcopy(core["candidate_image_ids"])
        runtime_pools[d["theme_id"]]["reference_image_ids"] = deepcopy(core["candidate_image_ids"])
        return evidence, images, checked, runtime_pools, population
    def valid_selection(b, p, proposed, review_context=None):
        require(proposed == selection and choice["alignment_mode"] == "exploration", "unbound exploration selection")
        return proposed
    ns["validate_inputs"] = validated_inputs
    ns["validate_selection"] = valid_selection
    # Enumeration only: DO NOT pre-match required features here. The original
    # clustering engine must evaluate all approved carriers, including misses.
    ns["_bindings"] = lambda candidate_pool, images, features: deepcopy(full_bindings)
    resolutions = []
    for audit in manifest["negative_audit"]:
        pref, decision = audit["preference"], audit["design_scope_proposal"]
        if decision["disposition"] != "proposed": continue
        scope = {"kind": decision["scope_kind"], "status": "resolved", "evidence_refs": pref["evidence_refs"]}
        if scope["kind"] == "image": scope["image_ids"] = deepcopy(core["candidate_image_ids"])
        else: scope["bindings"] = [{"image_id": b["image_id"], "object_id": b["object_id"]} for b in full_bindings]
        features = {}
        for f in pref["features"]: features.setdefault(f["parameter_id"], []).append(deepcopy(f["value"]))
        for pid, values in features.items():
            resolutions.append({"resolution_id": context_id + ":" + pref["preference_id"] + ":" + pid,
                "direction_ids": [d["direction_id"]], "preference_id": pref["preference_id"], "parameter_id": pid,
                "forbidden_values": values, "evidence_refs": pref["evidence_refs"], "quotes": pref["quotes"], "scope": scope,
                "confirmation": {"status": "confirmed", "confirmed_by": "Root", "source_ref": confirmation_identity["path"],
                                 "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False}})
    negative = {"schema_version": RESOLUTION_SCHEMA, "input_snapshot": selection["input_snapshot"], "selection_snapshot": fingerprint(selection), "resolutions": resolutions}
    doc = {"proposals": [core], "input_snapshot": selection["input_snapshot"], "review_context_snapshot": selection["review_context_snapshot"], "selection_snapshot": fingerprint(selection)}
    result = ns["compile_directions"](effective, frame["inputs"]["saved_profile"], doc, "exploration", selection,
                                     review_context=opts["review_context"], negative_scope_resolutions=negative)
    if d["scale_status"] == "unknown":
        result["grouping_requests"] = []
        result["pending_directions"].append({"direction_id": d["direction_id"], "reason": "scale_unknown"})
    for request in result["grouping_requests"]:
        request["request_id"] = context_id + ":" + request["request_id"]
        request.update(exploration_context_id=context_id, candidate_pool_kind=POOL_KIND,
                       reference_role=ROLE, example_bindings=deepcopy(d["example_bindings"]))
        request["provenance"].update(authority_kind="user_delegated_ai", human_designer_actually_reviewed=False,
                                     T01_visual_evidence_created=False, explicit_exploratory_library=True)
        require(request["candidate_image_ids"] == pool["qualified_image_ids"], "request lost approved library images")
    return {"context_id": context_id, "selection": selection, "h02_result": result, "core_proposal": core,
            "library_bindings": full_bindings, "examples": d["example_bindings"], "feature_anchor_observations": manifest["feature_anchor_observations"]}
