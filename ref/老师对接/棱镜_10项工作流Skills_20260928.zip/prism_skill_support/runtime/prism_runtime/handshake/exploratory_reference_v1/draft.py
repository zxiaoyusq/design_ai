"""Validate example anchors and library-wide scope rules, never pre-group."""
from copy import deepcopy
from pathlib import Path
from prism_runtime.contracts import require, index_by, value_key
from ..common import fingerprint, validate_relation
from ..context_sidecar_v1.view import evaluate_preference_scope
from ..matrix_state_bridge_v1.api import read_response
from ..proposal_gate_v1.api import _core, SCALE_PARAMETERS
from .prepare import prepare_request, RESPONSE_SCHEMA, VERSION
from .qualification import carriers, CARRIER_RULE, POOL_KIND


def observation_index(documents):
    rows = {o["observation_id"]: (iid, o) for iid, d in documents.items() for o in d["observations"]}
    require(len(rows) == sum(len(d["observations"]) for d in documents.values()), "ambiguous original observation IDs")
    return rows


def _ids(values, valid, label, nonempty=False):
    require(isinstance(values, list) and all(isinstance(v, str) for v in values) and len(values) == len(set(values))
            and (values or not nonempty) and set(values) <= set(valid), "invalid " + label)
    return set(values)


def validate_direction(direction, frame, prepared):
    side = prepared["side_table"]
    documents, library = side["documents"], side["library"]
    observations = observation_index(documents)
    relations = {r["match_id"]: r for r in frame["result"]["theme_candidates"]}
    mids = _ids(direction["h01_match_ids"], relations, "actual H01 matches", True)
    require(all(relations[m]["theme_id"] == direction["theme_id"] for m in mids), "H01 theme changed")
    users = _ids(direction["target_user_ids"], set.intersection(*(set(relations[m]["target_user_ids"]) for m in mids)), "H01 target population", True)
    context = frame["side_table"]["context_role_view"]["execution_scope"]["values"]
    require(direction["scene"] == context.get("scene", ""), "source scene changed")
    prefs = index_by(frame["side_table"]["validated_profile"]["preferences"], "preference_id")
    pids = _ids(direction["preference_ids"], prefs, "preference anchors", True)
    require(all(prefs[p]["level"] in {"theme", "element"} and prefs[p]["attitude"] in {"like", "conditional"} for p in pids), "invalid positive anchor level/attitude")
    allowed_pairs = {(b["image_id"], b["object_id"]) for d in documents.values() for b in carriers(d, CARRIER_RULE)}
    examples = [(b["image_id"], b["object_id"]) for b in direction["example_bindings"]]
    require(examples and len(examples) == len(set(examples)) and set(examples) <= allowed_pairs, "examples must be real library carriers")
    required = _ids(direction["required_observation_ids"], observations, "required observations", True)
    comparison = _ids(direction["comparison_observation_ids"], observations, "comparison observations")
    scale = _ids(direction["scale_observation_ids"], observations, "scale observations")
    require((direction["scale_status"] == "source_values") == bool(scale), "scale state differs from numeric anchors")
    for oid in required | comparison | scale:
        iid, o = observations[oid]
        require((iid, o["object_id"]) in examples, "feature must link to a declared located example")
        if oid in scale:
            require(o["parameter_id"] in SCALE_PARAMETERS and type(o["value"]) in {int, float} and o.get("unit") and o.get("reference_object_id"), "invalid original numeric scale")
    for h in direction["hypotheses"]:
        require(h["observation_id"] in required | scale and h["reason"].strip(), "hypothesis lacks selected original value")
    legacy = deepcopy(direction)
    legacy["candidate_bindings"] = legacy.pop("example_bindings")
    core = _core(legacy, frame, observations)
    validate_relation(core, "exploration")
    supported = {(f["parameter_id"], value_key(f["value"])) for p in pids if prefs[p]["level"] == "element" for f in prefs[p]["features"]}
    requested = {(f["parameter_id"], value_key(v)) for f in core["required_features"] for v in f["allowed_values"]}
    hypotheses = {(h["parameter_id"], value_key(h["value"])) for h in core["hypotheses"]}
    require(requested - supported <= hypotheses, "novel original feature/scale value lacks hypothesis")
    if direction["relation_basis"] == "direct_support": require(requested <= supported, "direct support introduces novel features")
    if direction["relation_basis"] == "anchored_extension": require(bool(requested & supported), "extension lacks invariant visual support")
    evidence = {e["evidence_id"]: e for e in frame["inputs"]["bundle"]["evidence"]}
    def scope(pref):
        return evaluate_preference_scope(frame["side_table"]["context_role_view"], pref, users, context,
            evidence=evidence, review_context=frame["inputs"]["review_context"])
    positives, negatives, pending = [], [], []
    for pid in sorted(pids):
        s = scope(prefs[pid])
        positives.append({"preference": deepcopy(prefs[pid]), "scope": s})
        if s["context_state"] != "applies" or prefs[pid]["semantic_assessment"]["status"] != "supported": pending.append("positive_source_unresolved:" + pid)
    decisions = index_by(direction["negative_scope_proposals"], "preference_id")
    original_negatives = {p: f for p, f in prefs.items() if f["attitude"] == "dislike"}
    require(set(decisions) <= set(original_negatives), "scope proposal introduces a negative not in original P01")
    for pid, pref in original_negatives.items():
        s = scope(pref)
        decision = decisions.get(pid)
        if decision is None:
            require(s["context_state"] != "applies", "an applicable negative was omitted")
            state = "not_applicable" if s["context_state"] == "not_applicable" else "pending"
            decision = {"preference_id": pid, "disposition": state, "scope_kind": state, "scope_rule": state,
                        "reason": "原范围求值保持" + state + "；未新作范围决定。"}
        require(decision["reason"].strip(), "negative scope needs reason")
        if decision["disposition"] == "proposed":
            require(s["context_state"] == "applies" and pref["semantic_assessment"]["status"] == "supported", "unresolved negative cannot become resolved")
            rules = {"image": "all_approved_library_images", "candidate_bindings": "all_approved_library_carriers"}
            require(decision["scope_kind"] in rules and decision["scope_rule"] == rules[decision["scope_kind"]], "negative scope must cover the approved library, not examples")
            if not pref["features"]: pending.append("negative_feature_attribution_unresolved:" + pid)
        elif decision["disposition"] == "not_applicable":
            require(s["context_state"] == "not_applicable" and decision["scope_rule"] == decision["scope_kind"] == "not_applicable", "unknown cannot be relabelled NA")
        else:
            require(decision["disposition"] == decision["scope_kind"] == decision["scope_rule"] == "pending", "invalid pending negative rule")
            if s["context_state"] != "not_applicable": pending.append("negative_scope_pending:" + pid)
        negatives.append({"preference": deepcopy(pref), "scope": s, "design_scope_proposal": deepcopy(decision)})
    if direction["scale_status"] == "unknown": pending.append("scale_unknown")
    anchors = []
    for oid in sorted(required | comparison | scale):
        iid, o = observations[oid]
        anchors.append({"image_id": iid, "image_path": documents[iid]["image_path"], **deepcopy(o)})
    manifest = {"direction": deepcopy(direction), "H01_result_snapshot": frame["result_snapshot"],
        "H01_relations": [relations[m] for m in sorted(mids)], "library_snapshot": library["library_snapshot"],
        "candidate_pool_kind": POOL_KIND, "full_library_image_ids": library["qualified_image_ids"], "carrier_rule": CARRIER_RULE,
        "example_bindings": deepcopy(direction["example_bindings"]), "feature_anchor_observations": anchors,
        "positive_audit": positives, "negative_audit": negatives, "pending": pending,
        "authority_identity": side["authority"]["identity"], "request_snapshot": prepared["request_snapshot"]}
    return {"direction_id": direction["direction_id"], "manifest": manifest, "manifest_snapshot": fingerprint(manifest),
        "status": "pending_Root_library_and_design_decision", "allowed_alignment_modes": ["exploration"],
        "example_images_are_not_candidate_pool": True, "grouping_requests": [], "human_designer_actually_reviewed": False}


def accept_proposal(config, prepared, response_path):
    current = prepare_request(config)
    require(current == prepared, "exploratory preparation no longer binds current source/version")
    reply, source, raw = read_response(response_path)
    from jsonschema import Draft202012Validator
    errors = list(Draft202012Validator(prepared["response_schema"]).iter_errors(reply))
    require(not errors, "invalid exploratory response schema")
    require(reply["schema_version"] == RESPONSE_SCHEMA and reply["request_snapshot"] == prepared["request_snapshot"], "stale exploration response")
    index_by(reply["directions"], "direction_id")
    frames = {f["frame_id"]: f for f in prepared["side_table"]["frames"]}
    cards = [validate_direction(d, frames[d["frame_id"]], prepared) for d in reply["directions"]]
    result = {"schema_version": "prism.exploratory_H02_draft.v1", "algorithm_version": VERSION, "mode": "proposal_only",
        "source_response": source, "request_snapshot": prepared["request_snapshot"], "library_snapshot": prepared["side_table"]["library"]["library_snapshot"],
        "candidate_pool_kind": POOL_KIND, "cards": cards, "grouping_requests": [], "human_designer_actually_reviewed": False}
    result["draft_snapshot"] = fingerprint(result)
    require(Path(source["path"]).read_bytes() == raw, "response changed during acceptance")
    return result
