"""Lossless JSON DAG and path-prefix encoding; no text summarization."""
from collections import Counter
from copy import deepcopy
import json
from prism_runtime.contracts import require


def _json(v):
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def compact(value):
    prefixes, prefix_ids = {}, {}
    def paths(v):
        if isinstance(v, str) and len(v) > 70 and len(v) > 2 and v[1] == ":" and v[2] in "/\\":
            if "#/objects/" in v:
                prefix, suffix = v.split("#/objects/", 1); prefix += "#/objects/"
            else:
                cut = max(v.rfind("/"), v.rfind("\\")) + 1
                prefix, suffix = v[:cut], v[cut:]
            if prefix not in prefix_ids:
                ident = "P" + str(len(prefix_ids))
                prefix_ids[prefix] = ident; prefixes[ident] = prefix
            return {"$path": [prefix_ids[prefix], suffix]}
        if isinstance(v, dict):
            if set(v) in ({"$path"}, {"$literal_object"}, {"$node"}):
                return {"$literal_object": [[k, paths(x)] for k, x in v.items()]}
            return {k: paths(x) for k, x in v.items()}
        if isinstance(v, list): return [paths(x) for x in v]
        return deepcopy(v)
    path_encoded = paths(value)
    counts, examples = Counter(), {}
    def census(v):
        if isinstance(v, (dict, list, str)):
            key = _json(v)
            if len(key) >= 16:
                counts[key] += 1; examples.setdefault(key, v)
        if isinstance(v, dict):
            for x in v.values(): census(x)
        elif isinstance(v, list):
            for x in v: census(x)
    census(path_encoded)
    keys = [k for k, n in counts.items() if n > 1 and (len(k) - 16) * n - len(k) > 28]
    node_ids = {k: "N" + str(i) for i, k in enumerate(keys)}
    def encode(v, own=None):
        key = _json(v) if isinstance(v, (dict, list, str)) else None
        if key in node_ids and key != own: return {"$node": node_ids[key]}
        if isinstance(v, dict): return {k: encode(x) for k, x in v.items()}
        if isinstance(v, list): return [encode(x) for x in v]
        return deepcopy(v)
    result = {"data": encode(path_encoded), "shared_nodes": {node_ids[k]: encode(examples[k], k) for k in keys}, "path_prefixes": prefixes}
    require(expand(result) == value, "lossless material codec round trip failed")
    return result


def expand(packed):
    nodes, prefixes = packed["shared_nodes"], packed["path_prefixes"]
    def decode(v, seen=frozenset()):
        if isinstance(v, dict) and set(v) == {"$node"}:
            key = v["$node"]
            require(key in nodes and key not in seen, "unknown or cyclic shared node")
            return decode(nodes[key], seen | {key})
        if isinstance(v, dict) and set(v) == {"$path"}:
            parts = decode(v["$path"], seen)
            require(len(parts) == 2 and parts[0] in prefixes, "unknown path prefix")
            return prefixes[parts[0]] + parts[1]
        if isinstance(v, dict) and set(v) == {"$literal_object"}:
            return {k: x for k, x in decode(v["$literal_object"], seen)}
        if isinstance(v, dict): return {k: decode(x, seen) for k, x in v.items()}
        if isinstance(v, list): return [decode(x, seen) for x in v]
        return deepcopy(v)
    return decode(packed["data"])


def material_rows(data):
    """Typed row tables eliminate repeated column names/units/regions/IDs."""
    output = deepcopy(data)
    fields, regions, states = {}, {}, {}
    indices = [{}, {}, {}]
    def ref(table, lookup, value, prefix):
        key = _json(value)
        if key not in lookup:
            ident = prefix + str(len(table)); lookup[key] = ident; table[ident] = deepcopy(value)
        return lookup[key]
    for material in output["materials"]:
        prefix = material["image_id"] + ":a"
        def oid(value):
            suffix = value[len(prefix):] if value.startswith(prefix) else ""
            return int(suffix) if len(suffix) == 4 and suffix.isdigit() else value
        known = []
        for o in material.pop("known_observations"):
            f = ref(fields, indices[0], {k: o[k] for k in ("parameter_id", "parameter_name", "unit")}, "F")
            r = ref(regions, indices[1], o["region_ref"], "G")
            known.append([oid(o["observation_id"]), f, o["object_id"], o["reference_object_id"], o["value"], r])
        unavailable = []
        for u in material.pop("unavailable_units"):
            s = ref(states, indices[2], {k: u[k] for k in ("value_status", "disposition", "program_errors")}, "S")
            unavailable.append([oid(u["observation_id"]), u["parameter_id"], u["object_id"], u["reference_object_id"], s])
        material["observation_id_integer_prefix"] = prefix
        material["known_rows"] = known
        material["unavailable_rows"] = unavailable
    packed = {"data": output, "material_encoding": {"fields": fields, "regions": regions, "states": states,
        "known_columns": ["observation_id_suffix_or_string", "field_ref", "object_id", "reference_object_id", "value", "region_ref"],
        "unavailable_columns": ["observation_id_suffix_or_string", "parameter_id", "object_id", "reference_object_id", "state_ref"],
        "integer_observation_id_suffix_width": 4}}
    require(expand_material_rows(packed) == data, "material row round trip failed")
    return packed


def expand_material_rows(packed):
    output = deepcopy(packed["data"])
    tables = packed["material_encoding"]
    for material in output["materials"]:
        prefix = material.pop("observation_id_integer_prefix")
        def oid(value): return prefix + str(value).zfill(4) if type(value) is int else value
        material["known_observations"] = [
            {"observation_id": oid(row[0]), **deepcopy(tables["fields"][row[1]]), "object_id": row[2], "reference_object_id": row[3],
             "value": deepcopy(row[4]), "region_ref": deepcopy(tables["regions"][row[5]])} for row in material.pop("known_rows")]
        material["unavailable_units"] = [
            {"observation_id": oid(row[0]), "parameter_id": row[1], "object_id": row[2], "reference_object_id": row[3],
             **deepcopy(tables["states"][row[4]])} for row in material.pop("unavailable_rows")]
    return output
