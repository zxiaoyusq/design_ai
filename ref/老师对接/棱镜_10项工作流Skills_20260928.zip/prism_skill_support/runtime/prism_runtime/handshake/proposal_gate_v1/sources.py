"""Actual H01 replay and official persisted projection loading, read-only."""
from copy import deepcopy
import hashlib
from pathlib import Path
from prism_runtime.contracts import require, read_json
from ..common import fingerprint
from ..admission import reference_pool


def identity(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def load_frame(spec, mode=None):
    from ..compact_context_v1 import accept_theme_response as compact_accept
    from ..matrix_state_bridge_v1 import accept_response_file as matrix_accept
    from ..relation_repair_v1 import accept_repair
    side = read_json(spec["side_table_path"])
    request = read_json(spec["request_path"])
    inputs = side["inputs"]
    opts = {k: inputs[k] for k in ("review_context", "execution_scope_context", "design_intent_context", "admission_context")}
    selected_mode = mode or spec.get("mode", "consensus")
    refs = {k: identity(spec[k]) for k in ("request_path", "side_table_path")}
    if spec["consumer"] == "compact_v1":
        refs["response_path"] = identity(spec["response_path"])
        result = compact_accept(inputs["bundle"], inputs["saved_profile"], request, side, read_json(spec["response_path"]), mode=selected_mode, **opts)
    elif spec["consumer"] == "matrix_state_bridge_v1":
        refs["response_path"] = identity(spec["response_path"])
        result = matrix_accept(inputs["bundle"], inputs["saved_profile"], request, side, spec["response_path"], mode=selected_mode, **opts)
    elif spec["consumer"] == "relation_repair_v1":
        refs.update({k: identity(spec[k]) for k in ("repair_prepared_path", "repair_response_path")})
        prepared = read_json(spec["repair_prepared_path"])
        require(prepared["source_identities"]["request"] == refs["request_path"] and
                prepared["source_identities"]["side_table"] == refs["side_table_path"], "repair frame uses another H01 input")
        result = accept_repair(prepared, spec["repair_response_path"], mode=selected_mode)
    else:
        raise ValueError("unsupported H01 consumer")
    if spec.get("accepted_result_path") and mode is None:
        refs["accepted_result_path"] = identity(spec["accepted_result_path"])
        require(read_json(spec["accepted_result_path"]) == result, "saved H01 acceptance differs from official replay")
    return {"frame_id": spec["frame_id"], "spec": deepcopy(spec), "source_identities": refs,
            "inputs": inputs, "request": request, "side_table": side, "result": result,
            "result_snapshot": fingerprint(result), "options": opts}


def load_projections(paths):
    from prism_runtime.clustering.local_cmf_bridge_v1 import load_verified_projection
    outputs, seen = [], set()
    for path in paths:
        document, receipt = load_verified_projection(path)
        require(document["image_id"] not in seen, "duplicate projection image")
        seen.add(document["image_id"])
        outputs.append({"document": document, "receipt": receipt, "path": str(Path(path).resolve())})
    return outputs


def authority(path):
    record = read_json(path)
    kind = record.get("authority_kind")
    require(kind in {"user_delegated_ai", "synthetic_protocol_fixture"}, "explicit delegated or fixture authority required")
    require(record.get("human_designer_actually_reviewed") is False, "this interface cannot claim a real human design review")
    if kind == "user_delegated_ai":
        require(record.get("schema_version") == "prism.user_delegated_design_confirmation.v1" and
                record.get("requires_stored_algorithm_proposals") is True and record.get("decisions_must_be_traceable") is True,
                "delegation must require stored traceable proposals")
        require(record.get("verbatim_user_instruction") and any("H02" in s for s in record.get("scope", [])), "H02 delegation is absent")
    else:
        require(record.get("fixture_only") is True, "fixture authority must be explicitly synthetic")
    return {"identity": identity(path), "record": record}


def image_catalog(projections, registered_ids):
    catalog = []
    for entry in projections:
        d = entry["document"]
        catalog.append({"image_id": d["image_id"], "source_kind": d["source_kind"], "image_path": d["image_path"],
            "source_projection": entry["receipt"]["projection_identity"], "reference_eligible": d["image_id"] in registered_ids,
            "objects": deepcopy(d["objects"]),
            "observations": [{k: deepcopy(o.get(k)) for k in ("observation_id", "parameter_id", "parameter_name", "object_id",
                "reference_object_id", "value", "value_status", "unit", "region_ref", "local_cmf_review", "dependency_object_ids", "dependency_observation_ids")}
                for o in d["observations"]],
            "unavailable_units": [{k: deepcopy(u.get(k)) for k in ("observation_id", "parameter_id", "object_id", "reference_object_id",
                "value_status", "value", "disposition", "program_errors", "model_review", "dependency_object_ids", "dependency_observation_ids")}
                for u in d["cmf_admission"]["all_cmf_units"] if u.get("admitted") is not True],
            "not_checked_parameter_ids": deepcopy(d["cmf_admission"]["not_checked_parameter_ids"]),
            "out_of_scope_parameter_ids": deepcopy(d["cmf_admission"]["out_of_scope_parameter_ids"]),
            "review_issues": deepcopy(d["cmf_admission"].get("review_issues", [])),
            "original_r17_validation": deepcopy(d["cmf_admission"].get("original_r17_validation")),
            "source_validation": deepcopy(d.get("source_validation")),
            "no_whole_image_negative_clearance": True})
    return catalog
