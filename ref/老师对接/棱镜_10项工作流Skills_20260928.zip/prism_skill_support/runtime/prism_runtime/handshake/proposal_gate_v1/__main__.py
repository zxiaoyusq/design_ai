import argparse
from pathlib import Path
from prism_runtime.contracts import read_json, write_json, require
from .api import prepare_request, accept_proposal, compile_confirmed

parser = argparse.ArgumentParser(description="H02 proposal_only and user_delegated_ai gate; no model/API calls.")
parser.add_argument("action", choices=["prepare", "accept-proposal", "compile-confirmed"])
parser.add_argument("--config", required=True)
parser.add_argument("--prepared")
parser.add_argument("--response")
parser.add_argument("--draft")
parser.add_argument("--confirmation")
parser.add_argument("--output", required=True)
args = parser.parse_args()
require(not Path(args.output).exists(), "use a new versioned output file")
config = read_json(args.config)
if args.action == "prepare":
    result = prepare_request(config)
elif args.action == "accept-proposal":
    if not args.prepared or not args.response: parser.error("--prepared and --response required")
    result = accept_proposal(config, read_json(args.prepared), args.response)
else:
    if not args.prepared or not args.draft or not args.confirmation: parser.error("--prepared --draft --confirmation required")
    result = compile_confirmed(config, read_json(args.prepared), read_json(args.draft), args.confirmation)
write_json(args.output, result)
print(args.output)
