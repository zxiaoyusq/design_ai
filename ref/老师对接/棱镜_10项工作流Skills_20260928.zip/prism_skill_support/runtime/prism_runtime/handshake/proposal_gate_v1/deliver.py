"""Offline self-assessment and actual dependency inspection; no H02 inference."""
from copy import deepcopy
import argparse
import io
from pathlib import Path
import unittest
from prism_runtime.contracts import read_json, write_json, require
from ..admission import reference_pool
from .api import prepare_request, response_schema_template, VERSION
from .sources import identity, image_catalog, load_projections, authority
from .tests import GateTests

PROJECT = Path(__file__).resolve().parents[3]
LOOP = PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
CLOSURE = LOOP / "closure-20260927"
OUTPUT = PROJECT / "outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/CLOSURE-H02-001"


def deliver(output=OUTPUT):
    output = Path(output).resolve()
    require(not (output / "self-assessment.json").exists(), "use a fresh delivery output directory")
    output.mkdir(parents=True, exist_ok=True)
    peer = read_json(PROJECT / "outputs/prism-algorithm-loop-20260926/modules/clustering/closure-local-cmf-v1/handoff.json")
    config = {"frames": [{"frame_id": "source-scene-01-original-t2", "consumer": "matrix_state_bridge_v1", "mode": "exploration",
        "request_path": str(CLOSURE / "h01/scene01/request.json"), "side_table_path": str(CLOSURE / "h01/scene01/side-table.json"),
        "response_path": str(CLOSURE / "calls/H01-S01-t2/answer.json")}],
        "projection_paths": [str(CLOSURE / "images" / iid / "cmf.image-dna.json") for iid in ("R002", "R005", "R009")],
        "delegation_path": str(CLOSURE / "user-delegation.json"), "inventory_path": peer["inventory"]["preparation_ref"]}
    protected = {Path(config["delegation_path"]), Path(config["inventory_path"])}
    protected.update(Path(p) for p in config["projection_paths"])
    protected.update(Path(p) for k, p in config["frames"][0].items() if k.endswith("_path"))
    for folder in ("handshake/compact_context_v1", "handshake/context_sidecar_v1", "handshake/matrix_state_bridge_v1",
                   "handshake/relation_repair_v1", "clustering/local_cmf_bridge_v1", "dna/local_cmf_v1", "dna/local_cmf_v1_1"):
        protected.update(p for p in (PROJECT / "prism_runtime" / folder).glob("*.*") if p.is_file())
    protected.update((PROJECT / "prism_runtime/handshake").glob("*.py"))
    protected.update((PROJECT / "prism_runtime/clustering").glob("*.py"))
    protected.update((PROJECT / "prism_runtime/preferences").glob("*.py"))
    protected.add(PROJECT / "prism_runtime/CONTRACT.md")
    before = [identity(p) for p in sorted(protected)]
    GateTests.scratch_root = output / "_test_tmp"
    stream = io.StringIO()
    tested = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(GateTests))
    (output / "unit-tests.txt").write_text(stream.getvalue(), encoding="utf-8")
    dependency = prepare_request(config)
    write_json(output / "config.original-t2-dependency.json", config)
    write_json(output / "actual-dependency-inspection.json", dependency)
    template = deepcopy(config)
    template["frames"][0] = {"frame_id": "source-scene-01-repair", "consumer": "relation_repair_v1", "mode": "exploration",
        "request_path": config["frames"][0]["request_path"], "side_table_path": config["frames"][0]["side_table_path"],
        "repair_prepared_path": str(PROJECT / "outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/CLOSURE-H01-003/prepared.json"),
        "repair_response_path": "__ROOT_ACTUAL_REPAIR_RESPONSE_REQUIRED__"}
    write_json(output / "config.actual-repair.template.json", template)
    write_json(output / "response.schema-template.json", response_schema_template())
    side = read_json(config["frames"][0]["side_table_path"])
    original = side["inputs"]
    pool = reference_pool(original["bundle"], [t["theme_id"] for t in original["bundle"]["themes"]], original["admission_context"])
    projections = load_projections(config["projection_paths"])
    catalog = image_catalog(projections, set(pool["eligible_image_ids"]))
    write_json(output / "actual-three-image-catalog.json", catalog)
    delegation = authority(config["delegation_path"])
    checks = {
        "actual_t2_failure_not_fabricated_as_H01_acceptance": not dependency["model_call_ready"] and not dependency["messages"] and not dependency["grouping_requests"]
            and any(d["status"] == "H01_rejected" and "same-category" in d["error"] for d in dependency["dependencies"]),
        "three_official_replays_preserve_33_43_43": [len(p["document"]["observations"]) for p in projections] == [33, 43, 43],
        "calibration_examples_not_registered_references": all(c["source_kind"] == "calibration" and c["reference_eligible"] is False for c in catalog),
        "nine_registered_references_unchanged": len(pool["eligible_image_ids"]) == 9,
        "all_source_objects_preserved": all(c["objects"] == p["document"]["objects"] for c, p in zip(catalog, projections)),
        "all_unavailable_units_preserved": all(len(c["unavailable_units"]) == sum(u.get("admitted") is not True for u in p["document"]["cmf_admission"]["all_cmf_units"]) for c, p in zip(catalog, projections)),
        "delegation_is_AI_not_human_review": delegation["record"]["authority_kind"] == "user_delegated_ai" and delegation["record"]["human_designer_actually_reviewed"] is False,
        "official_projection_replay_has_zero_model_calls": all(p["receipt"]["model_calls"] == 0 and p["receipt"]["passed"] is True for p in projections),
    }
    after = [identity(p["path"]) for p in before]
    checks["protected_files_unchanged"] = before == after
    write_json(output / "source-manifest.json", {"protected_before": before, "protected_after": after, "all_unchanged": before == after,
        "new_module_files": [identity(p) for p in sorted(Path(__file__).parent.iterdir()) if p.is_file()]})
    report = {"issue_id": "CLOSURE-H02-001", "version": VERSION,
        "status": "owner_offline_protocol_qualified_actual_H02_pending" if tested.wasSuccessful() and all(checks.values()) else "needs_repair",
        "tests": {"run": tested.testsRun, "failures": len(tested.failures), "errors": len(tested.errors)},
        "actual_checks": checks, "protected_file_count": len(before), "actual_H02_model_response_generated": False,
        "actual_grouping_request_generated": False, "actual_delegated_confirmation_created": False,
        "new_model_calls": 0, "new_paid_calls": 0, "fast_mode_used": False, "independent_holdout": False,
        "limits": ["Original t2 is intentionally inspected as its preserved failed version, not as the status of any later Root repair.",
                   "Supply Root's actual accepted repair/other scene artifacts to the config; no real H01/H02 response was fabricated.",
                   "End-to-end positive control uses explicit synthetic persisted producer fixtures; numeric-scale formatting uses a separate in-memory fixture.",
                   "Current actual projection replay covers only the three cited calibration images, not all120 or executable trend grouping.",
                   "Root independent review/freeze and its separate user_delegated_ai decision remain required before execution."]}
    write_json(output / "self-assessment.json", report)
    print(report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(OUTPUT))
    args = parser.parse_args()
    r = deliver(args.output)
    raise SystemExit(0 if r["status"] == "owner_offline_protocol_qualified_actual_H02_pending" else 1)
