"""Synthetic-only persisted producer + H01 + H02 gate protocol; no inference."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

from prism_runtime.contracts import read_json, write_json, ContractError
from ..examples import fixture
from ..context_sidecar_v1.tests import reviewed
from ..compact_context_v1.tests import intent, response_fixture
from ..compact_context_v1 import prepare_theme_request, accept_theme_response
from ..admission import prepare_fixture_admission
from .api import prepare_request, accept_proposal, compile_confirmed, RESPONSE_SCHEMA, CONFIRM_SCHEMA
from .sources import identity


class GateTests(unittest.TestCase):
    scratch_root = Path(__file__).resolve().parents[3] / "outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/CLOSURE-H02-001/_test_tmp"

    @classmethod
    def setUpClass(cls):
        from prism_runtime.dna.local_cmf_v1 import pipeline, common as c
        from prism_runtime.dna.local_cmf_v1.test_boundaries import supported
        cls.scratch_root.mkdir(parents=True, exist_ok=True)
        cls.temp = tempfile.TemporaryDirectory(dir=cls.scratch_root)
        cls.root = Path(cls.temp.name).resolve()
        assert cls.root.is_relative_to(cls.scratch_root.resolve())
        photo = c.OPT / "round4/cases/camera.jpg"
        source = c.write_new(cls.root / "fixture-manifest.json", {"records": [{"image_id": "synthetic-camera", "sha256": c.file_hash(photo), "source_kind": "synthetic", "basis": "SYNTHETIC protocol only"}]})
        folder = cls.root / "producer"
        pipeline.prepare(photo, "synthetic-camera", "synthetic", source, folder)
        raw = c.OPT / "round4/trials/r17-camera/model-output.json"
        def record(stage, output, prompt, schema):
            return c.write_new(cls.root / (stage + "-fixture-record.json"), {"stage": stage, "model": "gpt-6-astra", "service_tier": "default",
                "image_sha256": c.file_hash(photo), "prompt_sha256": c.file_hash(prompt), "schema_sha256": c.file_hash(schema), "schema_ref": str(schema),
                "raw_output_sha256": c.file_hash(output), "call_id": "synthetic-" + stage, "execution_kind": "synthetic_fixture", "source_ref": str(source)})
        pipeline.accept(folder, raw, record("primary", raw, folder / "primary.prompt.txt", folder / "primary.schema.json"))
        response = c.write_new(cls.root / "fixture-review.json", supported(c.read(folder / "review.proposal.json")))
        pipeline.accept_review(folder, response, record("review", response, folder / "review.prompt.txt", folder / "review.schema.json"))
        cls.projection = folder / "cmf.image-dna.json"
        pipeline.verify_projection(cls.projection)
        cls.dna = read_json(cls.projection)
        cls.observation = next(o for o in cls.dna["observations"] if o["parameter_id"] == "OPT-002" and o["value"] != "镜面外观")
        b, p, t, _ = fixture()
        b["images"] = [deepcopy(cls.dna)]
        b["themes"][0].update(image_ids=["synthetic-camera"], reference_image_ids=["synthetic-camera"])
        b["evidence"][0]["image_ids"] = ["synthetic-camera"]
        b["evidence"][2]["text"] = "合成接口样例喜欢这一表面值：" + str(cls.observation["value"])
        p["preferences"][1].update(summary=b["evidence"][2]["text"], quotes=[{"evidence_id": "R2", "text": b["evidence"][2]["text"]}])
        p["preferences"][1]["features"][0]["value"] = deepcopy(cls.observation["value"])
        p, rc = reviewed(b, p)
        options = dict(review_context=rc, design_intent_context=intent(), admission_context=prepare_fixture_admission(b))
        package = prepare_theme_request(b, p, **options)
        answer = response_fixture(package, t["proposals"])
        accepted = accept_theme_response(b, p, package["request"], package["side_table"], answer, **options)
        for name, doc in (("h01-request", package["request"]), ("h01-side", package["side_table"]), ("h01-response", answer), ("h01-accepted", accepted)):
            write_json(cls.root / (name + ".json"), doc)
        write_json(cls.root / "authority.json", {"authority_kind": "synthetic_protocol_fixture", "fixture_only": True, "human_designer_actually_reviewed": False})
        cls.config = {"frames": [{"frame_id": "fixture-frame", "consumer": "compact_v1", "mode": "consensus",
            "request_path": str(cls.root / "h01-request.json"), "side_table_path": str(cls.root / "h01-side.json"),
            "response_path": str(cls.root / "h01-response.json"), "accepted_result_path": str(cls.root / "h01-accepted.json")}],
            "projection_paths": [str(cls.projection)], "delegation_path": str(cls.root / "authority.json")}
        cls.prepared = prepare_request(cls.config)

    @classmethod
    def tearDownClass(cls):
        assert cls.root.is_relative_to(cls.scratch_root.resolve())
        cls.temp.cleanup()

    def setUp(self):
        o = self.observation
        self.direction = {"direction_id": "SYN-D1", "frame_id": "fixture-frame", "title": "合成表面接口样例", "scene": "office",
            "theme_id": "TH1", "h01_match_ids": ["M1"], "preference_ids": ["P2"], "target_user_ids": ["U1"],
            "relation_basis": "direct_support", "transfer_scope": "same_category", "shared_principle": "合成表面测试", "explanation": "仅接口fixture，不是实际设计结论。",
            "candidate_bindings": [{"image_id": "synthetic-camera", "object_id": o["object_id"]}], "required_observation_ids": [o["observation_id"]],
            "comparison_observation_ids": [], "scale_observation_ids": [], "scale_status": "reference_region_only", "hypotheses": [],
            "negative_scope_proposals": [{"preference_id": "P3", "disposition": "proposed", "scope_kind": "candidate_bindings", "target_image_ids": [],
                "target_bindings": [{"image_id": "synthetic-camera", "object_id": o["object_id"]}], "reason": "SYNTHETIC carrier scope fixture"}], "open_questions": []}

    def draft(self, direction=None, response_extra=None):
        response = {"schema_version": RESPONSE_SCHEMA, "request_snapshot": self.prepared["request_snapshot"], "directions": [direction or self.direction]}
        response.update(response_extra or {})
        write_json(self.root / "h02-fixture-response.json", response)
        return accept_proposal(self.config, self.prepared, self.root / "h02-fixture-response.json")

    def confirmation(self, draft):
        receipt = {"schema_version": CONFIRM_SCHEMA, "draft_snapshot": draft["draft_snapshot"], "authority_kind": "synthetic_protocol_fixture",
            "authority_ref": identity(self.config["delegation_path"]), "human_designer_actually_reviewed": False,
            "recorded_by": "SYNTHETIC protocol fixture", "reason": "Not a real user/agent decision",
            "selected_directions": [{"direction_id": "SYN-D1", "manifest_snapshot": draft["cards"][0]["manifest_snapshot"], "alignment_mode": "consensus"}]}
        write_json(self.root / "confirmation.json", receipt)
        return self.root / "confirmation.json"

    def test_proposal_only_never_creates_grouping_requests_or_confirmation(self):
        draft = self.draft()
        self.assertEqual(draft["grouping_requests"], [])
        self.assertFalse(draft["human_designer_actually_reviewed"])
        self.assertEqual(draft["cards"][0]["blocking_issues"], [])

    def test_confirmed_fixture_compiles_existing_H02_and_returns_guards(self):
        draft = self.draft()
        out = compile_confirmed(self.config, self.prepared, draft, self.confirmation(draft))
        self.assertEqual(len(out["grouping_requests"]), 1)
        self.assertFalse(out["human_designer_actually_reviewed"])
        self.assertFalse(out["clustering_executed"])
        req = out["grouping_requests"][0]
        self.assertFalse(req["provenance"]["theme_designer_confirmed"])
        self.assertEqual(req["negative_audit_ids"], ["P3"])
        self.assertEqual(req["forbidden_features"][0]["scope"]["kind"], "candidate_bindings")
        self.assertTrue(out["guarded_transports"][0]["coverage_audits"][0]["guards"])

    def test_model_cannot_return_confirmation_or_grouping_request(self):
        for extra in ({"user_confirmed": True}, {"grouping_requests": []}):
            with self.subTest(extra=extra), self.assertRaises(ContractError): self.draft(response_extra=extra)

    def test_unreviewed_or_invented_observation_cannot_be_a_feature_or_scale(self):
        for field in ("required_observation_ids", "scale_observation_ids"):
            d = deepcopy(self.direction); d[field] = ["unknown:observation"]
            with self.subTest(field=field), self.assertRaises(ContractError): self.draft(d)

    def test_applicable_negative_cannot_be_omitted_or_changed_to_NA(self):
        for case in ("omit", "NA"):
            d = deepcopy(self.direction)
            if case == "omit": d["negative_scope_proposals"] = []
            else: d["negative_scope_proposals"][0].update(disposition="not_applicable", scope_kind="not_applicable", target_bindings=[])
            with self.subTest(case=case), self.assertRaises(ContractError): self.draft(d)

    def test_pending_negative_remains_blocked_even_after_confirmation(self):
        d = deepcopy(self.direction)
        d["negative_scope_proposals"][0].update(disposition="pending", scope_kind="pending", target_bindings=[])
        draft = self.draft(d)
        with self.assertRaisesRegex(ContractError, "blocked"):
            compile_confirmed(self.config, self.prepared, draft, self.confirmation(draft))

    def test_wrong_scene_or_target_or_carrier_is_rejected(self):
        for field, value in (("scene", "home"), ("target_user_ids", ["unknown-user"]), ("candidate_bindings", [{"image_id": "synthetic-camera", "object_id": "missing"}])):
            d = deepcopy(self.direction); d[field] = value
            with self.subTest(field=field), self.assertRaises(ContractError): self.draft(d)

    def test_source_scale_retains_original_unit_value_and_reference(self):
        # Explicit in-memory numeric protocol fixture for the private card
        # mapper. Public accept always replays persisted producer verification;
        # the separate invented-observation test proves this cannot enter it.
        from .api import _card, _core
        numeric = deepcopy(self.observation)
        numeric.update(observation_id="SYNTHETIC-numeric-unit", parameter_id="TEX-003", value=0.125, unit="单元尺寸／对象尺寸")
        prepared = deepcopy(self.prepared)
        prepared["side_table"]["projections"][0]["document"]["observations"].append(numeric)
        observations = {o["observation_id"]: ("synthetic-camera", o) for o in prepared["side_table"]["projections"][0]["document"]["observations"]}
        d = deepcopy(self.direction)
        d.update(scale_status="source_values", scale_observation_ids=[numeric["observation_id"]], required_observation_ids=[numeric["observation_id"]],
                 candidate_bindings=[{"image_id": "synthetic-camera", "object_id": numeric["object_id"]}], relation_basis="exploratory_hypothesis",
                 hypotheses=[{"observation_id": numeric["observation_id"], "reason": "SYNTHETIC numeric scale hypothesis"}])
        d["negative_scope_proposals"][0]["target_bindings"] = deepcopy(d["candidate_bindings"])
        frame = prepared["side_table"]["frames"][0]
        card = _card(d, frame, prepared, observations)
        source = card["manifest"]["known_source_values"][0]
        self.assertEqual(source["value"], numeric["value"])
        self.assertEqual(source["unit"], numeric["unit"])
        self.assertEqual(source["reference_object_id"], numeric["reference_object_id"])
        self.assertEqual(_core(d, frame, observations)["required_features"], [{"parameter_id": "TEX-003", "allowed_values": [0.125]}])

    def test_gloss_label_cannot_be_relabelled_as_numeric_scale(self):
        d = deepcopy(self.direction)
        d.update(scale_status="source_values", scale_observation_ids=[self.observation["observation_id"]])
        with self.assertRaises(ContractError): self.draft(d)

    def test_cached_H01_acceptance_cannot_replace_actual_replay(self):
        path = Path(self.config["frames"][0]["accepted_result_path"])
        raw = path.read_bytes()
        try:
            wrong = read_json(path); wrong["theme_candidates"] = []
            write_json(path, wrong)
            prepared = prepare_request(self.config)
            self.assertFalse(prepared["model_call_ready"])
            self.assertEqual(prepared["dependencies"][0]["status"], "H01_rejected")
        finally: path.write_bytes(raw)

    def test_scope_targets_cannot_escape_explicit_carrier_selection(self):
        d = deepcopy(self.direction)
        d["negative_scope_proposals"][0]["target_bindings"][0]["object_id"] = "not-selected"
        with self.assertRaisesRegex(ContractError, "carrier scope expanded"): self.draft(d)

    def test_unknown_scale_is_not_cleared_by_confirmation(self):
        d = deepcopy(self.direction); d["scale_status"] = "unknown"
        draft = self.draft(d)
        with self.assertRaisesRegex(ContractError, "scale_unknown"):
            compile_confirmed(self.config, self.prepared, draft, self.confirmation(draft))

    def test_confirmation_binds_entire_manifest_and_draft(self):
        draft = self.draft(); path = self.confirmation(draft)
        for key in ("draft_snapshot", "authority_ref"):
            record = read_json(path); record[key] = "stale"
            write_json(self.root / "bad-confirmation.json", record)
            with self.subTest(key=key), self.assertRaises(ContractError):
                compile_confirmed(self.config, self.prepared, draft, self.root / "bad-confirmation.json")
        record = read_json(path); record["selected_directions"][0]["manifest_snapshot"] = "changed-value"
        write_json(self.root / "bad-confirmation.json", record)
        with self.assertRaises(ContractError): compile_confirmed(self.config, self.prepared, draft, self.root / "bad-confirmation.json")

    def test_human_review_flag_cannot_be_forged(self):
        draft = self.draft(); path = self.confirmation(draft)
        record = read_json(path); record["human_designer_actually_reviewed"] = True
        write_json(self.root / "bad-confirmation.json", record)
        with self.assertRaises(ContractError): compile_confirmed(self.config, self.prepared, draft, self.root / "bad-confirmation.json")

    def test_missing_actual_H01_is_a_dependency_not_a_fabricated_response(self):
        config = deepcopy(self.config); config["frames"][0]["response_path"] = str(self.root / "not-arrived.json")
        result = prepare_request(config)
        self.assertFalse(result["model_call_ready"])
        self.assertEqual(result["messages"], [])
        self.assertEqual(result["grouping_requests"], [])

    def test_persisted_projection_tamper_cannot_reuse_cached_approval(self):
        raw = self.projection.read_bytes()
        try:
            d = read_json(self.projection); d["observations"][0]["value"] = "tampered"
            write_json(self.projection, d)
            with self.assertRaises(ValueError): prepare_request(self.config)
        finally:
            self.projection.write_bytes(raw)

    def test_sparse_projection_does_not_clear_whole_image_negative(self):
        d = deepcopy(self.direction)
        d["negative_scope_proposals"][0].update(scope_kind="image", target_image_ids=["synthetic-camera"], target_bindings=[])
        draft = self.draft(d)
        out = compile_confirmed(self.config, self.prepared, draft, self.confirmation(draft))
        self.assertEqual(out["grouping_requests"][0]["forbidden_features"][0]["scope"]["kind"], "image")
        audit = out["guarded_transports"][0]["coverage_audits"][0]
        self.assertTrue(audit["guards"])
        self.assertFalse(audit["whole_image_qualification_created"])

if __name__ == "__main__":
    unittest.main()
