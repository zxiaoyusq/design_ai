# proposal_gate_v1 · CLOSURE-H02-001

`handshake-proposal-gate-v1.0.0` 是 H02 最小准备、proposal_only 接收和代理确认后编译封装。
不修改冻结 compact v1、0.3.2、context sidecar、DNA 或聚类器；不请求模型/API，不创建确认记录。
Root 统一标准 Astra 推理，H02 使用剩余的两次合并提案预算，不用 Fast。

用户最新授权“人确认的环节由你来代替”，因此生产确认类型是 **user_delegated_ai**，由授权的 Root 任务另存决定。
所有输出保留 human_designer_actually_reviewed=false；六大风格、模型草案、9 图资格、代理选择与真实受访者偏好互不替代。

## 三个接口

```python
from prism_runtime.handshake.proposal_gate_v1 import prepare_request, accept_proposal, compile_confirmed
prepared = prepare_request(config)
# 仅在 model_call_ready=true 时，Root 才给模型 messages + response_schema。
draft = accept_proposal(config, prepared, actual_model_response_path)
# draft 永远没有 GroupingRequest。Root 看完整 cards 后另存代理决定文件。
compiled = compile_confirmed(config, prepared, draft, root_confirmation_path)
```

prepare 支持把多个同一原始 corpus/profile/registry/intent/admission 的 H01 场景合并为一份 H02 请求。
每个 frame 从实际回复重新调用原 H01 consumer；可选 accepted_result_path 必须等于重放结果。
支持 compact_v1、matrix_state_bridge_v1、relation_repair_v1。不是信任 cached accepted=true。
缺真实文件、H01 拒绝、无关系或无已审核局部观察时，model_call_ready=false，messages 为空，返回明确依赖；不造 H01 成功。

每次 prepare/accept/compile 都通过聚类 owner 的 load_verified_projection 重放官方持久化投影验证。
当前桥接显式注册已获 Root 接受的 v1/v1.1；未知版本不能 fallback。请用附带 **Python 3.12**，因为现有 rpds 依赖为 cp312。

## config

```json
{
  "frames": [{
    "frame_id": "source-scene-01",
    "consumer": "relation_repair_v1",
    "mode": "exploration",
    "request_path": "原H01 request.json绝对路径",
    "side_table_path": "原H01 side-table.json绝对路径",
    "repair_prepared_path": "返修prepared.json绝对路径",
    "repair_response_path": "Root实际新返修回复绝对路径",
    "accepted_result_path": "可选：该mode下官方返回的完整纯result JSON"
  }],
  "projection_paths": ["实际cmf.image-dna.json绝对路径"],
  "delegation_path": "Root原user-delegation.json绝对路径",
  "inventory_path": "聚类owner原120图closure准备inventory绝对路径"
}
```

compact_v1 / matrix_state_bridge_v1 使用 response_path，不用两个 repair 路径。
inventory_path 在真实趋势执行的 prepare_guarded_view 中必需；proposal_only 可以先读取研究校准例子而不赋予资格。
源文件、所有草案字段、投影与审核回执、当前代码哈希一起绑定 request_snapshot。

## 模型草案和用户可审卡

模型只选择已同图程序+模型双审的 observation_id；宿主精确回填原 PID、原值、原单位、参照、区域与证据。
不能靠生成一个新值来补齐数据。所有 object、unknown/NA、未检查、错误及依赖保留在原 projection 旁表中；
模型只看原 known 与原审计，不会把消费方添加的 unknown guard 当图像证据。

每个方向含中文标题/场景/目标用户、具体 H01 match/主题、载体选择、required/comparison/scale 观察引用、关系/假设及负向范围提案。
cards 提供完整 H01 关系、原值/区域、正向原子证据与原条件、全量负向原话/条件/范围审计、允许档位和阻塞项。
模型需给所有当前目标下 applies 的负向指定 proposed/pending 范围；其余原负向也全部保留，宿主只沿用原范围求值器的 pending/NA，
不把 source context unknown 改成 NA。所有真正执行的负向 scope 仍走冻结 CT002 的双向审计。

尺度规则：

- source_values 只能取原 COL-009、TEX-003/004/008/009/013 的已审 numeric 值、原单位和 reference_object_id；原值加入 required_features 精确约束。
- reference_region_only 仅绑定来源图归一化区域例子，明确不是实物尺寸，也不是跨图的数值尺度条件；颜色/光泽等无可靠量值时可以这样展示。
- unknown 保持阻塞。色相/明度/光泽序数即使数字也不能冒充空间尺度；不换算毫米、不宣称物理实测。

required/scale 原值必须在每个选定载体上共同成立，不能跨载体拼凑。新颖值有明确 hypothesis，三档还须同时容纳关联的 H01 和 H02 关系。
只读 `response_schema_template()` 可给出通用结构；实际 prepare 才绑定真实 source IDs/token，未准备的模板不能作为实际请求。

## Root 的代理确认文件

```json
{
  "schema_version": "prism.h02_scoped_confirmation.v1",
  "authority_kind": "user_delegated_ai",
  "authority_ref": {"path": "Root原user-delegation.json路径", "sha256": "原文件字节SHA256"},
  "human_designer_actually_reviewed": false,
  "recorded_by": "Root",
  "recorder_thread_id": "与授权文件source_thread_id相同",
  "reason": "Root依据存储的算法草案选择的理由",
  "draft_snapshot": "draft中的精确值",
  "selected_directions": [{
    "direction_id": "草案现有方向ID",
    "manifest_snapshot": "该card中的精确值",
    "alignment_mode": "exploration"
  }]
}
```

确认绑定整份草案，以及每个方向的 H01/字段/原值/尺度/图片-载体/全负向范围，不是一个宽泛 true。
Root 可以选择草案中的方向与允许档位；改特征或范围必须成为新的草案版本后重新作代理决定。
代码核来源/哈希/范围，授权真实性由调用方 Root 的用户消息记录负责，不声称密码学证明身份。
synthetic_protocol_fixture 只供明确协议用例；一旦输入含真实 trend/calibration 图就不能用 fixture 确认。

## 确认后怎样继续

只对原主题池中已具资格的确认候选构造独立传输 bundle；保留原图身份，用 prepare_pid_view 的原 known+unknown 守卫替换传输观察。
研究刺激 DNA 不修改；重新 validate_reviewed_profile/ContextSession，若涉及 P01 指纹变化就拒绝，不重签审阅。
此有界版本针对原120图 synthetic simulation，旧选择接口使用 synthetic_assumption=true、designer_confirmed=false，
并单独记录真实 user_delegated_ai 设计决定，绝不把代理确认写成真人确认。真实访谈数据项目不走这个兼容分支。

执行仍调用原 select_themes/compile_directions 和 CT001/CT002；每个最终 GroupingRequest 再通过 prepare_guarded_view，覆盖全部正/负/比较 PID。
输出 guarded_transports 与完整 coverage_audits 给聚类 owner，自己不运行聚类、不改相似度。
GroupingRequest 的产生不代表整图排斥已排除；缺失覆盖在守卫中继续 unknown，下游可判 boundary，不能用稀疏投影证明不存在禁用特征。

## CLI 与复验

```text
python -B -m prism_runtime.handshake.proposal_gate_v1 prepare --config CONFIG --output NEW_PREPARED
python -B -m prism_runtime.handshake.proposal_gate_v1 accept-proposal --config CONFIG --prepared PREPARED --response ACTUAL_REPLY --output NEW_DRAFT
python -B -m prism_runtime.handshake.proposal_gate_v1 compile-confirmed --config CONFIG --prepared PREPARED --draft DRAFT --confirmation ROOT_DECISION --output NEW_COMPILED
```

输出必须是新文件。附带 Python 路径：`C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`。
单元测试走官方 synthetic 持久化 prepare/accept/review/verify 后再走真实代码链，0 推理；不会把协议 fixture 当实际模型语义。
数值尺度映射还有单独的显式内存 fixture 测试，不宣称是实图数值测量金标。
Root 可将 GateTests.scratch_root 设置到自己的新目录再运行，保持唯一写边界。
