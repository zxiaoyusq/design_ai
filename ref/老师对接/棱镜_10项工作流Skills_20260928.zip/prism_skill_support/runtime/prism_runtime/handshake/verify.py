"""Reproduce local tests, complete CLI examples and downstream compatibility."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import io
from pathlib import Path
import subprocess
import sys
import time
import unittest

from prism_runtime.contracts import read_json, write_json
from .api import compile_theme_handshake, select_themes, compile_directions
from .examples import export, negative_scope_fixture
from .semantic_cases import export_cases
from .scope_cases import export_cases as export_scope_cases
from .common import fingerprint
from .admission import prepare_fixture_admission


def run(output, admission_source=None):
    start = time.perf_counter()
    out = Path(output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    project = Path(__file__).resolve().parents[2]
    dependencies = [project / "prism_runtime/contracts.py", project / "prism_runtime/CONTRACT.md"]
    for name in ("preferences", "clustering", "quality"):
        dependencies.extend(sorted((project / "prism_runtime" / name).glob("*.py")))
    dependency_hashes = {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest() for p in dependencies}
    examples = out / "examples"
    summary = export(examples)
    semantic_regression = export_cases(out / "semantic-regression")
    negative_scope_cases = export_scope_cases(examples / "CT-002")
    log = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromName("prism_runtime.handshake.test_handshake")
    if admission_source:
        from . import test_admission
        test_admission.SOURCE = Path(admission_source).resolve()
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_admission))
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    (out / "test-results.txt").write_text(log.getvalue(), encoding="utf-8")
    commands = [
        ("prepare-theme", ["--output", str(out / "cli-h01-request.json")], "h01-request.json", "cli-h01-request.json"),
        ("accept-theme", ["--proposals", str(examples / "h01-proposals.json"), "--output", str(out / "cli-h01-result.json")], "h01-result.json", "cli-h01-result.json"),
        ("select", ["--theme-result", str(out / "cli-h01-result.json"), "--theme-id", "TH1", "--selection-id", "SYNTHETIC-S1", "--synthetic-assumption",
                    "--admission-context", str(examples / "reference-admission.fixture.json"), "--output", str(out / "cli-selection.json")], "theme-selection.json", "cli-selection.json"),
        ("prepare", ["--selection", str(out / "cli-selection.json"), "--output", str(out / "cli-h02-request.json")], "h02-request.json", "cli-h02-request.json"),
    ]
    for mode in summary["modes"]:
        commands.append(("accept", ["--selection", str(out / "cli-selection.json"), "--proposals", str(examples / "h02-proposals.json"),
                                    "--negative-scopes", str(examples / "negative-scopes.fixture.json"),
                                    "--mode", mode, "--output", str(out / ("cli-" + mode + ".json"))], "h02-" + mode + ".json", "cli-" + mode + ".json"))
    cli = []
    for action, extra, expected, actual in commands:
        cmd = [sys.executable, "-m", "prism_runtime.handshake", action, "--bundle", str(examples / "bundle.json"), "--profile", str(examples / "profile.json"), "--review-context", str(examples / "review-context.fixture.json"), *extra]
        proc = subprocess.run(cmd, capture_output=True, encoding="utf-8", errors="replace", timeout=30)
        same = proc.returncode == 0 and read_json(out / actual) == read_json(examples / expected)
        cli.append({"action": action, "output": actual, "exit_code": proc.returncode, "matches_function_output": same, "stderr": proc.stderr})
    admission_replay = None
    if admission_source:
        from .replay_admission import replay
        admission_replay = replay(admission_source, out / "actual-replay")
        source = Path(admission_source).resolve()
        cmd = [sys.executable, "-B", "-m", "prism_runtime.handshake", "prepare-admission",
               "--bundle", str(source / "inputs/bundle.json"), "--trends-result", str(source / "outputs/trends/themes.json"),
               "--material-manifest", str(source / "inputs/material-manifest.json"), "--output", str(out / "cli-reference-admission.json")]
        proc = subprocess.run(cmd, capture_output=True, encoding="utf-8", errors="replace", timeout=30)
        same = proc.returncode == 0 and read_json(out / "cli-reference-admission.json") == read_json(out / "actual-replay/reference-admission.json")
        cli.append({"action": "prepare-admission", "output": "cli-reference-admission.json", "exit_code": proc.returncode, "matches_function_output": same, "stderr": proc.stderr})
    downstream = {"status": "not_available", "requests": []}
    try:
        from prism_runtime.clustering import cluster_candidates
    except ImportError as exc:
        downstream["reason"] = str(exc)
    else:
        bundle, profile = read_json(examples / "bundle.json"), read_json(examples / "profile.json")
        review_context = read_json(examples / "review-context.fixture.json")
        for mode in summary["modes"]:
            for request in read_json(examples / ("h02-" + mode + ".json"))["grouping_requests"]:
                value = cluster_candidates(request, bundle["images"])
                name = "downstream-" + request["request_id"] + ".json"
                write_json(out / name, value)
                downstream["requests"].append({"request_id": request["request_id"], "status": value["status"],
                                               "input_errors": value.get("input_errors", []), "output": name})
        # Hold the target shell constant and add a separate mirrored background.
        probe = deepcopy(bundle)
        bg = deepcopy(probe["images"][0]["observations"][1])
        bg.update({"observation_id": "I1-background-mirror", "object_id": "background", "value": "镜面外观"})
        bg["region_ref"] = {"object_id": "background", "bbox_xyxy": [0, 0, 0.08, 0.08]}
        bg["evidence_refs"] = ["synthetic:I1:background"]
        probe["images"][0]["observations"].append(bg)
        h01 = compile_theme_handshake(probe, profile, read_json(examples / "h01-proposals.json"), review_context=review_context)
        selection = select_themes(probe, profile, h01, ["TH1"], selection_id="scope-probe", synthetic_assumption=True,
                                  review_context=review_context, admission_context=prepare_fixture_admission(probe))
        proposals = read_json(examples / "h02-proposals.json")
        proposals["selection_snapshot"] = fingerprint(selection)
        negative_scopes = negative_scope_fixture(probe, profile, selection, proposals)
        request = compile_directions(probe, profile, proposals, "consensus", selection, review_context=review_context, negative_scope_resolutions=negative_scopes)["grouping_requests"][0]
        value = cluster_candidates(request, probe["images"])
        included = any(m["image_id"] == "I1" and m["object_id"] == "shell" for c in value["clusters"] for m in c["members"])
        write_json(out / "carrier-probe-input.json", {"request": request, "images": probe["images"]})
        write_json(out / "carrier-probe-result.json", value)
        downstream["carrier_scope_probe"] = {"target_shell_retained": included, "expected": True,
                                              "input": "carrier-probe-input.json", "output": "carrier-probe-result.json"}
        downstream["status"] = "compatible_on_synthetic_checks" if included and all(not r["input_errors"] for r in downstream["requests"]) else "incompatible_on_synthetic_checks"
    files = sorted(Path(__file__).parent.glob("*.py"))
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    dependency_changed = [str(p.relative_to(project)) for p in dependencies
                          if hashlib.sha256(p.read_bytes()).hexdigest() != dependency_hashes[str(p.relative_to(project))]]
    report = {"algorithm_version": "handshake-0.3.2", "tested_at_utc": datetime.now(timezone.utc).isoformat(),
              "python": sys.version, "source_hashes": hashes, "new_paid_calls": 0,
              "dependency_hashes": dependency_hashes, "dependencies_changed_during_run": dependency_changed,
              "tests": {"run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "passed": result.wasSuccessful()},
              "cli": cli, "three_mode_demo": summary, "downstream": downstream,
              "semantic_regression": semantic_regression,
              "negative_scope_cases": negative_scope_cases,
              "admission_replay": admission_replay,
              "module_interface_checks_passed": result.wasSuccessful() and all(c["matches_function_output"] for c in cli) and not dependency_changed and all(c["passed"] for c in semantic_regression) and all(c["handshake_passed"] for c in negative_scope_cases) and (admission_replay is None or admission_replay["passed"]),
              "algorithm_effectiveness_validated": False, "independent_holdout": "none; all fixtures are development tests",
              "elapsed_seconds": round(time.perf_counter() - start, 6)}
    write_json(out / "verification.json", report)
    print({"tests": report["tests"], "cli_passed": sum(c["matches_function_output"] for c in cli),
           "downstream": downstream["status"], "elapsed_seconds": report["elapsed_seconds"]})
    return 0 if report["module_interface_checks_passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--admission-source", help="FULLCHAIN-POOL-001 source evidence; adds receipt-binding tests and actual boundary replay")
    args = parser.parse_args()
    raise SystemExit(run(args.output, args.admission_source))
