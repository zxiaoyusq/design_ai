"""FULLCHAIN-POOL-001: evidence images are not executable reference images.

Read-only qualification checks. No image decoding, model call or quality
reclassification. Local source manifests are supplied by the trusted caller.
"""
from copy import deepcopy
import hashlib
from pathlib import Path

from prism_runtime.contracts import ContractError, require, index_by, read_json
from .common import fingerprint

SCHEMA = "prism.reference_admission_context.v0.1"


def _sha(path):
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    except (OSError, TypeError) as exc:
        raise ContractError("admission source unavailable: " + str(path)) from exc


def _file_ref(path):
    path = str(Path(path).resolve())
    return {"path": path, "sha256": _sha(path)}


def _read_bound(ref):
    require(isinstance(ref, dict) and ref.get("path") and ref.get("sha256"), "bound admission source required")
    require(_sha(ref["path"]) == ref["sha256"], "admission source changed: " + ref["path"])
    return read_json(ref["path"])


def _identities(bundle):
    return [{"image_id": i["image_id"], "source_kind": i.get("source_kind"),
             "image_path": i.get("image_path"), "image_sha256": i.get("provenance", {}).get("image_sha256"),
             "source_provenance_ref": i.get("provenance", {}).get("source_provenance_ref"),
             "provenance_mode": i.get("provenance", {}).get("mode")}
            for i in bundle.get("images", [])]


def prepare_reference_admission(bundle, trends_result_ref, material_manifest_ref):
    """Bind existing T01 and original->quality-input evidence; do not rerun T01."""
    context = {"schema_version": SCHEMA, "purpose": "source_bound_reference",
               "trends_result": _file_ref(trends_result_ref), "material_manifest": _file_ref(material_manifest_ref),
               "theme_snapshot": fingerprint(bundle.get("themes", [])),
               "image_identity_snapshot": fingerprint(_identities(bundle))}
    # Surface invalid corpus bindings at preparation instead of emitting a claim.
    reference_pool(bundle, [t["theme_id"] for t in bundle.get("themes", [])], context)
    return context


def prepare_fixture_admission(bundle):
    """Explicit protocol-test qualification. Never usable for real image records."""
    require(bundle.get("provenance", {}).get("mode") == "synthetic", "fixture admission requires a synthetic project")
    require(all(i.get("source_kind") == "synthetic" and i.get("provenance", {}).get("mode") == "synthetic"
                for i in bundle.get("images", [])), "fixture admission cannot qualify trend/research/calibration/generated images")
    return {"schema_version": SCHEMA, "purpose": "fixture_only",
            "theme_snapshot": fingerprint(bundle.get("themes", [])), "image_identity_snapshot": fingerprint(_identities(bundle)),
            "fixture_decisions": [{"image_id": i["image_id"], "image_snapshot": fingerprint(i), "decision": "PASS", "status": "complete",
                                   "production_admission": False, "source_ref": "synthetic:reference-fixture:" + i["image_id"]}
                                  for i in bundle.get("images", [])],
            "provenance": {"mode": "synthetic", "not_a_quality_judgement": True}}


def _manifest_file(files, path):
    matches = [f for f in files if f.get("frozen") and Path(f["frozen"]).resolve() == Path(path).resolve()]
    require(len(matches) == 1, "quality binding missing or ambiguous in material manifest")
    entry = matches[0]
    require(_sha(entry["frozen"]) == entry.get("sha256"), "material file changed: " + entry["frozen"])
    return entry


def _qualified_image(image, route, material):
    """Verify saved single-call quality against original/input/call identity."""
    from prism_runtime.quality import adapt_file
    iid = image["image_id"]
    require(image.get("source_kind") == "trend" and material.get("source_kind") == "trend", "nontrend or calibration source")
    require(image.get("provenance", {}).get("mode") == "existing_model_output", "unverified image provenance")
    quality = route.get("quality_record")
    require(isinstance(quality, dict) and quality.get("image_id") == iid and route.get("image_id") == iid, "quality identity mismatch")
    require(quality.get("source_kind") == "trend", "quality is not a trend verdict")
    require(quality.get("provenance", {}).get("mode") == "existing_model_output", "synthetic or unverified quality cannot qualify reference")
    require(quality.get("calibration_only") is False and quality.get("applicable") is True, "quality applicability is not explicitly established")
    require(type(quality.get("production_admission")) is bool, "explicit boolean production admission required")
    files = material.get("files", [])
    original = material.get("original_manifest_record", {})
    require(material.get("image_id") == iid and original.get("id", original.get("candidate_id")) == iid, "material identity mismatch")
    original_sha = original.get("original_sha256")
    require(isinstance(original_sha, str) and len(original_sha) == 64, "original image hash missing")
    require(image.get("provenance", {}).get("image_sha256") == original_sha, "ImageDNA points to a different original image")
    require(_sha(image.get("image_path")) == original_sha, "current image bytes differ from qualified original")
    _manifest_file(files, image["image_path"])
    result_ref = quality.get("source_ref")
    require(isinstance(result_ref, str) and bool(result_ref), "quality source reference missing")
    require(result_ref in quality.get("evidence_refs", []), "quality source is not in its evidence chain")
    result_file = _manifest_file(files, result_ref)
    require(result_file["sha256"] == quality.get("source_sha256"), "stale quality source receipt")
    result = read_json(result_ref)
    input_path = str(Path(result_ref).with_name("input.json"))
    input_file = _manifest_file(files, input_path)
    call_input = read_json(input_path)
    require(result.get("image_id") == iid and call_input.get("image_id") == iid, "quality call/image mismatch")
    require(result.get("call_id") and result["call_id"] == call_input.get("call_id"), "quality input/result call mismatch")
    input_sha = original.get("input_sha256")
    require(isinstance(input_sha, str) and len(input_sha) == 64 and call_input.get("input_sha256") == input_sha, "quality input does not match declared preprocessing lineage")
    input_images = [f for f in files if f.get("sha256") == input_sha and Path(f.get("frozen", "")).suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}]
    require(bool(input_images) and all(_sha(f["frozen"]) == input_sha for f in input_images), "quality input image bytes unavailable or changed")
    current = adapt_file(image, result_ref, rubric_version=quality.get("rubric_version"))
    # Existing verdicts are compared, never recomputed under a new visual rubric.
    fields = ("image_id", "source_kind", "decision", "status", "production_admission", "applicable", "calibration_only", "rubric_version", "source_sha256")
    require(all(current.get(k) == quality.get(k) for k in fields), "T01 quality receipt conflicts with saved verdict")
    require(route.get("quality_decision") == current.get("decision") and route.get("quality_status") == current.get("status"), "T01 quality route cache conflicts with source")
    positive = current.get("decision") == "PASS" and current.get("status") == "complete" and current.get("production_admission") is True
    require(route.get("reference_eligible") is positive, "T01 eligibility cache conflicts with source qualification")
    return {"image_id": iid, "eligible": positive, "decision": current.get("decision"), "status": current.get("status"),
            "production_admission": current.get("production_admission") is True,
            "source_kind": image["source_kind"], "image_sha256": original_sha,
            "quality_input_sha256": input_sha, "quality_source_ref": result_ref,
            "quality_source_sha256": result_file["sha256"], "quality_call_input_ref": input_path,
            "quality_call_input_sha256": input_file["sha256"], "quality_call_id": result["call_id"],
            "rubric_version": current.get("rubric_version"),
            "exclusion_reasons": [] if positive else ["no_completed_production_PASS"]}


def reference_pool(bundle, theme_ids, context):
    """Rebuild eligibility on every selection/H02 consumption, including files."""
    themes = index_by(bundle.get("themes", []), "theme_id")
    images = index_by(bundle.get("images", []), "image_id")
    require(set(theme_ids).issubset(themes), "unknown theme in admission request")
    evidence_ids, declared_ids = set(), set()
    for tid in theme_ids:
        theme = themes[tid]
        all_ids = theme.get("image_ids", [])
        refs = theme.get("reference_image_ids", [] if not all_ids else None)
        only = theme.get("evidence_only_image_ids", [] if not all_ids else None)
        require(isinstance(refs, list) and isinstance(only, list), "theme reference/evidence-only pools are missing; no fallback to image_ids")
        require(len(refs) == len(set(refs)) and len(only) == len(set(only)), "duplicate image in theme admission pools")
        require(not set(refs).intersection(only) and set(refs).union(only) == set(all_ids), "theme reference and evidence-only pools must partition evidence images")
        evidence_ids.update(all_ids)
        declared_ids.update(refs)
    if not evidence_ids:
        return {"purpose": "text_only", "eligible_image_ids": [], "evidence_image_ids": [], "audit": [], "admission_snapshot": fingerprint([])}
    if not declared_ids and context is None:
        payload = {"purpose": "evidence_only", "eligible_image_ids": [], "evidence_image_ids": sorted(evidence_ids),
                   "audit": [{"image_id": iid, "eligible": False, "production_admission": False,
                              "exclusion_reasons": ["T01_evidence_only_not_reference", "quality_not_revalidated"]} for iid in sorted(evidence_ids)]}
        return {**payload, "admission_snapshot": fingerprint(payload)}
    require(isinstance(context, dict) and context.get("schema_version") == SCHEMA, "reference admission context required; image_ids alone is not qualification")
    require(context.get("theme_snapshot") == fingerprint(bundle.get("themes", [])), "stale admission theme snapshot")
    require(context.get("image_identity_snapshot") == fingerprint(_identities(bundle)), "stale admission image identities")
    purpose = context.get("purpose")
    if purpose == "fixture_only":
        require(bundle.get("provenance", {}).get("mode") == "synthetic", "fixture admission cannot authorize a real project")
        require(all(i.get("source_kind") == "synthetic" and i.get("provenance", {}).get("mode") == "synthetic" for i in images.values()), "fixture admission cannot bypass real image quality")
        fixtures = index_by(context.get("fixture_decisions", []), "image_id")
        trend_routes, materials = {}, {}
    else:
        require(purpose == "source_bound_reference", "unknown reference admission purpose")
        trends = _read_bound(context.get("trends_result"))
        manifest = _read_bound(context.get("material_manifest"))
        require(trends.get("schema_version") == "prism.trends.v0.1", "T01 output required")
        require(trends.get("provenance", {}).get("mode") == "real_evidence", "source-bound reference context needs real T01 source evidence")
        require(trends.get("themes") == bundle.get("themes"), "bundle themes are not the bound T01 output")
        trend_routes = index_by(trends.get("quality_routes", []), "image_id")
        materials = index_by(manifest.get("records", []), "image_id")
        fixtures = {}
    audit = []
    for iid in sorted(evidence_ids):
        try:
            require(iid in images, "ImageDNA identity missing")
            if purpose == "fixture_only":
                q = fixtures.get(iid, {})
                require(q.get("image_snapshot") == fingerprint(images[iid]), "stale fixture image snapshot")
                require(q.get("production_admission") is False and q.get("source_ref"), "fixture is not a production qualification")
                passed = q.get("decision") == "PASS" and q.get("status") == "complete"
                row = {"image_id": iid, "eligible": passed, "production_admission": False,
                       "decision": q.get("decision"), "status": q.get("status"), "source_kind": "synthetic",
                       "source_ref": q["source_ref"], "image_snapshot": q["image_snapshot"],
                       "exclusion_reasons": [] if passed else ["fixture_has_no_completed_PASS"]}
            else:
                require(iid in trend_routes and iid in materials, "quality route or material binding missing")
                row = _qualified_image(images[iid], trend_routes[iid], materials[iid])
        except (ContractError, OSError, ValueError, TypeError) as exc:
            reported = trend_routes.get(iid, {}).get("quality_record", {})
            row = {"image_id": iid, "eligible": False, "production_admission": False,
                   "reported_decision": reported.get("decision"), "quality_source_ref": reported.get("source_ref"),
                   "source_binding_verified": False, "exclusion_reasons": [str(exc)]}
        if iid not in declared_ids:
            row["eligible"] = False
            row["exclusion_reasons"].append("T01_evidence_only_not_reference")
        audit.append(row)
    for row in audit:
        row["reference_theme_ids"] = sorted(tid for tid in theme_ids if row["eligible"] and row["image_id"] in themes[tid].get("reference_image_ids", []))
        row["evidence_only_theme_ids"] = sorted(tid for tid in theme_ids if row["image_id"] in themes[tid].get("evidence_only_image_ids", []))
    payload = {"purpose": purpose, "eligible_image_ids": sorted(r["image_id"] for r in audit if r["eligible"]),
               "evidence_image_ids": sorted(evidence_ids), "declared_reference_image_ids": sorted(declared_ids), "audit": audit,
               "context_snapshot": fingerprint(context)}
    admitted = set(payload["eligible_image_ids"])
    payload["reference_pool_status"] = "complete" if admitted == declared_ids else "partial" if admitted else "needs_input"
    return {**payload, "admission_snapshot": fingerprint(payload)}
