"""CT-002 full input/output fixtures. These are synthetic scope protocol tests."""
import argparse
from copy import deepcopy
from pathlib import Path
from prism_runtime.contracts import ContractError, write_json
from .examples import fixture, reviewed_fixture_context, negative_scope_fixture
from .api import compile_theme_handshake, select_themes, compile_directions
from .admission import prepare_fixture_admission

CASES = {
    "carrier_matte_shell_mirror_background": ("哑光", "镜面外观", "candidate_bindings", "request", True),
    "carrier_mirror_shell_matte_background": ("镜面外观", "哑光", "candidate_bindings", "request", False),
    "image_matte_shell_mirror_background": ("哑光", "镜面外观", "image", "request", False),
    "scope_missing": ("哑光", "镜面外观", "missing", "pending", None),
    "scope_pending": ("哑光", "镜面外观", "pending", "pending", None),
    "scope_unconfirmed": ("哑光", "镜面外观", "unconfirmed", "pending", None),
    "scope_unknown_kind": ("哑光", "镜面外观", "unknown", "pending", None),
    "scope_nonexistent_carrier": ("哑光", "镜面外观", "nonexistent", "pending", None),
    "scope_empty_images": ("哑光", "镜面外观", "empty_images", "pending", None),
    "model_proposal_scope_is_not_authority": ("哑光", "镜面外观", "proposal_only", "pending", None),
}


def scope_case(name):
    shell_value, bg_value, kind, expected, included = CASES[name]
    bundle, profile, themes, directions = fixture()
    bundle["images"] = [bundle["images"][0]]
    bundle["themes"][0]["image_ids"] = ["I1"]
    bundle["themes"][0]["reference_image_ids"] = ["I1"]
    bundle["evidence"][0]["image_ids"] = ["I1"]
    source = bundle["evidence"][2]
    source["text"] = "我喜欢手机后壳的圆弧轮廓。"
    positive = profile["preferences"][1]
    positive.update({"summary": source["text"], "quotes": [{"evidence_id": "R2", "text": source["text"]}],
                     "features": [{"parameter_id": "GEO-001", "value": "圆弧", "attribution": "explicit_text", "evidence_refs": ["R2"]}]})
    negative_source = bundle["evidence"][3]
    negative_source["text"] = "整张参考图都不能出现镜面外观，包括背景。" if kind in {"image", "empty_images"} else "我不接受手机后壳出现镜面外观，背景不在这个判断范围内。"
    negative = profile["preferences"][2]
    negative.update({"summary": negative_source["text"], "quotes": [{"evidence_id": "R3", "text": negative_source["text"]}],
                     "conditions": [], "condition_bindings": []})
    image = bundle["images"][0]
    next(o for o in image["observations"] if o["parameter_id"] == "OPT-002")["value"] = shell_value
    for field, value in [("OPT-002", bg_value), ("GEO-001", "圆弧")]:
        image["observations"].append({"observation_id": "I1-background-" + field, "parameter_id": field,
                                      "object_id": "background", "value": value, "value_status": "known",
                                      "region_ref": {"object_id": "background", "bbox_xyxy": [0, 0, 0.08, 0.08]},
                                      "evidence_refs": ["synthetic:I1:background:" + field]})
    profile, context = reviewed_fixture_context(bundle, profile)
    h01 = compile_theme_handshake(bundle, profile, themes, review_context=context)
    selection = select_themes(bundle, profile, h01, ["TH1"], selection_id="CT-002-S1", synthetic_assumption=True,
                              review_context=context, admission_context=prepare_fixture_admission(bundle))
    direction = directions["proposals"][0]
    direction.update({"title": "圆弧手机后壳", "design_axis": "ID", "candidate_image_ids": ["I1"],
                      "candidate_bindings": [{"image_id": "I1", "object_id": "shell"}],
                      "required_features": [{"parameter_id": "GEO-001", "allowed_values": ["圆弧"]}], "comparison_features": []})
    directions["proposals"] = [direction]
    resolutions = negative_scope_fixture(bundle, profile, selection, directions)
    resolution = resolutions["resolutions"][0]
    if kind in {"image", "empty_images"}:
        resolution["scope"] = {"kind": "image", "status": "resolved", "image_ids": ["I1"] if kind == "image" else [], "evidence_refs": ["R3"]}
    elif kind == "pending":
        resolution["scope"]["status"] = "pending"
    elif kind == "unconfirmed":
        resolution["confirmation"]["status"] = "proposed"
    elif kind == "unknown":
        resolution["scope"]["kind"] = "unknown"
    elif kind == "nonexistent":
        resolution["scope"]["bindings"][0]["object_id"] = "nonexistent-shell"
    elif kind == "proposal_only":
        directions["negative_scope_resolutions"] = deepcopy(resolutions)
        resolutions = None
    elif kind == "missing":
        resolutions = None
    return {"bundle": bundle, "profile": profile, "h01_result": h01, "selection": selection,
            "proposals": directions, "review_context": context, "negative_scope_resolutions": resolutions,
            "expected": {"handshake": expected, "target_shell_in_cluster": included}}


def run_case(data, mode="consensus"):
    return compile_directions(data["bundle"], data["profile"], data["proposals"], mode, data["selection"],
                              review_context=data["review_context"], negative_scope_resolutions=data["negative_scope_resolutions"])


def export_cases(destination, *, downstream=True):
    out = Path(destination)
    rows = []
    for name in CASES:
        data = scope_case(name)
        result = run_case(data)
        requests = result["grouping_requests"]
        expected = data["expected"]
        passed = bool(requests) if expected["handshake"] == "request" else not requests and bool(result["pending_directions"])
        audit_kept = any(a["preference_id"] == "P3" for d in result["design_directions"] for a in d["scoped_negative_preferences"])
        value = {"case": name, "input": data, "handshake_output": result, "handshake_passed": bool(passed and audit_kept),
                 "provenance": {"mode": "synthetic", "real_user_effect_validated": False}}
        if downstream and requests:
            try:
                from prism_runtime.clustering import cluster_candidates
                cluster = cluster_candidates(requests[0], data["bundle"]["images"])
                members = [(m["image_id"], m["object_id"]) for c in cluster["clusters"] for m in c["members"]]
                value["clustering_output"] = cluster
                negative_reason = any(r.get("code") == "known_forbidden_feature" for row in cluster.get("excluded", []) for r in row.get("reasons", []))
                value["downstream_passed"] = ((("I1", "shell") in members) == expected["target_shell_in_cluster"]
                                               and (expected["target_shell_in_cluster"] or negative_reason)
                                               and ("I1", "background") not in members and not cluster.get("boundary_members")
                                               and not cluster.get("unresolved_request_constraints") and not cluster.get("input_errors"))
            except ImportError:
                value["downstream_passed"] = None
        write_json(out / (name + ".json"), value)
        rows.append({"case": name, "handshake_passed": value["handshake_passed"], "downstream_passed": value.get("downstream_passed")})
    write_json(out / "summary.json", {"cases": rows, "new_paid_calls": 0, "independent_holdout": False})
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    rows = export_cases(args.output)
    print(rows)
    raise SystemExit(0 if all(r["handshake_passed"] for r in rows) else 1)
