# CT-002：负向作用范围

本文件是握手与聚类 owner 对齐的字段说明。公共 GroupingRequest 仍为 v0.1；新请求增加 `negative_scope_version=prism.negative_scope.v0.1`。旧的无 scope 请求由聚类维持既有明确行为，新字段不能被忽略。

## 可执行请求

```json
{
  "negative_scope_version": "prism.negative_scope.v0.1",
  "negative_audit_ids": ["P3"],
  "scoped_negative_preferences": [{
    "preference_id": "P3",
    "user_ids": ["U1"],
    "context_state": "applies",
    "conditions": [],
    "features": [{"parameter_id": "OPT-002", "value": "镜面外观"}],
    "evidence_refs": ["R3"],
    "scope_status": "resolved",
    "executable_constraint_ids": ["negative-example"],
    "scope_resolution_refs": ["scope-example"]
  }],
  "forbidden_features": [{
    "constraint_id": "negative-example",
    "audit_refs": ["P3"],
    "parameter_id": "OPT-002",
    "forbidden_values": ["镜面外观"],
    "evidence_refs": ["R3"],
    "scope": {
      "kind": "candidate_bindings",
      "status": "resolved",
      "bindings": [{"image_id": "I1", "object_id": "shell"}],
      "evidence_refs": ["R3"]
    }
  }]
}
```

图片级范围改为 `scope={kind:"image",status:"resolved",image_ids:["I1"],evidence_refs:["R3"]}`。两种选择器不能混用。

- candidate_bindings 范围是请求白名单中的明确子集，作用于列出的 image_id/object_id；同载体的全部相关观察都要检查，不能只看核心 observation_ids。
- image 范围作用于列出图片的全部已声明载体，包括背景；未观察到相关属性不能当作明确不存在。
- 新版本按 constraint_id 唯一，允许同一 parameter_id 对应多个不同范围；不得直接合并为全图禁用。
- negative_audit_ids 是全部原负向审计身份清单。每个 applies 审计的每个 `(parameter_id, value)` 都要有可执行约束，且 audit_refs 与 executable_constraint_ids 双向相符。
- not_applicable 审计继续保留来源、条件或目标人群不相交的判定依据，可不执行；未决、未复核或未映射审计不得删除。
- 产品硬约束也保留审计，使用 `brief:<brief_id>:negative:<index>` 身份及 `source_kind=product_hard_constraint`；它不是伪造的消费者偏好。

## 范围确认从哪里来

H02 接收独立参数 `negative_scope_resolutions`，CLI 对应 `--negative-scopes`。这个参数由可信调用方在实际核对原话与对象后提供。模型的 proposals 自带同名字段或 `resolved=true` 不具有确认效力。

```json
{
  "schema_version": "prism.negative_scope_resolutions.v0.1",
  "input_snapshot": "prepare 的资料快照",
  "selection_snapshot": "完整主题选择的 fingerprint",
  "resolutions": [{
    "resolution_id": "scope-example",
    "direction_ids": ["D1"],
    "preference_id": "P3",
    "parameter_id": "OPT-002",
    "forbidden_values": ["镜面外观"],
    "evidence_refs": ["R3"],
    "quotes": [{"evidence_id": "R3", "text": "我不接受手机后壳出现镜面外观，背景不在这个判断范围内。"}],
    "confirmation": {
      "status": "confirmed",
      "confirmed_by": "实际范围核对者",
      "source_ref": "实际范围确认记录"
    },
    "scope": {
      "kind": "candidate_bindings",
      "status": "resolved",
      "bindings": [{"image_id": "I1", "object_id": "shell"}],
      "evidence_refs": ["R3"]
    }
  }]
}
```

输入字段是范围决定及其依据，不是程序自动判断自然语言的证明。调用方负责确认记录的真实性；程序核对快照、引用原话、原负向字段/值、载体身份和候选范围。缺确认、未知范围、空目标、不存在载体、超出白名单、部分负向值未映射，全部保留 pending，不能默认全图或不受限制。

核对原子偏好的受信入口仍是用研模块的 validate_reviewed_profile；scope 决定不替代原子语义审阅，也不能通过它翻转用户态度。

## 可复跑样例

```powershell
py -3.13 -m prism_runtime.handshake.scope_cases --output outputs/prism-algorithm-loop-20260926/modules/handshake/examples/CT-002
```

每个文件保存完整 bundle、profile、主题选择、命题、可信登记表夹具、范围确认、H02 输出和可用的聚类输出。十种场景包括载体级与图片级三组正反例、范围缺失/未确认/未知/不存在/空目标，以及模型自填范围不具有权限。

原文和图像观察均为明确合成协议夹具，没有新增模型调用，也不代表真实用户偏好效果。三档使用相同禁用范围和证据。H02 自测通过、下游回放通过与 Root 独立验收分别记录。
