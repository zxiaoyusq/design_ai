"""Offline protocol counterexamples, not model/semantic-accuracy evaluation."""
from copy import deepcopy
import unittest

from prism_runtime.contracts import ContractError
from .. import common, themes, directions
from ..examples import fixture, reviewed_fixture_context, negative_scope_fixture
from ..admission import prepare_fixture_admission
from ..scope_cases import CASES, scope_case
from .api import ContextSession, verify_base
from .policy import EXECUTION_SCHEMA, VERSION
from .view import evaluate_preference_scope


def reviewed(bundle, profile, approve_mappings=True):
    profile, context = reviewed_fixture_context(bundle, profile)
    if approve_mappings:
        context["approved_condition_binding_hashes"] = {
            p["preference_id"]: [common.fingerprint(b) for b in p.get("condition_bindings", [])]
            for p in profile["preferences"]}
    return profile, context


def bind(session, document, selection=None):
    """Bind authored protocol fixtures only; never rebind saved model replies."""
    doc = deepcopy(document)
    doc.update(context_sidecar_snapshot=session.token, input_snapshot=common.snapshot(session.bundle, session.profile),
               review_context_snapshot=common.fingerprint(session.review_context))
    if selection is not None:
        doc["selection_snapshot"] = common.fingerprint(selection)
    return doc


def scope(session, preference_id="P1", users=None):
    evidence, _, prefs, _, selected = common.validate_inputs(session.bundle, session.profile, session.review_context)
    return evaluate_preference_scope(session.view, prefs[preference_id], selected if users is None else users,
                                     session.view["execution_scope"]["values"], evidence=evidence,
                                     review_context=session.review_context)


def simulation_row(row, scene="office", scenario_id="arbitrary-17"):
    row.update(project_id="simulation-120-research", source="synthetic", simulation=True, is_real_interview=False,
               source_subkind="authored_fictional_image_response", record_kind="image_evaluation", target_scope="region",
               scenario={"scenario_ids": [scenario_id], "labels": [scene], "speech_labels": [scene], "source": "synthetic"},
               context={"respondent_identity": "fictional", "project_kind": "simulation", "current_scope": "local_CMF_only",
                        "scenario_ids": [scenario_id], "image_origin": "fixture-calibration-origin",
                        "picture_evaluation_does_not_prove_real_material_or_experience": True})
    return row


def simulation_fixture():
    b, p, t, d = fixture()
    simulation_row(b["evidence"][1])
    return b, p, t, d


def execution(bundle, profile, *, eid="R1", pointer="/scenario/labels/0", field="scene", coverage=None):
    from .view import _pointer
    row = next(r for r in bundle["evidence"] if r["evidence_id"] == eid)
    return {"schema_version": EXECUTION_SCHEMA, "mode": "source_scoped_simulation", "user_confirmed": False,
            "p01_input_digest": profile["input_digest"], "profile_snapshot": common.fingerprint(profile),
            "evidence_ids": coverage or [eid], "values": {field: _pointer(row, pointer)},
            "source_bindings": [{"target_field": field, "evidence_id": eid, "source_pointer": pointer,
                                 "source_snapshot": common.fingerprint(row)}]}


class RoleTests(unittest.TestCase):
    def session(self, b, p, **kwargs):
        p, c = reviewed(b, p)
        return ContextSession(b, p, review_context=c, **kwargs)

    def test_metadata_only_differences_preserve_raw_and_do_not_conflict(self):
        b, p, _, _ = simulation_fixture()
        extra = deepcopy(b["evidence"][1])
        extra["evidence_id"] = "R1-copy"
        extra["context"]["image_origin"] = "another-calibration-origin"
        extra["context"]["current_scope"] = "local_CMF_research_input_only"
        b["evidence"].append(extra)
        p["preferences"][0]["evidence_refs"].append("R1-copy")
        p["preferences"][0]["quotes"].append({"evidence_id": "R1-copy", "text": extra["text"]})
        s = self.session(b, p)
        old = common.preference_scope(s.profile["preferences"][0], ["U1"], common.context_of(b))
        self.assertIn("multiple_source_contexts_need_separation", old["evaluated_conditions"])
        out = scope(s)
        self.assertEqual(out["context_state"], "applies")
        self.assertEqual(out["evaluated_conditions"], [])
        raw = out["source_context_role_audit"]["sources"]
        self.assertEqual(raw[0]["raw_context"], b["evidence"][1]["context"])
        self.assertEqual(raw[1]["raw_context"], extra["context"])
        self.assertEqual(out["source_context_role_audit"]["analysis_scope"], "local_CMF")
        self.assertEqual(len(out["source_context_role_audit"]["capability_limits"]), 2)

    def test_genuine_scene_difference_remains_unknown(self):
        b, p, _, _ = simulation_fixture()
        row = b["evidence"][1]
        row["scenario"]["scenario_ids"].append("another-id")
        row["scenario"]["labels"].append("home")
        row["context"]["scenario_ids"].append("another-id")
        out = scope(self.session(b, p))
        self.assertEqual(out["context_state"], "unknown")
        self.assertIn("multiple_source_scenarios_need_attribution", [x["reason"] for x in out["scope_pending_reasons"]])

    def test_same_id_conflicting_labels_remains_unknown(self):
        b, p, _, _ = simulation_fixture()
        row = deepcopy(b["evidence"][1])
        row["evidence_id"] = "R1-second"
        row["scenario"]["labels"] = ["home"]
        b["evidence"].append(row)
        p["preferences"][0]["evidence_refs"].append(row["evidence_id"])
        p["preferences"][0]["quotes"].append({"evidence_id": row["evidence_id"], "text": row["text"]})
        out = scope(self.session(b, p))
        self.assertEqual(out["context_state"], "unknown")
        self.assertIn("conflicting_scenario_labels", [x["reason"] for x in out["scope_pending_reasons"]])

    def test_missing_source_scope_and_unknown_fields_never_disappear(self):
        for case in ("scenario", "current_scope", "scenario_ids", "unknown_key", "unknown_value", "wrong_schema", "capability", "identity"):
            with self.subTest(case=case):
                b, p, _, _ = simulation_fixture()
                row = b["evidence"][1]
                if case == "scenario":
                    row.pop("scenario")
                elif case in {"current_scope", "scenario_ids"}:
                    row["context"].pop(case)
                elif case == "unknown_key":
                    row["context"]["unknown/business~scope"] = "retain me"
                elif case == "unknown_value":
                    row["context"]["current_scope"] = "everything"
                elif case == "wrong_schema":
                    row["project_id"] = "another-producer"
                elif case == "capability":
                    row["context"]["picture_evaluation_does_not_prove_real_material_or_experience"] = False
                else:
                    row["context"]["respondent_identity"] = "real-person"
                out = scope(self.session(b, p))
                self.assertEqual(out["context_state"], "unknown")
                self.assertTrue(out["scope_pending_reasons"])

    def test_scenario_suffix_is_not_interpreted(self):
        b, p, _, _ = simulation_fixture()
        b["evidence"][1]["scenario"].pop("labels")
        b["evidence"][1]["context"]["scenario_ids"] = ["SYN-U01-SC-P"]
        out = scope(self.session(b, p))
        self.assertEqual(out["context_state"], "unknown")
        self.assertEqual(out["source_context_role_audit"]["scenario_refs"], [])

    def test_source_scene_is_not_target_approval(self):
        b, p, _, _ = simulation_fixture()
        b["brief"]["context"].pop("scene")
        out = scope(self.session(b, p))
        self.assertEqual(out["context_state"], "unknown")
        self.assertFalse(out["execution_scope_user_confirmed"])

    def test_target_outside_single_source_scene_stays_pending(self):
        b, p, _, _ = simulation_fixture()
        b["brief"]["context"]["scene"] = "home"
        self.assertEqual(scope(self.session(b, p))["context_state"], "unknown")

    def test_explicit_business_conditions_keep_three_valued_logic(self):
        for target, expected in (("office", "applies"), ("home", "not_applicable"), (None, "unknown")):
            with self.subTest(target=target):
                b, p, _, _ = fixture()
                b["evidence"][1].update(context_schema="prism.business-context.v1", context={"scene": "office"})
                b["brief"]["context"]["scene"] = target
                out = scope(self.session(b, p))
                self.assertEqual(out["context_state"], expected)
                self.assertEqual(out["evaluated_conditions"][0]["field"], "scene")

    def test_same_metadata_key_in_unknown_schema_is_pending(self):
        b, p, _, _ = fixture()
        b["evidence"][1]["context"] = {"respondent_identity": "fictional"}
        out = scope(self.session(b, p))
        self.assertEqual(out["context_state"], "unknown")
        self.assertEqual(out["source_context_role_audit"]["roles"][0]["role"], "unknown")

    def test_condition_mapping_requires_caller_approved_hash(self):
        b, p, _, _ = fixture()
        p, c = reviewed(b, p, approve_mappings=False)
        self.assertEqual(scope(ContextSession(b, p, review_context=c), "P3")["context_state"], "unknown")
        c["approved_condition_binding_hashes"] = {"P3": [common.fingerprint(p["preferences"][2]["condition_bindings"][0])]}
        self.assertEqual(scope(ContextSession(b, p, review_context=c), "P3")["context_state"], "applies")
        p["preferences"][2]["condition_bindings"][0]["predicates"][0]["value"] = "home"
        self.assertEqual(scope(ContextSession(b, p, review_context=c), "P3")["context_state"], "unknown")

    def test_unbound_extra_context_scope_cannot_create_support(self):
        b, p, _, _ = fixture()
        p, c = reviewed(b, p)
        p["preferences"][0]["context_scope"] = {"scene": "office"}
        out = scope(ContextSession(b, p, review_context=c))
        self.assertEqual(out["context_state"], "unknown")
        self.assertIn("unbound_preference_context_scope", [x["reason"] for x in out["scope_pending_reasons"]])

    def test_open_ended_scene_condition_cannot_resolve_two_scenes(self):
        b, p, _, _ = simulation_fixture()
        row = b["evidence"][1]
        row["scenario"]["scenario_ids"].append("second")
        row["scenario"]["labels"].append("home")
        row["context"]["scenario_ids"].append("second")
        p["preferences"][0]["conditions"] = ["办公手机"]
        p["preferences"][0]["condition_bindings"] = [{"source_condition": "办公手机", "evidence_refs": ["R1"],
            "predicates": [{"field": "scene", "operator": "ne", "value": "outdoors"}],
            "review_status": "reviewed", "reviewer": "synthetic_fixture_author"}]
        self.assertEqual(scope(self.session(b, p))["context_state"], "unknown")

    def test_approved_mapping_still_needs_original_source_and_quote(self):
        for key, value in (("evidence_refs", ["R2"]), ("source_condition", "没有出现过的条件")):
            with self.subTest(key=key):
                b, p, _, _ = fixture()
                p, c = reviewed(b, p)
                mapping = p["preferences"][2]["condition_bindings"][0]
                mapping[key] = value
                c["approved_condition_binding_hashes"]["P3"] = [common.fingerprint(mapping)]
                if key == "evidence_refs":
                    with self.assertRaises(ContractError):
                        scope(ContextSession(b, p, review_context=c), "P3")
                else:
                    self.assertEqual(scope(ContextSession(b, p, review_context=c), "P3")["context_state"], "unknown")

    def test_no_target_user_support_remains_not_applicable(self):
        b, p, _, _ = simulation_fixture()
        self.assertEqual(scope(self.session(b, p), users=[])["context_state"], "not_applicable")


class ExecutionScopeTests(unittest.TestCase):
    def setUp(self):
        self.b, p, self.t, self.d = simulation_fixture()
        self.b["brief"]["context"].pop("scene")
        self.p, self.c = reviewed(self.b, p)
        self.e = execution(self.b, self.p)

    def session(self, **options):
        return ContextSession(self.b, self.p, review_context=self.c, execution_scope_context=options.get("execution", self.e))

    def test_single_source_simulation_is_separately_bound_and_not_approval(self):
        before = common.fingerprint([self.b, self.p, self.c, self.e])
        s = self.session()
        out = scope(s)
        self.assertEqual(out["context_state"], "applies")
        self.assertFalse(out["execution_scope_user_confirmed"])
        self.assertEqual(s.view["original_profile_snapshot"], common.fingerprint(self.p))
        self.assertEqual(before, common.fingerprint([self.b, self.p, self.c, self.e]))

    def test_simulation_does_not_resolve_multiple_source_scenes(self):
        row = self.b["evidence"][1]
        row["scenario"]["scenario_ids"].append("secondary")
        row["scenario"]["labels"].append("home")
        row["context"]["scenario_ids"].append("secondary")
        self.p, self.c = reviewed(self.b, self.p)
        self.e = execution(self.b, self.p)
        self.assertEqual(scope(self.session())["context_state"], "unknown")

    def test_false_binding_or_approval_is_rejected(self):
        for field, value in (("user_confirmed", True), ("p01_input_digest", "stale"), ("profile_snapshot", "stale")):
            with self.subTest(field=field):
                e = deepcopy(self.e)
                e[field] = value
                with self.assertRaises(ContractError):
                    self.session(execution=e)
        e = deepcopy(self.e)
        e["source_bindings"][0]["source_snapshot"] = "stale"
        with self.assertRaises(ContractError):
            self.session(execution=e)

    def test_metadata_cannot_be_rebound_as_scene(self):
        e = execution(self.b, self.p, pointer="/context/respondent_identity")
        with self.assertRaisesRegex(ContractError, "source field role"):
            self.session(execution=e)

    def test_cross_field_business_binding_is_rejected(self):
        self.b["evidence"][1] = {**self.b["evidence"][1], "project_id": "other", "context_schema": "prism.business-context.v1",
                                 "context": {"region": "office"}}
        self.p, self.c = reviewed(self.b, self.p)
        e = execution(self.b, self.p, pointer="/context/region")
        with self.assertRaisesRegex(ContractError, "source field role"):
            self.session(execution=e)

    def test_frozen_brief_cannot_be_overridden(self):
        self.b["brief"]["context"]["scene"] = "home"
        self.p, self.c = reviewed(self.b, self.p)
        self.e = execution(self.b, self.p)
        with self.assertRaisesRegex(ContractError, "override frozen brief"):
            self.session()

    def test_source_coverage_applies_even_without_scenario(self):
        s = self.session()
        self.assertEqual(scope(s, "P2")["context_state"], "unknown")
        self.assertIn("execution_scope_does_not_cover_candidate_sources", [x["reason"] for x in scope(s, "P2")["scope_pending_reasons"]])

    def test_label_and_id_must_form_actual_source_pair(self):
        row = self.b["evidence"][1]
        row["scenario"]["scenario_ids"].append("secondary")
        row["scenario"]["labels"].append("home")
        row["context"]["scenario_ids"].append("secondary")
        self.p, self.c = reviewed(self.b, self.p)
        self.e = execution(self.b, self.p)
        wrong = execution(self.b, self.p, pointer="/scenario/scenario_ids/1", field="scenario_id")
        self.e["values"].update(wrong["values"])
        self.e["source_bindings"].extend(wrong["source_bindings"])
        out = scope(self.session())
        self.assertIn("execution_scene_id_pair_not_in_source_scope", [x["reason"] for x in out["scope_pending_reasons"]])


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.b, p, self.t, self.d = fixture()
        self.p, self.c = reviewed(self.b, p)
        self.s = ContextSession(self.b, self.p, review_context=self.c)

    def selection(self, session=None, **options):
        s = session or self.s
        h01 = s.compile_theme_handshake(bind(s, self.t))
        defaults = dict(selection_id="sidecar-offline-fixture", synthetic_assumption=True,
                        admission_context=prepare_fixture_admission(s.bundle))
        defaults.update(options)
        return s.select_themes(h01, ["TH1"], **defaults)

    def run_mode(self, mode, s=None, proposals=None):
        s = s or self.s
        selected = self.selection(s)
        doc = bind(s, proposals or self.d, selected)
        return s.compile_directions(doc, mode, selected,
                                    negative_scope_resolutions=negative_scope_fixture(s.bundle, s.profile, selected, doc))

    def test_three_modes_are_cumulative_and_negatives_unchanged(self):
        expected = {"consensus": ["D1"], "extension": ["D1", "D2"], "exploration": ["D1", "D2", "D3"]}
        constraints = []
        for mode in common.POLICIES:
            out = self.run_mode(mode)
            self.assertEqual([d["direction_id"] for d in out["grouping_requests"]], expected[mode])
            constraints.append(out["grouping_requests"][0]["forbidden_features"])
            self.assertFalse(out["H02_user_confirmation_inferred"])
            self.assertEqual(out["algorithm_version"], VERSION)
        self.assertTrue(all(c == constraints[0] for c in constraints))
        self.assertEqual([p["label"] for p in common.POLICIES.values()], ["共识优先", "适度延展", "创新探索"])

    def test_ct001_and_ct002_matrix_preserves_audit_and_scope(self):
        for case in CASES:
            with self.subTest(case=case):
                data = scope_case(case)
                s = ContextSession(data["bundle"], data["profile"], review_context=data["review_context"])
                selected = self.selection(s)
                doc = bind(s, data["proposals"], selected)
                resolutions = deepcopy(data["negative_scope_resolutions"])
                if resolutions is not None:
                    resolutions["selection_snapshot"] = common.fingerprint(selected)
                out = s.compile_directions(doc, selection=selected, negative_scope_resolutions=resolutions)
                self.assertEqual(bool(out["grouping_requests"]), data["expected"]["handshake"] == "request")
                direction = out["design_directions"][0]
                self.assertEqual(direction["negative_audit_ids"], ["P3"])
                self.assertEqual(direction["scoped_negative_preferences"][0]["evidence_refs"], ["R3"])
                if out["grouping_requests"]:
                    req = out["grouping_requests"][0]
                    self.assertEqual([(b["image_id"], b["object_id"]) for b in req["candidate_bindings"]], [("I1", "shell")])
                    ban, audit = req["forbidden_features"][0], req["scoped_negative_preferences"][0]
                    self.assertEqual(ban["audit_refs"], ["P3"])
                    self.assertEqual(audit["executable_constraint_ids"], [ban["constraint_id"]])
                    self.assertEqual(ban["scope"]["kind"], "image" if case.startswith("image_") else "candidate_bindings")

    def test_missing_or_stale_bindings_rejected_at_every_transition(self):
        for field in ("context_sidecar_snapshot", "input_snapshot", "review_context_snapshot"):
            for value in (None, "stale"):
                with self.subTest(field=field, value=value):
                    doc = bind(self.s, self.t)
                    doc[field] = value
                    with self.assertRaises(ContractError):
                        self.s.compile_theme_handshake(doc)
        result = self.s.compile_theme_handshake(bind(self.s, self.t))
        result.pop("context_sidecar_snapshot")
        with self.assertRaises(ContractError):
            self.s.select_themes(result, ["TH1"], selection_id="bad")
        selected = self.selection()
        bad = deepcopy(selected)
        bad.pop("context_sidecar_snapshot")
        with self.assertRaises(ContractError):
            self.s.prepare_request(bad)
        doc = bind(self.s, self.d, selected)
        doc.pop("selection_snapshot")
        with self.assertRaises(ContractError):
            self.s.compile_directions(doc, selection=selected)

    def test_old_reply_cannot_reuse_new_execution_scope(self):
        b, p, t, _ = simulation_fixture()
        b["brief"]["context"].pop("scene")
        p, c = reviewed(b, p)
        before = ContextSession(b, p, review_context=c)
        after = ContextSession(b, p, review_context=c, execution_scope_context=execution(b, p))
        self.assertNotEqual(before.token, after.token)
        with self.assertRaisesRegex(ContractError, "sidecar binding"):
            after.compile_theme_handshake(bind(before, t))

    def test_prepare_round_trip_has_bound_role_view(self):
        import json
        request = self.s.prepare_theme_request()
        payload = json.loads(request["messages"][-1]["content"])
        self.assertEqual(payload["context_sidecar_snapshot"], self.s.token)
        self.assertEqual(request["context_role_view"], self.s.view)
        selected = self.selection()
        h02 = self.s.prepare_request(selected)
        self.assertEqual(h02["selection_snapshot"], common.fingerprint(selected))
        self.assertFalse(selected["designer_confirmed"])

    def test_missing_admission_and_failed_reference_are_rejected(self):
        with self.assertRaises(ContractError):
            self.selection(admission_context=None)
        admission = prepare_fixture_admission(self.b)
        admission["fixture_decisions"][0]["decision"] = "FAIL"
        with self.assertRaises(ContractError):
            self.selection(admission_context=admission, candidate_image_ids=["I1"])

    def test_H02_revalidates_admission_and_DNA(self):
        for kind in ("admission", "dna", "pool"):
            selected = self.selection()
            if kind == "admission":
                selected["admission_context"]["fixture_decisions"][0]["decision"] = "FAIL"
            elif kind == "dna":
                selected["dna_snapshot"] = "stale"
            else:
                selected["candidate_image_ids"].append("nonexistent")
            with self.subTest(kind=kind), self.assertRaises(ContractError):
                self.s.prepare_request(selected)

    def test_trusted_review_cannot_be_replaced_by_saved_flags(self):
        from ..semantic_cases import semantic_case
        b, p, d, _, c = semantic_case("like")
        p["preferences"][1]["semantic_assessment"].update(status="supported", support_eligibility="reviewed_positive", review_ids=["fabricated"])
        p["preferences"][1]["confirmed_user_support"] = True
        s = ContextSession(b, p, review_context=c)
        checked = next(x for x in s.view["preferences"] if x["preference_id"] == "P2")
        self.assertEqual(checked["semantic_assessment"]["status"], "pending_independent_review")
        self.assertFalse(self.run_mode("consensus", s, d)["grouping_requests"])

    def test_unknown_negative_scope_blocks_all_modes_and_preserves_audit(self):
        b, p, _, _ = fixture()
        b["evidence"][3]["context"] = {"unknown_negative_scope": "retain"}
        p, c = reviewed(b, p)
        s = ContextSession(b, p, review_context=c)
        for mode in common.POLICIES:
            out = self.run_mode(mode, s)
            self.assertFalse(out["grouping_requests"])
            self.assertTrue(all(d["negative_audit_ids"] == ["P3"] for d in out["design_directions"]))
            self.assertTrue(all(d["scoped_negative_preferences"][0]["context_state"] == "unknown" for d in out["design_directions"]))

    def test_wrong_registry_or_changed_candidate_rejected(self):
        registry = deepcopy(self.c)
        registry["reviewer_registry"]["registry_version"] = "changed"
        with self.assertRaises(ContractError):
            ContextSession(self.b, self.p, review_context=registry)
        p = deepcopy(self.p)
        p["preferences"][0]["summary"] = "different interpretation"
        with self.assertRaises(ContractError):
            ContextSession(self.b, p, review_context=self.c)

    def test_local_CMF_blocks_other_axes_and_nonvisual_fields(self):
        self.b["brief"]["current_scope"] = "local_CMF_only"
        p, c = reviewed(self.b, self.p)
        s = ContextSession(self.b, p, review_context=c)
        good = {"proposals": [self.d["proposals"][0]]}
        self.assertEqual(len(self.run_mode("consensus", s, good)["grouping_requests"]), 1)
        for axis, parameter in (("ID", "OPT-002"), ("CMF", "GEO-001"), ("CMF", "MAT-001")):
            with self.subTest(axis=axis, parameter=parameter):
                bad = deepcopy(good)
                bad["proposals"][0]["design_axis"] = axis
                bad["proposals"][0]["required_features"][0]["parameter_id"] = parameter
                with self.assertRaisesRegex(ContractError, "local"):
                    self.run_mode("exploration", s, bad)

    def test_capability_and_analysis_limits_survive_grouping_output(self):
        b, p, _, _ = fixture()
        simulation_row(b["evidence"][2])
        p, c = reviewed(b, p)
        s = ContextSession(b, p, review_context=c)
        good = {"proposals": [self.d["proposals"][0]]}
        request = self.run_mode("consensus", s, good)["grouping_requests"][0]
        audit = next(x for x in request["source_scope_limits"] if x["preference_id"] == "P2")
        self.assertEqual(audit["analysis_scope"], "local_CMF")
        self.assertEqual(audit["capability_limits"][0]["evidence_id"], "R2")
        self.assertIs(audit["capability_limits"][0]["value"], True)

    def test_source_global_namespaces_and_inputs_are_unchanged(self):
        before = common.fingerprint([self.b, self.p, self.c, self.t, self.d])
        modules = [common, themes, directions]
        identities = [{k: id(v) for k, v in vars(m).items()} for m in modules]
        hashes = verify_base()
        self.run_mode("exploration")
        self.assertEqual(before, common.fingerprint([self.b, self.p, self.c, self.t, self.d]))
        self.assertEqual(hashes, verify_base())
        self.assertEqual(identities, [{k: id(v) for k, v in vars(m).items()} for m in modules])
        self.assertIs(self.s._themes["compile_theme_handshake"].__code__, themes.compile_theme_handshake.__code__)
        self.assertIs(self.s._directions["compile_directions"].__code__, directions.compile_directions.__code__)
        self.assertIsNot(self.s._themes["compile_theme_handshake"].__globals__, themes.compile_theme_handshake.__globals__)

    def test_sessions_do_not_share_context_or_mutable_views(self):
        b, p, _, _ = fixture()
        b["brief"]["context"]["scene"] = "home"
        p, c = reviewed(b, p)
        s = ContextSession(b, p, review_context=c)
        self.assertEqual(scope(self.s, "P3")["context_state"], "applies")
        self.assertEqual(scope(s, "P3")["context_state"], "not_applicable")
        detached = self.s.view
        detached["execution_scope"]["values"]["scene"] = "mutated"
        self.assertEqual(scope(self.s, "P3")["context_state"], "applies")
        self.s.bundle["brief"]["context"]["scene"] = "tampered"
        with self.assertRaises(ContractError):
            self.s.prepare_theme_request()


if __name__ == "__main__":
    unittest.main()
