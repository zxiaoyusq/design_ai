"""Owner offline evaluation of QWEN-H01-CONTEXT-001. No provider calls."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
from pathlib import Path
import unittest

from prism_runtime.contracts import read_json, write_json, require
from ..common import fingerprint, preference_scope, context_of, validate_inputs
from ..admission import reference_pool
from .api import ContextSession, verify_base
from .policy import BASE_HASHES, VERSION
from .tests import scope, execution

PROJECT = Path(__file__).resolve().parents[3]
CHAIN = PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/qwen-cli-20260927/runs/full120-qwen-v1-20260927/semantic-chain"
OUTPUT = PROJECT / "outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/QWEN-H01-CONTEXT-001"
QUIET = "preference-wire001-001:F-SYN-U01-THEME-QUIET"
EXPECTED = {
    "inputs/combined-bundle-input-v2.json": "5cbd6e6823a4e13bb2571459f9ca736f59d03b2836a8d840e49158e77d908044",
    "P01-wire002/candidate-profile.json": "d7543067db43064e9c5e223b7204198849eae8399884cad843cedc6fe73cc0f3",
    "admission-v1/bundle.json": "b20742278ecd9c5647c4dcc67dcaf777fc672e14a4f10bcb588b6796ed520f4d",
}
FROZEN_BASE_HASHES = {
    **BASE_HASHES,
    "api.py": "90eed623e580bbd01ae37f4368b97b284e6f0487574fcd25e5b8e8aaf7c9d9c6",
    "examples.py": "af9d889792aaa0c7b3d80707fa23c1320b394070175d2c8b264f74ef0c84fe38",
    "replay_admission.py": "f907b906b7dea8c2523754bdbd9eb5db65cd562790ec8fe271de205257cdd6be",
    "scope_cases.py": "4ec34467a3ae8331eac1dc7cdcb499b934224360a6d74ef3654acaf6e0141992",
    "semantic_cases.py": "60abc9f87eb61349fcdea325ee361e813110c80e8fa46ed9007516af97aa6e70",
    "test_admission.py": "2c89362d17949d2cdb0b8299c5d2eb5cec61d56048588b623b7ee0cf5023b244",
    "test_handshake.py": "e9d89e9151f9377eba701491df87226249c3cb59a908c10d8a69b0c01f3c8c81",
    "verify.py": "f972be81f10b55e63e1158d5531b0dc6066a952f38dbff9b2e2e5047156d58a4",
    "__init__.py": "cdd25a49614b8bc62a0491c5922405e17b7b4fe0b70523373b39768372b1992c",
    "__main__.py": "93f8313e1565db106660efcfb5e044dbc801b4e2e8315009691a8a452df19c25",
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def file_record(path):
    return {"path": str(path.resolve()), "sha256": sha(path), "size_bytes": path.stat().st_size}


def protected_files():
    paths = list((PROJECT / "prism_runtime/handshake").glob("*.py"))
    paths += list((PROJECT / "prism_runtime/preferences").glob("*.py"))
    paths.append(PROJECT / "prism_runtime/CONTRACT.md")
    for directory in ("inputs", "P01-wire002", "review-v1", "review-wire001", "review-wire001-recovery", "admission-v1"):
        paths.extend((CHAIN / directory).rglob("*.json"))
    return sorted(set(p.resolve() for p in paths))


def evaluate(output=OUTPUT):
    output = Path(output).resolve()
    require(output == OUTPUT.resolve() or output.is_relative_to(OUTPUT.resolve()), "evaluation output must stay in this repair folder")
    output.mkdir(parents=True, exist_ok=True)
    before = [file_record(p) for p in protected_files()]
    original_code = PROJECT / "prism_runtime/handshake"
    require(all(sha(original_code / name) == digest for name, digest in FROZEN_BASE_HASHES.items()), "frozen 0.3.2 differs from pre-repair manifest")
    require(all(sha(CHAIN / name) == digest for name, digest in EXPECTED.items()), "dispatch source fingerprint changed")
    verify_base()

    stream = io.StringIO()
    suite = unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromName("prism_runtime.handshake.context_sidecar_v1.tests"),
        unittest.defaultTestLoader.loadTestsFromName("prism_runtime.handshake.test_handshake"),
    ])
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (output / "unit-tests.txt").write_text(stream.getvalue(), encoding="utf-8")

    b = read_json(CHAIN / "inputs/combined-bundle-input-v2.json")
    p = read_json(CHAIN / "review-wire001-recovery/validated-profile.json")
    candidate = read_json(CHAIN / "P01-wire002/candidate-profile.json")
    registry = read_json(CHAIN / "review-wire001-recovery/reviewer-registry.json")
    review = {"reviewer_registry": registry}
    original_objects = fingerprint([b, p, candidate, review])
    s = ContextSession(b, p, review_context=review)
    s0 = ContextSession(b, candidate, review_context=review)
    evidence, _, checked, _, users = validate_inputs(b, p, review)
    old = preference_scope(checked[QUIET], users, context_of(b))
    new = scope(s, QUIET)
    before_review = scope(s0, QUIET)
    sim = execution(b, p, eid="SYN-OPEN-SYN-U01", pointer="/scenario/primary")
    sim_session = ContextSession(b, p, review_context=review, execution_scope_context=sim)
    sim_quiet = scope(sim_session, QUIET)
    checks = []

    def check(name, passed, detail=None):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    expected_eq = {"setting_source", "respondent_identity", "current_scope"}
    check("old_bug_reproduced_on_original_data", {v["field"] for v in old["evaluated_conditions"]} == expected_eq and old["context_state"] == "unknown")
    check("metadata_not_promoted_to_business_predicates", new["evaluated_conditions"] == [])
    check("supported_atomic_review_does_not_resolve_scene_attribution",
          checked[QUIET]["semantic_assessment"]["status"] == "supported" and new["context_state"] == "unknown")
    check("unreviewed_candidate_remains_unreviewed", before_review["source_context_role_audit"]["semantic_assessment"]["status"] == "pending_independent_review")
    check("source_scoped_simulation_does_not_resolve_QUIET", sim_quiet["context_state"] == "unknown" and not sim_quiet["execution_scope_user_confirmed"])
    check("raw_context_and_source_scenario_preserved", all(
        raw["raw_context"] == evidence[raw["evidence_id"]].get("context", {})
        and raw["raw_scenario"] == evidence[raw["evidence_id"]].get("scenario")
        and raw["source_snapshot"] == fingerprint(evidence[raw["evidence_id"]])
        for row in s.view["preferences"] for raw in row["sources"]))
    original_digests = {r["preference_id"]: r["semantic_assessment"]["candidate_digest"] for r in candidate["preferences"]}
    check("all_179_candidate_digests_preserved", len(checked) == 179 and all(
        r["semantic_assessment"]["candidate_digest"] == original_digests[pid] for pid, r in checked.items()))
    check("profile_fingerprint_and_p01_digest_unchanged", s.view["original_profile_snapshot"] == fingerprint(p)
          and s.view["p01_input_digest"] == p["input_digest"] == candidate["input_digest"])
    # The dispatch reproduction bundle intentionally has zero T01 themes.
    # Root's already-saved admission bundle adds the ten actual T01 themes;
    # load it as a separate immutable input, never rewrite the dispatch bundle.
    admission_bundle = read_json(CHAIN / "admission-v1/bundle.json")
    admission_session = ContextSession(admission_bundle, p, review_context=review)
    admission = read_json(CHAIN / "admission-v1/admission-context.json")
    pool = reference_pool(admission_bundle, [t["theme_id"] for t in admission_bundle["themes"]], admission)
    check("actual_source_bound_admission_still_revalidates", len(pool["eligible_image_ids"]) == 9 and all(
        a.get("production_admission") is True and a.get("quality_source_sha256") and a.get("quality_call_input_sha256")
        for a in pool["audit"] if a["eligible"]), {"bundle_path": str(CHAIN / "admission-v1/bundle.json"),
                                                "theme_count": len(admission_bundle["themes"]), "eligible_image_ids": pool["eligible_image_ids"]})
    check("root_admission_bundle_preserves_original_p01_input", admission_session.view["p01_input_digest"] == p["input_digest"],
          {"bundle_top_level_differences": [k for k in b if fingerprint(b[k]) != fingerprint(admission_bundle[k])]})
    all_scopes = [s._common["preference_scope"](pref, users, s.view["execution_scope"]["values"]) for pref in checked.values()]
    check("no_unclassified_role_is_silently_usable", all(
        r["context_state"] != "applies" for r in all_scopes if r["source_context_role_audit"]["issues"]))
    request = admission_session.prepare_theme_request()
    check("actual_H01_request_is_new_bound_request_only", request["context_sidecar_snapshot"] == admission_session.token
          and request["input_snapshot"] == admission_session.view["original_handshake_input_snapshot"] and not request["H02_user_confirmation_inferred"])
    check("in_memory_source_objects_unchanged", fingerprint([b, p, candidate, review]) == original_objects)

    write_json(output / "context-role-view.json", s.view)
    write_json(output / "context-role-view.h01-bundle.json", admission_session.view)
    write_json(output / "review-context.bound.json", review)
    write_json(output / "h01-request.sidecar.json", request)
    write_json(output / "actual-preference-scopes.json", {"context_sidecar_snapshot": s.token, "preferences": all_scopes})
    write_json(output / "quiet-before-after.json", {"old_0_3_2": old, "sidecar_before_atomic_review": before_review,
        "sidecar_after_atomic_review": new, "diagnostic_simulation_scope_only": sim,
        "sidecar_simulation_scope": sim_quiet, "not_active_H01_selection": True,
        "note": "These are actual input diagnostics, no H01/H02 model proposal was written or accepted."})
    after = [file_record(Path(p["path"])) for p in before]
    check("all_protected_file_bytes_unchanged", before == after, {"file_count": len(before)})
    self_files = [file_record(p) for p in sorted(Path(__file__).parent.iterdir()) if p.is_file()]
    write_json(output / "source-manifest.json", {"protected_before": before, "protected_after": after,
        "all_unchanged": before == after, "frozen_0_3_2_expected": FROZEN_BASE_HASHES, "sidecar_files": self_files})
    passed = result.wasSuccessful() and all(c["passed"] for c in checks)
    report = {"issue_id": "QWEN-H01-CONTEXT-001", "repair_cycle": 1, "sidecar_version": VERSION,
        "evaluated_at_utc": datetime.now(timezone.utc).isoformat(), "status": "owner_offline_qualified_role_protocol_only" if passed else "needs_repair",
        "overall_status": "partial_pending_root_independent_retest_and_semantic_execution", "independent_holdout": False,
        "new_paid_calls": 0, "new_model_calls": 0, "unit_tests": {"run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "passed": result.wasSuccessful()},
        "actual_source_checks": checks, "actual_review_status_counts": dict(Counter(r["semantic_assessment"]["status"] for r in checked.values())),
        "h01_preparation_only": {"bundle_path": str(CHAIN / "admission-v1/bundle.json"), "context_sidecar_snapshot": admission_session.token,
                                 "target_context_resolved": False, "do_not_treat_as_ready_semantic_selection": True},
        "actual_execution_context_scope_counts": dict(Counter(r["context_state"] for r in all_scopes)),
        "scope_pending_reason_counts": dict(Counter(r["reason"] for p in all_scopes for r in p["scope_pending_reasons"])),
        "limits": ["Actual source data remains a synthetic research simulation, not real interviews.",
                   "Atomic supported/contradicted counts are review states, not accuracy.",
                   "No H01/H02 semantic proposals were generated, rebased or accepted by this evaluation.",
                   "No H02 confirmation is inferred from a scope context or an atomic review.",
                   "local_CMF enforcement checks axis/parameter families; natural-language truth still requires semantic review.",
                   "Root independent freeze/retest is required before integration."]}
    write_json(output / "self-assessment.json", report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(OUTPUT))
    args = parser.parse_args()
    report = evaluate(args.output)
    import json
    print(json.dumps({k: report[k] for k in ("status", "unit_tests", "actual_review_status_counts", "actual_execution_context_scope_counts")}, ensure_ascii=False))
    print("Actual checks:", sum(c["passed"] for c in report["actual_source_checks"]), "/", len(report["actual_source_checks"]))
    raise SystemExit(0 if report["status"] == "owner_offline_qualified_role_protocol_only" else 1)
