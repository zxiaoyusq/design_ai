"""Versioned, source-path-specific interpretation; no global key blacklist."""
VERSION = "handshake-context-sidecar-v1.0.0"
POLICY_VERSION = "prism.context-role-policy.v1"
VIEW_SCHEMA = "prism.context-role-view.v1"
EXECUTION_SCHEMA = "prism.execution-scope-context.v1"

POLICY = {
    "version": POLICY_VERSION,
    "simulation_source_contract": {
        "source_kind": "research", "project_id": "simulation-120-research", "source": "synthetic",
        "simulation": True, "is_real_interview": False,
        "record_kinds": {"opening": "authored_fictional_opening", "image_evaluation": "authored_fictional_image_response"},
        "required_context_fields": {
            "opening": ["setting_source", "respondent_identity", "current_scope"],
            "image_evaluation": ["respondent_identity", "project_kind", "current_scope", "scenario_ids", "image_origin",
                                 "picture_evaluation_does_not_prove_real_material_or_experience"],
        },
        "roles": {"setting_source": "provenance", "respondent_identity": "provenance", "project_kind": "provenance",
                  "image_origin": "provenance", "current_scope": "analysis_scope", "scenario_ids": "scenario_reference",
                  "picture_evaluation_does_not_prove_real_material_or_experience": "capability_limit"},
    },
    "explicit_business_schema": "prism.business-context.v1",
    "business_fields": ["scene", "region", "product_category", "scenario_id"],
    "local_cmf_aliases": ["local_CMF_only", "local_CMF_research_input_only"],
    "local_cmf_parameter_families": ["COL", "TEX", "OPT"],
    "unknown_role_policy": "pending",
    "source_scene_is_execution_approval": False,
}

# These existing files are read and reused, never edited or globally patched.
BASE_HASHES = {
    "common.py": "21b1e74203bae803b90655f74d066a112e383aff6e325e6736e6dd5c3500391a",
    "themes.py": "551cf241fce24b6ac14e5b81a43a2a5618ee681bbefff2b5c6265fb2fc496f83",
    "directions.py": "6129b58ebe16914543e8e62fe15aa183fef190f2cc5ec0d86ce3d98224a83ceb",
    "negative_scopes.py": "b9f78e7a9fdc4eaf47f41f8cf3a91c662024807e1b7ea0dd60508b5f7ff0bc33",
    "admission.py": "d30d16b5681f5115255da9255bd6c0024651c4c653613369338e47943fbf6e3b",
    "semantic.py": "43d08e974377d7f4b4e5c4ba269719cc87ab3cfb592539df664874f51e9955fb",
}
