import argparse
from prism_runtime.contracts import read_json, write_json
from .api import ContextSession


def main():
    parser = argparse.ArgumentParser(description="Offline context-role sidecar; frozen source and inputs unchanged.")
    parser.add_argument("action", choices=["view", "prepare-h01", "accept-h01", "select", "prepare-h02", "accept-h02"])
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--profile", required=True)
    parser.add_argument("--review-context", required=True)
    parser.add_argument("--execution-scope")
    parser.add_argument("--input")
    parser.add_argument("--selection")
    parser.add_argument("--mode", choices=["consensus", "extension", "exploration"], default="consensus")
    parser.add_argument("--theme-id", action="append")
    parser.add_argument("--selection-id")
    parser.add_argument("--synthetic-assumption", action="store_true")
    parser.add_argument("--confirmed-by")
    parser.add_argument("--admission-context")
    parser.add_argument("--negative-scopes")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    session = ContextSession(read_json(args.bundle), read_json(args.profile), review_context=read_json(args.review_context),
                             execution_scope_context=read_json(args.execution_scope) if args.execution_scope else None)
    if args.action == "view":
        result = session.view
    elif args.action == "prepare-h01":
        result = session.prepare_theme_request()
    elif args.action == "accept-h01":
        if not args.input:
            parser.error("--input proposals required")
        result = session.compile_theme_handshake(read_json(args.input), args.mode)
    elif args.action == "select":
        if not args.input or not args.theme_id or not args.selection_id:
            parser.error("--input H01 result, --theme-id and --selection-id required")
        result = session.select_themes(read_json(args.input), args.theme_id, selection_id=args.selection_id,
                                      synthetic_assumption=args.synthetic_assumption, designer_confirmed=bool(args.confirmed_by),
                                      confirmed_by=args.confirmed_by, admission_context=read_json(args.admission_context) if args.admission_context else None)
    elif args.action == "prepare-h02":
        if not args.selection:
            parser.error("--selection required")
        result = session.prepare_request(read_json(args.selection))
    else:
        if not args.input or not args.selection:
            parser.error("--input proposals and --selection required")
        result = session.compile_directions(read_json(args.input), args.mode, read_json(args.selection),
                                            negative_scope_resolutions=read_json(args.negative_scopes) if args.negative_scopes else None)
    write_json(args.output, result)
    print(args.output)


if __name__ == "__main__":
    main()
