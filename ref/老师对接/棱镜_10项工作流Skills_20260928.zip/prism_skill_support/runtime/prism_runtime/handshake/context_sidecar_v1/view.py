"""Immutable role views derived from a revalidated preference profile."""
from copy import deepcopy

from prism_runtime.contracts import require, value_key
from ..common import fingerprint, snapshot, context_of, condition_state, validate_inputs
from .policy import VERSION, POLICY, VIEW_SCHEMA, EXECUTION_SCHEMA


def _pointer(value, path):
    require(isinstance(path, str) and path.startswith("/"), "source JSON pointer required")
    try:
        for token in path[1:].split("/"):
            token = token.replace("~1", "/").replace("~0", "~")
            value = value[int(token)] if isinstance(value, list) else value[token]
        return value
    except (KeyError, IndexError, ValueError, TypeError) as exc:
        raise ValueError("invalid source pointer: " + path) from exc


def _scope_claim(preference):
    return {k: preference.get(k) for k in ("preference_id", "attitude", "title", "summary", "topic_key", "user_ids", "evidence_refs", "conditions", "condition_bindings",
                                         "context_scope", "source_contexts", "features", "quotes")}


def _contract(row):
    definition = POLICY["simulation_source_contract"]
    expected = definition["record_kinds"].get(row.get("record_kind"))
    if expected and row.get("source_subkind") == expected and all(
            row.get(k) == definition[k] for k in ("source_kind", "project_id", "source", "simulation", "is_real_interview")):
        # Identity flags must be booleans, not truthy model strings/numbers.
        if row.get("simulation") is True and row.get("is_real_interview") is False:
            return "simulation120.authored-evidence.v1"
    if row.get("context_schema") == POLICY["explicit_business_schema"]:
        return POLICY["explicit_business_schema"]
    return "untyped_source_context"


def _scenarios(row, contract):
    eid = row["evidence_id"]
    raw = row.get("scenario")
    raw_context = row.get("context") if isinstance(row.get("context"), dict) else {}
    required = contract == "simulation120.authored-evidence.v1" or row.get("target_scope") == "style_and_scenario_context"
    references, issues = [], []
    if raw is None:
        if required or raw_context.get("scenario_ids"):
            issues.append({"reason": "source_scenario_missing", "evidence_id": eid})
        return references, issues
    if not isinstance(raw, dict):
        return [], [{"reason": "untyped_source_scenario", "evidence_id": eid, "raw": deepcopy(raw)}]
    for role in ("primary", "secondary"):
        if role in raw:
            value = raw[role]
            if isinstance(value, str) and value.strip():
                references.append({"evidence_id": eid, "source_pointer": "/scenario/" + role,
                                   "label": value, "scenario_id": None, "source_role": role})
            else:
                issues.append({"reason": "invalid_scene_label", "evidence_id": eid, "source_role": role})
    ids, labels = raw.get("scenario_ids", []), raw.get("labels", [])
    if ids or labels:
        if not (isinstance(ids, list) and isinstance(labels, list) and len(ids) == len(labels) and ids
                and all(isinstance(x, str) and x for x in ids + labels) and len(ids) == len(set(ids))):
            issues.append({"reason": "scenario_id_label_mapping_missing_or_ambiguous", "evidence_id": eid})
        else:
            for i, (sid, label) in enumerate(zip(ids, labels)):
                references.append({"evidence_id": eid, "source_pointer": "/scenario/labels/" + str(i),
                                   "id_pointer": "/scenario/scenario_ids/" + str(i), "scenario_id": sid,
                                   "label": label, "source_role": "source_declared_mapping"})
    context_ids = raw_context.get("scenario_ids")
    if context_ids is not None:
        if not isinstance(context_ids, list) or not context_ids or not all(isinstance(x, str) for x in context_ids) or set(context_ids) != {r["scenario_id"] for r in references if r["scenario_id"]}:
            issues.append({"reason": "context_scenario_refs_do_not_resolve", "evidence_id": eid, "raw": deepcopy(context_ids)})
    if required and not references and not issues:
        issues.append({"reason": "source_scenario_missing", "evidence_id": eid})
    known = {"primary", "secondary", "scenario_ids", "labels", "speech_labels", "source"}
    for key in set(raw) - known:
        issues.append({"reason": "unknown_scenario_field", "evidence_id": eid, "field": key, "raw": deepcopy(raw[key])})
    return references, issues


def _classify(row):
    contract = _contract(row)
    raw = row.get("context", {})
    roles, issues, predicates = [], [], []
    if not isinstance(raw, dict):
        return {"evidence_id": row["evidence_id"], "source_contract": contract, "source_snapshot": fingerprint(row),
                "raw_context": deepcopy(raw), "raw_scenario": deepcopy(row.get("scenario")), "fields": [], "scenario_refs": [],
                "business_predicates": [], "issues": [{"reason": "untyped_source_context", "evidence_id": row["evidence_id"]}]}
    if contract == "simulation120.authored-evidence.v1":
        required = POLICY["simulation_source_contract"]["required_context_fields"][row["record_kind"]]
        issues.extend({"reason": "source_context_scope_or_provenance_field_missing", "evidence_id": row["evidence_id"], "field": field}
                      for field in required if field not in raw)
    for field, value in raw.items():
        role = "unknown"
        if contract == "simulation120.authored-evidence.v1":
            role = POLICY["simulation_source_contract"]["roles"].get(field, "unknown")
        elif contract == POLICY["explicit_business_schema"] and field in POLICY["business_fields"]:
            role = "explicit_business_condition"
        item = {"evidence_id": row["evidence_id"], "source_contract": contract, "source_pointer": "/context/" + field.replace("~", "~0").replace("/", "~1"),
                "field": field, "value": deepcopy(value), "role": role,
                "classification_reason": "declared_source_contract_and_field_path" if role != "unknown" else "no_matching_role_rule"}
        roles.append(item)
        if role == "unknown":
            issues.append({"reason": "unknown_context_field_role", **item})
        elif role == "analysis_scope" and value not in POLICY["local_cmf_aliases"]:
            issues.append({"reason": "unknown_analysis_scope", **item})
        elif role == "capability_limit" and value is not True:
            issues.append({"reason": "capability_statement_not_established", **item})
        elif role == "provenance":
            expected = {"setting_source": "synthetic_author_design", "respondent_identity": "fictional", "project_kind": "simulation"}.get(field)
            if not isinstance(value, str) or not value.strip() or (expected is not None and value != expected):
                issues.append({"reason": "source_contract_provenance_conflict", **item})
        elif role == "explicit_business_condition":
            if value is None or isinstance(value, (dict, list)):
                issues.append({"reason": "business_context_value_needs_interpretation", **item})
            else:
                predicates.append({"field": field, "operator": "eq", "value": deepcopy(value), "evidence_refs": [row["evidence_id"]]})
    scenarios, scene_issues = _scenarios(row, contract)
    return {"evidence_id": row["evidence_id"], "source_contract": contract, "source_snapshot": fingerprint(row),
            "raw_context": deepcopy(raw), "raw_scenario": deepcopy(row.get("scenario")), "fields": roles,
            "scenario_refs": scenarios, "business_predicates": predicates, "issues": issues + scene_issues}


def _execution(bundle, profile, evidence, requested):
    frozen = context_of(bundle)
    if requested is None:
        return {"origin": "frozen_brief", "values": frozen, "user_confirmed": False,
                "approval_note": "Source context is not user confirmation.", "covered_evidence_ids": None}
    require(bundle["provenance"]["mode"] == "synthetic", "simulation scope cannot authorize a real project")
    require(requested.get("schema_version") == EXECUTION_SCHEMA and requested.get("mode") == "source_scoped_simulation", "invalid execution scope schema/mode")
    require(requested.get("user_confirmed") is False, "execution simulation must declare user_confirmed=false")
    require(requested.get("p01_input_digest") == profile.get("input_digest"), "stale execution scope input binding")
    require(requested.get("profile_snapshot") == fingerprint(profile), "stale execution scope profile binding")
    values = requested.get("values", {})
    require(isinstance(values, dict) and bool(values) and set(values).issubset(POLICY["business_fields"])
            and all(isinstance(v, str) and v.strip() for v in values.values()), "only explicit scalar business fields belong in execution scope")
    covered = requested.get("evidence_ids", [])
    require(isinstance(covered, list) and covered and all(isinstance(e, str) for e in covered)
            and len(covered) == len(set(covered)) and set(covered).issubset(evidence), "execution scope needs explicit source coverage")
    bindings = requested.get("source_bindings", [])
    require(isinstance(bindings, list) and all(isinstance(r, dict) and r.get("target_field") in values for r in bindings), "execution scope source bindings required")
    for field, value in values.items():
        require(field not in frozen or value_key(frozen[field]) == value_key(value), "execution scope cannot override frozen brief context")
        refs = [r for r in bindings if r.get("target_field") == field]
        require(bool(refs), "execution value lacks a source binding")
        for ref in refs:
            eid = ref.get("evidence_id")
            require(eid in covered, "execution binding outside declared sources")
            path = ref.get("source_pointer")
            source = _classify(evidence[eid])
            allowed = {f["source_pointer"] for f in source["fields"] if f["role"] == "explicit_business_condition" and f["field"] == field}
            if field == "scene":
                allowed.update(s["source_pointer"] for s in source["scenario_refs"])
            elif field == "scenario_id":
                allowed.update(s["id_pointer"] for s in source["scenario_refs"] if s.get("id_pointer"))
            require(isinstance(path, str) and path in allowed, "execution binding must retain the declared source field role")
            require(value_key(_pointer(evidence[eid], path)) == value_key(value), "execution context value differs from bound source")
            require(ref.get("source_snapshot") == fingerprint(evidence[eid]), "execution source snapshot changed")
    return {"origin": "source_scoped_simulation", "values": {**frozen, **deepcopy(values)}, "user_confirmed": False,
            "covered_evidence_ids": covered, "source_bindings": deepcopy(bindings), "not_H01_or_H02_user_approval": True}


def derive_context_role_view(bundle, profile, *, review_context, execution_scope_context=None):
    require(isinstance(review_context, dict) and isinstance(review_context.get("reviewer_registry"), dict), "trusted review context required before role derivation")
    evidence, _, preferences, _, selected = validate_inputs(bundle, profile, review_context)
    execution = _execution(bundle, profile, evidence, execution_scope_context)
    views = []
    for preference in preferences.values():
        source_views = [_classify(evidence[eid]) for eid in preference["evidence_refs"]]
        roles = [f for source in source_views for f in source["fields"]]
        scenarios = [r for s in source_views for r in s["scenario_refs"]]
        scene_labels = {}
        for scene in scenarios:
            if scene["scenario_id"]:
                scene_labels.setdefault(scene["scenario_id"], set()).add(scene["label"])
        conflicts = [{"reason": "conflicting_scenario_labels", "scenario_id": sid, "labels": sorted(labels)}
                     for sid, labels in scene_labels.items() if len(labels) > 1]
        views.append({"preference_id": preference["preference_id"], "scope_claim_snapshot": fingerprint(_scope_claim(preference)),
                      "candidate_digest": preference.get("semantic_assessment", {}).get("candidate_digest"),
                      "semantic_assessment": deepcopy(preference.get("semantic_assessment", {})),
                      "raw_source_contexts": deepcopy(preference.get("source_contexts", [])),
                      "raw_conditions": deepcopy(preference.get("conditions", [])), "sources": source_views,
                      "roles": roles, "scenario_refs": scenarios,
                      "business_predicates": [r for s in source_views for r in s["business_predicates"]],
                      "issues": [r for s in source_views for r in s["issues"]] + conflicts,
                      "analysis_scope": "local_CMF" if any(r["role"] == "analysis_scope" for r in roles) or bundle["brief"].get("current_scope") in POLICY["local_cmf_aliases"] else None,
                      "capability_limits": [r for r in roles if r["role"] == "capability_limit"]})
    result = {"schema_version": VIEW_SCHEMA, "sidecar_version": VERSION, "role_policy": deepcopy(POLICY),
              "role_policy_snapshot": fingerprint(POLICY), "original_handshake_input_snapshot": snapshot(bundle, profile),
              "p01_input_digest": profile.get("input_digest"), "original_profile_snapshot": fingerprint(profile),
              "review_context_snapshot": fingerprint(review_context), "execution_scope_snapshot": fingerprint(execution_scope_context),
              "execution_scope": execution, "preferences": views, "selected_user_ids": selected,
              "source_context_is_business_approval": False, "scope_view_is_semantic_approval": False,
              "provenance": deepcopy(bundle["provenance"])}
    result["context_sidecar_snapshot"] = fingerprint(result)
    return result


def _explicit_conditions(preference, evidence, approved_hashes):
    predicates, issues = [], []
    for raw in preference.get("conditions", []):
        if not isinstance(raw, str):
            predicates.append(deepcopy(raw))
            continue
        bindings = [b for b in preference.get("condition_bindings", []) if b.get("source_condition") == raw]
        if len(bindings) != 1 or fingerprint(bindings[0]) not in approved_hashes:
            predicates.append(raw)
            continue
        binding = bindings[0]
        refs = binding.get("evidence_refs", [])
        require(bool(refs) and set(refs).issubset(preference["evidence_refs"]), "condition mapping outside source")
        require(any(raw in q["text"] for q in preference.get("quotes", []) if q["evidence_id"] in refs), "condition mapping does not retain its quote")
        if binding.get("review_status") != "reviewed" or not binding.get("reviewer") or not binding.get("predicates"):
            predicates.append(raw)
        else:
            predicates.extend(deepcopy(binding["predicates"]))
    if preference.get("context_scope"):
        # This extra field is not part of the upstream review claim digest.
        issues.append({"reason": "unbound_preference_context_scope", "raw": deepcopy(preference["context_scope"])})
    return predicates, issues


def evaluate_preference_scope(view, preference, users, context, *, evidence, review_context):
    row = next((r for r in view["preferences"] if r["preference_id"] == preference["preference_id"]), None)
    require(row is not None and row["scope_claim_snapshot"] == fingerprint(_scope_claim(preference)), "scope view does not bind this candidate")
    require(context == view["execution_scope"]["values"], "execution context changed outside sidecar binding")
    affected = sorted(set(preference["user_ids"]).intersection(users))
    hashes = review_context.get("approved_condition_binding_hashes", {}).get(preference["preference_id"], [])
    predicates, explicit_issues = _explicit_conditions(preference, evidence, hashes)
    predicates.extend(deepcopy(row["business_predicates"]))
    issues = deepcopy(row["issues"]) + explicit_issues
    scenarios = row["scenario_refs"]
    identities = {r.get("scenario_id") or "label:" + value_key(r["label"]) for r in scenarios}
    labels = {r["label"] for r in scenarios}
    # A negative or open-ended predicate cannot attribute a multi-scene claim.
    scene_predicates = [p for p in predicates if isinstance(p, dict) and p.get("field") in {"scene", "scenario_id"}
                        and (p.get("operator", "eq") == "eq" and isinstance(p.get("value"), str)
                             or p.get("operator") == "in" and isinstance(p.get("value"), list) and p["value"]
                             and all(isinstance(v, str) for v in p["value"]))]
    for predicate in scene_predicates:
        permitted = labels if predicate["field"] == "scene" else {r["scenario_id"] for r in scenarios if r["scenario_id"]}
        claimed = [predicate["value"]] if predicate.get("operator", "eq") == "eq" else predicate["value"]
        if scenarios and not set(claimed).issubset(permitted):
            issues.append({"reason": "condition_scene_not_in_source_scope", "predicate": deepcopy(predicate)})
    if len(identities) > 1 and not scene_predicates:
        issues.append({"reason": "multiple_source_scenarios_need_attribution", "scenario_refs": deepcopy(scenarios)})
    if scenarios and not scene_predicates:
        execution = view["execution_scope"]
        target = context.get("scene")
        target_id = context.get("scenario_id")
        if target is None and target_id is None:
            issues.append({"reason": "execution_scene_not_selected", "scenario_refs": deepcopy(scenarios)})
        elif (target is not None and target not in labels or target_id is not None and target_id not in {r["scenario_id"] for r in scenarios if r["scenario_id"]}):
            issues.append({"reason": "transfer_outside_recorded_source_scene_unverified"})
    if context.get("scene") is not None and context.get("scenario_id") is not None and scenarios:
        if not any(r["label"] == context["scene"] and r["scenario_id"] == context["scenario_id"] for r in scenarios):
            issues.append({"reason": "execution_scene_id_pair_not_in_source_scope"})
    covered = view["execution_scope"].get("covered_evidence_ids")
    if covered is not None and not set(preference["evidence_refs"]).issubset(covered):
        issues.append({"reason": "execution_scope_does_not_cover_candidate_sources"})
    state = condition_state(predicates, context)
    if issues:
        state = "unknown"
    if not affected:
        state = "not_applicable"
    return {"preference_id": preference["preference_id"], "user_ids": affected,
            "conditions": deepcopy(preference.get("conditions", [])), "evaluated_conditions": predicates,
            "context_state": state, "evidence_refs": preference["evidence_refs"], "attitude": preference["attitude"],
            "condition_bindings": deepcopy(preference.get("condition_bindings", [])),
            "source_context_role_audit": deepcopy(row), "scope_pending_reasons": issues,
            "context_sidecar_snapshot": view["context_sidecar_snapshot"],
            "execution_scope_origin": view["execution_scope"]["origin"], "execution_scope_user_confirmed": False}
