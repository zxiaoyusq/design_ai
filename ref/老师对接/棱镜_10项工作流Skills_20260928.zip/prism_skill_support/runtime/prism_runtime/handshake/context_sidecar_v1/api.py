"""Explicit sidecar entrypoints. Frozen 0.3.2 modules/files/globals stay untouched.

Because 0.3.2 has no resolver injection argument, private function namespaces
reuse its exact code objects while replacing ONLY context evaluation and the
selection context check. This is a new named sidecar version, not an execution
claimed to be unmodified 0.3.2. Every other existing gate remains in that code.
"""
from copy import deepcopy
import hashlib
import inspect
import json
from pathlib import Path
from types import FunctionType

from prism_runtime.contracts import require
from .. import common as frozen_common
from .. import themes as frozen_themes
from .. import directions as frozen_directions
from .policy import VERSION, BASE_HASHES, POLICY
from .view import derive_context_role_view, evaluate_preference_scope


def verify_base():
    require(frozen_common.ALGORITHM_VERSION == "handshake-0.3.2", "context sidecar requires frozen handshake 0.3.2")
    base = Path(frozen_common.__file__).parent
    for name, expected in BASE_HASHES.items():
        require(hashlib.sha256((base / name).read_bytes()).hexdigest() == expected, "frozen base source changed: " + name)
    return deepcopy(BASE_HASHES)


def _private_namespace(module):
    namespace = dict(vars(module))
    namespace["__name__"] = __name__ + ".isolated." + module.__name__.rsplit(".", 1)[-1]
    for name, value in vars(module).items():
        if inspect.isfunction(value) and value.__module__ == module.__name__:
            clone = FunctionType(value.__code__, namespace, value.__name__, value.__defaults__, value.__closure__)
            clone.__kwdefaults__ = deepcopy(value.__kwdefaults__)
            clone.__doc__ = value.__doc__
            namespace[name] = clone
    namespace["ALGORITHM_VERSION"] = VERSION
    return namespace


class ContextSession:
    """One immutable bundle/profile/review/scope binding, no model/network calls."""
    def __init__(self, bundle, profile, *, review_context, execution_scope_context=None):
        self.base_hashes = verify_base()
        self.bundle, self.profile = deepcopy(bundle), deepcopy(profile)
        self.review_context = deepcopy(review_context)
        self.execution_scope_context = deepcopy(execution_scope_context)
        self._view = derive_context_role_view(self.bundle, self.profile, review_context=self.review_context,
                                            execution_scope_context=self.execution_scope_context)
        self.token = self._view["context_sidecar_snapshot"]
        self.evidence = {r["evidence_id"]: r for r in self.bundle["evidence"]}
        common = _private_namespace(frozen_common)
        common["context_of"] = lambda b: deepcopy(self._view["execution_scope"]["values"])
        common["preference_scope"] = lambda p, u, c: evaluate_preference_scope(
            self._view, p, u, c, evidence=self.evidence, review_context=self.review_context)
        themes = _private_namespace(frozen_themes)
        themes.update({k: common[k] for k in ("context_of", "preference_scope", "positive_anchors", "prepare_payload")})
        directions = _private_namespace(frozen_directions)
        directions.update({k: common[k] for k in ("preference_scope", "positive_anchors", "prepare_payload")})
        def check_selection(b, p, selection, review_context=None):
            self._bound(selection)
            return themes["validate_selection"](b, p, selection, review_context)
        directions["validate_selection"] = check_selection
        self._common, self._themes, self._directions = common, themes, directions

    @property
    def view(self):
        return deepcopy(self._view)

    def _integrity(self):
        verify_base()
        require(frozen_common.snapshot(self.bundle, self.profile) == self._view["original_handshake_input_snapshot"], "session source snapshot changed")
        require(frozen_common.fingerprint(self.review_context) == self._view["review_context_snapshot"], "session review context changed")
        require(frozen_common.fingerprint(self.execution_scope_context) == self._view["execution_scope_snapshot"], "session execution scope changed")
        require(frozen_common.fingerprint(POLICY) == self._view["role_policy_snapshot"], "role policy changed")

    def _bound(self, document):
        self._integrity()
        require(isinstance(document, dict) and document.get("context_sidecar_snapshot") == self.token,
                "missing/stale context sidecar binding")
        require(document.get("input_snapshot") == frozen_common.snapshot(self.bundle, self.profile),
                "stale source input in sidecar document")
        require(document.get("review_context_snapshot") == frozen_common.fingerprint(self.review_context),
                "missing/stale review context in sidecar document")

    def _annotate(self, result):
        result["context_sidecar_snapshot"] = self.token
        result["context_sidecar_version"] = VERSION
        result["base_engine_version"] = "handshake-0.3.2"
        result["base_source_hashes"] = deepcopy(self.base_hashes)
        result["context_role_policy_snapshot"] = self.view["role_policy_snapshot"]
        result["execution_scope_snapshot"] = self.view["execution_scope_snapshot"]
        result["execution_scope"] = deepcopy(self.view["execution_scope"])
        result["execution_scope_user_confirmed"] = False
        result["H02_user_confirmation_inferred"] = False
        refs = set(result.get("preference_refs", [])) | set(result.get("negative_audit_ids", []))
        if refs:
            relevant = [p for p in self._view["preferences"] if p["preference_id"] in refs]
            result["source_scope_limits"] = [{"preference_id": p["preference_id"], "analysis_scope": p["analysis_scope"],
                                              "capability_limits": deepcopy(p["capability_limits"]),
                                              "scenario_refs": deepcopy(p["scenario_refs"])} for p in relevant]
        return result

    def _request(self, request):
        require(request.get("messages") and request["messages"][-1]["role"] == "user", "unexpected frozen request format")
        payload = json.loads(request["messages"][-1]["content"])
        _, _, preferences, _, users = frozen_common.validate_inputs(self.bundle, self.profile, self.review_context)
        scopes = {pid: self._common["preference_scope"](p, users, self._view["execution_scope"]["values"])
                  for pid, p in preferences.items()}
        payload["context_sidecar_snapshot"] = self.token
        payload["context_role_view"] = {
            "policy_version": POLICY["version"], "execution_scope": deepcopy(self.view["execution_scope"]),
            "preferences": [{"preference_id": v["preference_id"], "roles": v["roles"], "scenario_refs": v["scenario_refs"],
                             "raw_conditions": v["raw_conditions"], "business_predicates": v["business_predicates"],
                             "issues": v["issues"], "analysis_scope": v["analysis_scope"], "capability_limits": v["capability_limits"],
                             "context_state": scopes[v["preference_id"]]["context_state"],
                             "evaluated_conditions": scopes[v["preference_id"]]["evaluated_conditions"],
                             "scope_pending_reasons": scopes[v["preference_id"]]["scope_pending_reasons"]}
                            for v in self.view["preferences"]],
        }
        request["messages"][-1]["content"] = json.dumps(payload, ensure_ascii=False)
        request["messages"][0]["content"] += (
            "\n复制context_sidecar_snapshot。source/context中的身份、来源和能力标签不是用户业务条件。"
            "来源场景不等于用户已确认目标场景；多场景、缺失范围和未归因条件保持候选/待核验。"
            "local_CMF只讨论可见颜色、纹理与光学外观；图片评价不能证明真实材质、触感或使用体验。"
            "不得根据元数据修复把原QUIET条件缺失解释成无条件适用，不代替用户H02确认。")
        request["context_role_view"] = deepcopy(self.view)
        return self._annotate(request)

    def prepare_theme_request(self):
        self._integrity()
        return self._request(self._themes["prepare_theme_request"](self.bundle, self.profile, review_context=self.review_context))

    def compile_theme_handshake(self, proposals_document, mode="consensus"):
        self._bound(proposals_document)
        result = self._themes["compile_theme_handshake"](self.bundle, self.profile, proposals_document, mode,
                                                         review_context=self.review_context)
        return self._annotate(result)

    def select_themes(self, result, theme_ids, **options):
        self._bound(result)
        require("review_context" not in options, "session review context cannot be replaced")
        selected = self._themes["select_themes"](self.bundle, self.profile, result, theme_ids,
                                                 review_context=self.review_context, **options)
        return self._annotate(selected)

    def prepare_request(self, selection):
        self._bound(selection)
        return self._request(self._directions["prepare_request"](self.bundle, self.profile, selection,
                                                                  review_context=self.review_context))

    def compile_directions(self, proposals_document, mode="consensus", selection=None, *, negative_scope_resolutions=None):
        self._bound(proposals_document)
        self._bound(selection)
        require(proposals_document.get("selection_snapshot") == frozen_common.fingerprint(selection),
                "missing/stale H02 selection binding in sidecar document")
        views = {p["preference_id"]: p for p in self.view["preferences"]}
        for proposal in proposals_document.get("proposals", []):
            local = self.bundle["brief"].get("current_scope") in POLICY["local_cmf_aliases"] or any(
                views.get(pid, {}).get("analysis_scope") == "local_CMF" for pid in proposal.get("preference_ids", []))
            if local:
                require(proposal.get("design_axis") == "CMF", "local_CMF analysis scope does not admit an ID direction")
                fields = [f.get("parameter_id", "") for f in proposal.get("required_features", [])] + proposal.get("comparison_features", [])
                require(all(isinstance(f, str) and f.split("-", 1)[0] in POLICY["local_cmf_parameter_families"] for f in fields),
                        "local visible CMF field requires scope review; no automatic material/experience/geometry claim")
        result = self._directions["compile_directions"](self.bundle, self.profile, proposals_document, mode, selection,
                                                         review_context=self.review_context, negative_scope_resolutions=negative_scope_resolutions)
        for request in result.get("grouping_requests", []):
            self._annotate(request)
            request["provenance"]["execution_scope_user_confirmed"] = False
        for direction in result.get("design_directions", []):
            self._annotate(direction)
        return self._annotate(result)


def prepare_theme_request(bundle, profile, *, review_context, execution_scope_context=None):
    return ContextSession(bundle, profile, review_context=review_context, execution_scope_context=execution_scope_context).prepare_theme_request()


def compile_theme_handshake(bundle, profile, proposals_document, mode="consensus", *, review_context, execution_scope_context=None):
    return ContextSession(bundle, profile, review_context=review_context, execution_scope_context=execution_scope_context).compile_theme_handshake(proposals_document, mode)


def select_themes(bundle, profile, result, theme_ids, *, review_context, execution_scope_context=None, **options):
    return ContextSession(bundle, profile, review_context=review_context, execution_scope_context=execution_scope_context).select_themes(result, theme_ids, **options)


def prepare_request(bundle, profile, selection, *, review_context, execution_scope_context=None):
    return ContextSession(bundle, profile, review_context=review_context, execution_scope_context=execution_scope_context).prepare_request(selection)


def compile_directions(bundle, profile, proposals_document, mode="consensus", selection=None, *, review_context, execution_scope_context=None, negative_scope_resolutions=None):
    return ContextSession(bundle, profile, review_context=review_context, execution_scope_context=execution_scope_context).compile_directions(proposals_document, mode, selection, negative_scope_resolutions=negative_scope_resolutions)
