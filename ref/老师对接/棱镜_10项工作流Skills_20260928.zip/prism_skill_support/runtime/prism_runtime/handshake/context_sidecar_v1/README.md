# H01/H02 context 角色侧车 v1.0.0

对应修复 `QWEN-H01-CONTEXT-001`，repair cycle 1。模块版本为
`handshake-context-sidecar-v1.0.0`，角色策略为 `prism.context-role-policy.v1`。
本目录与新 repair 输出是本次新增内容；原 handshake 0.3.2、共享 CONTRACT、P01、源资料及审阅回执保持原样。

## 两次握手及三档

| 阶段 | 输出 | 仍需保留的边界 |
| --- | --- | --- |
| H01 | 主题候选、未匹配诉求、冲突与待核验项；另行记录主题选择 | 原子偏好复核通过不等于趋势关系成立；来源场景不等于用户确认执行场景 |
| H02 | 设计方向、可定位载体、执行约束与 grouping_requests | 同载体特征、负面条件、人群范围、图片准入、语义证据继续核验；不推定用户已认可方向 |

`consensus` 共识优先只允许 direct_support；`extension` 适度延展增加
anchored_extension；`exploration` 创新探索再增加 exploratory_hypothesis。
三档累进调节方向延展幅度；排斥条件、证据要求、图片资格及对象范围不随档位放宽。

## 修复的错误与保留的未知

0.3.2 对单一 source_contexts 字典的每个键生成业务 eq；两个完整字典稍有不同则全部判为多语境。
真实回放中的 setting_source、respondent_identity、current_scope 因此被当成缺失的业务条件。
此侧车先调用现有 P01 `validate_reviewed_profile` 的受信消费路径，再从实际 evidence 原记录建立只读角色视图。
每个字段保留原值、JSON pointer、evidence_id、分类原因及完整来源 SHA256。

- `simulation-120-research` + research/source/record_kind/subkind/严格布尔身份联合匹配时，采用本批明确的生产者约定。
  来源、虚构身份及 image_origin 留作 provenance；current_scope 归 analysis_scope；图片不能证明真实材料/体验的标记归 capability_limit；scenario_ids 归来源场景引用。
- `prism.business-context.v1` 是另一个显式来源 schema，scene、region、product_category、scenario_id 才生成业务谓词。
  同名键在未识别来源中不自动忽略。未知字段/值、预期字段缺失或来源冲突保持 unknown。
- source.scenario 的 primary/secondary 或 scenario_ids/labels 按真实字段建立引用；context.scenario_ids 必须对上。
  不根据 ID 后缀猜场景。同 ID 不同标签、未归因的多场景、执行场景缺失或超出来源均保持 unknown。
- 原 conditions 保留。自由文本条件不会自动转谓词；condition_bindings 必须保留来源/原话且哈希列入调用方
  `review_context.approved_condition_binding_hashes[preference_id]`。此新版本对 synthetic 也执行这条要求。
  不在 P01 复核 claim 内的额外 context_scope 只能作为待核验项。

QUIET 的真实原子复核目前为 supported，来源同时含“夜间独自阅读／客厅白天陈设”，candidate.conditions 为空。
移除三个错误元数据 eq 后，它仍为 unknown；选择其中一个模拟执行场景也不能补上偏好归因。
代码不补写条件、不删掉另一个来源场景、不重签旧回执。

## 执行场景单独绑定

可选 `execution_scope_context` 仅适用于 synthetic 项目，schema 为
`prism.execution-scope-context.v1`、mode 为 `source_scoped_simulation`、user_confirmed 必须是 false。
它绑定原 P01 input_digest、完整 profile_snapshot、覆盖 evidence_ids，以及每个执行字段的原来源 pointer/source_snapshot。
scene 只能引用来源标签或显式业务 scene；scenario_id 只能引用来源 ID 或显式业务 scenario_id。
不能把身份字段改名成 scene，也不能覆盖原 brief.context。

这是一份来源范围内的模拟条件，不是补造的真实用户确认。单场景、无其他未决条件且受信复核通过的候选可以在此范围内继续；
多场景归因、自由文本条件和范围缺失仍 pending。未覆盖的证据不能借用该上下文获得支持。

完整角色策略、原输入、原 profile、调用方 review_context 和 execution_scope_context 一起生成 context_sidecar_snapshot。
H01 回复、H01 结果、主题选择和 H02 回复必须绑定该 token；input_snapshot、review_context_snapshot 均必填。
H02 回复还必须绑定完整 selection_snapshot，negative_scope_resolutions 继续绑定该选择。
变更场景或审阅版本后应重新 prepare，不能给旧回复补一个新 token 来冒充新运行。

## 复用方式与校验范围

0.3.2 没有 context resolver 注入参数。本侧车为 common/themes/directions 的本地函数创建每会话独立的 globals 字典，
复用原函数的同一个 code object；只替换 context_of、preference_scope 及其直接调用链，并标注新版本。
它不 monkeypatch 全局模块，不改原文件。每次公共操作检查原引擎 SHA256，核对会话的输入、审阅、策略及执行场景快照。
原有引用核验、受信审阅、CT001 同载体范围、CT002 双向负面审计和图片准入函数继续执行。

local_CMF 的结构限界：H02 只接受 CMF 轴以及 COL/TEX/OPT 参数族；ID、几何、实体材料类字段拒绝并要求另行明确范围。
正向与负向来源的 analysis_scope/capability_limits/scenario_refs 随设计方向和 grouping_request 继续传递。
这不能检测自然语言里所有夸大的材料、触感、体验或商业承诺；实际语义关系仍需独立审阅。

## 调用

```python
from prism_runtime.handshake.context_sidecar_v1 import ContextSession

session = ContextSession(bundle, profile,
    review_context={"reviewer_registry": trusted_registry},
    execution_scope_context=None)
view = session.view                 # 拷贝，不改原 P01
request = session.prepare_theme_request()
# 由独立模型/宿主实际响应 request；本模块不发模型请求。
h01 = session.compile_theme_handshake(response, "consensus")
selection = session.select_themes(h01, theme_ids, selection_id=selection_id,
    synthetic_assumption=True, admission_context=admission_context)
h02_request = session.prepare_request(selection)
h02 = session.compile_directions(h02_response, "consensus", selection,
    negative_scope_resolutions=separate_scope_decisions)
```

synthetic_assumption 只用于明确标注的模拟选择；真实 designer_confirmed 必须来自明确调用方授权。
本侧车不会把 execution_scope_context 或 P01 的 supported 当成 H01/H02 人工审批。

CLI 支持 view / prepare-h01 / accept-h01 / select / prepare-h02 / accept-h02；
所有动作需要 `--bundle --profile --review-context --output`，其余参数见 `--help`。
review-context JSON 应包含 reviewer_registry 对象；单独的 registry 文件不能直接冒充该包装。

```powershell
$env:PYTHONUTF8='1'
py -3.13 -B -m unittest prism_runtime.handshake.context_sidecar_v1.tests -v
py -3.13 -B -m prism_runtime.handshake.context_sidecar_v1.verify
```

verify 只在 `outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/QWEN-H01-CONTEXT-001` 下写入。
离线诊断使用原始 candidate 与新 review-wire001-recovery profile/registry，运行本侧车测试与原 0.3.2 内存测试；
另外只读回验 Root 已保存的 admission-v1/bundle.json 及质量文件，不改其路径或内容。
所有报告明确标记 owner self-assessment、零新增模型调用、零付费调用，不冒充独立验收。

## 交接文件与使用限制

- `context-role-view.json`、`actual-preference-scopes.json`：dispatch 原输入的诊断；此输入尚未接入 T01，themes 为空。
- `context-role-view.h01-bundle.json`、`h01-request.sidecar.json`：绑定 Root 已保存的 admission-v1/bundle.json，含 10 个真实 T01 主题和 9 个准入引用图。
  当前未选择执行场景，179 条范围均 unknown；这是新请求样本，不能直接声称主题已可选。
- `quiet-before-after.json`：旧错误复现、复核前后及单来源模拟的 QUIET 诊断。内含模拟上下文只用于反例，未用于选主题。
- `review-context.bound.json`：原 registry 的只读包装；`source-manifest.json` 记录受保护文件前后哈希及新侧车哈希；
  `unit-tests.txt`、`self-assessment.json` 记录有限自评。

Root 应独立冻结/复测此版本，并在明确的证据范围下准备真正的新 H01/Qwen 请求。
若没有充分的主题偏好场景归因，应报告证据/范围缺口；不能为获得非空方向结果改写 P01 或虚构 H02 确认。
