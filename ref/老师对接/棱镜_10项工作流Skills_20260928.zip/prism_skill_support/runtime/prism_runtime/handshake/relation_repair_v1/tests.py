from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from prism_runtime.contracts import write_json, ContractError
from ..compact_context_v1.tests import CompactTests, response_fixture
from .api import prepare_repair, accept_repair, SCHEMA, identity

class RepairTests(unittest.TestCase):
    scratch_root = Path(__file__).resolve().parents[3] / "outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/CLOSURE-H01-003/_test_tmp"

    def setUp(self):
        self.scratch_root.mkdir(parents=True, exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=self.scratch_root)
        self.path = Path(self.temp.name).resolve()
        assert self.path.is_relative_to(self.scratch_root.resolve())
        self.addCleanup(self.temp.cleanup)
        h = CompactTests(); h.setUp()
        self.h = h
        props = deepcopy(h.t["proposals"])
        props[0].update(relation_basis="anchored_extension", transfer_scope="cross_category", target_user_ids=["U1"], explanation="Synthetic conflicting relation fixture.",
                        hypotheses=[{"reason": "Synthetic cross-category hypothesis fixture."}])
        self.original = response_fixture(h.package, props)
        for name, doc in (("request", h.package["request"]), ("side", h.package["side_table"]), ("original", self.original)):
            write_json(self.path / (name + ".json"), doc)
        self.prepared = prepare_repair(self.path / "request.json", self.path / "side.json", self.path / "original.json")

    def reply(self, action="replace"):
        replacement = deepcopy(self.original["proposals"][0])
        replacement["relation_basis"] = "exploratory_hypothesis"
        return {"schema_version": SCHEMA, "repair_snapshot": self.prepared["repair_snapshot"],
            "original_response_sha256": self.prepared["source_identities"]["response"]["sha256"],
            "proposal_id": replacement["match_id"], "action": action, "replacement": replacement if action == "replace" else None,
            "reason": "SYNTHETIC repair protocol fixture only; not actual model semantics."}

    def accept(self, reply, mode="exploration"):
        write_json(self.path / "reply.json", reply)
        return accept_repair(self.prepared, self.path / "reply.json", mode=mode)

    def test_preparation_retains_target_negatives_and_policy(self):
        import json
        p = json.loads(self.prepared["messages"][-1]["content"])
        self.assertEqual(p["all_negative_audit_ids"], ["P3"])
        self.assertIn("P3", p["included_preference_ids"])
        self.assertEqual(p["original_proposal"], self.original["proposals"][0])

    def test_model_replacement_is_new_hypothesis_not_old_pass(self):
        original_sha = identity(self.path / "original.json")
        result = self.accept(self.reply())
        self.assertEqual(len(result["theme_candidates"]), 1)
        self.assertFalse(result["relation_repair"]["original_v1_pass_claimed"])
        self.assertEqual(result["axis_assessments"][0]["theme_assessments"][0]["reason"], self.original["axis_assessments"][0]["theme_assessments"][0]["reason"])
        self.assertEqual(identity(self.path / "original.json"), original_sha)
        self.assertFalse(self.accept(self.reply(), "consensus")["theme_candidates"])

    def test_drop_only_unlinks_match_ids_and_keeps_reference_groups(self):
        result = self.accept(self.reply("drop"))
        self.assertFalse(result["theme_candidates"])
        self.assertEqual(result["relation_repair"]["action"], "drop")
        for a, orig in zip(result["axis_assessments"], self.original["axis_assessments"]):
            for cell, old in zip(a["theme_assessments"], orig["theme_assessments"]):
                self.assertEqual(cell["match_ids"], [])
                for field in ("positive_preference_ids", "opposing_preference_ids", "pending_preference_ids", "reason"):
                    self.assertEqual(cell[field], old[field])
        self.assertEqual(len(result["complete_negative_audit"]), 1)

    def test_cannot_change_or_expand_any_frozen_claim_or_ref(self):
        for key, value in (("preference_ids", ["P2"]), ("trend_refs", ["new-source"]), ("title", "New title"), ("shared_principle", "new claim"), ("target_user_ids", ["new-user"])):
            r = self.reply(); r["replacement"][key] = value
            with self.subTest(key=key), self.assertRaises(ContractError): self.accept(r)

    def test_original_conflict_still_rejected(self):
        r = self.reply(); r["replacement"]["relation_basis"] = "anchored_extension"
        with self.assertRaisesRegex(ContractError, "same-category"): self.accept(r)

    def test_stale_snapshot_and_extra_matrix_edits_rejected(self):
        for key, value in (("repair_snapshot", "stale"), ("original_response_sha256", "stale"), ("axis_assessments", [])):
            r = self.reply(); r[key] = value
            with self.subTest(key=key), self.assertRaises(ContractError): self.accept(r)

    def test_drop_cannot_hide_replacement_or_empty_reason(self):
        for alteration in ("replacement", "reason"):
            r = self.reply("drop")
            r[alteration] = self.original["proposals"][0] if alteration == "replacement" else ""
            with self.subTest(alteration=alteration), self.assertRaises(ContractError): self.accept(r)

    def test_source_file_changed_after_prepare_is_rejected(self):
        with (self.path / "original.json").open("a", encoding="utf-8") as f: f.write("\n")
        with self.assertRaisesRegex(ContractError, "source bytes changed"): self.accept(self.reply())

    def test_unknown_transfer_or_new_hypothesis_fields_rejected(self):
        for field in ("transfer", "hypothesis"):
            r = self.reply()
            if field == "transfer": r["replacement"]["transfer_scope"] = "unknown"
            else: r["replacement"]["hypotheses"][0]["new_evidence"] = "invented"
            with self.subTest(field=field), self.assertRaises(ContractError): self.accept(r)

if __name__ == "__main__":
    unittest.main()
