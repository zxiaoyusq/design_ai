import argparse
from pathlib import Path
from prism_runtime.contracts import read_json, write_json, require
from .api import prepare_repair, accept_repair

parser = argparse.ArgumentParser(description="Bounded H01 repair prepare/accept; zero model calls.")
parser.add_argument("action", choices=["prepare", "accept"])
parser.add_argument("--request")
parser.add_argument("--side-table")
parser.add_argument("--original-response")
parser.add_argument("--prepared")
parser.add_argument("--repair-response")
parser.add_argument("--mode", choices=["consensus", "extension", "exploration"], default="consensus")
parser.add_argument("--output", required=True)
args = parser.parse_args()
require(not Path(args.output).exists(), "use a new output file")
if args.action == "prepare":
    if not all((args.request, args.side_table, args.original_response)):
        parser.error("--request --side-table --original-response required")
    result = prepare_repair(args.request, args.side_table, args.original_response)
else:
    if not args.prepared or not args.repair_response:
        parser.error("--prepared --repair-response required")
    result = accept_repair(read_json(args.prepared), args.repair_response, mode=args.mode)
write_json(args.output, result)
print(args.output)
