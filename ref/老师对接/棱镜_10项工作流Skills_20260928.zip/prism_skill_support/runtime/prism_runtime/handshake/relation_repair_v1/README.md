# relation_repair_v1 · CLOSURE-H01-003

`handshake-relation-repair-v1.0.0` 只准备/接收一次、一个既有 proposal 的模型返修，不运行模型/API。
前置：原来源、审阅、矩阵角色通过，但唯一原 proposal 因 anchored_extension+cross_category 被既有 CT001 拒绝。

prepare_repair(request_path, side_path, original_response_path) 先重验原输入与 typed failure，再提供原 proposal、
全部关系定义、完整趋势原文/原子原话/条件、目标用户相关全部负向、全矩阵争议与未决引用、所有负向 ID 和完整旁表。
模型可以 replace 或 drop，不要求非空正向结果。唯一可改字段是 relation_basis、transfer_scope、hypotheses、explanation；
标题、shared_principle、用户、主题、正反/趋势引用、所有其他 proposal 字段冻结不变。

response_schema 将 CT001 三种合法关系/迁移组合编码在 replacement 的 anyOf 分支：直接/适度延展必须同品类，
跨品类必须是明确探索假设。drop 的 replacement=null 由提示及接收闸口强制。
字段与来源不能扩大或偷换，原完整 negative/disputed 清单不可编辑，矩阵分组/理由不可编辑。
撤回时仅机械删除其 match_ids 回链，逐项记差异。

accept_repair(prepared, repair_response_path, mode=...) 核对真实新回复文件身份、精确 schema/快照和允许字段，
再把新 call 的派生完整回复交 matrix_state_bridge_v1 与冻结 v1/ContextSession 检查。
新结果不是旧 v1 PASS，也不表示人亲自复核或偏好关系正确。旧原文/失败不写入覆盖。

CLI：

```text
python -B -m prism_runtime.handshake.relation_repair_v1 prepare --request REQUEST --side-table SIDE --original-response ORIGINAL --output NEW_PREPARED
python -B -m prism_runtime.handshake.relation_repair_v1 accept --prepared NEW_PREPARED --repair-response ACTUAL_NEW_REPLY --mode exploration --output NEW_RESULT
```

Root 最多发起一次真实标准 Astra 返修，禁止 Fast；是否替换/撤回由该新模型回复决定，模块不自动给出选择。
准备产物包含 messages/response_schema/side_table；向模型只传 messages 和 response_schema，不附全旁表。
单元测试的替换/撤回回复为明确 synthetic 协议 fixture，不是实际 H01 输出。
