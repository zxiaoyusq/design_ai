# compact_context_v1 · CLOSURE-H01-001

新增 `handshake-compact-context-v1.0.0`，只负责第一次握手 H01 的确定性压缩准备与回复接收。
复用已独立验收的 context_sidecar_v1/handshake 0.3.2，不修改它们或共享 CONTRACT，不调用模型/API。
实际模型由 Root 统一使用 Astra 标准模式执行，禁止 Fast。H02 局部特征、尺度与载体尚待用户确认。

## 输出与不变量

`prepare_theme_request` 返回 `{request, side_table, size_report}`；**只把 request.messages 发给模型**。
完整 bundle、原 saved_profile、受信复核副本、registry、审阅回执、原角色视图、全部范围审计和图片准入旁表都在 side_table。
request 绑定其快照及原 bundle/profile/registry/执行场景/设计意图/准入上下文的内容 SHA256。
对象快照使用既有 canonical JSON fingerprint；CLI 另附导出文件的字节 SHA256。两种哈希用途不同。

所有语义候选先经过 `preferences.validate_reviewed_profile`，只使用返回副本建立模型输入。
saved_profile.cached supported 不具有权威。ContextSession 在接收阶段继续走同一个受信入口重新校验。

- 不按 Like/Dislike 或场景裁剪来源：四个真实请求均保留全部 181 条来源、179 个原子偏好、10 个 T01 主题。
  场景有效候选与 unknown 分别标明。全部 58 条 Dislike、1 条 contradicted、所有多场景/自由条件完整可见。
- 不截断原话，不生成摘要；原来源中的 text_kind、合成身份、场景、record_refs、区域/载体字段等保留。
  原 T01 摘要是已有模型解释，source_paraphrase 仍是转述，不能改成直接原话。
- shared_values 只共享完全相等的 JSON 值。来源 context/scenario、偏好 provenance 等重复对象用 ID 回链。
  source_contexts 的每条原 context 都核对实际 evidence 后，以 source_context_refs 引用。
- 重复记录的列名写在 record_schemas。`{"$r":["R01",[值1,值2,…]]}` 表示按 R01 列顺序排列的完整对象。
  嵌套对象同理；缺字段、null、顺序、原字符串及未知扩展字段都可精确还原。
  展开函数为 `unpack_record_columns`，不是模型摘要或关键词重写。
- `normalize.restore_prompt_sources` 精确还原所有来源；`restore_preferences` 加回旁表中的追踪字段后
  精确还原完整受信原子偏好。所有条件/quote/feature/feature_validation/审阅状态与理由都在语义请求中。

如需查看可读原对象，可离线展开 request.messages 最后一条中的 tables；不要把展开结果与压缩表同时发给模型。

## 从模型请求中移走的内容

每个导出目录都有 `off-prompt-fields.json`，逐项说明位置和判断影响。

| 内容 | 保留位置 | 模型仍能依据什么判断 |
| --- | --- | --- |
| 重复审阅回执、批次回执、计数与派生聚合缓存 | side_table 完整原 profile 与受信副本 | 每个原子候选的受信 verdict、完整 reason、candidate_digest、review_ids；全部原来源 |
| 重复 source_contexts 与角色审计副本 | side_table 原 profile、context_role_view、preference_scopes | 原字段值一次、明确的角色映射/场景指针、逐候选状态与完整 pending 原因 |
| source_preference_id/source_request_id | side_table.preference_fields_off_prompt | 唯一 namespaced preference_id；上游批次 ID 不作为支持证据 |
| 顶层 confirmed_user_support 缓存 | 同上及完整 profile | 重新核验后的 semantic_assessment，不能使用保存的布尔缓存 |
| 120 图完整 DNA 与图像运行元数据 | side_table.inputs.bundle.images | H01 的原主题文字/视觉引用 ID、通过原 admission 重验的图 ID；H01 不从 DNA 推局部特征 |

移走的是完整审计与重复派生副本，原子来源和候选逐值可还原；未把聚合缓存作为新的独立证据。
这不证明模型对记录表的理解精度已通过语义评测。Root 需独立复测，再实际调用并检查输出。
字符/token 估计针对 messages 内容；当前没有执行模型的本地 tokenizer，token 为明确标注的 UTF-8 启发式估计，不能作为已验证预算。

## 回复接口

准备请求中的 response_contract 是机器接收要求。回复必须携带：

- schema_version=`prism.compact_h01_response.v1`、request_id、compact_snapshot。
- input_snapshot、review_context_snapshot、context_sidecar_snapshot、side_table_snapshot。
- 与原 inventory 一致的全部 negative_audit_ids、review_disputed_preference_ids。
- 原 H01 proposals（允许为空），及每个风格×每个实际 T01 主题的 axis_assessments。

每个对应格保留正向、反向、争议、待定引用及原因，明确无当前证据；所有 proposal 都须用 match_ids 回链。
positive 不能用元素级偏好、未核验态度或 unknown 场景冒充主题支持；opposing 不能把场景未明的负向泛化。
旁表中所有负向都会在接收结果 complete_negative_audit 中完整恢复，包括 original_preference 的特征与对象范围；
即使 proposals 为空，也不丢掉负向证据。完整清单回传仅是协议完整性，不是模型已正确处理全部反证的证明。

`accept_theme_response` 用当前原输入重建请求、重放受信审阅，逐值比较 request 与 side_table，拒绝旧 token、改过的 prompt、
换场景/来源/registry/准入后复用回复，再交原 ContextSession.compile_theme_handshake 执行原约束。
六个大风格确认不会变成主题选择、图片池或 H02 的确认。矩阵是新模型回复中的语义提案，代码不生成六方向对应结论。
三档累计关系及 CT001/CT002 不变；H02 不在此版本接收，不生成新的 GroupingRequest。

## 最小可调用 API

```python
from prism_runtime.handshake.compact_context_v1 import prepare_theme_request, accept_theme_response

options = dict(review_context={"reviewer_registry": trusted_registry},
    execution_scope_context=source_scoped_simulation,  # 明确绑定且 user_confirmed=false
    design_intent_context=broad_style_intent,
    admission_context=existing_admission_context)
package = prepare_theme_request(bundle, saved_profile, request_id="H01-scene-01-compact", **options)
messages = package["request"]["messages"]  # 交 Root 实际执行；模块不请求模型
# response 必须来自该 messages 的新回复，不能给旧 H01 回复补 token。
result = accept_theme_response(bundle, saved_profile,
    package["request"], package["side_table"], response, mode="consensus", **options)
```

CLI 参数保持文件式输入，可独立调用；--review-context 文件是包含 reviewer_registry 的包装，而非裸 registry。
输出必须使用新路径，默认拒绝覆盖已准备/已接收版本。

```powershell
$env:PYTHONUTF8='1'
py -3.13 -B -m prism_runtime.handshake.compact_context_v1 prepare-h01 --help
py -3.13 -B -m prism_runtime.handshake.compact_context_v1 accept-h01 --help
py -3.13 -B -m unittest prism_runtime.handshake.compact_context_v1.tests -v
py -3.13 -B -m prism_runtime.handshake.compact_context_v1.deliver --output '<新的交付目录>'
```

deliver 从 Root 已有四个准备请求、原 scope、admission bundle 和新 review-wire001-recovery 只读生成四份新 compact 请求。
它只在调用方明确给出的 output 下写，Root 可使用自己唯一的 loop 写目录；不强制 Root 写握手 owner 的目录。
导出 `request.json`、`messages.json`、`side-table.json`、尺寸/字段/确认清单、文件 SHA256 及总索引与自评。
测试里的 response_fixture 是明确标注的人工协议样例；deliver 不生成任何实际 H01/H02 模型回复。

## H02 待确认

h02_pending_confirmation 列出局部颜色、材质外观、纹理、光泽四类的特征、尺度、载体，全部为 null/false。
需先得到实际 H01 结果与明确主题选择，再接 DNA owner 的局部投影契约，并保留 CT002 carrier/image 范围及全部负向审计。
现有 9 图通过准入只表示参考资格；图片校准来源、合成访谈身份、设计意图和用户批准互不替代。
