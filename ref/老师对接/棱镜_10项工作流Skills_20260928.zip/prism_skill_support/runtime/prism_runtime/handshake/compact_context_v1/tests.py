"""Protocol-only authored fixtures. Never actual H01/Qwen/Astra responses."""
from copy import deepcopy
import json
import unittest

from prism_runtime.contracts import ContractError
from ..examples import fixture
from ..context_sidecar_v1.tests import reviewed
from ..admission import prepare_fixture_admission
from ..common import fingerprint, POLICIES
from .api import prepare_theme_request, accept_theme_response, RESPONSE_SCHEMA
from .normalize import (normalize, restore_prompt_sources, restore_preferences, expand,
                        pack_record_columns, unpack_record_columns)


def intent():
    return {"approved_broad_style_axes": [{"axis_id": "STYLE-A", "name": "测试方向A"}, {"axis_id": "STYLE-B", "name": "测试方向B"}],
            "specific_theme_ids_confirmed": False, "specific_image_pool_confirmed": False,
            "H02_features_confirmed": False, "participant_preferences_inferred_from_design_intent": False,
            "fixture_only": True}


def decode(package):
    payload = json.loads(package["request"]["messages"][-1]["content"])
    return payload, unpack_record_columns(payload["tables"], payload["record_schemas"])


def response_fixture(package, proposals=None):
    payload, tables = decode(package)
    response = {"schema_version": RESPONSE_SCHEMA, "request_id": package["request"]["request_id"],
                "compact_snapshot": package["request"]["compact_snapshot"],
                **{k: package["request"]["bindings"][k] for k in ("input_snapshot", "review_context_snapshot", "context_sidecar_snapshot", "side_table_snapshot")},
                "negative_audit_ids": deepcopy(payload["inventory"]["negative_audit_ids"]),
                "review_disputed_preference_ids": deepcopy(payload["inventory"]["review_disputed_preference_ids"]),
                "proposals": deepcopy(proposals or []), "axis_assessments": []}
    for axis in payload["design_intent_context"]["approved_broad_style_axes"]:
        cells = []
        for theme in tables["themes"]:
            proposed = [p for p in response["proposals"] if p["theme_id"] == theme["theme_id"]]
            cells.append({"theme_id": theme["theme_id"], "state": "positive" if proposed else "no_evidence",
                          "reason": "Authored interface fixture only, not an actual semantic judgement.",
                          "positive_preference_ids": sorted({i for p in proposed for i in p["preference_ids"]}),
                          "opposing_preference_ids": [], "disputed_preference_ids": [], "pending_preference_ids": [],
                          "trend_refs": sorted({i for p in proposed for i in p["trend_refs"]}),
                          "match_ids": [p["match_id"] for p in proposed]})
        response["axis_assessments"].append({"axis_id": axis["axis_id"], "theme_assessments": cells})
    return response


class CompactTests(unittest.TestCase):
    def setUp(self):
        self.b, p, self.t, _ = fixture()
        self.p, self.review = reviewed(self.b, p)
        self.options = {"review_context": self.review, "design_intent_context": intent(),
                        "admission_context": prepare_fixture_admission(self.b)}
        self.package = prepare_theme_request(self.b, self.p, **self.options)

    def accept(self, response, package=None, bundle=None, profile=None, **options):
        package = package or self.package
        return accept_theme_response(bundle or self.b, profile or self.p, package["request"], package["side_table"], response,
                                     **{**self.options, **options})

    def test_exact_reconstruction_including_all_sources_and_quoted_text(self):
        _, tables = decode(self.package)
        self.assertEqual(restore_prompt_sources(tables), self.b["evidence"])
        self.assertEqual(restore_preferences(tables, self.package["side_table"]["preference_fields_off_prompt"]),
                         self.package["side_table"]["validated_profile"]["preferences"])
        self.assertEqual(tables["themes"], self.b["themes"])
        self.assertEqual(tables["users"], self.b["users"])

    def test_missing_and_null_and_reserved_marker_remain_distinct(self):
        values = [{"id": "1", "long_property_field": None}, {"id": "2"},
                  {"$r": ["raw-source-string", [1, 2]]}, {"id": "3", "long_property_field": "完整原话\n第二行"}]
        packed, schemas = pack_record_columns(values)
        self.assertEqual(unpack_record_columns(packed, schemas), values)

    def test_unknown_fields_preserved_not_silently_whitelisted_out(self):
        p = deepcopy(self.package["side_table"]["validated_profile"])
        p["preferences"][0]["future_condition_field"] = {"verbatim": "未知扩展条件"}
        tables, off = normalize(self.b, p, self.package["side_table"]["context_role_view"], self.package["side_table"]["preference_scopes"])
        self.assertEqual(restore_preferences(tables, off), p["preferences"])

    def test_negative_carrier_image_and_region_annotations_roundtrip(self):
        p = deepcopy(self.package["side_table"]["validated_profile"])
        p["preferences"][2]["features"][0].update(object_scope={"kind": "candidate_bindings", "bindings": [{"image_id": "I1", "object_id": "shell"}]},
                                               observation_refs=["I1-OPT-002"], region_ref={"bbox_xyxy": [0.1, 0.1, 0.9, 0.9]})
        p["preferences"][2]["scope_alternative"] = {"kind": "image", "image_ids": ["I1"]}
        tables, off = normalize(self.b, p, self.package["side_table"]["context_role_view"], self.package["side_table"]["preference_scopes"])
        packed, schemas = pack_record_columns(tables)
        self.assertEqual(restore_preferences(unpack_record_columns(packed, schemas), off), p["preferences"])

    def test_repeat_preparation_is_deterministic_and_source_preserving(self):
        before = fingerprint([self.b, self.p, self.options])
        again = prepare_theme_request(self.b, self.p, **self.options)
        self.assertEqual(again, self.package)
        self.assertEqual(before, fingerprint([self.b, self.p, self.options]))

    def test_prepare_accept_existing_H01_pipeline_without_claiming_approval(self):
        result = self.accept(response_fixture(self.package, self.t["proposals"]))
        self.assertEqual(len(result["theme_candidates"]), 1)
        self.assertFalse(result["designer_confirmed"])
        self.assertFalse(result["compact_context"]["semantic_relation_verified"])
        self.assertFalse(result["h02_pending_confirmation"]["user_confirmed"])
        self.assertEqual([n["preference_id"] for n in result["complete_negative_audit"]], ["P3"])
        self.assertEqual(result["complete_negative_audit"][0]["original_preference"]["features"], self.p["preferences"][2]["features"])

    def test_empty_semantic_result_still_carries_all_negative_audit(self):
        result = self.accept(response_fixture(self.package))
        self.assertEqual(result["theme_candidates"], [])
        self.assertEqual([p["preference_id"] for p in result["complete_negative_audit"]], ["P3"])
        self.assertEqual(result["complete_negative_audit"][0]["conditions"], self.p["preferences"][2]["conditions"])

    def test_all_modes_keep_same_negative_evidence(self):
        outputs = [self.accept(response_fixture(self.package, self.t["proposals"]), mode=mode) for mode in POLICIES]
        self.assertTrue(all(r["complete_negative_audit"] == outputs[0]["complete_negative_audit"] for r in outputs))

    def test_modes_remain_cumulative_for_anchored_hypothesis(self):
        proposals = deepcopy(self.t["proposals"])
        proposals[0].update(relation_basis="anchored_extension", hypotheses=[{"reason": "Synthetic unverified same-category transfer."}])
        response = response_fixture(self.package, proposals)
        self.assertFalse(self.accept(response, mode="consensus")["theme_candidates"])
        for mode in ("extension", "exploration"):
            self.assertEqual(len(self.accept(response, mode=mode)["theme_candidates"]), 1)

    def test_negative_omission_or_duplicate_is_rejected(self):
        for ids in ([], ["P3", "P3"], ["nonexistent"]):
            response = response_fixture(self.package)
            response["negative_audit_ids"] = ids
            with self.subTest(ids=ids), self.assertRaises(ContractError):
                self.accept(response)

    def test_all_snapshot_bindings_are_mandatory(self):
        for key in ("request_id", "compact_snapshot", "input_snapshot", "review_context_snapshot", "context_sidecar_snapshot", "side_table_snapshot"):
            response = response_fixture(self.package)
            response[key] = "stale"
            with self.subTest(key=key), self.assertRaises(ContractError):
                self.accept(response)

    def test_side_table_or_message_mutation_is_rejected(self):
        response = response_fixture(self.package)
        for target in ("message", "side-table"):
            package = deepcopy(self.package)
            if target == "message":
                package["request"]["messages"][-1]["content"] += " drop the negative"
            else:
                package["side_table"]["preference_scopes"] = []
            with self.subTest(target=target), self.assertRaises(ContractError):
                self.accept(response, package)

    def test_changed_source_registry_and_scene_cannot_reuse_request(self):
        response = response_fixture(self.package)
        for target in ("source", "registry", "scene"):
            b, opts = deepcopy(self.b), deepcopy(self.options)
            if target == "source":
                b["evidence"][1]["text"] += "source changed"
            elif target == "registry":
                opts["review_context"]["reviewer_registry"]["registry_version"] = "changed"
            else:
                b["brief"]["context"]["scene"] = "home"
            with self.subTest(target=target), self.assertRaises(ContractError):
                self.accept(response, bundle=b, **opts)

    def test_cached_supported_does_not_override_trusted_pending(self):
        from ..semantic_cases import semantic_case
        b, p, _, _, rc = semantic_case("like")
        p["preferences"][1]["semantic_assessment"].update(status="supported", support_eligibility="reviewed_positive")
        p["preferences"][1]["confirmed_user_support"] = True
        package = prepare_theme_request(b, p, review_context=rc, design_intent_context=intent(), admission_context=prepare_fixture_admission(b))
        _, tables = decode(package)
        pref = next(p for p in tables["preferences"] if p["preference_id"] == "P2")
        self.assertEqual(pref["semantic_assessment"]["status"], "pending_independent_review")
        self.assertIn("P2", package["side_table"]["inventory"]["review_disputed_preference_ids"])

    def test_axis_and_theme_coverage_is_complete(self):
        for target in ("axis", "theme", "fake_theme"):
            response = response_fixture(self.package)
            if target == "axis":
                response["axis_assessments"].pop()
            elif target == "theme":
                response["axis_assessments"][0]["theme_assessments"] = []
            else:
                response["axis_assessments"][0]["theme_assessments"][0]["theme_id"] = "fake"
            with self.subTest(target=target), self.assertRaises(ContractError):
                self.accept(response)

    def test_matrix_cannot_promote_element_to_theme_or_unknown_to_support(self):
        response = response_fixture(self.package, self.t["proposals"])
        for pid in ("P2", "P3"):
            invalid = deepcopy(response)
            invalid["axis_assessments"][0]["theme_assessments"][0]["positive_preference_ids"] = [pid]
            with self.subTest(pid=pid), self.assertRaises(ContractError):
                self.accept(invalid)

    def test_proposal_and_matrix_refs_must_agree(self):
        response = response_fixture(self.package, self.t["proposals"])
        for axis in response["axis_assessments"]:
            axis["theme_assessments"][0]["match_ids"] = []
        with self.assertRaisesRegex(ContractError, "every H01 proposal"):
            self.accept(response)

    def test_admission_audit_is_bound_not_approval(self):
        payload, _ = decode(self.package)
        self.assertEqual(payload["reference_qualification"]["eligible_image_ids"], ["I1", "I2", "I3"])
        self.assertTrue(payload["reference_qualification"]["images_are_not_new_H01_or_H02_approval"])
        changed = deepcopy(self.options["admission_context"])
        changed["fixture_decisions"][0]["decision"] = "FAIL"
        with self.assertRaises(ContractError):
            self.accept(response_fixture(self.package), admission_context=changed)

    def test_H01_preparation_does_not_require_local_DNA_projection(self):
        b, p, _, _ = fixture()
        b["images"] = []
        p, rc = reviewed(b, p)
        package = prepare_theme_request(b, p, review_context=rc, design_intent_context=intent())
        payload, _ = decode(package)
        self.assertEqual(payload["reference_qualification"]["status"], "not_evaluated")
        self.assertTrue(payload["h02_pending_confirmation"]["items"])

    def test_broad_style_context_cannot_claim_H02_confirmation(self):
        wrong = intent()
        wrong["H02_features_confirmed"] = True
        with self.assertRaises(ContractError):
            prepare_theme_request(self.b, self.p, **{**self.options, "design_intent_context": wrong})


if __name__ == "__main__":
    unittest.main()
