"""File CLI: no model/provider execution. Explicit caller output path."""
import argparse
import hashlib
from pathlib import Path
from prism_runtime.contracts import read_json, write_json, require
from .api import prepare_theme_request, accept_theme_response, h02_confirmation_checklist


def export_package(package, destination):
    out = Path(destination)
    files = {"request.json": package["request"], "side-table.json": package["side_table"],
             "messages.json": package["request"]["messages"], "size-report.json": package["size_report"],
             "off-prompt-fields.json": package["side_table"]["off_prompt_inventory"],
             "h02-pending-confirmation.json": h02_confirmation_checklist()}
    require(all(not (out / name).exists() for name in [*files, "file-manifest.json"]), "refusing to overwrite a prepared compact version; use a new directory")
    for name, value in files.items():
        write_json(out / name, value)
    write_json(out / "file-manifest.json", {"files": [{"path": str((out / name).resolve()),
        "sha256": hashlib.sha256((out / name).read_bytes()).hexdigest()} for name in files],
        "compact_snapshot": package["request"]["compact_snapshot"], "new_model_calls": 0})
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare-h01", "accept-h01"])
    for arg in ("bundle", "profile", "review-context", "design-intent", "output"):
        parser.add_argument("--" + arg, required=True)
    parser.add_argument("--execution-scope")
    parser.add_argument("--admission-context")
    parser.add_argument("--request-id", default="H01-compact")
    parser.add_argument("--baseline-message-chars", type=int)
    parser.add_argument("--request")
    parser.add_argument("--side-table")
    parser.add_argument("--response")
    parser.add_argument("--mode", choices=["consensus", "extension", "exploration"], default="consensus")
    args = parser.parse_args()
    bundle, profile = read_json(args.bundle), read_json(args.profile)
    options = {"review_context": read_json(args.review_context), "design_intent_context": read_json(args.design_intent),
               "execution_scope_context": read_json(args.execution_scope) if args.execution_scope else None,
               "admission_context": read_json(args.admission_context) if args.admission_context else None}
    if args.action == "prepare-h01":
        package = prepare_theme_request(bundle, profile, request_id=args.request_id,
                                        baseline_message_chars=args.baseline_message_chars, **options)
        export_package(package, args.output)
        print(package["size_report"])
    else:
        if not all((args.request, args.side_table, args.response)):
            parser.error("--request, --side-table and --response required")
        require(not Path(args.output).exists(), "refusing to overwrite accepted output")
        result = accept_theme_response(bundle, profile, read_json(args.request), read_json(args.side_table),
                                       read_json(args.response), mode=args.mode, **options)
        write_json(args.output, result)
        print(args.output)


if __name__ == "__main__":
    main()
