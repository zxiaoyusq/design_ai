"""Build four real-source compact requests, without generating model answers."""
import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import unittest

from prism_runtime.contracts import read_json, write_json, require
from ..common import fingerprint
from .api import prepare_theme_request, VERSION
from .normalize import restore_prompt_sources, restore_preferences, unpack_record_columns, expand
from .__main__ import export_package

PROJECT = Path(__file__).resolve().parents[3]
LOOP = PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
CHAIN = LOOP / "qwen-cli-20260927/runs/full120-qwen-v1-20260927/semantic-chain"
DEFAULT_OUTPUT = PROJECT / "outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/CLOSURE-H01-001"


def file_info(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "size_bytes": path.stat().st_size}


def deliver(output):
    output = Path(output).resolve()
    require(not (output / "self-assessment.json").exists(), "use a fresh delivery directory; prior self-assessment is frozen")
    output.mkdir(parents=True, exist_ok=True)
    sources = {
        "bundle": CHAIN / "admission-v1/bundle.json",
        "profile": CHAIN / "review-wire001-recovery/validated-profile.json",
        "registry": CHAIN / "review-wire001-recovery/reviewer-registry.json",
        "design_intent": CHAIN / "H01-context-prepared/design-intent-context.json",
        "admission_context": CHAIN / "admission-v1/admission-context.json",
        "prepared_index": CHAIN / "H01-context-prepared/prepared-index.json",
    }
    index = read_json(sources["prepared_index"])
    protected = set(sources.values())
    for row in index["requests"]:
        protected.update(Path(row[k]) for k in ("prepared_ref", "execution_scope_ref"))
    protected.update((PROJECT / "prism_runtime/handshake").glob("*.py"))
    protected.update((PROJECT / "prism_runtime/handshake/context_sidecar_v1").glob("*.*"))
    protected.update((PROJECT / "prism_runtime/preferences").glob("*.py"))
    protected.update((CHAIN / "review-wire001-recovery").rglob("*.json"))
    protected.update((CHAIN / "review-wire001").rglob("*.json"))
    protected.update((CHAIN / "admission-v1").rglob("*.json"))
    protected.add(PROJECT / "prism_runtime/CONTRACT.md")
    intent = read_json(sources["design_intent"])
    if intent.get("confirmation_ref"):
        protected.add(Path(intent["confirmation_ref"]))
    before = [file_info(p) for p in sorted(protected)]
    tests = unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromName("prism_runtime.handshake.compact_context_v1.tests"),
        unittest.defaultTestLoader.loadTestsFromName("prism_runtime.handshake.context_sidecar_v1.tests")])
    stream = io.StringIO()
    tested = unittest.TextTestRunner(stream=stream, verbosity=2).run(tests)
    (output / "unit-tests.txt").write_text(stream.getvalue(), encoding="utf-8")
    b, p = read_json(sources["bundle"]), read_json(sources["profile"])
    review = {"reviewer_registry": read_json(sources["registry"])}
    admission = read_json(sources["admission_context"])
    write_json(output / "review-context.json", review)
    rows, checks = [], []

    def check(name, ok, request_id=None):
        checks.append({"check": name, "request_id": request_id, "passed": bool(ok)})

    for entry in index["requests"]:
        old = read_json(entry["prepared_ref"])
        old_payload = json.loads(old["messages"][-1]["content"])
        scope = read_json(entry["execution_scope_ref"])
        rid = entry["request_id"] + "-compact-v1"
        package = prepare_theme_request(b, p, review_context=review, execution_scope_context=scope,
            design_intent_context=intent, admission_context=admission, request_id=rid, baseline_message_chars=entry["message_chars"])
        payload = json.loads(package["request"]["messages"][-1]["content"])
        tables = unpack_record_columns(payload["tables"], payload["record_schemas"])
        side = package["side_table"]
        restored_sources = restore_prompt_sources(tables)
        restored_prefs = restore_preferences(tables, side["preference_fields_off_prompt"])
        check("source_records_and_full_text_exact_after_expansion", restored_sources == old_payload["evidence"] == b["evidence"], rid)
        check("all_179_trusted_atomic_candidates_reconstruct_exactly", restored_prefs == side["validated_profile"]["preferences"] and len(restored_prefs) == 179, rid)
        check("all_49_trend_and_132_research_sources_visible", Counter(r["source_kind"] for r in restored_sources) == {"trend": 49, "research": 132}, rid)
        old_reviews = old_payload["accepted_atomic_review_state"]
        check("trusted_review_states_reasons_and_candidate_digests_unchanged", all(row["semantic_assessment"] == old_reviews[row["preference_id"]] for row in restored_prefs), rid)
        check("negative_candidates_all_58_retained", set(side["inventory"]["negative_audit_ids"]) == {row["preference_id"] for row in restored_prefs if row["attitude"] == "dislike"}
              and len(side["inventory"]["negative_audit_ids"]) == 58, rid)
        check("contradicted_candidate_stays_visible", len(side["inventory"]["review_disputed_preference_ids"]) == 1 and
              [row["semantic_assessment"]["status"] for row in restored_prefs].count("contradicted") == 1, rid)
        old_scopes = {s["preference_id"]: s for s in old_payload["context_role_view"]["preferences"]}
        check("every_scene_state_and_pending_reason_unchanged", all(
            row["scope"]["context_state"] == old_scopes[row["preference_id"]]["context_state"] and
            row["scope"]["evaluated_conditions"] == old_scopes[row["preference_id"]]["evaluated_conditions"] and
            expand(row["scope"]["scope_pending_reasons"], tables["shared_values"]) == old_scopes[row["preference_id"]]["scope_pending_reasons"]
            for row in tables["preferences"]), rid)
        check("ten_original_themes_and_all_transfer_unknowns_retained", tables["themes"] == old_payload["themes"] and len(tables["themes"]) == 10, rid)
        check("six_style_intents_do_not_approve_concrete_themes_or_H02", payload["design_intent_context"] == old_payload["design_intent_context"]
              and len(intent["approved_broad_style_axes"]) == 6 and not payload["h02_pending_confirmation"]["user_confirmed"], rid)
        check("existing_nine_reference_images_revalidated", len(payload["reference_qualification"]["eligible_image_ids"]) == 9, rid)
        check("original_input_context_and_role_tokens_unchanged", package["request"]["bindings"]["context_sidecar_snapshot"] == old["context_sidecar_snapshot"]
              and package["request"]["bindings"]["input_snapshot"] == old["input_snapshot"], rid)
        check("source_identity_fingerprints_exact", package["request"]["bindings"]["source_object_hashes"]["bundle"] == fingerprint(b)
              and package["request"]["bindings"]["source_object_hashes"]["saved_profile"] == fingerprint(p)
              and package["request"]["bindings"]["reviewer_registry_snapshot"] == fingerprint(review["reviewer_registry"]), rid)
        check("at_least_70_percent_character_reduction_without_source_filtering", package["size_report"]["char_reduction_ratio"] >= 0.70, rid)
        export_package(package, output / rid)
        rows.append({"request_id": rid, "scene_label": entry["scene_label"], "request_path": str(output / rid / "request.json"),
            "side_table_path": str(output / rid / "side-table.json"), "execution_scope_path": entry["execution_scope_ref"],
            "compact_snapshot": package["request"]["compact_snapshot"], "size": package["size_report"],
            "source_scoped_positive_theme_ids": side["inventory"]["source_scoped_positive_theme_ids"],
            "status": "prepared_not_executed", "user_scene_approval": False, "H02_confirmation": False})
    # Only an in-memory cache attack, no fabricated actual semantic response.
    forged = deepcopy(p)
    target = next(row for row in forged["preferences"] if row["semantic_assessment"].get("status") == "contradicted")
    pid = target["preference_id"]
    target["semantic_assessment"].update(status="supported", support_eligibility="reviewed_positive", confirmed_user_support=True)
    target["confirmed_user_support"] = True
    attacked = prepare_theme_request(b, forged, review_context=review, design_intent_context=intent,
                                    admission_context=admission, request_id="memory-only-cache-counterexample")
    actual = next(row for row in attacked["side_table"]["validated_profile"]["preferences"] if row["preference_id"] == pid)
    check("real_contradicted_receipt_wins_over_forged_supported_cache", actual["semantic_assessment"]["status"] == "contradicted")
    after = [file_info(p["path"]) for p in before]
    check("all_protected_inputs_and_frozen_code_bytes_unchanged", before == after)
    files = [file_info(p) for p in sorted(Path(__file__).parent.iterdir()) if p.is_file()]
    write_json(output / "source-manifest.json", {"protected_before": before, "protected_after": after, "all_unchanged": before == after,
                                               "new_module_files": files, "sources": {k: file_info(v) for k, v in sources.items()}})
    write_json(output / "prepared-index.json", {"algorithm_version": VERSION, "requests": rows, "new_model_calls": 0,
        "fast_mode_allowed": False, "root_independent_acceptance_required": True,
        "send_to_model": "Only each request.messages; never include the full side-table package in the model prompt."})
    report = {"issue_id": "CLOSURE-H01-001", "version": VERSION, "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "owner_offline_interface_qualified" if tested.wasSuccessful() and all(c["passed"] for c in checks) else "needs_repair",
        "independent_holdout": False, "overall_status": "partial_pending_root_independent_retest_and_actual_semantic_call",
        "unit_tests": {"run": tested.testsRun, "failures": len(tested.failures), "errors": len(tested.errors)},
        "actual_source_checks": checks, "prepared_requests": rows, "protected_file_count": len(before),
        "new_model_calls": 0, "new_paid_calls": 0, "fast_mode_allowed": False,
        "limitations": ["Lossless record normalization is verified; model comprehension of packed tables is not a measured semantic accuracy result.",
            "Token numbers are UTF-8 heuristics, not the executing model tokenizer. Root must check actual context budget before running.",
            "All 181 sources and all 179 atomic preferences are visible; only derived/repeated trace payloads leave the prompt.",
            "H01 matrix is supplied by a new actual model/host response; no semantic mapping was fabricated by this deliver script.",
            "H02 local features/scales and specific theme/image selection remain unconfirmed; no new GroupingRequest is created."]}
    write_json(output / "self-assessment.json", report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    args = parser.parse_args()
    report = deliver(args.output)
    print(json.dumps({"status": report["status"], "unit_tests": report["unit_tests"],
                      "actual_checks_passed": sum(c["passed"] for c in report["actual_source_checks"]),
                      "actual_checks": len(report["actual_source_checks"]),
                      "message_chars": [r["size"]["message_chars"] for r in report["prepared_requests"]]}, ensure_ascii=False))
    raise SystemExit(0 if report["status"] == "owner_offline_interface_qualified" else 1)
