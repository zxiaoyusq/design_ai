"""Lossless tables and explicit off-prompt field inventory; no summarizer."""
from copy import deepcopy
from ..common import fingerprint
from prism_runtime.contracts import require

PREF_SIDE_FIELDS = {
    "source_preference_id": "upstream identifier; complete namespaced preference_id remains in prompt",
    "source_request_id": "upstream batch trace; no support/condition decision is based on batch ID",
    "confirmed_user_support": "duplicate cache; authoritative rebuilt semantic_assessment remains in prompt",
}
PREF_SHARED_FIELDS = ("provenance", "attitude_origin", "feature_validation", "source_roles", "semantic_status", "input_binding")


class SharedValues:
    def __init__(self):
        self.values, self.ids = {}, {}

    def ref(self, value):
        key = fingerprint(value)
        if key not in self.ids:
            ident = "V" + str(len(self.ids) + 1).zfill(3)
            self.ids[key] = ident
            self.values[ident] = deepcopy(value)
        return {"$shared": self.ids[key]}


def expand(value, shared):
    # Only called on schema-designated shared fields, never recursive user text.
    if isinstance(value, dict) and set(value) == {"$shared"}:
        require(value["$shared"] in shared, "unresolved shared value")
        return deepcopy(shared[value["$shared"]])
    return deepcopy(value)


def normalize(bundle, validated_profile, view, scopes):
    shared = SharedValues()
    source_rows, source_by_id, source_role_table = [], {}, {}
    for row in bundle.get("evidence", []):
        compact = deepcopy(row)
        for field in ("context", "scenario", "provenance"):
            if field in compact:
                compact[field] = shared.ref(compact[field])
        source_rows.append(compact)
        source_by_id[row["evidence_id"]] = row
    scope_by_id = {r["preference_id"]: r for r in scopes}
    preferences, omitted = [], {}
    for pref in validated_profile.get("preferences", []):
        row = deepcopy(pref)
        pid = pref["preference_id"]
        off_prompt = {k: row.pop(k) for k in PREF_SIDE_FIELDS if k in row}
        original_contexts = row.pop("source_contexts", [])
        for original in original_contexts:
            require(original["evidence_id"] in source_by_id and original.get("context", {}) ==
                    source_by_id[original["evidence_id"]].get("context", {}), "source context does not match actual source")
            require(set(original).issubset({"evidence_id", "context"}), "unrecognized source_contexts payload must not be dropped")
        row["source_context_refs"] = [x["evidence_id"] for x in original_contexts]
        for field in PREF_SHARED_FIELDS:
            if field in row:
                row[field] = shared.ref(row[field])
        scoped = scope_by_id[pid]
        row["scope"] = {
            "context_state": scoped["context_state"], "evaluated_conditions": deepcopy(scoped["evaluated_conditions"]),
            "scope_pending_reasons": shared.ref(scoped["scope_pending_reasons"]),
            "analysis_scope": scoped["source_context_role_audit"]["analysis_scope"],
            "capability_limit_evidence_ids": sorted({r["evidence_id"] for r in scoped["source_context_role_audit"]["capability_limits"]}),
            "full_audit_ref": pid,
        }
        preferences.append(row)
        omitted[pid] = off_prompt
    for pref in view["preferences"]:
        for source in pref["sources"]:
            eid = source["evidence_id"]
            item = {
                "source_snapshot": source["source_snapshot"], "source_contract": source["source_contract"],
                "context_roles": shared.ref({f["field"]: f["role"] for f in source["fields"]}),
                "scenario_refs": shared.ref([{k: v for k, v in s.items() if k != "evidence_id"} for s in source["scenario_refs"]]),
                "issues": shared.ref(source["issues"]),
            }
            require(eid not in source_role_table or source_role_table[eid] == item, "inconsistent source role audit")
            source_role_table[eid] = item
    return {
        "shared_values": shared.values, "sources": source_rows, "source_role_table": source_role_table,
        "preferences": preferences,
        # Original T01 prose, transfer conditions, unknowns and every trend ref.
        "themes": deepcopy(bundle.get("themes", [])), "users": deepcopy(bundle.get("users", [])),
    }, omitted


def restore_prompt_sources(tables):
    result = []
    for row in tables["sources"]:
        item = deepcopy(row)
        for field in ("context", "scenario", "provenance"):
            if field in item:
                item[field] = expand(item[field], tables["shared_values"])
        result.append(item)
    return result


def restore_preferences(tables, off_prompt_fields):
    """Exact reconstruction for owner/Root equivalence tests, not model inference."""
    sources = {r["evidence_id"]: r for r in restore_prompt_sources(tables)}
    result = []
    for row in tables["preferences"]:
        item = deepcopy(row)
        item.pop("scope")
        context_refs = item.pop("source_context_refs")
        item["source_contexts"] = [{"evidence_id": eid, "context": deepcopy(sources[eid].get("context", {}))} for eid in context_refs]
        for field in PREF_SHARED_FIELDS:
            if field in item:
                item[field] = expand(item[field], tables["shared_values"])
        item.update(deepcopy(off_prompt_fields[item["preference_id"]]))
        result.append(item)
    return result


def pack_record_columns(tables):
    """Write repeated object column names once; exact values/order survive."""
    counts = {}
    def census(value):
        if isinstance(value, dict):
            shape = tuple(value)
            counts[shape] = counts.get(shape, 0) + 1
            for child in value.values():
                census(child)
        elif isinstance(value, list):
            for child in value:
                census(child)
    census(tables)
    selected = [keys for keys, count in counts.items() if "$r" in keys or
                count > 1 and len(keys) >= 2 and sum(len(k) + 3 for k in keys) > 36]
    ids = {keys: "R" + str(i + 1).zfill(2) for i, keys in enumerate(selected)}
    schemas = {ident: list(keys) for keys, ident in ids.items()}
    def encode(value):
        if isinstance(value, dict):
            shape = tuple(value)
            if shape in ids:
                return {"$r": [ids[shape], [encode(v) for v in value.values()]]}
            return {k: encode(v) for k, v in value.items()}
        if isinstance(value, list):
            return [encode(v) for v in value]
        return deepcopy(value)
    return encode(tables), schemas


def unpack_record_columns(value, schemas):
    if isinstance(value, dict) and set(value) == {"$r"}:
        record = value["$r"]
        require(isinstance(record, list) and len(record) == 2 and record[0] in schemas, "invalid record schema")
        columns, values = schemas[record[0]], record[1]
        require(isinstance(values, list) and len(columns) == len(values), "record column/value count differs")
        return {k: unpack_record_columns(v, schemas) for k, v in zip(columns, values)}
    if isinstance(value, dict):
        return {k: unpack_record_columns(v, schemas) for k, v in value.items()}
    if isinstance(value, list):
        return [unpack_record_columns(v, schemas) for v in value]
    return deepcopy(value)
