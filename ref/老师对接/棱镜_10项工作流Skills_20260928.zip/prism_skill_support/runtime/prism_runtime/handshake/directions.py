"""H02: selected, evidenced design directions become grouping requests."""
from copy import deepcopy
from prism_runtime.contracts import require, index_by, value_key
from .common import (POLICIES, SEMANTIC_STATUS, ALGORITHM_VERSION, validate_inputs, target_users, positive_anchors,
                     preference_scope, validate_trend_refs, validate_relation, prepare_payload,
                     validate_proposal_snapshot, fingerprint)
from .themes import validate_selection
from .semantic import attitude_lineage
from .negative_scopes import VERSION as NEGATIVE_SCOPE_VERSION, compile_negative_scopes


def prepare_request(bundle, profile, selection=None, *, review_context=None):
    selection = validate_selection(bundle, profile, selection or bundle.get("theme_selection"), review_context)
    result = prepare_payload("H02", bundle, profile, {"theme_selection": selection, "selection_snapshot": fingerprint(selection)}, review_context)
    result["selection_snapshot"] = fingerprint(selection)
    return result


def _known(observation):
    region = observation.get("region_ref")
    if isinstance(region, dict) and region.get("object_id", observation.get("object_id")) != observation.get("object_id"):
        return False
    return (observation.get("value_status") == "known" and observation.get("value") is not None
            and observation.get("object_id") not in {None, "", "unknown"}
            and observation.get("region_ref") is not None and bool(observation.get("evidence_refs")))


def _matches(observation, feature):
    return (_known(observation) and observation.get("parameter_id") == feature["parameter_id"]
            and value_key(observation["value"]) in {value_key(v) for v in feature["allowed_values"]})


def _bindings(pool, images, features):
    bindings = []
    for iid in pool:
        carriers = {}
        for observation in images[iid].get("observations", []):
            if _known(observation):
                carriers.setdefault(observation["object_id"], []).append(observation)
        for oid, observations in carriers.items():
            groups = [[o for o in observations if _matches(o, f)] for f in features]
            if all(groups):
                rows = {o["observation_id"]: o for group in groups for o in group}
                bindings.append({"image_id": iid, "object_id": oid, "observation_ids": sorted(rows),
                                 "region_refs": list({value_key(o["region_ref"]): o["region_ref"] for o in rows.values()}.values())})
    return bindings


def _required_values_forbidden_on_all_bindings(features, bans, bindings):
    def conflict(binding):
        for ban in bans:
            scope = ban["scope"]
            applies = (binding["image_id"] in scope.get("image_ids", []) if scope["kind"] == "image" else
                       any(b["image_id"] == binding["image_id"] and b["object_id"] == binding["object_id"] for b in scope.get("bindings", [])))
            if applies and any(f["parameter_id"] == ban["parameter_id"] and
                               {value_key(v) for v in f["allowed_values"]}.issubset({value_key(v) for v in ban["forbidden_values"]}) for f in features):
                return True
        return False
    return bool(bindings) and all(conflict(b) for b in bindings)


def _constraints(bundle, prefs, users, context, evidence):
    bans, pending, scoped, outside = [], [], [], []
    for preference in prefs.values():
        if preference["attitude"] != "dislike":
            continue
        scope = preference_scope(preference, users, context)
        scope["features"] = deepcopy(preference.get("features", []))
        scope["original_user_ids"] = deepcopy(preference["user_ids"])
        scope["original_conditions"] = deepcopy(preference.get("conditions", []))
        scope["attitude_lineage"] = attitude_lineage(preference, evidence)
        scoped.append(scope)
        if scope["context_state"] == "not_applicable":
            outside.append(scope)
            continue
        if scope["attitude_lineage"]["interpretation_requires_review"]:
            pending.append({**scope, "reason": "unreviewed_negative_interpretation"})
            continue
        if scope["context_state"] == "unknown":
            pending.append({**scope, "reason": "negative_context_unresolved"})
            continue
        if set(scope["user_ids"]) != set(users):
            pending.append({**scope, "reason": "negative_applies_to_subset; narrow_or_split_target_population"})
            continue
        if not scope["features"]:
            pending.append({**scope, "reason": "negative_feature_attribution_unresolved"})
            continue
        if any(v.get("status") == "attribution_needs_review" for v in preference.get("feature_validation", [])):
            pending.append({**scope, "reason": "upstream_negative_attribution_unresolved"})
            continue
        for feature in scope["features"]:
            bans.append({"parameter_id": feature["parameter_id"], "forbidden_values": [deepcopy(feature["value"])],
                         "evidence_refs": scope["evidence_refs"], "preference_refs": [scope["preference_id"]],
                         "audit_refs": [scope["preference_id"]],
                         "original_object_scope": {k: deepcopy(feature[k]) for k in ("object_id", "object_scope", "observation_refs") if k in feature},
                         "user_ids": users, "conditions": scope["conditions"]})
    hard = bundle["brief"].get("hard_constraints", {})
    if hard and not isinstance(hard, dict):
        pending.append({"reason": "unstructured_product_hard_constraints", "source": deepcopy(hard)})
        hard = {}
    for index, feature in enumerate(hard.get("forbidden_features", [])):
        require(feature.get("parameter_id") and feature.get("forbidden_values") and feature.get("evidence_refs"), "invalid product exclusion")
        audit_id = "brief:" + bundle["brief"]["brief_id"] + ":negative:" + str(index)
        scoped.append({"preference_id": audit_id, "source_kind": "product_hard_constraint", "user_ids": users,
                       "conditions": feature.get("conditions", []), "context_state": "unknown" if feature.get("conditions") or feature.get("object_scope") else "applies",
                       "evidence_refs": feature["evidence_refs"], "features": [{"parameter_id": feature["parameter_id"], "value": v} for v in feature["forbidden_values"]]})
        if feature.get("conditions") or feature.get("object_scope"):
            pending.append({"reason": "scoped_product_constraint_needs_mapping", "constraint": feature})
            continue
        bans.append({**deepcopy(feature), "basis": "product_hard_constraint", "audit_refs": [audit_id]})
    if hard and set(hard) - {"required_features", "forbidden_features"}:
        pending.append({"reason": "unsupported_product_constraint_keys", "keys": sorted(set(hard) - {"required_features", "forbidden_features"})})
    # Preserve audit identity. Values from one original preference/field can be
    # mapped together; constraints from different people/scopes are never merged.
    grouped = {}
    for ban in bans:
        key = (ban["audit_refs"][0], ban["parameter_id"])
        target = grouped.setdefault(key, {**deepcopy(ban), "forbidden_values": [], "original_atomic_constraints": []})
        target["forbidden_values"] = list({value_key(v): v for v in target["forbidden_values"] + ban["forbidden_values"]}.values())
        target["evidence_refs"] = sorted(set(target["evidence_refs"] + ban["evidence_refs"]))
        target["original_atomic_constraints"].append(deepcopy(ban))
    return list(grouped.values()), pending, scoped, outside, hard.get("required_features", [])


def compile_directions(bundle, profile, proposals_document, mode="consensus", selection=None, *, review_context=None, negative_scope_resolutions=None):
    """Invalid sources raise; unresolved scopes never become grouping requests."""
    evidence, images, prefs, themes, population = validate_inputs(bundle, profile, review_context)
    selection = validate_selection(bundle, profile, selection or proposals_document.get("theme_selection") or bundle.get("theme_selection"), review_context)
    validate_proposal_snapshot(bundle, profile, proposals_document, review_context)
    bound_selection = proposals_document.get("selection_snapshot")
    require(bundle["provenance"]["mode"] == "synthetic" or bound_selection is not None, "real H02 proposals require selection_snapshot")
    require(bound_selection is None or bound_selection == fingerprint(selection), "stale H02 selection snapshot")
    require(mode in POLICIES, "unknown alignment mode")
    proposals = proposals_document.get("proposals", [])
    index_by(proposals, "direction_id")
    requests, pending, excluded, directions, gaps = [], [], [], [], []
    selected_users = target_users(selection, population)
    for proposal in proposals:
        pid, tid = proposal["direction_id"], proposal.get("theme_id")
        require(tid in selection["theme_ids"], "direction outside selected themes")
        require(proposal.get("design_axis") in {"ID", "CMF"}, "invalid design axis")
        require(bool(proposal.get("title")), "design title required")
        users = target_users(proposal, selected_users)
        anchors, positive_pending = positive_anchors(proposal, prefs, users, selection["context"])
        lineages = [attitude_lineage(a, evidence) for a in anchors]
        positive_pending.extend({"preference_id": a["preference_id"], "reason": "unreviewed_attitude_interpretation", "attitude_lineage": a}
                                for a in lineages if a["interpretation_requires_review"])
        refs = validate_trend_refs(proposal, themes[tid], evidence)
        allowed = validate_relation(proposal, mode)
        pool = proposal.get("candidate_image_ids", [])
        require(bool(pool) and len(pool) == len(set(pool)), "unique candidate image pool required")
        require(set(pool).issubset(selection["candidate_image_ids"]) and set(pool).issubset(themes[tid].get("image_ids", [])), "image outside selected theme pool")
        require(set(pool).issubset(themes[tid].get("reference_image_ids", [])), "image is evidence-only for this particular theme")
        require(all(i in images for i in pool), "candidate lacks ImageDNA")
        if bundle["provenance"]["mode"] == "real_evidence":
            require(all(images[i].get("source_kind") == "trend" for i in pool), "real trend pool cannot admit synthetic/research/calibration images")
        supported, attribution_pending = {}, []
        for anchor in anchors:
            if any(v.get("status") == "attribution_needs_review" for v in anchor.get("feature_validation", [])):
                attribution_pending.append({"preference_id": anchor["preference_id"], "reason": "upstream_feature_attribution_unresolved"})
            if anchor["level"] != "element":
                continue
            for feature in anchor.get("features", []):
                if feature.get("object_id") or feature.get("object_scope"):
                    attribution_pending.append({"preference_id": anchor["preference_id"], "reason": "positive_object_scope_requires_explicit_target_mapping"})
                supported.setdefault(feature["parameter_id"], {}).setdefault(value_key(feature["value"]), []).append(anchor)
        features = deepcopy(proposal.get("required_features", []))
        require(bool(features), "at least one grounded design feature required")
        index_by(features, "parameter_id")
        for feature in features:
            feature.pop("basis", None)  # Only the brief can introduce hard constraints.
        bans, negative_pending, scoped, outside, hard_required = _constraints(bundle, prefs, users, selection["context"], evidence)
        hard_conflict = False
        for hard in hard_required:
            require(hard.get("parameter_id") and hard.get("allowed_values") and hard.get("evidence_refs"), "invalid product requirement")
            if hard.get("conditions") or hard.get("object_scope"):
                negative_pending.append({"reason": "scoped_product_requirement_needs_mapping", "constraint": hard})
                continue
            same = next((f for f in features if f["parameter_id"] == hard["parameter_id"]), None)
            if same:
                values = {value_key(v) for v in hard["allowed_values"]}
                same["allowed_values"] = [v for v in same.get("allowed_values", []) if value_key(v) in values]
                if not same["allowed_values"]:
                    excluded.append({"direction_id": pid, "reason": "product_required_feature_conflict", "constraint": hard})
                    hard_conflict = True
                    break
            else:
                features.append({**deepcopy(hard), "basis": "product_hard_constraint"})
        if hard_conflict:
            continue
        novel, visual_anchors = [], []
        hypotheses = proposal.get("hypotheses", [])
        for feature in features:
            field, values = feature["parameter_id"], feature.get("allowed_values", [])
            require(isinstance(values, list) and bool(values) and all(v is not None for v in values), "typed allowed values required")
            require(all(any(_matches(o, {"parameter_id": field, "allowed_values": [v]}) for i in pool for o in images[i].get("observations", [])) for v in values), "required feature has no grounded image observation")
            direct = all(value_key(v) in supported.get(field, {}) for v in values)
            if direct:
                visual_anchors.append(field)
            elif feature.get("basis") != "product_hard_constraint":
                novel.append(field)
                for value in values:
                    if value_key(value) in supported.get(field, {}):
                        continue
                    require(any(h.get("parameter_id") == field and value_key(h.get("value")) == value_key(value) and h.get("reason") for h in hypotheses), "each novel feature value needs an explicit hypothesis")
            source_users = sorted({u for v in values for p in supported.get(field, {}).get(value_key(v), []) for u in p["user_ids"] if u in users})
            user_refs = {r for v in values for p in supported.get(field, {}).get(value_key(v), []) for r in p["evidence_refs"]}
            image_refs = {r for i in pool for o in images[i].get("observations", []) if _matches(o, feature) for r in o["evidence_refs"]}
            feature["evidence_refs"] = sorted(set(refs) | user_refs | image_refs | set(feature.get("evidence_refs", []) if feature.get("basis") == "product_hard_constraint" else []))
            feature["supporting_user_ids"] = source_users
            feature["support_basis"] = "direct_element_evidence" if direct else feature.get("basis", "explicit_hypothesis")
        if proposal["relation_basis"] == "direct_support":
            require(not novel, "direct support includes unverified design features")
        if proposal["relation_basis"] == "anchored_extension":
            require(bool(visual_anchors), "extension requires an invariant supported visual anchor")
        bindings = _bindings(pool, images, features)
        if "candidate_bindings" in proposal:
            requested_bindings = proposal["candidate_bindings"]
            require(isinstance(requested_bindings, list) and bool(requested_bindings), "explicit carrier selection cannot be empty")
            pairs = [(b.get("image_id"), b.get("object_id")) for b in requested_bindings]
            require(len(pairs) == len(set(pairs)), "duplicate selected carrier")
            actual = {(b["image_id"], b["object_id"]): b for b in bindings}
            require(set(pairs).issubset(actual), "selected carrier does not ground every core feature")
            for proposed_binding in requested_bindings:
                grounded = actual[(proposed_binding["image_id"], proposed_binding["object_id"])]
                if "observation_ids" in proposed_binding:
                    require(set(proposed_binding["observation_ids"]) == set(grounded["observation_ids"]), "selected carrier observation mismatch")
                if "region_refs" in proposed_binding:
                    require({value_key(r) for r in proposed_binding["region_refs"]} == {value_key(r) for r in grounded["region_refs"]}, "selected carrier region mismatch")
            bindings = [actual[pair] for pair in pairs]
        bans, scoped, scope_pending = compile_negative_scopes(bundle, profile, selection, pid, pool, bindings, bans, scoped, negative_scope_resolutions)
        negative_pending.extend(scope_pending)
        direction = {"direction_id": pid, "theme_id": tid, "theme_selection_id": selection["theme_selection_id"],
                     "title": proposal["title"], "design_axis": proposal["design_axis"], "target_user_ids": users,
                     "relation_basis": proposal["relation_basis"], "shared_principle": proposal["shared_principle"],
                     "required_features": features, "comparison_features": proposal.get("comparison_features", []),
                     "forbidden_features": bans, "scoped_negative_preferences": scoped, "out_of_scope_constraints": outside,
                     "negative_scope_version": NEGATIVE_SCOPE_VERSION, "negative_audit_ids": [a["preference_id"] for a in scoped],
                     "preference_refs": proposal["preference_ids"], "trend_refs": refs,
                     "hypotheses": deepcopy(hypotheses), "candidate_bindings": bindings,
                     "attitude_lineage": lineages, "independently_verified_user_support": False,
                     "atomic_preference_review_passed": all(not a["interpretation_requires_review"] for a in lineages),
                     "support_status": "pending_semantic_review" if any(a["interpretation_requires_review"] for a in lineages) else "reviewed_atomic_preferences_with_unverified_relation",
                     "semantic_status": SEMANTIC_STATUS, "explanation": proposal.get("explanation", "")}
        directions.append(direction)
        unresolved = positive_pending + negative_pending + attribution_pending
        if not bindings:
            gaps.append({"direction_id": pid, "reason": "no_single_carrier_satisfies_all_required_features", "trend_absence_verified": False})
        if not allowed:
            excluded.append({"direction_id": pid, "reason": "outside_alignment_policy", "relation_basis": proposal["relation_basis"]})
        elif unresolved:
            pending.append({"direction_id": pid, "reason": "scope_or_attribution_unresolved", "constraints": unresolved})
        elif not bindings:
            pass
        elif _required_values_forbidden_on_all_bindings(features, bans, bindings):
            excluded.append({"direction_id": pid, "reason": "explicit_scoped_conflict", "constraint_ids": [b["constraint_id"] for b in bans]})
        else:
            requests.append({"schema_version": "prism.grouping_request.v0.1", "request_id": mode + "-" + pid,
                             "brief_id": bundle["brief"]["brief_id"], "direction_id": pid, "theme_id": tid,
                             "theme_selection_id": selection["theme_selection_id"], "target_user_ids": users,
                             "admission_snapshot": selection["admission_snapshot"],
                             "reference_admission_purpose": selection["reference_admission"]["purpose"],
                             "reference_admission_audit": [deepcopy(a) for a in selection["reference_admission"]["audit"] if a["image_id"] in pool],
                             "alignment_mode": mode, "alignment_label": POLICIES[mode]["label"],
                             "relation_basis": proposal["relation_basis"], "title": proposal["title"],
                             "design_axis": proposal["design_axis"], "candidate_image_ids": pool,
                             "candidate_bindings": bindings, "required_features": features, "forbidden_features": bans,
                             "negative_scope_version": NEGATIVE_SCOPE_VERSION, "negative_audit_ids": [a["preference_id"] for a in scoped],
                             "comparison_features": proposal.get("comparison_features", []),
                             "preference_refs": proposal["preference_ids"], "trend_refs": refs,
                             "hypothesis_refs": [pid + "-hypothesis-" + str(i + 1) for i in range(len(hypotheses))],
                             "hypotheses": deepcopy(hypotheses), "semantic_status": SEMANTIC_STATUS,
                             "attitude_lineage": lineages, "independently_verified_user_support": False,
                             "atomic_preference_review_passed": True,
                             "support_status": "reviewed_atomic_preferences_with_unverified_relation",
                             "pending_context_constraints": [], "scoped_negative_preferences": scoped,
                             "provenance": {**deepcopy(bundle["provenance"]), "designer_confirmed": False,
                                            "theme_designer_confirmed": selection["designer_confirmed"],
                                            "synthetic_selection_assumption": selection["synthetic_assumption"]}})
    used = {p for request in requests for p in request["preference_refs"]}
    user_gaps = [{"preference_id": p["preference_id"], "reason": "no_executable_direction_in_current_scope_and_policy",
                  "trend_absence_verified": False} for p in prefs.values() if p["attitude"] in {"like", "conditional"} and p["preference_id"] not in used]
    return {"schema_version": "prism.design_handshake.v0.2", "algorithm_version": ALGORITHM_VERSION, "stage": "H02", "brief_id": bundle["brief"]["brief_id"],
            "theme_selection_id": selection["theme_selection_id"], "alignment_mode": mode, "policy": deepcopy(POLICIES[mode]),
            "review_context_snapshot": fingerprint(review_context),
            "design_directions": directions, "grouping_requests": requests, "pending_directions": pending,
            "excluded_directions": excluded, "visual_gaps": gaps, "user_gaps": user_gaps,
            "status": ("offline_candidate" if bundle["provenance"]["mode"] == "synthetic" else "needs_designer_review") if requests else "needs_input",
            "semantic_status": SEMANTIC_STATUS,
            "limitations": ["代码核对引用、态度标签、条件、范围、特征与策略；未独立核验原话到结论的语义推导。",
                            "候选不表示用户接受概率、市场热度或真实业务验证。趋势入库资格由上游质量路由负责。",
                            "candidate_bindings限定目标载体；聚类须保留该范围，不能把背景排斥泛化到目标载体。"],
            "provenance": deepcopy(bundle["provenance"])}
