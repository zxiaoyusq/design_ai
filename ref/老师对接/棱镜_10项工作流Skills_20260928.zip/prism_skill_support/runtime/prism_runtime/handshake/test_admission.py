"""Targeted FULLCHAIN-POOL-001 tests over read-only historical source copies.

Only JSON receipts/manifests are copied to an owned temporary directory. Source
image bytes and C07's original verdict remain read-only; no provider is called.
"""
from copy import deepcopy
import hashlib
from pathlib import Path
import shutil
import tempfile
import unittest

from prism_runtime.contracts import ContractError, read_json, write_json
from .admission import prepare_reference_admission, prepare_fixture_admission, reference_pool
from .api import select_themes, compile_directions
from .common import fingerprint, snapshot
from .themes import validate_selection

PROJECT = Path(__file__).resolve().parents[2]
SOURCE = PROJECT / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/fullchain-20260926"
OWNED = PROJECT / "outputs/prism-algorithm-loop-20260926/modules/handshake/repairs/FULLCHAIN-POOL-001/_test_tmp"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        OWNED.mkdir(parents=True, exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="receipt-", dir=OWNED)
        self.path = Path(self.temp.name).resolve()
        assert self.path.is_relative_to(OWNED.resolve())
        self.addCleanup(self.temp.cleanup)
        self.bundle = read_json(SOURCE / "inputs/bundle.json")
        self.profile = read_json(SOURCE / "outputs/preferences/validated-profile.json")
        self.review = {"reviewer_registry": read_json(SOURCE / "inputs/reviewer-registry.json")}
        self.h01 = read_json(SOURCE / "outputs/handshake/h01-exploration.json")
        self.trends = read_json(SOURCE / "outputs/trends/themes.json")
        self.material = read_json(SOURCE / "inputs/material-manifest.json")
        for record in self.material["records"]:
            iid = record["image_id"]
            folder = self.path / iid
            folder.mkdir()
            rewrites = {}
            for name in ("input.json", "result.json"):
                original = SOURCE / "inputs/saved-quality" / iid / name
                target = folder / name
                shutil.copyfile(original, target)
                rewrites[str(original.resolve())] = str(target)
            for file in record["files"]:
                file["frozen"] = rewrites.get(str(Path(file["frozen"]).resolve()), file["frozen"])
            route = next(r for r in self.trends["quality_routes"] if r["image_id"] == iid)
            route["quality_record"]["source_ref"] = str(folder / "result.json")
            route["quality_record"]["evidence_refs"] = [str(folder / "result.json")]
        self.write_views()

    def write_views(self):
        self.trends["themes"] = deepcopy(self.bundle["themes"])
        write_json(self.path / "trends.json", self.trends)
        write_json(self.path / "materials.json", self.material)

    def context(self):
        self.write_views()
        return prepare_reference_admission(self.bundle, self.path / "trends.json", self.path / "materials.json")

    def route(self, iid="C08"):
        return next(r for r in self.trends["quality_routes"] if r["image_id"] == iid)

    def pool(self):
        return reference_pool(self.bundle, ["TH-SHAPE"], self.context())

    def selection(self, **extra):
        h01 = deepcopy(self.h01)
        # Structural counterexamples may alter qualification metadata only;
        # this rebind is explicit and does not claim a new semantic analysis.
        h01["input_snapshot"] = snapshot(self.bundle, self.profile)
        return select_themes(self.bundle, self.profile, h01, ["TH-SHAPE"], selection_id="pool-repair-test",
                             synthetic_assumption=True, selected_user_ids=["ikea-visible-account:Shelly"],
                             review_context=self.review, admission_context=self.context(), **extra)

    def test_default_excludes_FAIL_and_keeps_article_evidence(self):
        result = self.selection()
        self.assertEqual(result["candidate_image_ids"], ["C08", "T01"])
        self.assertIn("C07", result["evidence_image_ids"])
        self.assertTrue(any("EV-A-C" in x["trend_refs"] for x in result["theme_relations"]))

    def test_explicit_FAIL_cannot_be_added(self):
        with self.assertRaises(ContractError):
            self.selection(candidate_image_ids=["C07", "C08"])

    def test_current_PASS_subset_is_usable(self):
        self.assertEqual(self.selection(candidate_image_ids=["C08"])["candidate_image_ids"], ["C08"])

    def test_missing_reference_field_has_no_legacy_fallback(self):
        self.bundle["themes"][1].pop("reference_image_ids")
        with self.assertRaisesRegex(ContractError, "pools are missing"):
            self.selection()

    def test_missing_quality_route_not_admitted(self):
        self.trends["quality_routes"] = [r for r in self.trends["quality_routes"] if r["image_id"] != "C08"]
        self.assertEqual(self.pool()["eligible_image_ids"], ["T01"])
        with self.assertRaises(ContractError):
            self.selection(candidate_image_ids=["C08"])

    def test_unknown_error_or_incomplete_quality_not_admitted(self):
        for decision, status in [(None, "not_evaluated"), (None, "execution_error"), ("PASS", "incomplete")]:
            with self.subTest(decision=decision, status=status):
                q = self.route()["quality_record"]
                q.update({"decision": decision, "status": status, "production_admission": False})
                self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_PASS_flag_without_production_permission_is_not_enough(self):
        self.route()["quality_record"]["production_admission"] = False
        self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_numeric_truthy_permission_is_not_a_boolean(self):
        self.route()["quality_record"]["production_admission"] = 1
        self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_caller_cannot_promote_FAIL_in_T01_reference_cache(self):
        self.bundle["themes"][1]["reference_image_ids"] = ["C07", "C08", "T01"]
        self.bundle["themes"][1]["evidence_only_image_ids"] = []
        self.assertNotIn("C07", self.pool()["eligible_image_ids"])

    def test_quality_receipt_cannot_conflict_with_saved_FAIL(self):
        self.bundle["themes"][1]["reference_image_ids"] = ["C07", "C08", "T01"]
        self.bundle["themes"][1]["evidence_only_image_ids"] = []
        route = self.route("C07")
        route.update({"quality_decision": "PASS", "reference_eligible": True})
        route["quality_record"].update({"decision": "PASS", "production_admission": True})
        self.assertNotIn("C07", self.pool()["eligible_image_ids"])

    def test_calibration_source_rejected_even_in_synthetic_project(self):
        next(i for i in self.bundle["images"] if i["image_id"] == "C08")["source_kind"] = "calibration"
        self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_synthetic_quality_cannot_qualify_actual_image(self):
        self.route()["quality_record"]["provenance"]["mode"] = "synthetic"
        self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_fixture_opt_in_cannot_bypass_actual_quality(self):
        with self.assertRaisesRegex(ContractError, "cannot qualify"):
            prepare_fixture_admission(self.bundle)

    def test_old_quality_source_hash_rejected(self):
        self.route()["quality_record"]["source_sha256"] = "0" * 64
        self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_input_call_mismatch_rejected_even_after_rebinding_files(self):
        path = self.path / "C08/input.json"
        data = read_json(path)
        data["call_id"] = "another-call"
        write_json(path, data)
        record = next(r for r in self.material["records"] if r["image_id"] == "C08")
        next(f for f in record["files"] if f["frozen"] == str(path))["sha256"] = sha(path)
        self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_wrong_quality_input_hash_rejected(self):
        path = self.path / "C08/input.json"
        data = read_json(path)
        data["input_sha256"] = "0" * 64
        write_json(path, data)
        record = next(r for r in self.material["records"] if r["image_id"] == "C08")
        next(f for f in record["files"] if f["frozen"] == str(path))["sha256"] = sha(path)
        self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_wrong_original_image_identity_rejected(self):
        image = next(i for i in self.bundle["images"] if i["image_id"] == "C08")
        image["provenance"]["image_sha256"] = "0" * 64
        self.assertNotIn("C08", self.pool()["eligible_image_ids"])

    def test_stale_T01_file_invalidates_context(self):
        context = self.context()
        self.trends["status"] = "changed"
        self.write_views()
        with self.assertRaisesRegex(ContractError, "source changed"):
            reference_pool(self.bundle, ["TH-SHAPE"], context)

    def test_H02_rechecks_changed_quality_after_selection(self):
        selected = self.selection()
        path = self.path / "C08/result.json"
        data = read_json(path)
        data["output"]["decision"] = "FAIL"
        write_json(path, data)
        with self.assertRaisesRegex(ContractError, "admission snapshot"):
            validate_selection(self.bundle, self.profile, selected, self.review)

    def test_H02_cannot_trust_modified_cached_eligibility(self):
        selected = self.selection()
        selected["candidate_image_ids"].append("C07")
        with self.assertRaisesRegex(ContractError, "unqualified"):
            validate_selection(self.bundle, self.profile, selected, self.review)

    def test_H02_cannot_use_another_themes_reference_permission(self):
        second = deepcopy(self.bundle["themes"][1])
        second.update({"theme_id": "EVIDENCE-ONLY", "reference_image_ids": [], "evidence_only_image_ids": second["image_ids"]})
        self.bundle["themes"].append(second)
        h01 = deepcopy(self.h01)
        relation = deepcopy(next(c for c in h01["theme_candidates"] if c["theme_id"] == "TH-SHAPE"))
        relation.update({"theme_id": "EVIDENCE-ONLY", "match_id": "evidence-only-match"})
        h01["theme_candidates"].append(relation)
        h01["input_snapshot"] = snapshot(self.bundle, self.profile)
        selected = select_themes(self.bundle, self.profile, h01, ["TH-SHAPE", "EVIDENCE-ONLY"], selection_id="two-theme-test",
                                 synthetic_assumption=True, selected_user_ids=["ikea-visible-account:Shelly"], review_context=self.review, admission_context=self.context())
        proposal = deepcopy(read_json(SOURCE / "inputs/h02-host-proposal.json")["proposals"][1])
        proposal.update({"theme_id": "EVIDENCE-ONLY", "candidate_image_ids": ["C08"], "candidate_bindings": [{"image_id": "C08", "object_id": "target"}]})
        doc = {"input_snapshot": snapshot(self.bundle, self.profile), "selection_snapshot": fingerprint(selected), "review_context_snapshot": fingerprint(self.review), "proposals": [proposal]}
        with self.assertRaisesRegex(ContractError, "evidence-only"):
            compile_directions(self.bundle, self.profile, doc, "exploration", selected, review_context=self.review)


if __name__ == "__main__":
    unittest.main()
