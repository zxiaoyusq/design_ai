"""CT-002: caller-confirmed negative scopes, with complete original audits."""
from copy import deepcopy
from prism_runtime.contracts import require, value_key
from .common import fingerprint, snapshot

VERSION = "prism.negative_scope.v0.1"
RESOLUTION_SCHEMA = "prism.negative_scope_resolutions.v0.1"


def compile_negative_scopes(bundle, profile, selection, direction_id, pool, bindings, bans, audits, resolutions):
    """No scope is inferred from image membership or a model's resolved flag.

    `resolutions` is a separate, explicit caller input. The caller is responsible
    for the truth of the scope decision; this compiler verifies its source and
    target bindings. It does not authenticate the resolver's identity.
    """
    rows = []
    if resolutions is not None:
        require(resolutions.get("schema_version") == RESOLUTION_SCHEMA, "invalid negative-scope resolution schema")
        require(resolutions.get("input_snapshot") == snapshot(bundle, profile), "stale negative-scope source snapshot")
        require(resolutions.get("selection_snapshot") == fingerprint(selection), "stale negative-scope selection snapshot")
        rows = resolutions.get("resolutions", [])
        require(isinstance(rows, list) and all(isinstance(r, dict) for r in rows), "negative scope resolutions must be a list of objects")
        ids = [r.get("resolution_id") for r in rows]
        require(all(isinstance(i, str) and i for i in ids) and len(ids) == len(set(ids)), "unique negative resolution IDs required")
    output_audits = deepcopy(audits)
    audit_by_id = {a["preference_id"]: a for a in output_audits}
    for audit in output_audits:
        audit["executable_constraint_ids"] = []
        audit["scope_resolution_refs"] = []
        audit["scope_status"] = "not_applicable" if audit["context_state"] == "not_applicable" else "pending"
        if audit["context_state"] == "not_applicable":
            audit["non_execution_reason"] = "recorded_user_or_context_scope_not_applicable"
    whitelist = {(b["image_id"], b["object_id"]) for b in bindings}
    source_evidence = {e["evidence_id"]: e for e in bundle.get("evidence", [])}
    image_index = {i["image_id"]: i for i in bundle.get("images", [])}
    constraints, pending = [], []
    for ban in bans:
        audit_id = ban["audit_refs"][0]
        audit = audit_by_id[audit_id]
        expected = {value_key(v) for v in ban["forbidden_values"]}
        candidates = [r for r in rows if r.get("preference_id") == audit_id
                      and r.get("parameter_id") == ban["parameter_id"]
                      and (not r.get("direction_ids") or direction_id in r["direction_ids"])]
        covered = set()
        for resolution in candidates:
            reason = None
            values = resolution.get("forbidden_values", [])
            keys = {value_key(v) for v in values} if isinstance(values, list) else set()
            confirmation = resolution.get("confirmation", {})
            refs = resolution.get("evidence_refs", [])
            scope = deepcopy(resolution.get("scope", {}))
            if not isinstance(values, list) or not values or not keys.issubset(expected):
                reason = "scope_values_not_in_original_negative"
            elif not isinstance(confirmation, dict) or not isinstance(scope, dict):
                reason = "malformed_scope_confirmation"
            elif confirmation.get("status") != "confirmed" or not confirmation.get("confirmed_by") or not confirmation.get("source_ref"):
                reason = "scope_not_confirmed_by_caller"
            elif not isinstance(refs, list) or not refs or not set(refs).issubset(audit["evidence_refs"]):
                reason = "scope_evidence_not_linked_to_negative"
            elif scope.get("status") != "resolved":
                reason = "scope_unresolved"
            elif not isinstance(scope.get("evidence_refs"), list) or set(scope["evidence_refs"]) != set(refs):
                reason = "scope_evidence_mismatch"
            else:
                quotes = resolution.get("quotes", [])
                for ref in refs:
                    raw = source_evidence.get(ref, {}).get("text")
                    if raw is not None and not any(q.get("evidence_id") == ref and isinstance(q.get("text"), str)
                                                  and q["text"].strip() and q["text"] in raw for q in quotes):
                        reason = "scope_needs_original_quote"
                        break
            if reason is None and scope.get("kind") == "image":
                ids = scope.get("image_ids", [])
                if not isinstance(ids, list) or not ids or len(ids) != len(set(ids)) or not set(ids).issubset(pool):
                    reason = "scope_images_not_in_candidate_pool"
                elif "bindings" in scope:
                    reason = "ambiguous_scope_selectors"
            elif reason is None and scope.get("kind") == "candidate_bindings":
                target = scope.get("bindings", [])
                pairs = [(b.get("image_id"), b.get("object_id")) for b in target] if isinstance(target, list) and all(isinstance(b, dict) for b in target) else []
                if not pairs or len(pairs) != len(set(pairs)) or not set(pairs).issubset(whitelist):
                    reason = "scope_carrier_not_in_candidate_bindings"
                elif any(not any(o.get("object_id") == oid and o.get("region_ref") is not None
                                 for o in image_index.get(iid, {}).get("observations", [])) for iid, oid in pairs):
                    reason = "scope_carrier_does_not_exist"
                elif "image_ids" in scope:
                    reason = "ambiguous_scope_selectors"
            elif reason is None:
                reason = "unsupported_negative_scope_kind"
            if reason:
                pending.append({"preference_id": audit_id, "parameter_id": ban["parameter_id"],
                                "resolution_id": resolution["resolution_id"], "reason": reason})
                continue
            identity = [direction_id, audit_id, ban["parameter_id"], values, scope, resolution["resolution_id"]]
            cid = "negative-" + fingerprint(identity)[:20]
            constraints.append({"constraint_id": cid, "audit_refs": [audit_id],
                                "parameter_id": ban["parameter_id"], "forbidden_values": deepcopy(values),
                                "evidence_refs": deepcopy(ban["evidence_refs"]), "scope": scope,
                                "scope_resolution_ref": resolution["resolution_id"],
                                "scope_confirmation": deepcopy(confirmation), "source_constraints": [deepcopy(ban)]})
            audit["executable_constraint_ids"].append(cid)
            audit["scope_resolution_refs"].append(resolution["resolution_id"])
            covered.update(keys)
        if not expected.issubset(covered):
            pending.append({"preference_id": audit_id, "parameter_id": ban["parameter_id"],
                            "unmapped_forbidden_values": [v for v in ban["forbidden_values"] if value_key(v) not in covered],
                            "reason": "original_negative_has_no_complete_executable_scope"})
    for audit in output_audits:
        if audit["context_state"] == "not_applicable":
            continue
        feature_keys = {(f["parameter_id"], value_key(f["value"])) for f in audit.get("features", [])}
        mapped = {(c["parameter_id"], value_key(v)) for c in constraints if audit["preference_id"] in c["audit_refs"] for v in c["forbidden_values"]}
        if feature_keys and feature_keys.issubset(mapped) and not any(p["preference_id"] == audit["preference_id"] for p in pending):
            audit["scope_status"] = "resolved"
        elif not any(p["preference_id"] == audit["preference_id"] for p in pending):
            pending.append({"preference_id": audit["preference_id"], "reason": "negative_audit_not_fully_executable"})
    return constraints, output_audits, pending
