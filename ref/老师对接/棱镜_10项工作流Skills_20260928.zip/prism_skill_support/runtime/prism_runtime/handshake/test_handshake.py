import copy
import unittest
from prism_runtime.contracts import ContractError
from .api import (POLICIES, prepare_theme_request, compile_theme_handshake,
                  select_themes, prepare_request, compile_directions)
from .common import condition_state
from .common import snapshot
from prism_runtime.preferences.api import compile_preferences
from .examples import fixture, reviewed_fixture_context, negative_scope_fixture
from .admission import prepare_fixture_admission


class HandshakeTests(unittest.TestCase):
    def setUp(self):
        self.b, self.p, self.t, self.d = fixture()
        self.p, self.ctx = reviewed_fixture_context(self.b, self.p)

    def selection(self, **kwargs):
        self.p, self.ctx = reviewed_fixture_context(self.b, self.p, real_protocol_simulation=self.b["provenance"]["mode"] == "real_evidence")
        self.t["input_snapshot"] = snapshot(self.b, self.p)
        from .common import fingerprint
        self.t["review_context_snapshot"] = fingerprint(self.ctx)
        result = compile_theme_handshake(self.b, self.p, self.t, review_context=self.ctx)
        opts = {"selection_id": "test-selection", "synthetic_assumption": True}
        opts.update(kwargs)
        return select_themes(self.b, self.p, result, ["TH1"], review_context=self.ctx,
                             admission_context=prepare_fixture_admission(self.b) if self.b["images"] else None, **opts)

    def run_directions(self, mode="exploration"):
        selection = self.selection()
        scopes = negative_scope_fixture(self.b, self.p, selection, self.d)
        return compile_directions(self.b, self.p, self.d, mode, selection, review_context=self.ctx, negative_scope_resolutions=scopes)

    def test_h01_text_only_and_distinct_output(self):
        self.b["images"] = []
        self.b["themes"][0]["image_ids"] = []
        self.b["themes"][0]["reference_image_ids"] = []
        out = compile_theme_handshake(self.b, self.p, self.t, review_context=self.ctx)
        self.assertEqual(len(out["theme_candidates"]), 1)
        self.assertNotIn("grouping_requests", out)
        self.assertEqual(out["stage"], "H01")
        self.assertEqual(prepare_theme_request(self.b, self.p)["stage"], "H01")

    def test_three_modes_and_preserved_exclusions(self):
        for mode, expected in [("consensus", ["D1"]), ("extension", ["D1", "D2"]), ("exploration", ["D1", "D2", "D3"])]:
            with self.subTest(mode=mode):
                out = self.run_directions(mode)
                self.assertEqual([r["direction_id"] for r in out["grouping_requests"]], expected)
                for r in out["grouping_requests"]:
                    self.assertEqual(r["forbidden_features"][0]["forbidden_values"], ["镜面外观"])
                    self.assertFalse(r["provenance"]["designer_confirmed"])

    def test_h02_requires_explicit_selection(self):
        with self.assertRaises(ContractError):
            compile_directions(self.b, self.p, self.d)

    def test_real_selection_not_fabricated(self):
        self.b["images"] = []
        self.b["themes"][0].update({"image_ids": [], "reference_image_ids": [], "evidence_only_image_ids": []})
        self.b["provenance"]["mode"] = "real_evidence"
        self.p["provenance"]["mode"] = "real_evidence"
        selection = self.selection(synthetic_assumption=False)
        with self.assertRaises(ContractError):
            compile_directions(self.b, self.p, self.d, selection=selection)
        with self.assertRaises(ContractError):
            self.selection()

    def test_real_explicit_confirmation(self):
        self.b["images"] = []
        self.b["themes"][0].update({"image_ids": [], "reference_image_ids": [], "evidence_only_image_ids": []})
        self.b["provenance"]["mode"] = "real_evidence"
        self.p["provenance"]["mode"] = "real_evidence"
        s = self.selection(synthetic_assumption=False, designer_confirmed=True, confirmed_by="synthetic_test_actor")
        self.assertEqual(prepare_request(self.b, self.p, s, review_context=self.ctx)["stage"], "H02")

    def test_selection_stales_on_evidence_or_dna_change(self):
        for part in ["text", "dna"]:
            self.setUp()
            s = self.selection()
            if part == "text":
                self.b["evidence"][0]["text"] += " new"
            else:
                self.b["images"][0]["observations"][0]["value"] = "直线"
            with self.subTest(part=part), self.assertRaises(ContractError):
                compile_directions(self.b, self.p, self.d, selection=s)

    def test_dna_can_arrive_after_h01_before_selection(self):
        images = self.b.pop("images")
        h01 = compile_theme_handshake(self.b, self.p, self.t, review_context=self.ctx)
        self.b["images"] = images
        s = select_themes(self.b, self.p, h01, ["TH1"], selection_id="late-DNA", synthetic_assumption=True,
                          review_context=self.ctx, admission_context=prepare_fixture_admission(self.b))
        self.assertEqual(len(compile_directions(self.b, self.p, self.d, selection=s, review_context=self.ctx,
                                             negative_scope_resolutions=negative_scope_fixture(self.b, self.p, s, self.d))["grouping_requests"]), 1)

    def test_condition_unknown_is_pending_not_global_ban(self):
        del self.b["brief"]["context"]["scene"]
        out = self.run_directions()
        self.assertFalse(out["grouping_requests"])
        self.assertEqual(len(out["pending_directions"]), 3)
        self.assertFalse(out["excluded_directions"])

    def test_negative_condition_false_preserved_not_applied(self):
        self.b["brief"]["context"]["scene"] = "home"
        out = self.run_directions()
        self.assertEqual(len(out["grouping_requests"]), 3)
        self.assertTrue(all(not r["forbidden_features"] for r in out["grouping_requests"]))
        self.assertTrue(out["design_directions"][0]["out_of_scope_constraints"])

    def test_free_text_conditions_remain_pending(self):
        self.p["preferences"][2]["conditions"] = ["仅在正式会议时"]
        self.assertEqual(len(self.run_directions()["pending_directions"]), 3)

    def test_subset_dislike_does_not_ban_entire_population(self):
        self.b["users"].append({"user_id": "U2", "tags": {"region": "test-region"}})
        self.p["selection"]["selected_user_ids"].append("U2")
        out = self.run_directions()
        self.assertEqual(len(out["pending_directions"]), 3)
        self.assertFalse(out["excluded_directions"])

    def test_h01_cannot_expand_target_scope_at_selection(self):
        self.b["users"].append({"user_id": "U2", "tags": {"region": "test-region"}})
        self.p["selection"]["selected_user_ids"].append("U2")
        self.t["proposals"][0]["target_user_ids"] = ["U1"]
        with self.assertRaises(ContractError):
            self.selection()

    def test_dislike_cannot_be_positive_anchor(self):
        self.d["proposals"][0]["preference_ids"] = ["P3"]
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_recorded_dislike_cannot_be_relabelled(self):
        self.p["preferences"][2]["attitude"] = "like"
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_image_like_does_not_supply_element_support(self):
        self.p["preferences"][1]["level"] = "image"
        self.p["preferences"][1]["features"] = []
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_unknown_never_satisfies_known_required_value(self):
        for image in self.b["images"]:
            for o in image["observations"]:
                if o["parameter_id"] == "OPT-002":
                    o["value_status"] = "unknown"
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_observation_without_region_is_not_grounded(self):
        for image in self.b["images"]:
            for o in image["observations"]:
                o["region_ref"] = None
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_separate_objects_cannot_fake_joint_core(self):
        for o in self.b["images"][1]["observations"]:
            if o["parameter_id"] == "OPT-007":
                o["object_id"] = "background"
                o["region_ref"]["object_id"] = "background"
        self.d["proposals"] = [self.d["proposals"][1]]
        out = self.run_directions()
        self.assertFalse(out["grouping_requests"])
        self.assertEqual(out["visual_gaps"][0]["reason"], "no_single_carrier_satisfies_all_required_features")

    def test_exploration_retains_thematic_anchor_and_hypothesis(self):
        out = self.run_directions()
        req = out["grouping_requests"][2]
        self.assertEqual(req["required_features"][0]["support_basis"], "explicit_hypothesis")
        self.assertEqual(req["required_features"][0]["supporting_user_ids"], [])
        self.assertTrue(req["hypothesis_refs"])

    def test_extension_requires_real_visual_anchor(self):
        d = self.d["proposals"][2]
        d["relation_basis"] = "anchored_extension"
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_novel_values_require_specific_hypotheses(self):
        self.d["proposals"][1]["hypotheses"][0]["value"] = "透明"
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_model_cannot_forge_hard_constraint_to_skip_support(self):
        d = self.d["proposals"][2]
        d["required_features"][0]["basis"] = "product_hard_constraint"
        d["relation_basis"], d["hypotheses"] = "direct_support", []
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_cross_category_is_not_direct_support(self):
        self.d["proposals"][0]["transfer_scope"] = "cross_category"
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_product_exclusion_is_not_relaxed_in_any_mode(self):
        self.b["brief"]["hard_constraints"] = {"forbidden_features": [{"parameter_id": "OPT-002", "forbidden_values": ["哑光"], "evidence_refs": ["brief:constraint-1"]}]}
        for mode in POLICIES:
            with self.subTest(mode=mode):
                out = self.run_directions(mode)
                self.assertIn("D1", [d["direction_id"] for d in out["excluded_directions"]])

    def test_unmatched_preference_is_not_market_gap(self):
        out = compile_theme_handshake(self.b, self.p, {"proposals": []})
        self.assertFalse(out["user_gaps"][0]["trend_absence_verified"])
        self.assertEqual(out["user_gaps"][0]["kind"], "unmatched_user_need")

    def test_gap_review_needs_full_theme_coverage(self):
        with self.assertRaises(ContractError):
            compile_theme_handshake(self.b, self.p, {"proposals": [], "gap_reviews": [{"preference_id": "P1", "theme_coverage": []}]})

    def test_bad_trend_ref_rejected(self):
        self.t["proposals"][0]["trend_refs"] = ["R1"]
        with self.assertRaises(ContractError):
            self.selection()

    def test_unconfirmed_semantics_never_becomes_proved(self):
        self.t["proposals"][0]["shared_principle"] = "这是故意捏造的语义，仅用来证明程序不会宣称核验成功"
        out = compile_theme_handshake(self.b, self.p, self.t)
        self.assertEqual(out["semantic_status"], "source_linked_not_independently_verified")
        self.assertFalse(out["designer_confirmed"])

    def test_inputs_not_mutated(self):
        selection = self.selection()
        before = copy.deepcopy((self.b, self.p, self.t, self.d))
        compile_directions(self.b, self.p, self.d, "exploration", selection, review_context=self.ctx)
        self.assertEqual(before, (self.b, self.p, self.t, self.d))

    def test_upstream_profile_snapshot_must_still_match(self):
        self.b["brief"]["context"]["scene"] = "home"
        with self.assertRaisesRegex(ContractError, "source snapshot|stale upstream"):
            compile_theme_handshake(self.b, self.p, self.t)

    def test_stale_semantic_proposal_rejected(self):
        self.t["input_snapshot"] = "old-snapshot"
        with self.assertRaisesRegex(ContractError, "stale semantic"):
            compile_theme_handshake(self.b, self.p, self.t)

    def test_unreviewed_condition_mapping_is_pending(self):
        self.p["preferences"][2]["condition_bindings"][0]["review_status"] = "proposed"
        self.assertEqual(len(self.run_directions()["pending_directions"]), 3)

    def test_scope_mapping_without_source_quote_rejected(self):
        self.p["preferences"][2]["condition_bindings"][0]["evidence_refs"] = ["R1"]
        with self.assertRaisesRegex(ContractError, "condition binding"):
            self.run_directions()

    def test_explicit_carriers_restrict_without_fabrication(self):
        self.d["proposals"][0]["candidate_bindings"] = [{"image_id": "I1", "object_id": "shell"}]
        out = self.run_directions()
        self.assertEqual(len(out["grouping_requests"][0]["candidate_bindings"]), 1)
        self.assertEqual(out["grouping_requests"][0]["candidate_bindings"][0]["image_id"], "I1")

    def test_unknown_or_empty_carrier_selection_is_not_unlimited(self):
        for value in [[], [{"image_id": "I1", "object_id": "made-up"}]]:
            self.d["proposals"][0]["candidate_bindings"] = value
            with self.subTest(value=value), self.assertRaises(ContractError):
                self.run_directions()

    def test_forged_region_binding_rejected(self):
        self.d["proposals"][0]["candidate_bindings"] = [{"image_id": "I1", "object_id": "shell", "region_refs": ["fabricated"]}]
        with self.assertRaises(ContractError):
            self.run_directions()

    def test_condition_three_valued_logic(self):
        self.assertEqual(condition_state([{"field": "scene", "value": "office"}, "unparsed"], {"scene": "home"}), "not_applicable")
        self.assertEqual(condition_state([{"field": "scene", "value": "office"}, "unparsed"], {"scene": "office"}), "unknown")

    def test_h01_unrecorded_attitude_is_pending_candidate(self):
        self.b["evidence"][1].pop("recorded_attitude")
        self.p = compile_preferences(self.b, {"findings": self.p["preferences"], "provenance": self.b["provenance"]})
        result = compile_theme_handshake(self.b, self.p, self.t)
        self.assertFalse(result["theme_candidates"])
        self.assertEqual(result["pending_candidates"][0]["support_status"], "pending_semantic_review")
        self.assertEqual(result["pending_candidates"][0]["independently_verified_support_user_ids"], [])

    def test_wrong_like_with_valid_quote_cannot_be_executable_support(self):
        from .semantic_cases import semantic_case, SOURCE_QUOTE
        bundle, profile, directions, selection, ctx = semantic_case("like")
        result = compile_directions(bundle, profile, directions, "consensus", selection, review_context=ctx)
        self.assertEqual(profile["preferences"][1]["quotes"][0]["text"], SOURCE_QUOTE)
        self.assertFalse(result["grouping_requests"])
        self.assertEqual(result["pending_directions"][0]["constraints"][0]["reason"], "unreviewed_attitude_interpretation")

    def test_control_preserves_dislike_and_refuses_positive_use(self):
        from .semantic_cases import semantic_case
        bundle, profile, directions, selection, ctx = semantic_case("dislike")
        self.assertEqual(profile["preferences"][1]["attitude"], "dislike")
        with self.assertRaisesRegex(ContractError, "negative or unknown"):
            compile_directions(bundle, profile, directions, "consensus", selection, review_context=ctx)

    def test_self_declared_review_does_not_unlock_wrong_like(self):
        from .semantic_cases import semantic_case
        bundle, profile, directions, selection, ctx = semantic_case("like")
        profile["preferences"][1].update({"reviewed": True, "confirmed_user_support": True, "semantic_review": {"status": "supported"}})
        h01 = compile_theme_handshake(bundle, profile, self.t, review_context=ctx)
        selection = select_themes(bundle, profile, h01, ["TH1"], selection_id="fake-review", synthetic_assumption=True,
                                  review_context=ctx, admission_context=prepare_fixture_admission(bundle))
        result = compile_directions(bundle, profile, directions, "consensus", selection, review_context=ctx)
        self.assertFalse(result["grouping_requests"])
        self.assertTrue(result["pending_directions"])

    def test_support_review_packet_preserves_raw_source_and_version(self):
        from .semantic_cases import semantic_case, SOURCE_QUOTE
        from .api import prepare_support_review
        bundle, profile, _, _, _ = semantic_case("like")
        packet = prepare_support_review(bundle, profile, ["P2"])
        import json
        payload = json.loads(packet["messages"][1]["content"])
        self.assertEqual(payload["source_evidence"][0]["text"], SOURCE_QUOTE)
        self.assertEqual(packet["input_digest"], profile["input_digest"])
        self.assertTrue(payload["candidates"][0]["semantic_assessment"]["candidate_digest"])
        self.assertEqual(packet["schema_version"], "prism.preference_semantic_review.v0.1")

    def test_source_recorded_like_alone_is_still_candidate(self):
        out = compile_theme_handshake(self.b, self.p, self.t)
        self.assertFalse(out["theme_candidates"])
        pending = out["pending_candidates"][0]
        self.assertEqual(pending["source_recorded_support_user_ids"], ["U1"])
        self.assertEqual(pending["independently_verified_support_user_ids"], [])

    def test_verified_interpretation_without_original_attitude_can_be_used(self):
        self.b["evidence"][2].pop("recorded_attitude")
        self.p, self.ctx = reviewed_fixture_context(self.b, self.p, ["P1", "P2", "P3"])
        h01 = compile_theme_handshake(self.b, self.p, self.t, review_context=self.ctx)
        selection = select_themes(self.b, self.p, h01, ["TH1"], selection_id="reviewed", synthetic_assumption=True,
                                  review_context=self.ctx, admission_context=prepare_fixture_admission(self.b))
        out = compile_directions(self.b, self.p, self.d, "consensus", selection, review_context=self.ctx,
                                 negative_scope_resolutions=negative_scope_fixture(self.b, self.p, selection, self.d))
        self.assertEqual(len(out["grouping_requests"]), 1)
        self.assertEqual(out["grouping_requests"][0]["attitude_lineage"][0]["origin"], "model_or_host_interpreted")
        self.assertTrue(out["grouping_requests"][0]["atomic_preference_review_passed"])
        self.assertFalse(out["grouping_requests"][0]["independently_verified_user_support"])

    def test_contradicted_or_disputed_review_is_not_positive(self):
        from prism_runtime.preferences import apply_semantic_reviews
        for verdict in ["contradicted", "disputed"]:
            context = copy.deepcopy(self.ctx)
            envelope = copy.deepcopy(self.p["semantic_review_receipts"][0]["review_envelope"])
            envelope["review_id"] = "review-disagreement"
            envelope["items"][0]["verdict"] = "contradicted"
            base = self.p
            if verdict == "contradicted":
                base = compile_preferences(self.b, {"findings": self.p["preferences"], "input_digest": self.p["input_digest"]},
                                           require_input_digest=True, extraction_context=self.p["extraction_context"])
            reviewed = apply_semantic_reviews(self.b, base, envelope, reviewer_registry=context["reviewer_registry"])
            out = compile_theme_handshake(self.b, reviewed, self.t, review_context=context)
            self.assertFalse(out["theme_candidates"])
            self.assertEqual(out["pending_candidates"][0]["attitude_lineage"][0]["independent_semantic_review"], verdict)

    def test_review_registry_cannot_be_taken_from_candidate(self):
        self.p["preferences"][0]["semantic_assessment"].update({"status": "supported", "support_eligibility": "reviewed_positive"})
        self.p["reviewer_registry"] = copy.deepcopy(self.ctx["reviewer_registry"])
        self.p["review_envelopes"] = [copy.deepcopy(self.p["semantic_review_receipts"][0]["review_envelope"])]
        out = compile_theme_handshake(self.b, self.p, self.t)
        self.assertFalse(out["theme_candidates"])

    def test_unregistered_or_same_producer_review_rejected(self):
        for alteration in ["unknown", "same_group"]:
            context = copy.deepcopy(self.ctx)
            if alteration == "unknown":
                context["reviewer_registry"]["reviewers"] = []
            else:
                context["reviewer_registry"]["reviewers"][0]["independence_group"] = self.p["extraction_context"]["independence_group"]
            with self.subTest(alteration=alteration), self.assertRaises(ContractError):
                compile_theme_handshake(self.b, self.p, self.t, review_context=context)

    def test_changed_candidate_cannot_reuse_review(self):
        self.p["preferences"][0]["summary"] = "A different unreviewed interpretation"
        with self.assertRaisesRegex(ContractError, "exact candidate|candidate changed"):
            compile_theme_handshake(self.b, self.p, self.t, review_context=self.ctx)

    def test_changed_review_context_invalidates_selection(self):
        selection = self.selection()
        changed = copy.deepcopy(self.ctx)
        changed["reviewer_registry"]["registry_version"] = "2"
        with self.assertRaisesRegex(ContractError, "review context|registry snapshot"):
            compile_directions(self.b, self.p, self.d, selection=selection, review_context=changed)

    def test_reviewed_conditional_still_requires_scope(self):
        source = self.b["evidence"][2]
        source["text"] = "在办公室时我喜欢哑光表面。"
        p = self.p["preferences"][1]
        p.update({"summary": source["text"], "quotes": [{"evidence_id": "R2", "text": source["text"]}],
                  "conditions": ["在办公室时"], "condition_bindings": [{"source_condition": "在办公室时", "evidence_refs": ["R2"],
                    "predicates": [{"field": "scene", "value": "office"}], "review_status": "reviewed", "reviewer": "synthetic_fixture_author"}]})
        out = self.run_directions("consensus")
        self.assertEqual(out["grouping_requests"][0]["attitude_lineage"][0]["support_eligibility"], "reviewed_conditional")
        self.b["brief"]["context"]["scene"] = "home"
        with self.assertRaisesRegex(ContractError, "outside current context"):
            self.run_directions("consensus")

    def test_ct002_scope_matrix_preserves_every_negative(self):
        from .scope_cases import CASES, scope_case, run_case
        for name in CASES:
            with self.subTest(case=name):
                data = scope_case(name)
                result = run_case(data)
                self.assertEqual(bool(result["grouping_requests"]), data["expected"]["handshake"] == "request")
                self.assertEqual(result["design_directions"][0]["negative_audit_ids"], ["P3"])
                self.assertEqual(result["design_directions"][0]["scoped_negative_preferences"][0]["preference_id"], "P3")

    def test_ct002_audit_constraints_are_bidirectional(self):
        from .scope_cases import scope_case, run_case
        request = run_case(scope_case("carrier_matte_shell_mirror_background"))["grouping_requests"][0]
        constraint = request["forbidden_features"][0]
        audit = request["scoped_negative_preferences"][0]
        self.assertEqual(constraint["audit_refs"], [audit["preference_id"]])
        self.assertEqual(audit["executable_constraint_ids"], [constraint["constraint_id"]])
        self.assertEqual(constraint["scope"]["bindings"], [{"image_id": "I1", "object_id": "shell"}])
        self.assertEqual(constraint["evidence_refs"], ["R3"])

    def test_ct002_source_and_selection_version_binding(self):
        from .scope_cases import scope_case, run_case
        for field in ["input_snapshot", "selection_snapshot"]:
            data = scope_case("carrier_matte_shell_mirror_background")
            data["negative_scope_resolutions"][field] = "stale"
            with self.subTest(field=field), self.assertRaises(ContractError):
                run_case(data)

    def test_ct002_same_field_different_scopes_not_merged(self):
        from .scope_cases import scope_case, run_case
        data = scope_case("image_matte_shell_mirror_background")
        second = copy.deepcopy(data["negative_scope_resolutions"]["resolutions"][0])
        second["resolution_id"] = "additional-explicit-shell-scope"
        second["scope"] = {"kind": "candidate_bindings", "status": "resolved", "bindings": [{"image_id": "I1", "object_id": "shell"}], "evidence_refs": ["R3"]}
        data["negative_scope_resolutions"]["resolutions"].append(second)
        request = run_case(data)["grouping_requests"][0]
        self.assertEqual(len(request["forbidden_features"]), 2)
        self.assertEqual(len({c["constraint_id"] for c in request["forbidden_features"]}), 2)
        self.assertEqual({c["scope"]["kind"] for c in request["forbidden_features"]}, {"image", "candidate_bindings"})

    def test_ct002_model_cannot_delete_unmapped_original_negative(self):
        from .scope_cases import scope_case, run_case
        data = scope_case("scope_missing")
        data["proposals"]["scoped_negative_preferences"] = []
        data["proposals"]["negative_audit_ids"] = []
        result = run_case(data)
        self.assertFalse(result["grouping_requests"])
        self.assertEqual(result["design_directions"][0]["negative_audit_ids"], ["P3"])

    def test_ct002_resolution_cannot_invent_negative_values(self):
        from .scope_cases import scope_case, run_case
        data = scope_case("carrier_matte_shell_mirror_background")
        data["negative_scope_resolutions"]["resolutions"][0]["forbidden_values"].append("哑光")
        result = run_case(data)
        self.assertFalse(result["grouping_requests"])
        self.assertEqual(result["design_directions"][0]["scoped_negative_preferences"][0]["features"][0]["value"], "镜面外观")

    def test_ct002_scope_invariant_in_all_alignment_modes(self):
        from .scope_cases import scope_case, run_case
        constraints = []
        for mode in POLICIES:
            request = run_case(scope_case("carrier_matte_shell_mirror_background"), mode)["grouping_requests"][0]
            constraints.append(request["forbidden_features"])
        self.assertTrue(all(c == constraints[0] for c in constraints))

    def test_saved_supported_cache_injection_cannot_cross_review_consumer(self):
        from .semantic_cases import semantic_case
        bundle, profile, directions, _, context = semantic_case("like")
        profile["preferences"][1]["semantic_assessment"].update({"status": "supported", "support_eligibility": "reviewed_positive", "review_ids": ["fabricated"]})
        profile["preferences"][1]["confirmed_user_support"] = True
        h01 = compile_theme_handshake(bundle, profile, self.t, review_context=context)
        selection = select_themes(bundle, profile, h01, ["TH1"], selection_id="cached-injection", synthetic_assumption=True,
                                  review_context=context, admission_context=prepare_fixture_admission(bundle))
        original = copy.deepcopy(profile)
        result = compile_directions(bundle, profile, directions, selection=selection, review_context=context,
                                    negative_scope_resolutions=negative_scope_fixture(bundle, profile, selection, directions))
        self.assertFalse(result["grouping_requests"])
        self.assertEqual(result["design_directions"][0]["attitude_lineage"][0]["independent_semantic_review"], "pending_independent_review")
        self.assertEqual(profile, original)

    def multi_value_scope_case(self):
        from .scope_cases import scope_case
        data = scope_case("carrier_matte_shell_mirror_background")
        raw = data["bundle"]["evidence"][3]
        raw["text"] = "我不接受手机后壳出现镜面或高光外观，背景不在这个判断范围内。"
        preference = data["profile"]["preferences"][2]
        preference.update({"summary": raw["text"], "quotes": [{"evidence_id": "R3", "text": raw["text"]}]})
        preference["features"].append({"parameter_id": "OPT-002", "value": "高光", "attribution": "explicit_text", "evidence_refs": ["R3"]})
        data["profile"], data["review_context"] = reviewed_fixture_context(data["bundle"], data["profile"])
        h01 = compile_theme_handshake(data["bundle"], data["profile"], self.t, review_context=data["review_context"])
        data["selection"] = select_themes(data["bundle"], data["profile"], h01, ["TH1"], selection_id="multi-value", synthetic_assumption=True,
                                          review_context=data["review_context"], admission_context=prepare_fixture_admission(data["bundle"]))
        data["negative_scope_resolutions"] = negative_scope_fixture(data["bundle"], data["profile"], data["selection"], data["proposals"])
        return data

    def test_ct002_missing_one_original_negative_value_stays_pending(self):
        from .scope_cases import run_case
        data = self.multi_value_scope_case()
        data["negative_scope_resolutions"]["resolutions"] = data["negative_scope_resolutions"]["resolutions"][:1]
        result = run_case(data)
        self.assertFalse(result["grouping_requests"])
        self.assertEqual(len(result["design_directions"][0]["scoped_negative_preferences"][0]["features"]), 2)

    def test_ct002_one_resolution_can_cover_multiple_original_values(self):
        from .scope_cases import run_case
        data = self.multi_value_scope_case()
        first = data["negative_scope_resolutions"]["resolutions"][0]
        first["forbidden_values"] = ["镜面外观", "高光"]
        data["negative_scope_resolutions"]["resolutions"] = [first]
        result = run_case(data)
        self.assertEqual(len(result["grouping_requests"]), 1)
        self.assertEqual(set(result["grouping_requests"][0]["forbidden_features"][0]["forbidden_values"]), {"镜面外观", "高光"})


if __name__ == "__main__":
    unittest.main()
