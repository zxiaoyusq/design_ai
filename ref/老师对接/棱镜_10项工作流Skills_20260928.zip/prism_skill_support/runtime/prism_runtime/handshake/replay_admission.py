"""Read the FULLCHAIN-POOL-001 evidence; replay only selection/H02 boundaries."""
import argparse
from copy import deepcopy
import hashlib
from pathlib import Path

from prism_runtime.contracts import ContractError, read_json, write_json
from prism_runtime.handshake import select_themes, compile_directions
from .admission import prepare_reference_admission, reference_pool
from .common import fingerprint, snapshot, ALGORITHM_VERSION


def replay(source_directory, output_directory):
    source, out = Path(source_directory).resolve(), Path(output_directory).resolve()
    require_paths = [source / p for p in ["inputs/bundle.json", "outputs/preferences/validated-profile.json",
                     "inputs/reviewer-registry.json", "outputs/handshake/h01-exploration.json",
                     "inputs/h02-host-proposal.json", "outputs/trends/themes.json", "inputs/material-manifest.json",
                     "outputs/quality/C07.json", "inputs/saved-quality/C07/result.json"]]
    before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in require_paths}
    bundle = read_json(source / "inputs/bundle.json")
    profile = read_json(source / "outputs/preferences/validated-profile.json")
    review_context = {"reviewer_registry": read_json(source / "inputs/reviewer-registry.json")}
    h01 = read_json(source / "outputs/handshake/h01-exploration.json")
    admission = prepare_reference_admission(bundle, source / "outputs/trends/themes.json", source / "inputs/material-manifest.json")
    kwargs = {"selection_id": "POOL-001-repair-selection", "synthetic_assumption": True,
              "selected_user_ids": ["ikea-visible-account:Shelly"], "review_context": review_context}
    observed = []
    try:
        select_themes(bundle, profile, h01, ["TH-SHAPE"], **kwargs)
    except ContractError as exc:
        observed.append({"case": "missing_qualification_context", "passed": True, "error": str(exc)})
    else:
        observed.append({"case": "missing_qualification_context", "passed": False})
    selection = select_themes(bundle, profile, h01, ["TH-SHAPE"], admission_context=admission, **kwargs)
    observed.append({"case": "default_pool_only_qualified", "passed": selection["candidate_image_ids"] == ["C08", "T01"], "actual": selection["candidate_image_ids"]})
    observed.append({"case": "C07_semantic_evidence_retained", "passed": "C07" in selection["evidence_image_ids"] and
                     any("C07" in c["case_pool_image_ids"] for c in selection["theme_relations"])})
    try:
        select_themes(bundle, profile, h01, ["TH-SHAPE"], candidate_image_ids=["C07", "C08", "T01"], admission_context=admission, **kwargs)
    except ContractError as exc:
        observed.append({"case": "explicit_FAIL_reinsertion_rejected", "passed": True, "error": str(exc)})
    else:
        observed.append({"case": "explicit_FAIL_reinsertion_rejected", "passed": False})
    original = deepcopy(read_json(source / "inputs/h02-host-proposal.json")["proposals"][1])
    original["candidate_image_ids"] = ["T01", "C07", "C08"]
    original["candidate_bindings"] = [{"image_id": iid, "object_id": "target"} for iid in original["candidate_image_ids"]]
    doc = {"input_snapshot": snapshot(bundle, profile), "selection_snapshot": fingerprint(selection),
           "review_context_snapshot": fingerprint(review_context), "proposals": [original]}
    try:
        compile_directions(bundle, profile, doc, "exploration", selection, review_context=review_context)
    except ContractError as exc:
        observed.append({"case": "H02_FAIL_reinsertion_rejected", "passed": True, "error": str(exc)})
    else:
        observed.append({"case": "H02_FAIL_reinsertion_rejected", "passed": False})
    positive = deepcopy(doc)
    positive["proposals"][0]["candidate_image_ids"] = selection["candidate_image_ids"]
    positive["proposals"][0]["candidate_bindings"] = [{"image_id": iid, "object_id": "target"} for iid in selection["candidate_image_ids"]]
    result = compile_directions(bundle, profile, positive, "exploration", selection, review_context=review_context)
    from prism_runtime.clustering import cluster_candidates
    clusters = [cluster_candidates(request, bundle["images"]) for request in result["grouping_requests"]]
    actual = sorted({m["image_id"] for cluster in clusters for c in cluster["clusters"] for m in c["members"]})
    observed.append({"case": "PASS_controls_reach_clusters_without_C07", "passed": actual == ["C08", "T01"], "actual": actual})
    real_mode = deepcopy(bundle)
    real_mode["provenance"]["mode"] = "real_evidence"
    real_pool = reference_pool(real_mode, ["TH-SHAPE"], admission)
    observed.append({"case": "same_material_policy_under_real_project_mode", "passed": real_pool["eligible_image_ids"] == ["C08", "T01"],
                     "note": "Admission-only check; original hypothesis-bound user reviews/selection are not relabelled as real."})
    unchanged = all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in before.items())
    observed.append({"case": "source_and_C07_old_decision_unchanged", "passed": unchanged})
    write_json(out / "reference-admission.json", admission)
    write_json(out / "selection.json", selection)
    write_json(out / "allowed-h02-input.json", positive)
    write_json(out / "allowed-h02-output.json", result)
    write_json(out / "allowed-clusters.json", clusters)
    report = {"issue": "FULLCHAIN-POOL-001", "repair_cycle": 1, "algorithm_version": ALGORITHM_VERSION,
              "source_directory": str(source), "source_hashes_before_and_after": before,
              "checks": observed, "passed": all(x["passed"] for x in observed),
              "new_paid_calls": 0, "quality_reclassification": False, "DNA_reextraction": False,
              "scope": "Existing real images/quality/host DNA and independent preference receipts; hypothetical brief/selection. This is a boundary repair replay, not a new model experiment or business-effect validation."}
    write_json(out / "replay.json", report)
    print({"checks": len(observed), "passed": report["passed"], "selected": selection["candidate_image_ids"], "clustered": actual})
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = replay(args.source, args.output)
    raise SystemExit(0 if result["passed"] else 1)
