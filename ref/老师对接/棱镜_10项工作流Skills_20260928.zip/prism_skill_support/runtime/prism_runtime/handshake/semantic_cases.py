"""PREF-SEM-R1 regression, using the quoted counterexample and synthetic context."""
from copy import deepcopy
from pathlib import Path
import argparse
from prism_runtime.contracts import ContractError, write_json
from prism_runtime.preferences.api import compile_preferences
from .examples import fixture, reviewed_fixture_context
from .api import compile_theme_handshake, select_themes, compile_directions, prepare_support_review
from .admission import prepare_fixture_admission

SOURCE_QUOTE = "我不喜欢满版图案，信息太杂。"


def semantic_case(attitude):
    bundle, profile, theme_doc, directions = fixture()
    record = next(r for r in bundle["evidence"] if r["evidence_id"] == "R2")
    record.pop("recorded_attitude")
    record["text"] = SOURCE_QUOTE
    record["quote_origin"] = "PREF-SEM-R1 independent loop counterexample; user/context/images here are synthetic"
    pref = next(p for p in profile["preferences"] if p["preference_id"] == "P2")
    pref.update({"attitude": attitude, "summary": SOURCE_QUOTE, "quotes": [{"evidence_id": "R2", "text": SOURCE_QUOTE}],
                 "features": [{"parameter_id": "fixture.pattern_coverage", "value": "full", "attribution": "explicit_text", "evidence_refs": ["R2"]}]})
    for image in bundle["images"]:
        observation = deepcopy(image["observations"][0])
        observation.update({"observation_id": image["image_id"] + "-pattern", "parameter_id": "fixture.pattern_coverage", "value": "full", "evidence_refs": ["synthetic:" + image["image_id"] + ":pattern"]})
        image["observations"].append(observation)
    profile = compile_preferences(bundle, {"findings": profile["preferences"], "provenance": bundle["provenance"]})
    directions["proposals"] = [directions["proposals"][0]]
    directions["proposals"][0].update({"title": "错误候选：以满版图案作为用户支持", "required_features": [{"parameter_id": "fixture.pattern_coverage", "allowed_values": ["full"]}]})
    profile, review_context = reviewed_fixture_context(bundle, profile, ["P1", "P3"])
    h01 = compile_theme_handshake(bundle, profile, theme_doc, review_context=review_context)
    selection = select_themes(bundle, profile, h01, ["TH1"], selection_id="semantic-regression", synthetic_assumption=True,
                              review_context=review_context, admission_context=prepare_fixture_admission(bundle))
    return bundle, profile, directions, selection, review_context


def export_cases(destination):
    out = Path(destination)
    summary = []
    for proposed in ["like", "dislike"]:
        bundle, profile, directions, selection, review_context = semantic_case(proposed)
        try:
            result = compile_directions(bundle, profile, directions, "consensus", selection, review_context=review_context)
        except ContractError as exc:
            result = {"rejected_positive_anchor": True, "error": str(exc)}
        preference = next(p for p in profile["preferences"] if p["preference_id"] == "P2")
        passed = (not result.get("grouping_requests") and bool(result.get("pending_directions"))) if proposed == "like" else (preference["attitude"] == "dislike" and result.get("rejected_positive_anchor") is True)
        name = "wrong-like" if proposed == "like" else "negative-preserved-control"
        write_json(out / (name + ".json"), {"case": name, "source_quote": SOURCE_QUOTE, "expected_attitude_from_independent_report": "dislike",
                                             "input": {"bundle": bundle, "profile": profile, "proposals": directions, "selection": selection, "review_context": review_context},
                                             "actual": result, "passed": passed,
                                             "scope": "proves handoff gate only; does not prove sentiment understanding"})
        if proposed == "like":
            write_json(out / "support-review-request.json", prepare_support_review(bundle, profile, ["P2"]))
        summary.append({"case": name, "passed": bool(passed)})
    write_json(out / "summary.json", {"cases": summary, "new_paid_calls": 0, "independent_holdout": False})
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = export_cases(args.output)
    print(result)
    raise SystemExit(0 if all(r["passed"] for r in result) else 1)
