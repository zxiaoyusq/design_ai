import argparse
from pathlib import Path
from prism_runtime.contracts import require, write_json
from . import accept_resolved, compile_confirmed, verify_draft

p = argparse.ArgumentParser(description="Bounded actual H02 design resolution; no model calls.")
p.add_argument("action", choices=["accept-resolved", "verify-draft", "compile-confirmed"])
for key in ("config", "prepared", "response", "resolution", "draft", "confirmation"):
    p.add_argument("--" + key)
p.add_argument("--output", required=True)
a = p.parse_args()
if a.action == "compile-confirmed":
    result = compile_confirmed(a.config, a.prepared, a.draft, a.confirmation, output_dir=a.output)
else:
    require(not Path(a.output).exists(), "use a new output file")
    if a.action == "accept-resolved":
        result = accept_resolved(a.config, a.prepared, a.response, a.resolution)
    else:
        result = verify_draft(a.draft)
    write_json(a.output, result)
print(a.output)
