"""Narrow CLOSURE-H02-002 counterexamples using the two actual stored inputs."""
from copy import deepcopy
from pathlib import Path
import unittest

from prism_runtime.contracts import ContractError, read_json
from ..context_sidecar_v1.view import evaluate_preference_scope
from ..exploratory_reference_v1.draft import observation_index
from ..proposal_gate_v1.sources import identity
from .api import _derive_response, _scope_overlay, _validate_decision, verify_context

ROOT = Path(__file__).resolve().parents[3] / "outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/closure-20260927"


class ActualResolutionChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.record_path = ROOT / "h02/Root-design-resolution-v2.json"
        cls.record = read_json(cls.record_path)
        cls.prepared = {s: read_json(ROOT / "h02" / s / "prepared.json") for s in ("scene01", "scene04")}
        cls.replies = {s: read_json(cls.record["source_responses"][s]["path"]) for s in cls.prepared}

    def test_only_authorized_response_changes_and_original_immutable(self):
        for scene in self.prepared:
            with self.subTest(scene=scene):
                original = deepcopy(self.replies[scene])
                derived, changes = _derive_response(original, self.prepared[scene], self.record, scene)
                self.assertEqual(original, self.replies[scene])
                before, after = original["directions"][0], derived["directions"][0]
                changed = {k for k in before if before[k] != after[k]}
                expected = {"scale_status", "negative_scope_proposals"}
                if scene == "scene04": expected.add("example_bindings")
                self.assertEqual(changed, expected)
                self.assertEqual(before["required_observation_ids"], after["required_observation_ids"])
                self.assertEqual(before["comparison_observation_ids"], after["comparison_observation_ids"])
                self.assertEqual(before["scale_observation_ids"], after["scale_observation_ids"])
                self.assertEqual(len(changes), 3)

    def test_wrong_carrier_new_observation_and_ambiguous_id_rejected(self):
        for kind in ("wrong_carrier", "new_observation", "ambiguous_id"):
            with self.subTest(kind=kind):
                record, prepared = deepcopy(self.record), deepcopy(self.prepared["scene04"])
                if kind == "wrong_carrier": record["missing_example_binding"]["object_id"] = "o5"
                elif kind == "new_observation":
                    record["missing_example_binding"]["only_existing_selected_comparison_observation_ids"].append("TR036:a0119")
                else:
                    d = prepared["side_table"]["documents"]["TR036"]
                    d["observations"].append(deepcopy(d["observations"][0]))
                with self.assertRaises(ContractError):
                    _derive_response(self.replies["scene04"], prepared, record, "scene04")

    def test_exact_Root_scope_binding_checks(self):
        valid = deepcopy(self.record)
        ppath = valid["prepared_inputs"]["scene01"]["path"]
        rpath = valid["source_responses"]["scene01"]["path"]
        self.assertEqual(_validate_decision(valid, self.prepared["scene01"], ppath, rpath), "scene01")
        for field, value in (("preference_id", "another-pref"), ("evidence_ids", ["another-evidence"]),
                             ("original_condition", "another-condition"), ("execution_scene", "another-scene")):
            with self.subTest(field=field):
                bad = deepcopy(valid)
                bad["scene_bindings"][0][field] = value
                with self.assertRaises(ContractError):
                    _validate_decision(bad, self.prepared["scene01"], ppath, rpath)

    def test_source_identity_and_physical_measurement_cannot_change(self):
        for kind in ("source_hash", "physical_known", "invented_metric", "real_human"):
            with self.subTest(kind=kind):
                bad = deepcopy(self.record)
                if kind == "source_hash": bad["source_responses"]["scene04"]["sha256"] = "0" * 64
                elif kind == "physical_known": bad["scale_decision"]["physical_scale_status"] = "known"
                elif kind == "invented_metric": bad["scale_decision"]["new_metric_values"] = [10]
                else: bad["human_designer_actually_reviewed"] = True
                with self.assertRaises(ContractError):
                    _validate_decision(bad, self.prepared["scene01"], self.record["prepared_inputs"]["scene01"]["path"],
                                       self.record["source_responses"]["scene01"]["path"])

    def test_scope_overlay_preserves_other_unknown_issues_and_unaffected_users(self):
        binding = self.record["scene_bindings"][0]
        frame = self.prepared["scene01"]["side_table"]["frames"][0]
        pref = next(p for p in frame["side_table"]["validated_profile"]["preferences"] if p["preference_id"] == binding["preference_id"])
        saved = deepcopy(pref)
        view = frame["side_table"]["context_role_view"]
        context = view["execution_scope"]["values"]
        base = evaluate_preference_scope(view, pref, ["SYN-U11"], context,
            evidence={e["evidence_id"]: e for e in frame["inputs"]["bundle"]["evidence"]}, review_context=frame["inputs"]["review_context"])
        self.assertEqual(base["context_state"], "unknown")
        resolved = _scope_overlay(base, pref, context, [binding], identity(self.record_path))
        self.assertEqual(resolved["context_state"], "applies")
        self.assertEqual(pref, saved)
        self.assertEqual(resolved["conditions"], base["conditions"])
        self.assertEqual(resolved["source_context_role_audit"], base["source_context_role_audit"])
        for kind in ("other_unknown", "source_issue", "outside_user"):
            with self.subTest(kind=kind):
                changed = deepcopy(base)
                if kind == "other_unknown": changed["evaluated_conditions"].append("未解释的其他条件")
                elif kind == "source_issue": changed["scope_pending_reasons"].append({"reason": "unreviewed_scope"})
                else: changed["user_ids"] = []
                result = _scope_overlay(changed, pref, context, [binding], identity(self.record_path))
                self.assertEqual(result["context_state"], "not_applicable" if kind == "outside_user" else "unknown")

    def test_pending_draft_cannot_be_registered_as_executable_context(self):
        with self.assertRaisesRegex(ContractError, "issued no executable context"):
            verify_context("not-issued.context.json", request={}, inventory_path="unused")


if __name__ == "__main__":
    unittest.main()
