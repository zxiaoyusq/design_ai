# H02 设计决定侧层 v1

`handshake-design-resolution-v1.0.0` 是 CLOSURE-H02-002 的独立、有界修复入口。它只消费 Root 的 `Root-design-resolution-v2.json` 和其中固定的两份真实 H02 回复。冻结的 `exploratory_reference_v1`、原模型回复、P01、审核凭据和原条件不变。

本版完成设计决定的逐条留痕，但 **H02 仍 pending，不生成执行 context、GroupingRequest 或聚类结果**。已核实的阻断是：原用研负向存在不属于原视觉字典的字段。场景决定不能建立字段和值的语义映射；这些负向不能被删除或当作不适用。

## 允许的派生变化

- 三条确切的 preference/evidence/原条件/执行场景映射，仅作用于本次模拟的条件求值。原字符串和原 `context_state` 另存，其他未知或证据问题仍未知。
- `scale_status` 从 `unknown` 改为设计展示口径 `reference_region_only`。`physical_scale_status` 始终是 `unknown`，没有新数值，不能解除面积、密度或其他物理事实守卫。
- S04 仅增加 `TR036/o4` 示例声明。它是模型已选 `TR036:a0118` 和 `TR036:a0206` 的唯一原载体。观察 ID、PID、值、required、comparison 和母库均不变。
- 三条原 pending 范围提案仅根据 Root v2 变为全母库载体的设计分析范围。原提案在差异审计中完整保留，这不是负向事实已排除的声明。

## 入口

```python
from prism_runtime.handshake.design_resolution_v1 import (
    accept_resolved, verify_draft, compile_confirmed, verify_context,
)

draft = accept_resolved(config_path, prepared_path, response_path, resolution_path)
receipt = verify_draft(draft_path)
registration = compile_confirmed(
    config_path, prepared_path, draft_path, confirmation_path,
    output_dir=new_output_directory,
)
```

`accept_resolved` 先调用冻结的 `prepare_request` 完整重放来源和正式审核，再使用独立函数命名空间调用冻结 `validate_direction`。只替换该次调用的条件求值入口，不改模块全局或旧源码。它保留旧 S01 pending / S04 拒绝的重放结果。

`verify_draft` 是无模型、无消费端回调的叶子复验。`passed=true` 仅表示派生草案可重放，返回 `executable=false`。它不能作为执行资格。

`compile_confirmed` 需要 Root 另存的 `prism.exploratory_library_confirmation.v1`，精确绑定新草案、manifest、全母库和载体规则。它验证代理决定后正式记录参数未解决的 pending，contexts 与 grouping_requests 都为空。owner 不代 Root 填写该确认。

`verify_context(context_path, *, request, inventory_path)` 保留显式注册符号，但本版没有任何合法执行 context，始终拒绝。预留 schema 名为 `prism.exploratory_reference_context_design_resolution.v1`，不代表已签发或测试通过的 context。消费端不能 fallback 到旧版、把草案当 context，或通过伪造 context 清除负向。以后若有正式语义映射，需要新的、单独命名和验收的入口。

## 核查

使用项目的 Python 3.12 运行 `python -B -m unittest prism_runtime.handshake.design_resolution_v1.tests -v`。6 个定点测试覆盖确切变化、错载体/新增观察/重复 ID、绑定错配、物理量及来源篡改、其他 unknown 保留和伪造执行 context 拒绝。两份实际输入另由正式 `accept_resolved` 重放。测试数量不是语义准确率或全链成功率。
