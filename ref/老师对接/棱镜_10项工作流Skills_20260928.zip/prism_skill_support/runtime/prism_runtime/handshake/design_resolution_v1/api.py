"""CLOSURE-H02-002: consume three bounded design decisions, never infer DNA.

This version replays the two actual H02 responses and emits auditable drafts.
Their unresolved original negative-field bindings prevent executable contexts.
It deliberately has no speculative bypass or synthetic success path.
"""
from copy import deepcopy
from pathlib import Path
from types import FunctionType

from prism_runtime.contracts import require, read_json, write_json
from ..common import fingerprint, condition_state
from ..context_sidecar_v1.view import evaluate_preference_scope
from ..exploratory_reference_v1 import draft as frozen_draft
from ..exploratory_reference_v1.prepare import prepare_request
from ..exploratory_reference_v1.runtime import validate_confirmation
from ..matrix_state_bridge_v1.api import read_response
from ..proposal_gate_v1.sources import identity, authority

VERSION = "handshake-design-resolution-v1.0.0"
CONTEXT_SCHEMA = "prism.exploratory_reference_context_design_resolution.v1"
DRAFT_SCHEMA = "prism.exploratory_H02_design_resolution_draft.v1"
DECISION_SHA256 = "07ecdb757c75f34a2ea74f77d6711d862368f22767f6bafd7c531c6f09082be3"
ALLOWED = {
    ("scene01", "preference-wire001-003:F-SYN-U11-R005-Dislike-Glossy-Band",
     ("SYN-IMG-R005-SYN-U11",), "工具与数码桌面场景", "工具与数码桌面"),
    ("scene01", "preference-wire001-009:F-SYN-U11-R027-dislike-large-grid-context",
     ("SYN-IMG-R027-SYN-U11",), "仅针对工具与数码桌面场景的排斥，非全局审美否定", "工具与数码桌面"),
    ("scene04", "preference-wire001-003:F-SYN-U09-R003-Avoid-Complex-Layers",
     ("SYN-IMG-R003-SYN-U09",), "通勤用品区", "通勤随身物件"),
}
MISSING = {"scene_id": "scene04", "image_id": "TR036", "object_id": "o4",
           "only_existing_selected_comparison_observation_ids": ["TR036:a0118", "TR036:a0206"]}


def _validate_decision(record, prepared, prepared_path, response_path):
    require(record.get("schema_version") == "prism.Root_H02_design_resolution.v1"
            and record.get("authority_kind") == "user_delegated_ai"
            and record.get("human_designer_actually_reviewed") is False
            and record.get("simulation_only") is True, "explicit simulation design authority required")
    auth = authority(record["authority_ref"]["path"])
    require(record["authority_ref"] == auth["identity"] == prepared["side_table"]["authority"]["identity"]
            and auth["record"] == prepared["side_table"]["authority"]["record"]
            and record.get("recorded_by") == "Root"
            and record.get("recorder_thread_id") == auth["record"]["source_thread_id"]
            and bool(record.get("reason")), "design decision is not from authorized Root")
    for flag in ("preserve_original_P01_and_review_fingerprints", "preserve_all_negative_conditions",
                 "no_unknown_to_NA", "original_reply_not_modified", "final_group_membership_not_decided"):
        require(record.get(flag) is True, "design decision loses original evidence boundary: " + flag)
    scale = record.get("scale_decision", {})
    require(scale.get("mode") == "reference_region_only" and scale.get("physical_scale_status") == "unknown"
            and scale.get("new_metric_values") == [] and bool(scale.get("reason")), "physical scale cannot be invented")
    require(record.get("missing_example_binding") == MISSING, "only the two already selected o4 observations may be located")
    bindings = record.get("scene_bindings", [])
    keys = [(b["scene_id"], b["preference_id"], tuple(b["evidence_ids"]), b["original_condition"], b["execution_scene"]) for b in bindings]
    require(len(keys) == len(set(keys)) == 3 and set(keys) == ALLOWED, "unapproved scene/preference/evidence alias")
    require(set(record["prepared_inputs"]) == set(record["source_responses"]) == {"scene01", "scene04"}, "both actual inputs required")
    for refs in (record["prepared_inputs"], record["source_responses"]):
        require(all(identity(ref["path"]) == ref for ref in refs.values()), "Root-bound original input changed")
    scene_ids = [s for s, ref in record["prepared_inputs"].items() if identity(prepared_path) == ref]
    require(len(scene_ids) == 1, "prepared input is not one of the actual Root-bound inputs")
    scene_id = scene_ids[0]
    require(identity(response_path) == record["source_responses"][scene_id], "actual reply belongs to another scene")
    for binding in bindings:
        source = prepared if binding["scene_id"] == scene_id else read_json(record["prepared_inputs"][binding["scene_id"]]["path"])
        require(len(source["side_table"]["frames"]) == 1, "bounded scene decision needs one actual frame")
        frame = source["side_table"]["frames"][0]
        pref = next(p for p in frame["side_table"]["validated_profile"]["preferences"] if p["preference_id"] == binding["preference_id"])
        require(pref["attitude"] == "dislike" and pref["evidence_refs"] == binding["evidence_ids"]
                and binding["original_condition"] in pref.get("conditions", []), "binding does not identify the exact original negative")
        view = frame["side_table"]["context_role_view"]
        row = next(r for r in view["preferences"] if r["preference_id"] == pref["preference_id"])
        require(view["execution_scope"]["values"].get("scene") == binding["execution_scene"]
                and any(r["label"] == binding["execution_scene"] for r in row["scenario_refs"]), "scene must remain inside its recorded source scope")
        scope = binding.get("confirmed_analysis_scope", {})
        require(scope.get("kind") == "candidate_bindings" and scope.get("scope_rule") == "all_approved_library_carriers"
                and scope.get("reason"), "Root has not confirmed the full-library analysis scope")
    return scene_id


def _scope_overlay(base, preference, context, bindings, resolution_identity):
    """Replace only the evaluation predicate, never original conditions/profile."""
    matches = [b for b in bindings if b["preference_id"] == preference["preference_id"]]
    if not matches:
        return base
    result = deepcopy(base)
    predicates = deepcopy(base["evaluated_conditions"])
    for binding in matches:
        require(preference["evidence_refs"] == binding["evidence_ids"]
                and binding["original_condition"] in preference.get("conditions", [])
                and context.get("scene") == binding["execution_scene"], "scope decision no longer binds original evidence/context")
        require(predicates.count(binding["original_condition"]) == 1, "raw condition is not one uniquely evaluable string")
        predicates[predicates.index(binding["original_condition"])] = {
            "field": "scene", "operator": "eq", "value": binding["execution_scene"]}
    state = condition_state(predicates, context)
    if base["scope_pending_reasons"]:
        state = "unknown"
    if not base["user_ids"]:
        state = "not_applicable"
    result.update(context_state=state, evaluated_conditions=predicates,
                  original_context_state=base["context_state"],
                  original_evaluated_conditions=deepcopy(base["evaluated_conditions"]),
                  design_resolution_identity=deepcopy(resolution_identity),
                  design_scope_origin="user_delegated_ai_simulation_only",
                  human_designer_actually_reviewed=False)
    return result


def _derive_response(reply, prepared, record, scene_id):
    derived, changes = deepcopy(reply), []
    observations = frozen_draft.observation_index(prepared["side_table"]["documents"])
    bindings = [b for b in record["scene_bindings"] if b["scene_id"] == scene_id]
    require(len(reply["directions"]) == 1, "bounded repair expects the single actual H02 direction")
    direction = derived["directions"][0]
    require(direction["scale_status"] == "unknown" and direction["scale_observation_ids"] == [], "unexpected original scale contract")
    direction["scale_status"] = "reference_region_only"
    changes.append({"path": "/directions/0/scale_status", "before": "unknown", "after": "reference_region_only",
                    "kind": "design_scope_only", "physical_scale_status": "unknown", "new_metric_values": []})
    for binding in bindings:
        require(direction["scene"] == binding["execution_scene"], "direction uses another execution scene")
        matches = [(i, d) for i, d in enumerate(direction["negative_scope_proposals"]) if d["preference_id"] == binding["preference_id"]]
        require(len(matches) == 1, "Root decision must bind one original negative proposal")
        index, prior = matches[0]
        require(prior["disposition"] == prior["scope_kind"] == prior["scope_rule"] == "pending", "unexpected original negative disposition")
        scope = binding["confirmed_analysis_scope"]
        replacement = {"preference_id": binding["preference_id"], "disposition": "proposed",
                       "scope_kind": scope["kind"], "scope_rule": scope["scope_rule"], "reason": scope["reason"]}
        direction["negative_scope_proposals"][index] = replacement
        changes.append({"path": f"/directions/0/negative_scope_proposals/{index}", "before": prior, "after": deepcopy(replacement),
                        "kind": "Root_analysis_scope_decision", "scene_binding": deepcopy(binding)})
    if scene_id == "scene04":
        missing = record["missing_example_binding"]
        ids = missing["only_existing_selected_comparison_observation_ids"]
        require(set(ids) <= set(direction["comparison_observation_ids"]), "cannot add new comparison observations")
        pair = {"image_id": missing["image_id"], "object_id": missing["object_id"]}
        require(pair not in direction["example_bindings"], "missing example was already present")
        for oid in ids:
            iid, observation = observations[oid]
            require(iid == pair["image_id"] and observation["object_id"] == pair["object_id"], "wrong or ambiguous original carrier")
        direction["example_bindings"].append(pair)
        changes.append({"path": "/directions/0/example_bindings/-", "before": None, "after": pair,
                        "kind": "declare_already_selected_observations_unique_carrier", "observation_ids": ids})
    return derived, changes


def _field_blockers(card, prepared):
    documents = prepared["side_table"]["documents"]
    dictionaries = {}
    for iid, document in documents.items():
        a = document["cmf_admission"]
        dictionaries[iid] = ({u["parameter_id"] for u in a["all_cmf_units"]}
                             | set(a["not_checked_parameter_ids"]) | set(a["out_of_scope_parameter_ids"]))
    shared_pids = set.intersection(*dictionaries.values())
    active, all_unregistered = [], set()
    for audit in card["manifest"]["negative_audit"]:
        pref = audit["preference"]
        features = [f for f in pref["features"] if f["parameter_id"] not in shared_pids]
        all_unregistered.update(f["parameter_id"] for f in features)
        if features and audit["scope"]["context_state"] != "not_applicable":
            active.append({"reason": "original_negative_parameter_not_in_visual_dictionary",
                "preference_id": pref["preference_id"], "evidence_refs": deepcopy(pref["evidence_refs"]),
                "user_ids": deepcopy(pref["user_ids"]), "original_conditions": deepcopy(pref.get("conditions", [])),
                "quotes": deepcopy(pref["quotes"]), "unmapped_features": deepcopy(features),
                "context_state": audit["scope"]["context_state"],
                "source_features_unchanged": True, "unknown_to_NA": False})
    return {"applicable_negative_field_gaps": active, "all_original_negative_unregistered_parameter_ids": sorted(all_unregistered),
            "original_negative_count": len(card["manifest"]["negative_audit"]),
            "official_guard": "prism_runtime.clustering.local_cmf_bridge_v1.bridge._derive_view",
            "official_rejection": "Request contains fields outside the original dictionary ledger",
            "all_library_images_and_carriers_preserved": True, "mapping_created": False}


def accept_resolved(config_path, prepared_path, response_path, resolution_path):
    inputs = {k: identity(p) for k, p in (("config", config_path), ("prepared", prepared_path),
                                         ("response", response_path), ("design_resolution", resolution_path))}
    require(inputs["design_resolution"]["sha256"] == DECISION_SHA256, "this bounded version requires exact Root v2 decision")
    config, prepared, record = read_json(config_path), read_json(prepared_path), read_json(resolution_path)
    require(prepare_request(config) == prepared, "frozen preparation/source/semantic review no longer replays")
    scene_id = _validate_decision(record, prepared, prepared_path, response_path)
    reply, source, raw = read_response(response_path)
    from jsonschema import Draft202012Validator
    require(not list(Draft202012Validator(prepared["response_schema"]).iter_errors(reply)), "invalid original H02 schema")
    derived, changes = _derive_response(reply, prepared, record, scene_id)
    require(not list(Draft202012Validator(prepared["response_schema"]).iter_errors(derived)), "invalid derived proposal view")
    bindings = [b for b in record["scene_bindings"] if b["scene_id"] == scene_id]
    def scoped(view, preference, users, context, *, evidence, review_context):
        base = evaluate_preference_scope(view, preference, users, context, evidence=evidence, review_context=review_context)
        return _scope_overlay(base, preference, context, bindings, inputs["design_resolution"])
    namespace = dict(vars(frozen_draft))
    namespace["evaluate_preference_scope"] = scoped
    validate = FunctionType(frozen_draft.validate_direction.__code__, namespace, "validate_resolved_direction")
    frames = {f["frame_id"]: f for f in prepared["side_table"]["frames"]}
    cards, legacy = [], []
    for original, direction in zip(reply["directions"], derived["directions"]):
        frame = frames[direction["frame_id"]]
        try:
            prior = frozen_draft.validate_direction(original, frame, prepared)
            legacy.append({"direction_id": original["direction_id"], "status": "accepted_original_draft",
                           "pending": prior["manifest"]["pending"], "manifest_snapshot": prior["manifest_snapshot"]})
        except ValueError as error:
            legacy.append({"direction_id": original["direction_id"], "status": "rejected_original_draft",
                           "error_type": type(error).__name__, "error": str(error)})
        card = validate(direction, frame, prepared)
        audit = _field_blockers(card, prepared)
        card["manifest"].update(original_direction=deepcopy(original), derivation_audit=deepcopy(changes),
            design_resolution_identity=deepcopy(inputs["design_resolution"]),
            physical_scale_status="unknown", scale_mode="reference_region_only", executable_field_audit=audit)
        card["manifest"]["pending"].extend("negative_dictionary_binding_pending:" + x["preference_id"] for x in audit["applicable_negative_field_gaps"])
        card["manifest_snapshot"] = fingerprint(card["manifest"])
        card["status"] = "pending_original_negative_dictionary_binding"
        cards.append(card)
    result = {"schema_version": DRAFT_SCHEMA, "algorithm_version": VERSION, "mode": "proposal_only",
        "inputs": inputs, "scene_id": scene_id, "source_response": source,
        "original_response_identities": deepcopy(record["source_responses"]),
        "design_resolution_identity": inputs["design_resolution"], "derivation_audit": changes,
        "original_acceptance_replay": legacy, "request_snapshot": prepared["request_snapshot"],
        "library_snapshot": prepared["side_table"]["library"]["library_snapshot"],
        "candidate_pool_kind": prepared["side_table"]["library"]["candidate_pool_kind"],
        "source_hashes": {p.name: identity(p)["sha256"] for p in sorted(Path(__file__).parent.glob("*.py"))},
        "cards": cards, "physical_scale_status": "unknown", "scale_mode": "reference_region_only",
        "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False,
        "original_reply_modified": False, "original_profile_modified": False,
        "grouping_requests": [], "contexts": [], "new_model_calls": 0}
    result["draft_snapshot"] = fingerprint(result)
    require(Path(response_path).read_bytes() == raw and all(identity(r["path"]) == r for r in inputs.values()), "source changed during replay")
    return result


def verify_draft(draft_path):
    before, draft = identity(draft_path), read_json(draft_path)
    require(draft.get("schema_version") == DRAFT_SCHEMA and draft.get("algorithm_version") == VERSION, "unsupported resolved draft")
    refs = draft["inputs"]
    require(all(identity(r["path"]) == r for r in refs.values()), "bound source changed")
    replay = accept_resolved(*(refs[k]["path"] for k in ("config", "prepared", "response", "design_resolution")))
    require(replay == draft and identity(draft_path) == before, "resolved draft differs from leaf replay")
    return {"passed": True, "draft_identity": before, "draft_snapshot": draft["draft_snapshot"],
            "algorithm_version": VERSION, "model_calls": 0, "executable": False,
            "status": "pending_original_negative_dictionary_binding", "grouping_requests": []}


def compile_confirmed(config_path, prepared_path, draft_path, confirmation_path, *, output_dir):
    """Bind a real Root library decision, then return the actual unresolved gate."""
    verify_draft(draft_path)
    draft, prepared, confirmation = read_json(draft_path), read_json(prepared_path), read_json(confirmation_path)
    require(identity(config_path) == draft["inputs"]["config"] and identity(prepared_path) == draft["inputs"]["prepared"], "compiler inputs differ from resolved draft")
    choices = validate_confirmation(prepared, draft, confirmation)
    by_id = {c["direction_id"]: c for c in draft["cards"]}
    pending = []
    for choice in choices:
        card = by_id[choice["direction_id"]]
        gaps = card["manifest"]["executable_field_audit"]
        require(gaps["applicable_negative_field_gaps"], "this bounded version has no verified executable path after a semantic mapping change")
        pending.append({"direction_id": choice["direction_id"], "reason": "original_negative_dictionary_binding_unresolved",
                        "field_audit": deepcopy(gaps), "pending": deepcopy(card["manifest"]["pending"])})
    result = {"schema_version": "prism.design_resolution_registration.v1", "algorithm_version": VERSION,
        "status": "pending_original_negative_dictionary_binding", "draft_identity": identity(draft_path),
        "confirmation_identity": identity(confirmation_path), "design_resolution_identity": draft["design_resolution_identity"],
        "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False,
        "physical_scale_status": "unknown", "scale_mode": "reference_region_only",
        "pending": pending, "contexts": [], "grouping_requests": [], "clustering_executed": False, "new_model_calls": 0}
    out = Path(output_dir).resolve()
    require(not out.exists(), "registration output must be a new directory")
    write_json(out / "registration.json", result)
    return result


def verify_context(context_path, *, request, inventory_path):
    """Fail closed: no executable context was issued for these blocked inputs.

    The explicit consumer can register this symbol, but it can never turn a
    draft/Root design decision into an executable or negatively cleared group.
    A future semantic-mapping repair needs a separately named/versioned path.
    """
    require(False, "design-resolution-v1 issued no executable context: original negative dictionary binding is unresolved")
