"""Complete stage-aware H02 preparation, acceptance and leaf registration.

Reuse the frozen closed-library enumeration and exact CT001/CT002 compiler.
Only source-frame selection and independently reviewed stage scope are new.
"""
from copy import deepcopy
from pathlib import Path
import json

from prism_runtime.contracts import require, read_json, write_json, index_by
from ..common import fingerprint
from ..proposal_gate_v1.sources import identity
from ..compact_context_v1.normalize import pack_record_columns
from ..exploratory_reference_v1 import prepare as frozen_prepare
from ..exploratory_reference_v1 import draft as frozen_draft
from ..exploratory_reference_v1 import runtime as frozen_runtime
from ..exploratory_reference_v1 import api as frozen_api
from ..exploratory_reference_v1.qualification import POOL_KIND, CARRIER_RULE
from .roles import VERSION
from .context import StageSession, private_namespace, scoped_evaluator, annotate
from .h01 import accept_h01, validate_h01_selection, source_hashes
from .phase_roles import PHASE, load_h02_stage_context, CONTEXT_SCHEMA as H02_ROLE_CONTEXT

REQUEST_SCHEMA = "prism.stage_scope_H02_request.v1"
RESPONSE_SCHEMA = "prism.stage_scope_H02_proposal.v1"
DRAFT_SCHEMA = "prism.stage_scope_H02_draft.v1"
CONTEXT_SCHEMA = "prism.stage_scope_exploratory_reference_context.v1"


def _context(config):
    return load_h02_stage_context(config["stage_context_path"])


def _frame(spec, context, context_identity):
    require(spec.get("consumer") == "stage_scope_v1", "explicit stage-aware H01 source consumer required")
    paths = {k: spec[k] for k in ("h01_prepared_path", "h01_response_path", "h01_selection_path")}
    refs = {k: identity(p) for k, p in paths.items()}
    prepared = read_json(paths["h01_prepared_path"])
    original_result = accept_h01(paths["h01_prepared_path"], paths["h01_response_path"], mode=spec.get("mode", "exploration"))
    selected = validate_h01_selection(prepared, original_result, read_json(paths["h01_selection_path"]))
    if spec.get("accepted_result_path"):
        require(read_json(spec["accepted_result_path"]) == original_result, "saved H01 result differs from actual replay")
        refs["accepted_result_path"] = identity(spec["accepted_result_path"])
    if context["schema_version"] == H02_ROLE_CONTEXT:
        role_prepared = read_json(context["source_preparation_identity"]["path"])
        linked = role_prepared["payload"]["actual_H01_selection"]
        require(linked["prepared_identity"] == refs["h01_prepared_path"]
                and linked["response_identity"] == refs["h01_response_path"]
                and linked["selection_identity"] == refs["h01_selection_path"], "H02 phase review used another H01 selection")
    source_side = prepared["side_table"]
    inputs = deepcopy(source_side["inputs"])
    options = {k: deepcopy(inputs[k]) for k in ("review_context", "execution_scope_context", "design_intent_context", "admission_context")}
    session = StageSession(inputs["bundle"], inputs["saved_profile"], review_context=options["review_context"],
        execution_scope_context=options["execution_scope_context"], stage_context=context,
        stage_identity=context_identity, stage=PHASE)
    evaluator = scoped_evaluator(context, context_identity, PHASE)
    view = session.view
    scopes = [evaluator(view, p, view["selected_user_ids"], view["execution_scope"]["values"],
        evidence=session.evidence, review_context=options["review_context"]) for p in source_side["validated_profile"]["preferences"]]
    side = deepcopy(source_side)
    side.update(context_role_view=view, preference_scopes=scopes,
                stage_evaluation_origin="H02 view derived after original H01 replay; original H01 artifact unchanged")
    # Create a explicitly named H02 research transport, not a rewritten H01
    # request with a stale token. The original request remains in source files.
    from ..compact_context_v1.normalize import normalize
    material_tables, _ = normalize(inputs["bundle"], source_side["validated_profile"], view, scopes)
    material_tables["stage_scope_contract"] = deepcopy(view["stage_scope"])
    for pref in material_tables["preferences"]:
        s = next(x for x in scopes if x["preference_id"] == pref["preference_id"])
        pref["scope"].update(stage_role_evaluation=deepcopy(s["stage_role_evaluation"]),
            deferred_design_obligations=deepcopy([o for o in s["deferred_design_obligations"] if o["preference_id"] == pref["preference_id"]]))
    packed, schemas = pack_record_columns(material_tables)
    transport = {"schema_version": "prism.stage_scope_H02_research_view.v1", "source_H01_request_identity": refs["h01_prepared_path"],
        "messages": [{"role": "user", "content": json.dumps({"tables": packed, "record_schemas": schemas}, ensure_ascii=False)}]}
    result = deepcopy(original_result)
    result.update(theme_candidates=selected, original_H01_result_snapshot=fingerprint(original_result),
        delegated_H01_selection_identity=refs["h01_selection_path"],
        current_view="Root-selected H01 candidates, not a changed model reply")
    return {"frame_id": spec["frame_id"], "spec": deepcopy(spec), "source_identities": refs,
        "inputs": inputs, "request": transport, "side_table": side, "result": result,
        "result_snapshot": fingerprint(result), "original_H01_result": original_result,
        "options": options, "stage_scope_context_identity": context_identity}


def inspect_h02_scope(config):
    context, ref = _context(config)
    frames = [_frame(spec, context, ref) for spec in config["frames"]]
    rows = []
    for frame in frames:
        scopes = index_by(frame["side_table"]["preference_scopes"], "preference_id")
        for match in frame["result"]["theme_candidates"]:
            anchors = [scopes[p] for p in match["preference_refs"]]
            rows.append({"frame_id": frame["frame_id"], "match_id": match["match_id"], "theme_id": match["theme_id"],
                "preference_ids": match["preference_refs"], "eligible": all(s["context_state"] == "applies" for s in anchors),
                "scopes": anchors})
    return {"algorithm_version": VERSION, "processing_stage": PHASE, "stage_scope_context_identity": ref,
        "relations": rows, "eligible_match_ids": [r["match_id"] for r in rows if r["eligible"]],
        "product_design_approved": False, "new_model_calls": 0}


def prepare_h02(config):
    context, ref = _context(config)
    cache = {}
    def load(spec):
        key = fingerprint(spec)
        if key not in cache: cache[key] = _frame(spec, context, ref)
        return deepcopy(cache[key])
    ns = private_namespace(frozen_prepare, VERSION=VERSION, RESPONSE_SCHEMA=RESPONSE_SCHEMA,
                           load_frame=load, __file__=__file__)
    result = ns["prepare_request"](config)
    diagnostics = []
    for frame in result["side_table"]["frames"]:
        scopes = index_by(frame["side_table"]["preference_scopes"], "preference_id")
        for match in frame["result"]["theme_candidates"]:
            diagnostics.append({"frame_id": frame["frame_id"], "match_id": match["match_id"],
                "eligible": all(scopes[p]["context_state"] == "applies" for p in match["preference_refs"])})
    require(any(d["eligible"] for d in diagnostics), "no independently stage-qualified H01 anchor for H02; do not call the model")
    source_pins = {p.name: identity(p)["sha256"] for p in Path(frozen_prepare.__file__).parent.glob("*.py")}
    result["side_table"].update(stage_scope_context_identity=ref, stage_context_snapshot=context["stage_context_snapshot"],
        H02_stage_eligibility=diagnostics, frozen_exploratory_source_hashes=source_pins,
        H01_stage_source_hashes=source_hashes())
    payload = json.loads(result["messages"][-1]["content"])
    system = result["messages"][0]["content"] + (
        "\n本请求已通过单独H02阶段角色复核，先前H01批准不替代本阶段。研究表的stage_scope_contract保留全部原条件及未履行后续义务。"
        "只用H02范围applies的主题锚点。局部PID/值都是新的exploratory_hypothesis，不能成为受访者元素喜好或产品定稿。"
        "本阶段scale_status必须reference_region_only且scale_observation_ids为空；不批准真实材料或物理量测。"
        "完整声明每个所选required/comparison观察的真实原载体。全批准母库/载体由原引擎筛选，不预写成员或用示例替代候选池。")
    token = fingerprint({"version": VERSION, "side_table": result["side_table"], "system": system})
    payload.update(request_snapshot=token, processing_stage=PHASE,
                   stage_scope_context_identity=ref, H02_stage_eligibility=diagnostics)
    result.update(schema_version=REQUEST_SCHEMA, request_snapshot=token,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": json.dumps(payload, ensure_ascii=False, separators=(",", ":"))}])
    result["response_schema"]["properties"]["request_snapshot"] = {"type": "string", "const": token}
    d = result["response_schema"]["properties"]["directions"]["items"]["properties"]
    d["scale_status"] = {"type": "string", "const": "reference_region_only"}
    d["scale_observation_ids"].update(maxItems=0)
    d["relation_basis"] = {"type": "string", "const": "exploratory_hypothesis"}
    return result


def _draft_namespace(context, ref):
    ns = private_namespace(frozen_draft, VERSION=VERSION, RESPONSE_SCHEMA=RESPONSE_SCHEMA,
        prepare_request=prepare_h02, evaluate_preference_scope=scoped_evaluator(context, ref, PHASE))
    original = ns["validate_direction"]
    def validate(direction, frame, prepared):
        require(direction["scale_status"] == "reference_region_only" and not direction["scale_observation_ids"], "this stage cannot approve physical measurements")
        require(direction["relation_basis"] == "exploratory_hypothesis", "local stage outputs are new exploration hypotheses, not element preference approvals")
        card = original(direction, frame, prepared)
        annotate(card["manifest"], context, ref, PHASE, direction["preference_ids"])
        card["manifest_snapshot"] = fingerprint(card["manifest"])
        return card
    ns["validate_direction"] = validate
    return ns


def accept_h02_proposal(config, prepared, response_path):
    context, ref = _context(config)
    result = _draft_namespace(context, ref)["accept_proposal"](config, prepared, response_path)
    result.pop("draft_snapshot")
    result["schema_version"] = DRAFT_SCHEMA
    annotate(result, context, ref, PHASE)
    result["draft_snapshot"] = fingerprint(result)
    return result


def _compile(prepared, draft, receipt, receipt_identity, choice, context, ref):
    def session(bundle, profile, **opts):
        return StageSession(bundle, profile, **opts, stage_context=context, stage_identity=ref, stage=PHASE)
    ns = private_namespace(frozen_runtime, VERSION=VERSION, ContextSession=session)
    result = ns["compile_direction"](prepared, draft, receipt, receipt_identity, choice)
    annotate(result, context, ref, PHASE, result["core_proposal"]["preference_ids"])
    annotate(result["selection"], context, ref, PHASE, result["core_proposal"]["preference_ids"])
    annotate(result["h02_result"], context, ref, PHASE, result["core_proposal"]["preference_ids"])
    for direction in result["h02_result"]["design_directions"]:
        annotate(direction, context, ref, PHASE, direction.get("preference_refs"))
    for request in result["h02_result"]["grouping_requests"]:
        annotate(request, context, ref, PHASE, request["preference_refs"])
        request.update(physical_scale_status="unknown", scale_mode="reference_region_only")
    return result


def _replay(inputs, direction_id=None):
    data = frozen_api._read_inputs(inputs)
    config, prepared, draft, confirmation = (data[k] for k in ("config", "prepared", "draft", "confirmation"))
    require(accept_h02_proposal(config, prepared, draft["source_response"]["path"]) == draft, "stage H02 draft differs from actual proposal replay")
    context, ref = _context(config)
    choices = frozen_runtime.validate_confirmation(prepared, draft, confirmation)
    if direction_id is not None:
        choices = [c for c in choices if c["direction_id"] == direction_id]
        require(len(choices) == 1, "direction is not in the explicit Root choice")
    results = [_compile(prepared, draft, confirmation, inputs["confirmation"], c, context, ref) for c in choices]
    return prepared, draft, confirmation, results


def compile_confirmed(config_path, prepared_path, draft_path, confirmation_path, *, output_dir):
    # The frozen writer calls the new leaf replay in a private namespace; no
    # consumer callback, source mutation, candidate prefilter or engine change.
    ns = private_namespace(frozen_api, VERSION=VERSION, CONTEXT_SCHEMA=CONTEXT_SCHEMA, _replay=_replay)
    result = ns["compile_confirmed"](config_path, prepared_path, draft_path, confirmation_path, output_dir=output_dir)
    return result


def verify_context(context_path, *, request, inventory_path):
    ns = private_namespace(frozen_api, VERSION=VERSION, CONTEXT_SCHEMA=CONTEXT_SCHEMA, _replay=_replay)
    receipt = ns["verify_context"](context_path, request=request, inventory_path=inventory_path)
    context = read_json(context_path)
    config = read_json(context["inputs"]["config"]["path"])
    stage, stage_identity = _context(config)
    require(request.get("processing_stage") == PHASE and request.get("stage_scope_context_identity") == stage_identity
            and request.get("stage_context_snapshot") == stage["stage_context_snapshot"], "request lost independently reviewed H02 stage identity")
    require(all(request.get(k) is False for k in ("product_design_approved", "real_material_approved", "physical_measurement_approved"))
            and request.get("physical_scale_status") == "unknown" and request.get("scale_mode") == "reference_region_only", "exploration cannot grant product/material/physical approval")
    require(all(o.get("obligation_status") == "unfulfilled" for o in request.get("deferred_design_obligations", [])), "future obligation was falsely marked satisfied")
    receipt.update(algorithm_version=VERSION, context_schema_version=CONTEXT_SCHEMA,
        processing_stage=PHASE, stage_scope_context_identity=stage_identity,
        stage_context_snapshot=stage["stage_context_snapshot"],
        deferred_design_obligations=deepcopy(request["deferred_design_obligations"]),
        stage_condition_audit=deepcopy(request["stage_condition_audit"]),
        product_design_approved=False, real_material_approved=False, physical_measurement_approved=False,
        physical_scale_status="unknown", scale_mode="reference_region_only")
    return receipt
