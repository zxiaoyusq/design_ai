"""Actual H01 continuation using the frozen compact engine in a private namespace."""
from copy import deepcopy
from pathlib import Path
import json

from prism_runtime.contracts import require, read_json, index_by
from ..compact_context_v1 import api as frozen
from ..matrix_state_bridge_v1.api import read_response, derive_display_states
from ..proposal_gate_v1.sources import identity, authority
from ..common import fingerprint
from .roles import VERSION, verify_stage_context, _object, _array, STRING, _schema_check
from .context import StageSession, private_namespace, scoped_evaluator

REQUEST_SCHEMA = "prism.stage_scope_h01_request.v1"
SIDE_SCHEMA = "prism.stage_scope_h01_side_table.v1"
RESPONSE_SCHEMA = "prism.stage_scope_h01_response.v1"
SELECTION_SCHEMA = "prism.stage_scope_h01_selection.v1"


def source_hashes():
    result = frozen._engine_hashes()
    result.update({"stage_scope_v1/" + name: identity(Path(__file__).with_name(name))["sha256"]
                   for name in ("roles.py", "context.py", "h01.py")})
    return result


def _namespace(context, context_identity):
    def session(bundle, profile, **options):
        return StageSession(bundle, profile, **options, stage_context=context,
                            stage_identity=context_identity, stage="H01_theme_exploration")
    def normalize(bundle, profile, view, scopes):
        tables, off = frozen.normalize(bundle, profile, view, scopes)
        by_id = {s["preference_id"]: s for s in scopes}
        for pref in tables["preferences"]:
            scope = by_id[pref["preference_id"]]
            pref["scope"].update(processing_stage=scope["processing_stage"],
                original_context_state=scope["original_context_state"],
                stage_role_evaluation=deepcopy(scope["stage_role_evaluation"]),
                deferred_design_obligations=deepcopy([o for o in scope["deferred_design_obligations"] if o["preference_id"] == pref["preference_id"]]))
        tables["stage_scope_contract"] = deepcopy(view["stage_scope"])
        return tables, off
    system = frozen.SYSTEM.replace("六个方向", "预设方向").replace("六个大风格", "输入中明确批准的大风格")
    system += ("\n本入口已逐条件执行实际独立复核的阶段角色。当前requirement未满足或未知仍阻断；获批的deferred义务只在明确阶段不作前置，"
        "仍原文保留、未履行并下传。applies仅表示该阶段可作探索锚点，不能推定具体材料、物理尺寸、宗教归属或最终产品批准。"
        "使用实际axis数组，不补轴；宗教无原来源支持保留缺口。H01只提主题关系，不指定分组成员。")
    return private_namespace(frozen, VERSION=VERSION, REQUEST_SCHEMA=REQUEST_SCHEMA, SIDE_SCHEMA=SIDE_SCHEMA,
        RESPONSE_SCHEMA=RESPONSE_SCHEMA, SYSTEM=system, ContextSession=session,
        evaluate_preference_scope=scoped_evaluator(context, context_identity, "H01_theme_exploration"),
        normalize=normalize, _engine_hashes=source_hashes)


def _inputs(config):
    keys = ("bundle_path", "profile_path", "review_context_path", "execution_scope_path", "design_intent_path", "admission_context_path", "stage_context_path")
    refs = {k: identity(config[k]) for k in keys}
    values = {k: read_json(v["path"]) for k, v in refs.items()}
    context, context_identity = verify_stage_context(config["stage_context_path"])
    options = {name: values[key] for name, key in (("review_context", "review_context_path"),
        ("execution_scope_context", "execution_scope_path"), ("design_intent_context", "design_intent_path"),
        ("admission_context", "admission_context_path"))}
    return refs, values, options, context, context_identity


def _ids(ids, minimum=0, exact=False):
    value = {"type": "array", "items": {"type": "string"}, "uniqueItems": True, "minItems": minimum}
    if ids: value["items"]["enum"] = list(ids)
    else: value["maxItems"] = 0
    if exact: value.update(minItems=len(ids), maxItems=len(ids))
    return value


def response_schema(package):
    request, side = package["request"], package["side_table"]
    inv = side["inventory"]
    pids, tids = inv["preference_ids"], inv["theme_ids"]
    evidence = [r["evidence_id"] for r in side["inputs"]["bundle"]["evidence"] if r["source_kind"] == "trend"]
    users = side["validated_profile"]["selection"]["selected_user_ids"]
    axes = side["inputs"]["design_intent_context"]["approved_broad_style_axes"]
    proposal = _object({"match_id": STRING, "theme_id": {"type": "string", "enum": tids}, "title": STRING,
        "preference_ids": _ids(pids, 1), "trend_refs": _ids(evidence, 1), "target_user_ids": _ids(users, 1),
        "relation_basis": {"type": "string", "enum": ["direct_support", "anchored_extension", "exploratory_hypothesis"]},
        "shared_principle": STRING, "explanation": STRING, "hypotheses": _array(_object({"reason": STRING})),
        "transfer_scope": {"type": "string", "enum": ["same_category", "cross_category"]},
        "opposition_preference_ids": _ids(inv["negative_audit_ids"])})
    cell = _object({"theme_id": {"type": "string", "enum": tids},
        "state": {"type": "string", "enum": sorted(frozen.MATRIX_STATES)}, "reason": STRING,
        "positive_preference_ids": _ids(pids), "opposing_preference_ids": _ids(inv["negative_audit_ids"]),
        "disputed_preference_ids": _ids(inv["review_disputed_preference_ids"]), "pending_preference_ids": _ids(pids),
        "trend_refs": _ids(evidence), "match_ids": _array(STRING)})
    fields = {"schema_version": {"type": "string", "const": RESPONSE_SCHEMA},
        "request_id": {"type": "string", "const": request["request_id"]},
        "compact_snapshot": {"type": "string", "const": request["compact_snapshot"]}}
    fields.update({k: {"type": "string", "const": request["bindings"][k]} for k in
                   ("input_snapshot", "review_context_snapshot", "context_sidecar_snapshot", "side_table_snapshot")})
    fields.update({k: _ids(inv[k], exact=True) for k in ("negative_audit_ids", "review_disputed_preference_ids")})
    fields.update(proposals=_array(proposal), axis_assessments=_array(_object({
        "axis_id": {"type": "string", "enum": [a["axis_id"] for a in axes]}, "theme_assessments": _array(cell, len(tids))}), len(axes)))
    return _object(fields)


def prepare_h01(config):
    refs, values, options, context, context_identity = _inputs(config)
    ns = _namespace(context, context_identity)
    result = ns["prepare_theme_request"](values["bundle_path"], values["profile_path"],
                                         request_id=config.get("request_id", "H01-stage-scope"), **options)
    result.update(config=deepcopy(config), source_identities=refs, stage_scope_context_identity=context_identity,
                  new_model_calls=0, response_schema=response_schema(result))
    require(all(identity(ref["path"]) == ref for ref in refs.values()), "H01 source changed during preparation")
    return result


def accept_h01(prepared_path, response_path, *, mode="exploration"):
    prepared = read_json(prepared_path)
    require(prepare_h01(prepared["config"]) == prepared, "stage H01 request no longer binds current source or code")
    refs, values, options, context, context_identity = _inputs(prepared["config"])
    response, source, _ = read_response(response_path)
    _schema_check(response, prepared["response_schema"])
    adapted, display_audit = derive_display_states(response)
    result = _namespace(context, context_identity)["accept_theme_response"](
        values["bundle_path"], values["profile_path"], prepared["request"], prepared["side_table"], adapted, mode=mode, **options)
    result["stage_scope_h01"] = {"prepared_identity": identity(prepared_path), "source_response": source,
        "source_response_snapshot": fingerprint(response), "display_only_audit": display_audit,
        "original_response_modified": False, "mode": mode, "stage_scope_context_identity": context_identity}
    return result


def validate_h01_selection(prepared, result, confirmation):
    require(confirmation.get("schema_version") == SELECTION_SCHEMA
            and confirmation.get("authority_kind") == "user_delegated_ai"
            and confirmation.get("human_designer_actually_reviewed") is False, "explicit Root delegated H01 selection required")
    context, _ = verify_stage_context(prepared["config"]["stage_context_path"])
    auth = authority(confirmation["authority_ref"]["path"])
    require(auth["identity"] == confirmation["authority_ref"] == context["authority_identity"]
            and confirmation.get("recorded_by") == "Root"
            and confirmation.get("recorder_thread_id") == auth["record"]["source_thread_id"], "H01 selection authority mismatch")
    meta = result["stage_scope_h01"]
    source_identity = {k: meta["source_response"][k] for k in ("path", "sha256")}
    require(confirmation.get("h01_prepared_identity") == meta["prepared_identity"]
            and confirmation.get("h01_response_identity") == source_identity
            and confirmation.get("h01_result_snapshot") == fingerprint(result), "selection no longer binds actual H01 result")
    ids = confirmation.get("selected_match_ids", [])
    candidates = index_by(result["theme_candidates"], "match_id")
    require(isinstance(ids, list) and ids and len(ids) == len(set(ids)) and set(ids) <= set(candidates), "selection outside admitted H01 candidates")
    require(confirmation.get("selection_id") and confirmation.get("reason"), "specific H01 decision and reason required")
    return [deepcopy(candidates[i]) for i in ids]
