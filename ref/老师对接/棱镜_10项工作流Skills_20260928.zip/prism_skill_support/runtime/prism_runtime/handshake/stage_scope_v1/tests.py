"""Bounded synthetic protocol tests; these are not answers for case B."""
from copy import deepcopy
import unittest

from prism_runtime.contracts import ContractError
from ..common import fingerprint
from .roles import CHECKS, effective_role
from .context import apply_stage_scope, annotate


def synthetic_stage(role="deferred_design_obligation", *, reviewed=True, negative=False):
    raw = "材料验证留待产品定稿前完成"
    pref = {"preference_id": "synthetic:stage-pref", "user_ids": ["synthetic:person"],
        "attitude": "dislike" if negative else "like", "conditions": [raw],
        "evidence_refs": ["synthetic:stage-source"], "quotes": [{"evidence_id": "synthetic:stage-source", "text": raw}],
        "semantic_assessment": {"candidate_digest": "synthetic:candidate"}}
    original = {"condition_id": "synthetic:condition", "preference_id": pref["preference_id"], "condition_index": 0,
        "source_condition": raw, "candidate_digest": "synthetic:candidate", "original_attitude": pref["attitude"],
        "evidence_refs": pref["evidence_refs"], "quotes": pref["quotes"], "sensitive_prerequisite_or_negative_marker": False}
    proposal = {"role": role, "active_stages": ["H01_theme_exploration", "H02_reference_exploration"],
        "predicates": [], "due_before": "product_finalization" if role == "deferred_design_obligation" else ""}
    review = {"verdict": "supported" if reviewed else "insufficient", "checks": {k: True for k in CHECKS},
              "genuine_current_prerequisite_or_exclusion": False}
    effective, reason = effective_role(original, proposal, review)
    row = {"original": original, "proposal": proposal, "independent_review": review,
           "effective_role": effective, "role_resolution_reason": reason,
           "obligation_status": "unfulfilled" if effective == "deferred_design_obligation" else None}
    context = {"fixture_only": True, "classifications": [row], "stage_context_snapshot": "synthetic:context"}
    base = {"context_state": "unknown", "conditions": [raw], "evaluated_conditions": [raw], "user_ids": pref["user_ids"],
            "scope_pending_reasons": [], "evidence_refs": pref["evidence_refs"]}
    return pref, context, base


def consumer_fixture():
    """Existing CT002 fixture plus stage transport, not a production context."""
    from prism_runtime.clustering.scope_examples import scope_example
    from prism_runtime.clustering import cluster_candidates
    request, images = scope_example(mode="exploration")
    second = deepcopy(images[0])
    second["image_id"] = "synthetic:second-stage-scene"
    second["source_ref"] = "synthetic:fixture/second-stage-scene"
    images.append(second)
    request["candidate_image_ids"].append(second["image_id"])
    request["candidate_bindings"].append({**deepcopy(request["candidate_bindings"][0]), "image_id": second["image_id"]})
    request["forbidden_features"][0]["scope"]["bindings"].append({"image_id": second["image_id"], "object_id": "body"})
    request["design_axis"] = "CMF"
    pref, context, _ = synthetic_stage()
    annotate(request, context, {"path": "synthetic:unit-test-only", "sha256": "0" * 64}, "H02_reference_exploration", [pref["preference_id"]])
    request.update(physical_scale_status="unknown", scale_mode="reference_region_only")
    result = cluster_candidates(request, images)
    return {"fixture_only": True, "purpose": "synthetic request/obligation transport and unchanged CT001/CT002 engine checks",
        "actual_case_B_answer": False, "production_context_issued": False,
        "production_leaf_must_not_accept_this_as_an_authorized_context": True,
        "request": request, "image_dna": images, "expected_engine_result": result,
        "request_snapshot": fingerprint(request), "new_model_calls": 0}


class StageScopeChecks(unittest.TestCase):
    def evaluate(self, pref, context, base, stage="H01_theme_exploration"):
        return apply_stage_scope(base, pref, {"scene": "synthetic-office"}, context,
                                 {"path": "synthetic:fixture", "sha256": "0" * 64}, stage)

    def test_current_requirement_not_met_or_unknown_still_blocks(self):
        pref, context, base = synthetic_stage("current_requirement")
        context["classifications"][0]["proposal"]["predicates"] = [{"field": "scene", "operator": "eq", "value": "synthetic-home"}]
        self.assertEqual(self.evaluate(pref, context, base)["context_state"], "not_applicable")
        context["classifications"][0]["proposal"]["predicates"] = [{"field": "product_category", "operator": "eq", "value": "synthetic-device"}]
        self.assertEqual(self.evaluate(pref, context, base)["context_state"], "unknown")

    def test_unreviewed_role_and_current_prerequisite_cannot_be_deferred(self):
        pref, context, base = synthetic_stage(reviewed=False)
        self.assertEqual(self.evaluate(pref, context, base)["context_state"], "unknown")
        row = context["classifications"][0]
        row["independent_review"].update(verdict="supported", genuine_current_prerequisite_or_exclusion=True)
        self.assertEqual(effective_role(row["original"], row["proposal"], row["independent_review"])[0], "unknown")

    def test_negative_and_explicit_sensitive_condition_cannot_be_deferred(self):
        pref, context, base = synthetic_stage(negative=True)
        self.assertEqual(self.evaluate(pref, context, base)["context_state"], "unknown")
        row = context["classifications"][0]
        row["original"].update(original_attitude="like", sensitive_prerequisite_or_negative_marker=True)
        self.assertEqual(effective_role(row["original"], row["proposal"], row["independent_review"])[0], "unknown")

    def test_source_tampering_rejected_and_unreviewed_stage_stays_unknown(self):
        pref, context, base = synthetic_stage()
        wrong = deepcopy(context)
        wrong["classifications"][0]["original"]["source_condition"] = "synthetic altered source"
        with self.assertRaises(ContractError): self.evaluate(pref, wrong, base)
        context["classifications"][0]["proposal"]["active_stages"] = ["H01_theme_exploration"]
        self.assertEqual(self.evaluate(pref, context, base, "H02_reference_exploration")["context_state"], "unknown")

    def test_deferred_text_unfulfilled_and_no_product_or_physical_approval(self):
        pref, context, base = synthetic_stage()
        before = deepcopy((pref, context, base))
        result = self.evaluate(pref, context, base)
        self.assertEqual((pref, context, base), before)
        self.assertEqual(result["context_state"], "applies")
        self.assertEqual(result["conditions"], pref["conditions"])
        obligation = result["deferred_design_obligations"][0]
        self.assertEqual(obligation["original_condition"], pref["conditions"][0])
        self.assertEqual(obligation["obligation_status"], "unfulfilled")
        self.assertFalse(result["product_design_approved"])
        self.assertFalse(result["real_material_approved"])
        self.assertFalse(result["physical_measurement_approved"])
        with self.assertRaises(ContractError): self.evaluate(pref, context, base, "product_finalization")

    def test_synthetic_transport_retains_negative_and_multimember_group(self):
        fixture = consumer_fixture()
        request, result = fixture["request"], fixture["expected_engine_result"]
        self.assertTrue(fixture["fixture_only"])
        self.assertFalse(fixture["production_context_issued"])
        self.assertTrue(request["negative_audit_ids"] and request["forbidden_features"])
        self.assertTrue(any(len(g["members"]) == 2 for g in result["clusters"]))
        self.assertEqual(request["deferred_design_obligations"][0]["obligation_status"], "unfulfilled")


if __name__ == "__main__": unittest.main()
