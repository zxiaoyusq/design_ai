"""A separately proposed/reviewed H02 phase, bound to an actual Root H01 choice."""
from copy import deepcopy
import json

from prism_runtime.contracts import require, read_json
from ..proposal_gate_v1.sources import identity
from ..common import fingerprint
from . import roles
from .context import private_namespace
from .h01 import accept_h01, validate_h01_selection

PHASE = "H02_reference_exploration"
CONTEXT_SCHEMA = "prism.reviewed_H02_stage_scope_context.v1"


def _namespace(review_override=True):
    namespace = private_namespace(roles, STAGES=[PHASE],
        ROLE_RESPONSE="prism.H02_stage_role_proposal.v1",
        REVIEW_RESPONSE="prism.H02_stage_role_independent_review.v1",
        STAGE_CONTEXT=CONTEXT_SCHEMA, prepare_roles=prepare_h02_roles)
    if review_override: namespace["prepare_role_review"] = _prepare_review
    return namespace


def prepare_h02_roles(config):
    original = roles.prepare_roles(config)
    hp, hr, hs = (config[k] for k in ("h01_prepared_path", "h01_response_path", "h01_selection_path"))
    prepared, selection = read_json(hp), read_json(hs)
    result = accept_h01(hp, hr, mode=config.get("h01_mode", "exploration"))
    chosen = validate_h01_selection(prepared, result, selection)
    purpose_ref = identity(config["stage_purpose_path"])
    purpose = read_json(purpose_ref["path"])
    require(purpose.get("schema_version") == "prism.Root_delegated_stage_purpose.v1"
            and purpose.get("target_processing_stage") == PHASE
            and purpose.get("recorded_by") == "Root"
            and purpose.get("recorder_thread_id") == selection["recorder_thread_id"]
            and purpose.get("authority_ref") == selection["authority_ref"]
            and purpose.get("authority_kind") == "user_delegated_ai"
            and purpose.get("human_designer_actually_reviewed") is False,
            "H02 stage purpose must be a bound Root delegated decision")
    require(purpose.get("semantic_role_approval_granted_here") is False
            and purpose.get("stage_role_proposal_and_independent_review_required") is True
            and purpose.get("original_source_statements_and_conditions_remain_authoritative") is True
            and purpose.get("current_requirements_must_not_be_relabelled_as_future_tasks") is True,
            "stage purpose cannot approve semantic roles or waive original conditions")
    require(config["profile_path"] == prepared["config"]["profile_path"]
            and config["bundle_path"] == prepared["config"]["bundle_path"], "H02 phase cannot silently replace the original H01 source/profile")
    payload = deepcopy(original["payload"])
    payload.update(stages=[PHASE], requested_stage=PHASE,
        transition_contract={"source_stage": "H01_theme_exploration", "target_stage": PHASE,
            "purpose": "Use actually selected H01 theme relations only as anchors for NEW local-CMF exploratory hypotheses.",
            "does_not_establish": ["element-level user liking", "product finalization", "true material", "physical dimensions", "religious source meaning"],
            "future_obligations_must_remain": "unfulfilled; an H01 selection does not satisfy product/material/tradition obligations",
            "scale_mode": "reference_region_only"},
        actual_H01_selection={"prepared_identity": identity(hp), "response_identity": identity(hr),
            "selection_identity": identity(hs), "result_snapshot": fingerprint(result), "selected_relations": chosen},
        Root_stage_purpose={"identity": purpose_ref, "record": purpose},
        phase_contract_source=identity(__file__))
    payload["stage_contract"] = {PHASE: original["payload"]["stage_contract"][PHASE], "product_design_approval_supported": False}
    token = fingerprint(payload)
    payload_for_model = {**payload, "request_snapshot": token}
    system = original["messages"][0]["content"] + (
        "\n本请求只针对H02_reference_exploration，前一份只批准H01的角色结果不会自动扩展到这里。"
        "现在已经有实际H01主题关系及Root代理选择，需独立判断原条件是否允许提出局部CMF参考假设。"
        "H02不是产品定稿、材质确认或真实物理量测；也不是把H01主题兴趣升级为元素喜好。"
        "仍必须按原话判定：只有确实不阻断该参考探索阶段的未来安排才能deferred；需要先选具体传统等才能开展的表达可unknown。"
        "不要求所有主题获批，不以完成流程为理由降级条件。所有7条件继续完整分类，active_stages只可含当前H02或留空。")
    return {"schema_version": "prism.H02_stage_role_request.v1", "algorithm_version": roles.VERSION,
        "config": deepcopy(config), "request_snapshot": token, "payload": payload,
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": json.dumps(payload_for_model, ensure_ascii=False)}],
        "response_schema": _namespace()["role_schema"](token, payload["conditions"]), "new_model_calls": 0}


def accept_h02_roles(prepared_path, response_path):
    return _namespace()["accept_roles"](prepared_path, response_path)


def _prepare_review(prepared_path, proposal_path):
    result = _namespace(False)["prepare_role_review"](prepared_path, proposal_path)
    proposal_prepared = read_json(prepared_path)
    for key in ("requested_stage", "transition_contract", "actual_H01_selection", "Root_stage_purpose", "phase_contract_source"):
        result["payload"][key] = deepcopy(proposal_prepared["payload"][key])
    token = fingerprint(result["payload"])
    result["request_snapshot"] = token
    result["response_schema"] = _namespace(False)["review_schema"](token, result["payload"]["items"])
    result["messages"][0]["content"] += (
        "\n本次仅复核H02_reference_exploration角色；附实际H01关系/Root选择及阶段转换合同。"
        "H01批准不是H02元素喜好或产品批准，不可因先前H01角色获批而自动认可当前角色。"
        "H02只能提出原图局部CMF比较假设，未来的产品、材料、传统等义务仍未完成。")
    result["messages"][-1]["content"] = json.dumps({**result["payload"], "request_snapshot": token}, ensure_ascii=False)
    return result


def prepare_h02_role_review(prepared_path, proposal_path):
    return _prepare_review(prepared_path, proposal_path)


def register_h02_role_review(review_prepared_path, response_path, execution_path):
    return _namespace()["register_role_review"](review_prepared_path, response_path, execution_path)


def verify_h02_stage_context(path):
    return _namespace()["verify_stage_context"](path)


def load_h02_stage_context(path):
    schema = read_json(path).get("schema_version")
    if schema == CONTEXT_SCHEMA:
        return verify_h02_stage_context(path)
    require(schema == roles.STAGE_CONTEXT, "unsupported H02 stage context; no arbitrary verifier or fallback")
    # An H01-only context is readable for explicit eligibility diagnostics;
    # StageSession then keeps every unreviewed H02 condition unknown.
    return roles.verify_stage_context(path)
