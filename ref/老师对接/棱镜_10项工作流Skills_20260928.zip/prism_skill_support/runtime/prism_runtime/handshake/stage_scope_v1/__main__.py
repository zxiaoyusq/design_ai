import argparse
from pathlib import Path
from prism_runtime.contracts import read_json, write_json, require
from .roles import prepare_roles, accept_roles, prepare_role_review, register_role_review, verify_stage_context


def main():
    p = argparse.ArgumentParser(description="Stage-role proposal/review and verified exploration; no model calls.")
    p.add_argument("action", choices=["prepare-roles", "accept-roles", "prepare-review", "register-review", "verify-stage-context"])
    for name in ("config", "prepared", "response", "proposal", "review-prepared", "execution", "stage-context"):
        p.add_argument("--" + name)
    p.add_argument("--output", required=True)
    a = p.parse_args()
    require(not Path(a.output).exists(), "use a new output file")
    if a.action == "prepare-roles": result = prepare_roles(read_json(a.config))
    elif a.action == "accept-roles": result = accept_roles(a.prepared, a.response)
    elif a.action == "prepare-review": result = prepare_role_review(a.prepared, a.proposal)
    elif a.action == "register-review": result = register_role_review(a.review_prepared, a.response, a.execution)
    else:
        value, ref = verify_stage_context(a.stage_context)
        result = {"passed": True, "context_identity": ref, "stage_context_snapshot": value["stage_context_snapshot"], "model_calls": 0}
    write_json(a.output, result)
    print(a.output)


if __name__ == "__main__": main()
