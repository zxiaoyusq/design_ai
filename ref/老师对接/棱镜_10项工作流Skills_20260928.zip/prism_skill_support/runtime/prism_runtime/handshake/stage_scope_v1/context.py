"""Per-session reviewed stage semantics; original profiles/conditions stay intact."""
from copy import deepcopy
from types import FunctionType
import inspect

from prism_runtime.contracts import require
from prism_runtime.preferences import validate_reviewed_profile
from ..common import fingerprint, snapshot, condition_state
from ..context_sidecar_v1 import ContextSession
from ..context_sidecar_v1.view import evaluate_preference_scope as original_scope
from .roles import VERSION, STAGES


def private_namespace(module, **overrides):
    namespace = dict(vars(module))
    for name, fn in vars(module).items():
        if inspect.isfunction(fn) and fn.__module__ == module.__name__:
            clone = FunctionType(fn.__code__, namespace, fn.__name__, fn.__defaults__, fn.__closure__)
            clone.__kwdefaults__ = deepcopy(fn.__kwdefaults__)
            namespace[name] = clone
    namespace.update(overrides)
    return namespace


def condition_records(context, stage, preference_ids=None):
    selected = set(preference_ids or [])
    return [{"condition_id": r["original"]["condition_id"], "preference_id": r["original"]["preference_id"],
        "condition_index": r["original"]["condition_index"], "original_condition": r["original"]["source_condition"],
        "candidate_digest": r["original"]["candidate_digest"], "evidence_refs": deepcopy(r["original"]["evidence_refs"]),
        "quotes": deepcopy(r["original"]["quotes"]), "effective_role": r["effective_role"],
        "active_stages": deepcopy(r["proposal"]["active_stages"]), "processing_stage": stage,
        "independent_review_verdict": r["independent_review"]["verdict"],
        "role_resolution_reason": r["role_resolution_reason"],
        "obligation_status": r["obligation_status"], "due_before": r["proposal"]["due_before"],
        "active_direction_anchor": r["original"]["preference_id"] in selected if selected else None}
        for r in context["classifications"]]


def annotate(value, context, identity, stage, preference_ids=None):
    rows = condition_records(context, stage, preference_ids)
    value.update(stage_scope_version=VERSION, stage_scope_context_identity=deepcopy(identity),
        stage_context_snapshot=context["stage_context_snapshot"], processing_stage=stage,
        stage_condition_audit=rows,
        deferred_design_obligations=[deepcopy(r) for r in rows if r["effective_role"] == "deferred_design_obligation"],
        design_output_status="exploratory_reference_only_not_product_finalization",
        product_design_approved=False, real_material_approved=False, physical_measurement_approved=False)
    return value


def apply_stage_scope(base, preference, values, stage_context, stage_identity, stage):
    require(stage in STAGES, "only the two declared exploration stages are supported")
    rows = [r for r in stage_context["classifications"] if r["original"]["preference_id"] == preference["preference_id"]]
    conditions = preference.get("conditions", [])
    require(len(rows) == len(conditions) and {r["original"]["condition_index"] for r in rows} == set(range(len(conditions))), "stage roles do not cover every original condition")
    for row in rows:
        o = row["original"]
        require(o["source_condition"] == conditions[o["condition_index"]]
            and o["candidate_digest"] == preference["semantic_assessment"]["candidate_digest"]
            and o["evidence_refs"] == preference["evidence_refs"]
            and o["original_attitude"] == preference["attitude"], "stage role source claim changed")
    result = deepcopy(base)
    # Existing source/business predicates and already trusted condition
    # bindings are retained. Raw clauses get separately reviewed stage roles.
    effective = [deepcopy(c) for c in base["evaluated_conditions"] if not isinstance(c, str)]
    audits = []
    for row in sorted(rows, key=lambda r: r["original"]["condition_index"]):
        original, proposal, role = row["original"], row["proposal"], row["effective_role"]
        audit = {"condition_id": original["condition_id"], "original_condition": original["source_condition"],
                 "role": role, "processing_stage": stage, "current_requirement_satisfied": None,
                 "obligation_status": row["obligation_status"], "due_before": proposal["due_before"]}
        if role == "unknown" or stage not in proposal["active_stages"]:
            effective.append({"unresolved_stage_condition": original["condition_id"]})
            audit["evaluation"] = "unknown" if role == "unknown" else "stage_not_independently_reviewed"
        else:
            phase = {"field": "__processing_stage", "operator": "in", "value": proposal["active_stages"]}
            effective.append(phase)
            if role == "current_requirement" and not proposal["predicates"]:
                effective.append({"unresolved_current_requirement": original["condition_id"]})
                audit["evaluation"] = "unknown"
            elif role in {"current_requirement", "stage_scope"}:
                effective.extend(deepcopy(proposal["predicates"]))
                audit["evaluation"] = condition_state([phase, *proposal["predicates"]], {**values, "__processing_stage": stage})
                if role == "current_requirement": audit["current_requirement_satisfied"] = audit["evaluation"] == "applies"
            else:
                require(role == "deferred_design_obligation" and row["obligation_status"] == "unfulfilled", "invalid deferred role")
                audit["evaluation"] = "deferred_not_satisfied" if stage in proposal["active_stages"] else "outside_reviewed_stage"
        audits.append(audit)
    state = condition_state(effective, {**values, "__processing_stage": stage})
    if base["scope_pending_reasons"]: state = "unknown"
    if not base["user_ids"]: state = "not_applicable"
    # This version does not turn any negative into a deferred/nonblocking rule.
    # The complete original negative evaluation remains authoritative.
    if preference["attitude"] == "dislike":
        state, effective = base["context_state"], deepcopy(base["evaluated_conditions"])
    result.update(original_context_state=base["context_state"],
        original_evaluated_conditions=deepcopy(base["evaluated_conditions"]),
        context_state=state, evaluated_conditions=effective, stage_role_evaluation=audits)
    annotate(result, stage_context, stage_identity, stage, [preference["preference_id"]])
    return result


def scoped_evaluator(stage_context, stage_identity, stage):
    def evaluate(view, preference, users, context, *, evidence, review_context):
        base = original_scope(view, preference, users, context, evidence=evidence, review_context=review_context)
        return apply_stage_scope(base, preference, context, stage_context, stage_identity, stage)
    return evaluate


class StageSession(ContextSession):
    def __init__(self, bundle, profile, *, review_context, execution_scope_context=None,
                 stage_context, stage_identity, stage):
        super().__init__(bundle, profile, review_context=review_context, execution_scope_context=execution_scope_context)
        require(stage in stage_context["allowed_stages"], "stage is outside independently reviewed exploration scope")
        trusted = validate_reviewed_profile(bundle, profile, reviewer_registry=review_context["reviewer_registry"])
        require(snapshot(bundle, profile) == stage_context["original_input_snapshot"]
                and fingerprint(trusted) == stage_context["validated_profile_snapshot"], "stage role review belongs to another source/profile")
        require(self._view["execution_scope"]["values"] == stage_context["execution_values"], "stage role execution context changed")
        self.stage_context, self.stage_identity, self.stage = deepcopy(stage_context), deepcopy(stage_identity), stage
        self._view["original_context_sidecar_snapshot"] = self.token
        self._view["stage_scope"] = {"version": VERSION, "context_identity": stage_identity,
            "context_snapshot": stage_context["stage_context_snapshot"], "processing_stage": stage,
            "condition_roles": condition_records(stage_context, stage)}
        self.token = fingerprint(self._view)
        self._view["context_sidecar_snapshot"] = self.token
        evaluate = scoped_evaluator(stage_context, stage_identity, stage)
        self._common["preference_scope"] = lambda p, u, c: evaluate(
            self._view, p, u, c, evidence=self.evidence, review_context=self.review_context)
        for namespace in (self._common, self._themes, self._directions):
            namespace["ALGORITHM_VERSION"] = VERSION
        for namespace in (self._themes, self._directions):
            namespace.update(preference_scope=self._common["preference_scope"], positive_anchors=self._common["positive_anchors"])

    def _annotate(self, value):
        super()._annotate(value)
        return annotate(value, self.stage_context, self.stage_identity, self.stage, value.get("preference_refs"))
