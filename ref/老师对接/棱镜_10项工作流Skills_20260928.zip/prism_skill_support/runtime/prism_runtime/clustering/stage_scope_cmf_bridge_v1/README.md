# Stage-scoped CMF consumer v1

Bounded B-STAGE-CONSUME-001 adapter. It adds a fixed reviewed-stage entrypoint, uses the existing full-scope transport and official projection verifiers, and calls clustering **0.2.0 unchanged**. It makes no model/API call and does not approve a design, material, measurement or future obligation.

## Minimal API

```python
from prism_runtime.clustering.stage_scope_cmf_bridge_v1 import (
    prepare_request_views, run_grouping, reconcile_inventory,
)

# request/context come from official stage_scope_v1.h02.compile_confirmed.
# index is the complete original image_id -> persisted projection mapping.
run = run_grouping(
    request, index,
    inventory_path=config['inventory_path'],
    exploration_context_path=registered_context_path,
)
raw_result = run['engine_result']

# Once all requested directions have actual results:
ledger = reconcile_inventory(config['inventory_path'], index, [run])
```

`prepare_request_views` accepts the same arguments and returns `guarded_image_dna`, `coverage_audits` and `stage_audit` without running the matcher. When calling the original engine directly, retain that complete audit with its result. `run_grouping` is the simpler audited path: it stores the original complete request, unchanged `engine_result`, its fingerprint, wrapper version, complete verified owner receipt, stage conditions and unfulfilled obligations. It does not insert stage fields into the original engine result or change its memberships.

## Fixed contract and full pool

The only verifier route is `prism_runtime.handshake.stage_scope_v1.h02.verify_context(context_path, request=request, inventory_path=inventory_path)`. Schema is `prism.stage_scope_exploratory_reference_context.v1`; owner version is `handshake-stage-scope-v1.0.0`; stage is `H02_reference_exploration`. There is no callback parameter, arbitrary import, old-schema fallback, fixture bypass or host-issued approval.

This bounded entry pins the B inventory SHA256 `78404f9eeb7bf5fa8f97ba0de90aa3e903b4ec89dcbad67ea0cfe079e11d073b` and brief `case-b-india-broad-design-hypotheses-20260927`. Every actual request must retain all **39** approved original trend images and **495** explicit carriers. Examples cannot replace that pool. Original T01 roles and source identity remain separate from the exploratory-library role; global source images are not relabelled as Indian-origin evidence.

The leaf replays actual H01, Root selection, independent phase reviews, H02 proposal and confirmation. This adapter additionally checks context bytes and complete request identity, exact request/receipt stage fields, stage-context bytes, original inventory roles and full-pool enumeration. Existing `exploratory_cmf_bridge_v1._prepare` then revalidates each official projection and preserves all source observations, full objects and unknown/background guards. No required-feature prefilter, carrier splicing, new visual fact or distance function is introduced.

## Stage audit is not product approval

`stage_condition_audit` is retained in full. Unselected religion conditions may remain `unknown`, with empty active stages and `active_direction_anchor=false`; this consumer does not demand that all seven conditions apply or reinterpret the owner's scope decision. `deferred_design_obligations` must be the exact deferred subset of the audit and remain `unfulfilled`.

`product_design_approved`, `real_material_approved` and `physical_measurement_approved` remain false. `physical_scale_status=unknown` and `scale_mode=reference_region_only` remain unchanged even when the matcher produces a group. Known conflicts, unresolved negatives, boundaries and CT002 retain their original effects.

## Complete 120-image accounting

`reconcile_inventory` takes `run_grouping` envelopes. To record a qualified but not-yet-executed request, supply `{request, exploration_context_path, engine_result: None}` instead. A missing actual result remains null/pending; it is not reported as a zero-group match.

The function uses the existing official v1/v1.1/v1.2 projection accounting for all original 120 images, freshly validates each supplied stage context and checks saved results against a deterministic replay of the unchanged matcher. It does not rerun image inference. Every image retains one primary disposition, while each request's memberships, exclusions, boundaries and carrier diagnostics remain separate. An explicit exclusion is not overwritten merely because a different image in that request is pending.

Full stage audits and original requests/results are stored under `stage_runs`; row-level `stage_request_outcomes` keep audit pointers, unfulfilled obligations and false approval flags. Unselected images and calibration records retain their source roles and original accounting. The ledger creates no new H02 authorization, reference qualification or fulfilled obligation, and does not replace case A's separate result.

## Verification scope

`tests.py` uses an unchanged local copy of the owner's clearly marked `synthetic-transport-fixture.json`, explicit mocks for source/admission where needed, and the unchanged engine. It requires no real image files or projections. It checks stage-field preservation, no escalation, full-pool boundaries, complete 120-row bookkeeping, negative-scope behavior and rejection of tampering. Both the real owner leaf and the public bridge reject that unissued fixture. A synthetic two-image group demonstrates protocol transport only; it is not an actual case-B grouping result.

Root must still run its independently accepted actual H02 contexts over the whole pool and audit member evidence. No actual business success, visual accuracy or product approval is established by this module's unit-test count.
