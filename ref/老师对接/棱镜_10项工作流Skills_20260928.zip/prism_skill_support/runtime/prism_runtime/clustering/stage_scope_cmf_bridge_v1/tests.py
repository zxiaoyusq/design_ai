"""Synthetic protocol fixtures only; never a case-B outcome or issued context."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from . import bridge, ledger

FIXTURE = Path(__file__).with_name("synthetic-transport-fixture.json")


def fixture():
    data = json.loads(FIXTURE.read_text(encoding="utf-8-sig"))
    assert data["fixture_only"] is True and data["actual_case_B_answer"] is False
    request = deepcopy(data["request"])
    receipt = {"fixture_only": True, "passed": True, "model_calls": 0,
        "algorithm_version": bridge.OWNER_VERSION, "context_schema_version": bridge.CONTEXT_SCHEMA,
        "context_identity": {"path": "synthetic:unissued", "sha256": "0" * 64},
        "authority_kind": "user_delegated_ai", "human_designer_actually_reviewed": False,
        **{k: deepcopy(request[k]) for k in bridge.STAGE_FIELDS}}
    return data, request, receipt


def prepared_fixture(request, receipt, images):
    return {"guarded_image_dna": deepcopy(images), "coverage_audits": [
        {"image_id": d["image_id"], "reference_qualification": {"fixture_only": True, "image_id": d["image_id"],
         "role": "user_delegated_ai_selected_exploratory_reference"}} for d in images],
        "stage_audit": bridge._stage_audit(request, receipt)}


def accounting_fixture(images):
    ids = [d["image_id"] for d in images] + ["synthetic:unprovided-" + str(i) for i in range(118)]
    rows = []
    for i, iid in enumerate(ids):
        rows.append({"image_id": iid, "source_kind": "trend" if i < 60 else "calibration",
            "cmf_status": "verified_useful_local" if i < 2 else "projection_not_provided",
            "primary_disposition": "parsed_not_reference_pool" if i < 2 else "local_pending",
            "group_memberships": [], "singletons": [], "boundaries": [], "exclusions": [],
            "request_outcomes": [], "exploratory_library_memberships": [], "h02_authorization_granted_by_ledger": False})
    return {"records": rows, "summary": {"total_images": 120, "all_images_accounted_for": True,
        "reference_eligible_images": 9, "verified_projection_count": 2, "source_counts": {"trend": 60, "calibration": 60},
        "new_model_calls": 0, "new_API_calls": 0, "real_effectiveness_established": False}}


class StageProtocolTests(unittest.TestCase):
    def setUp(self):
        self.data, self.request, self.receipt = fixture()

    def test_production_leaf_and_public_bridge_reject_the_unissued_fixture(self):
        from prism_runtime.handshake.stage_scope_v1.h02 import verify_context
        with self.assertRaisesRegex(ValueError, "unsupported supplemental context"):
            verify_context(FIXTURE, request=self.request, inventory_path="synthetic:inventory")
        with patch.object(bridge, "_verify_owner") as owner:
            with self.assertRaisesRegex(ValueError, "Unregistered stage context"):
                bridge.prepare_request_views(self.request, {}, inventory_path="synthetic:inventory", exploration_context_path=FIXTURE)
            owner.assert_not_called()

    def test_original_two_image_group_and_obligations_are_preserved(self):
        before = deepcopy(self.request)
        prepared = prepared_fixture(self.request, self.receipt, self.data["image_dna"])
        with patch.object(bridge, "prepare_request_views", return_value=prepared):
            result = bridge.run_grouping(self.request, {}, inventory_path="synthetic", exploration_context_path="synthetic:unissued")
        self.assertEqual(result["engine_result"], self.data["expected_engine_result"])
        self.assertEqual(result["engine_result"]["summary"]["clustered_images"], 2)
        self.assertEqual(result["stage_audit"]["deferred_design_obligations"], before["deferred_design_obligations"])
        self.assertEqual(result["request"], before)
        self.assertEqual(self.request, before)
        self.assertFalse(result["stage_audit"]["product_design_approved"])
        self.assertFalse(result["real_effectiveness_established"])

    def test_unselected_unknown_religion_condition_is_retained_without_new_scope_judgment(self):
        unused = {"condition_id": "synthetic:unselected-religion", "original_condition": "传统仍需选定",
                  "effective_role": "unknown", "active_stages": [], "active_direction_anchor": False}
        self.request["stage_condition_audit"].append(unused)
        self.receipt["stage_condition_audit"] = deepcopy(self.request["stage_condition_audit"])
        audit = bridge._stage_audit(self.request, self.receipt)
        self.assertEqual(audit["stage_condition_audit"][-1], unused)
        prepared = prepared_fixture(self.request, self.receipt, self.data["image_dna"])
        result = bridge._run_prepared(self.request, prepared, "synthetic:unissued")
        self.assertEqual(result["engine_result"]["summary"]["clustered_images"], 2)

    def test_changed_or_missing_stage_metadata_rejected(self):
        for field in ("stage_context_snapshot", "stage_scope_context_identity", "stage_condition_audit", "deferred_design_obligations"):
            request = deepcopy(self.request)
            request.pop(field)
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, "lost or changed"):
                bridge._stage_audit(request, self.receipt)

    def test_approvals_physical_scale_and_H01_stage_cannot_be_promoted(self):
        for field, value in (("product_design_approved", True), ("real_material_approved", True),
                             ("physical_measurement_approved", True), ("physical_scale_status", "known"),
                             ("scale_mode", "measured"), ("processing_stage", "H01_theme_exploration")):
            request, receipt = deepcopy(self.request), deepcopy(self.receipt)
            request[field] = receipt[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError): bridge._stage_audit(request, receipt)

    def test_fulfilled_or_deleted_obligations_rejected_even_in_matching_copies(self):
        for mutation in ("fulfilled", "deleted"):
            request, receipt = deepcopy(self.request), deepcopy(self.receipt)
            if mutation == "fulfilled":
                request["deferred_design_obligations"][0]["obligation_status"] = "fulfilled"
                request["stage_condition_audit"][0]["obligation_status"] = "fulfilled"
            else:
                request["deferred_design_obligations"] = []
            for field in ("deferred_design_obligations", "stage_condition_audit"):
                receipt[field] = deepcopy(request[field])
            with self.subTest(mutation=mutation), self.assertRaises(ValueError): bridge._stage_audit(request, receipt)

    def test_whole_image_unknown_negative_remains_boundary(self):
        request = deepcopy(self.request)
        request["forbidden_features"][0]["scope"] = {"kind": "image", "status": "resolved",
            "image_ids": request["candidate_image_ids"], "evidence_refs": ["synthetic:scope"]}
        images = deepcopy(self.data["image_dna"])
        for doc in images:
            next(o for o in doc["observations"] if o["observation_id"] == "finish-background").update(value_status="unknown", value=None)
        prepared = prepared_fixture(request, self.receipt, images)
        result = bridge._run_prepared(request, prepared, "synthetic:unissued")
        self.assertFalse(result["engine_result"]["clusters"])
        self.assertEqual(len({x["image_id"] for x in result["engine_result"]["boundary_members"]}), 2)
        self.assertEqual(result["engine_result"]["scoped_negative_preferences"], request["scoped_negative_preferences"])
        self.assertTrue(result["stage_audit"]["deferred_design_obligations"])

    def test_full_library_guard_rejects_two_example_pool_with_mocked_owner_receipt(self):
        with tempfile.TemporaryDirectory() as temporary:
            context = Path(temporary) / "explicitly-mocked-context.json"
            context.write_text(json.dumps({"schema_version": bridge.CONTEXT_SCHEMA, "algorithm_version": bridge.OWNER_VERSION}), encoding="utf-8")
            request = deepcopy(self.request)
            request.update(brief_id=bridge.B_BRIEF_ID, exploration_context_id="synthetic:mocked-id")
            receipt = deepcopy(self.receipt)
            context_identity = bridge._identity(context)
            receipt.update(context_identity=context_identity, context_id=request["exploration_context_id"],
                request_snapshot=bridge.fingerprint(request), candidate_pool_kind="approved_closed_exploration_library",
                carrier_rule={"kind": "synthetic:rule"}, selected_references=[{"image_id": i, "bindings": []} for i in request["candidate_image_ids"]])
            real_identity = bridge._identity
            def identity(path):
                if str(path) == "synthetic:inventory": return {"path": str(path), "sha256": bridge.B_INVENTORY_SHA256}
                if str(path) == request["stage_scope_context_identity"]["path"]: return request["stage_scope_context_identity"]
                return real_identity(path)
            with patch.object(bridge, "_identity", side_effect=identity), patch.object(bridge, "_verify_owner", return_value=receipt), \
                 patch.object(bridge.frozen.legacy, "_inventory_data", return_value=({"records": []}, {}, {"eligible_image_ids": []})):
                with self.assertRaisesRegex(ValueError, "39-image"):
                    bridge._checked_context(request, context, "synthetic:inventory")
                request["candidate_image_ids"] = ["synthetic:pool-" + str(i) for i in range(39)]
                request["candidate_bindings"] = []
                receipt["selected_references"] = [{"image_id": iid, "bindings": []} for iid in request["candidate_image_ids"]]
                receipt["request_snapshot"] = bridge.fingerprint(request)
                with self.assertRaisesRegex(ValueError, "495-carrier"):
                    bridge._checked_context(request, context, "synthetic:inventory")

    def test_A_brief_and_wrong_inventory_do_not_reach_the_new_verifier(self):
        with tempfile.TemporaryDirectory() as temporary:
            context = Path(temporary) / "mocked-context.json"
            context.write_text(json.dumps({"schema_version": bridge.CONTEXT_SCHEMA, "algorithm_version": bridge.OWNER_VERSION}), encoding="utf-8")
            real_identity = bridge._identity
            def identity(path):
                return {"path": str(path), "sha256": bridge.B_INVENTORY_SHA256} if str(path) == "synthetic:inventory" else real_identity(path)
            with patch.object(bridge, "_identity", side_effect=identity), patch.object(bridge, "_verify_owner") as owner:
                with self.assertRaisesRegex(ValueError, "impersonate"):
                    bridge._checked_context(self.request, context, "synthetic:inventory")
                with self.assertRaisesRegex(ValueError, "fixed B inventory"):
                    bridge._checked_context(self.request, context, context)
                owner.assert_not_called()


class AccountingTests(unittest.TestCase):
    def setUp(self):
        self.data, self.request, self.receipt = fixture()
        self.prepared = prepared_fixture(self.request, self.receipt, self.data["image_dna"])
        self.run = bridge._run_prepared(self.request, self.prepared, "synthetic:unissued")

    def account(self, runs):
        with patch.object(ledger.base, "reconcile_inventory", return_value=accounting_fixture(self.data["image_dna"])), \
             patch.object(ledger, "prepare_request_views", return_value=self.prepared):
            return ledger.reconcile_inventory("synthetic:inventory", {}, runs)

    def test_complete_120_grouped_rows_retain_unfulfilled_obligations(self):
        report = self.account([self.run])
        self.assertEqual(len(report["records"]), 120)
        self.assertEqual(sum(report["summary"]["primary_disposition_counts"].values()), 120)
        self.assertEqual(report["summary"]["primary_disposition_counts"]["grouped"], 2)
        self.assertEqual(report["summary"]["reference_eligible_images"], 9)
        for row in report["records"][:2]:
            self.assertEqual(row["stage_request_outcomes"][0]["deferred_design_obligations"], self.request["deferred_design_obligations"])
            self.assertFalse(row["h02_authorization_granted_by_ledger"])
        self.assertFalse(report["records"][-1]["stage_request_outcomes"])
        self.assertFalse(report["physical_measurement_approved"])

    def test_pending_request_stays_pending_without_claiming_zero_matching_groups(self):
        report = self.account([{"request": self.request, "exploration_context_path": "synthetic:unissued", "engine_result": None}])
        self.assertFalse(report["stage_runs"][0]["clustering_executed"])
        self.assertIsNone(report["stage_runs"][0]["engine_result"])
        self.assertEqual(report["summary"]["primary_disposition_counts"], {"local_pending": 120})
        self.assertTrue(report["stage_runs"][0]["stage_audit"]["deferred_design_obligations"])

    def test_dropped_obligation_or_negative_audit_and_forged_member_rejected(self):
        for mutation in ("obligation", "negative", "member"):
            run = deepcopy(self.run)
            if mutation == "obligation": run["stage_audit"]["deferred_design_obligations"] = []
            elif mutation == "negative": run["engine_result"]["scoped_negative_preferences"] = []
            else: run["engine_result"]["clusters"][0]["members"][0]["image_id"] = "synthetic:unapproved"
            run["engine_result_snapshot"] = bridge.fingerprint(run["engine_result"])
            with self.subTest(mutation=mutation), self.assertRaises(ValueError): self.account([run])

    def test_known_exclusion_is_not_overwritten_by_another_images_pending_state(self):
        self.request["forbidden_features"][0]["scope"] = {"kind": "image", "status": "resolved",
            "image_ids": self.request["candidate_image_ids"], "evidence_refs": ["synthetic:scope"]}
        images = deepcopy(self.data["image_dna"])
        next(o for o in images[1]["observations"] if o["observation_id"] == "finish-background").update(value_status="unknown", value=None)
        self.prepared = prepared_fixture(self.request, self.receipt, images)
        run = bridge._run_prepared(self.request, self.prepared, "synthetic:unissued")
        report = self.account([run])
        self.assertEqual(report["records"][0]["primary_disposition"], "excluded")
        self.assertEqual(report["records"][1]["primary_disposition"], "local_pending")
        self.assertEqual(sum(report["summary"]["primary_disposition_counts"].values()), 120)

    def test_duplicate_requests_rejected_before_inventory_replay(self):
        with patch.object(ledger.base, "reconcile_inventory") as accounting:
            with self.assertRaisesRegex(ValueError, "Duplicate request"):
                ledger.reconcile_inventory("synthetic", {}, [self.run, self.run])
            accounting.assert_not_called()


if __name__ == "__main__":
    unittest.main()
