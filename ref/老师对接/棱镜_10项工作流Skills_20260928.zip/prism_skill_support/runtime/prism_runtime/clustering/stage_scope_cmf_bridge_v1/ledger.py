"""Full original-120 accounting; stage obligations never disappear into groups."""
from collections import Counter
from copy import deepcopy

from ..exploratory_cmf_bridge_v1 import ledger as base
from .bridge import VERSION, RUN_SCHEMA, _require, fingerprint, engine, prepare_request_views


def _verify_run(run, prepared):
    request, result = run["request"], run.get("engine_result")
    if result is None:
        return
    _require(run.get("schema_version") == RUN_SCHEMA and run.get("wrapper_version") == VERSION,
             "A completed run must retain the stage wrapper identity")
    _require(run.get("request_snapshot") == fingerprint(request) and run.get("engine_result_snapshot") == fingerprint(result),
             "Completed run request/result identity changed")
    _require(fingerprint(run.get("stage_audit")) == fingerprint(prepared["stage_audit"]), "Completed run lost stage audit or obligations")
    # Replay only the deterministic existing matcher, not image extraction or
    # any model. This rejects forged memberships and dropped CT002 constraints.
    _require(fingerprint(result) == fingerprint(engine.cluster_candidates(request, prepared["guarded_image_dna"])),
             "Saved result differs from the unchanged matcher")


def _image_disposition(result, image_id):
    if result is None:
        return "local_pending"
    groups = [c for c in result["clusters"] if any(m["image_id"] == image_id for m in c["members"])]
    if any(len({m["image_id"] for m in c["members"]}) > 1 for c in groups):
        return "grouped"
    if groups:
        return "singleton"
    if any(b["image_id"] == image_id for b in result["boundary_members"]):
        return "local_pending"
    if any(e["image_id"] == image_id and e.get("reason") != "outside_candidate_bindings" for e in result["excluded"]):
        return "excluded"
    return "local_pending" if result["status"] in ("needs_input", "partial") else "ungrouped"


def reconcile_inventory(inventory_path, projection_index, grouping_runs=()):
    """Accept run_grouping envelopes, or request/context plus engine_result=None.

    Revalidates original projection accounting and each supplied stage context.
    It never creates authorization, selects examples or calls an inference API.
    """
    runs = list(grouping_runs)
    ids = [r["request"]["request_id"] for r in runs]
    _require(len(ids) == len(set(ids)), "Duplicate request outcome")
    report = base.reconcile_inventory(inventory_path, projection_index, [])
    rows = {r["image_id"]: r for r in report["records"]}
    _require(len(rows) == len(report["records"]) == 120, "Complete unique original 120 inventory required")
    report["stage_runs"] = []
    for row in rows.values():
        row["stage_request_outcomes"] = []
    for run in runs:
        request, result = run["request"], run.get("engine_result")
        rid = request["request_id"]
        prepared = prepare_request_views(request, projection_index, inventory_path=inventory_path,
                                         exploration_context_path=run["exploration_context_path"])
        _verify_run(run, prepared)
        position = len(report["stage_runs"])
        stage_ref = "/stage_runs/" + str(position) + "/stage_audit"
        report["stage_runs"].append({"request": deepcopy(request), "request_id": rid,
            "request_snapshot": fingerprint(request), "engine_result": deepcopy(result),
            "stage_audit": deepcopy(prepared["stage_audit"]), "clustering_executed": result is not None})
        for audit in prepared["coverage_audits"]:
            iid = audit["image_id"]
            _require(iid in rows and rows[iid]["cmf_status"] == "verified_useful_local", "Stage member lacks original verified useful CMF")
            rows[iid]["exploratory_library_memberships"].append({"request_id": rid, **deepcopy(audit["reference_qualification"])})
            outcome = {"request_id": rid, "status": result["status"] if result is not None else "not_executed",
                       "image_disposition": _image_disposition(result, iid),
                       "stage_audit_ref": stage_ref,
                       "deferred_design_obligations": deepcopy(prepared["stage_audit"]["deferred_design_obligations"]),
                       "product_design_approved": False, "real_material_approved": False, "physical_measurement_approved": False}
            rows[iid]["request_outcomes"].append({"request_id": rid, "status": outcome["status"]})
            rows[iid]["stage_request_outcomes"].append(outcome)
        if result is None:
            continue
        for cluster in result["clusters"]:
            target = "group_memberships" if len({m["image_id"] for m in cluster["members"]}) > 1 else "singletons"
            for member in cluster["members"]:
                rows[member["image_id"]][target].append({"request_id": rid, "cluster_id": cluster["cluster_id"],
                                                        "stage_audit_ref": stage_ref, **deepcopy(member)})
        for source, target in (("excluded", "exclusions"), ("boundary_members", "boundaries")):
            for record in result[source]:
                rows[record["image_id"]][target].append({"request_id": rid, "stage_audit_ref": stage_ref, **deepcopy(record)})
        for record in result.get("carrier_diagnostics", []):
            rows[record["image_id"]].setdefault("carrier_diagnostics", []).append({"request_id": rid, **deepcopy(record)})
    for row in rows.values():
        if not row["stage_request_outcomes"]:
            continue
        if row["group_memberships"]:
            status, reason = "grouped", "member_of_multi_image_candidate_group"
        elif row["singletons"]:
            status, reason = "singleton", "single_image_candidate_not_forced_into_larger_group"
        elif row["boundaries"] or any(o["image_disposition"] == "local_pending" for o in row["stage_request_outcomes"]):
            status, reason = "local_pending", "unresolved_local_or_request_scope"
        elif any(e.get("reason") != "outside_candidate_bindings" for e in row["exclusions"]):
            status, reason = "excluded", "explicit_exclusion_in_supplied_request_scope"
        else:
            status, reason = "ungrouped", "approved_library_member_without_candidate_group"
        row.update(primary_disposition=status, reason_codes=[reason], has_boundary_carriers=bool(row["boundaries"]))
    counts = dict(Counter(r["primary_disposition"] for r in rows.values()))
    _require(sum(counts.values()) == 120, "An original image was lost or counted twice")
    report.update(schema_version="prism.stage_scope_clustering_ledger.v1", wrapper_version=VERSION,
                  evaluation_scope="original_120_accounting_and_official_stage_context_runs",
                  product_design_approved=False, real_material_approved=False, physical_measurement_approved=False,
                  physical_scale_status="unknown", scale_mode="reference_region_only")
    report["summary"].update(primary_disposition_counts=counts, request_count=len(runs),
        stage_context_request_count=len(runs), exploratory_context_request_count=len(runs),
        approved_exploration_library_images=sum(bool(r["stage_request_outcomes"]) for r in rows.values()),
        deterministic_engine_results_replayed=sum(r.get("engine_result") is not None for r in runs),
        deferred_obligations_fulfilled_by_grouping=False)
    return report
