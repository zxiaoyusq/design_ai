"""No selectable callbacks, old-context fallback, feature edits or new matcher."""
from copy import deepcopy
import json
from pathlib import Path

from prism_runtime.handshake.common import fingerprint
from .. import engine
from ..exploratory_cmf_bridge_v1 import bridge as frozen

VERSION = "stage-scope-cmf-bridge-v1.0.0"
CONTEXT_SCHEMA = "prism.stage_scope_exploratory_reference_context.v1"
OWNER_VERSION = "handshake-stage-scope-v1.0.0"
PHASE = "H02_reference_exploration"
RUN_SCHEMA = "prism.stage_scope_clustering_run.v1"
B_INVENTORY_SHA256 = "78404f9eeb7bf5fa8f97ba0de90aa3e903b4ec89dcbad67ea0cfe079e11d073b"
B_BRIEF_ID = "case-b-india-broad-design-hypotheses-20260927"
POOL_IMAGES, POOL_CARRIERS = 39, 495
STAGE_FIELDS = ("processing_stage", "stage_scope_context_identity", "stage_context_snapshot",
    "stage_condition_audit", "deferred_design_obligations", "product_design_approved",
    "real_material_approved", "physical_measurement_approved", "physical_scale_status", "scale_mode")
_require = frozen._require
_identity = frozen.legacy._identity


def _verify_owner(context_path, request, inventory_path):
    from prism_runtime.handshake.stage_scope_v1.h02 import verify_context
    return verify_context(context_path, request=request, inventory_path=inventory_path)


def _stage_audit(request, receipt):
    """Pure metadata preservation. This is not an independent admission API."""
    _require(receipt.get("algorithm_version") == OWNER_VERSION
             and receipt.get("context_schema_version") == CONTEXT_SCHEMA, "Stage receipt schema/version mismatch")
    for field in STAGE_FIELDS:
        _require(field in request and field in receipt and fingerprint(request[field]) == fingerprint(receipt[field]),
                 "Stage request/receipt metadata lost or changed: " + field)
    _require(request["processing_stage"] == PHASE and request.get("stage_scope_version") == OWNER_VERSION,
             "Only the reviewed H02 exploration stage is consumable")
    _require(isinstance(request["stage_context_snapshot"], str) and request["stage_context_snapshot"], "Missing stage snapshot")
    _require(all(request[k] is False for k in ("product_design_approved", "real_material_approved", "physical_measurement_approved")),
             "Reference exploration cannot confer product/material/measurement approval")
    _require(request["physical_scale_status"] == "unknown" and request["scale_mode"] == "reference_region_only",
             "Physical scale must remain unknown")
    conditions, obligations = request["stage_condition_audit"], request["deferred_design_obligations"]
    _require(isinstance(conditions, list) and isinstance(obligations, list), "Complete stage condition/obligation lists required")
    deferred = [r for r in conditions if r.get("effective_role") == "deferred_design_obligation"]
    _require(fingerprint(deferred) == fingerprint(obligations), "Deferred obligations were omitted from the condition audit")
    _require(all(o.get("obligation_status") == "unfulfilled" for o in obligations), "An obligation was falsely fulfilled")
    return {"schema_version": "prism.stage_scope_clustering_audit.v1", "wrapper_version": VERSION,
        "context_identity": deepcopy(receipt["context_identity"]), "request_snapshot": fingerprint(request),
        "verified_owner_receipt": deepcopy(receipt),
        **{k: deepcopy(request[k]) for k in STAGE_FIELDS},
        "design_output_status": request.get("design_output_status"),
        "authority_kind": receipt["authority_kind"], "human_designer_actually_reviewed": False,
        "approval_created_by_consumer": False}


def _checked_context(request, context_path, inventory_path):
    _require(context_path is not None and inventory_path is not None, "Explicit stage context and B inventory required")
    before = _identity(context_path)
    header = json.loads(Path(context_path).read_text(encoding="utf-8-sig"))
    _require(header.get("schema_version") == CONTEXT_SCHEMA and header.get("algorithm_version") == OWNER_VERSION,
             "Unregistered stage context; no old-context fallback")
    _require(_identity(inventory_path)["sha256"] == B_INVENTORY_SHA256, "This bounded bridge requires the fixed B inventory")
    _require(request.get("brief_id") == B_BRIEF_ID, "Case A or another brief cannot impersonate case B")
    _require(request.get("alignment_mode") == "exploration" and request.get("alignment_label") == engine.MODES["exploration"][0]
             and request.get("relation_basis") == "exploratory_hypothesis" and request.get("design_axis") == "CMF",
             "Stage-local features remain CMF exploration hypotheses")
    receipt = _verify_owner(context_path, request, inventory_path)
    _require(receipt.get("passed") is True and receipt.get("model_calls") == 0, "Official zero-inference stage replay failed")
    _require(before == receipt.get("context_identity") == _identity(context_path), "Context identity changed")
    _require(receipt.get("request_snapshot") == fingerprint(request) and receipt.get("context_id")
             and receipt["context_id"] == request.get("exploration_context_id"), "Entire request/context binding changed")
    _require(receipt.get("authority_kind") == "user_delegated_ai" and receipt.get("human_designer_actually_reviewed") is False,
             "Root's delegated decision must not be presented as a human review")
    _require(receipt.get("candidate_pool_kind") == "approved_closed_exploration_library"
             and isinstance(receipt.get("carrier_rule"), dict) and receipt["carrier_rule"], "Explicit library and carrier rule required")
    audit = _stage_audit(request, receipt)
    stage_ref = receipt["stage_scope_context_identity"]
    _require(_identity(stage_ref["path"]) == stage_ref, "Reviewed stage-context file changed")
    inventory, originals, pool = frozen.legacy._inventory_data(inventory_path)
    original_roles = {r["image_id"]: r.get("reference_theme_ids", []) for r in inventory["records"]}
    refs = receipt.get("selected_references", [])
    selected = {r["image_id"]: r for r in refs}
    ids = request.get("candidate_image_ids", [])
    _require(len(refs) == len(selected) == len(ids) == POOL_IMAGES and set(selected) == set(ids),
             "The full approved 39-image library must reach the engine")
    declared = [(r["image_id"], b["object_id"]) for r in refs for b in r.get("bindings", [])]
    requested = [(b["image_id"], b["object_id"]) for b in request.get("candidate_bindings", [])]
    _require(len(declared) == len(set(declared)) == len(requested) == len(set(requested)) == POOL_CARRIERS
             and set(declared) == set(requested), "The full approved 495-carrier enumeration changed")
    for iid, entry in selected.items():
        _require(iid in originals and originals[iid]["source_kind"] == "trend" and entry.get("role") == frozen.EXPLORATORY_ROLE,
                 "Only original trend sources with the explicit exploration role are consumable")
        role = entry.get("original_T01_reference_role", {})
        _require(isinstance(role, dict) and role.get("globally_registered") is (iid in pool["eligible_image_ids"])
                 and sorted(role.get("theme_ids", [])) == sorted(original_roles[iid]), "Original T01 roles changed")
    return {"receipt": receipt, "selected": selected, "originals": originals, "pool": pool, "stage_audit": audit}


def prepare_request_views(request, projection_index, *, inventory_path, exploration_context_path):
    """Replay one stage context, then preserve every approved image and its full scope."""
    checked = _checked_context(request, exploration_context_path, inventory_path)
    ids = request["candidate_image_ids"]
    _require(isinstance(projection_index, dict) and set(ids) <= set(projection_index), "An approved projection is missing")
    views = [frozen._prepare(request, projection_index[iid], checked) for iid in ids]
    _require([v["image_dna"]["image_id"] for v in views] == ids, "Projection index image identity changed")
    _require(_identity(exploration_context_path) == checked["receipt"]["context_identity"], "Stage context changed during preparation")
    return {"wrapper_version": VERSION, "request_id": request["request_id"],
        "guarded_image_dna": [v["image_dna"] for v in views], "coverage_audits": [v["audit"] for v in views],
        "stage_audit": deepcopy(checked["stage_audit"]), "clustering_executed": False,
        "new_model_calls": 0, "new_API_calls": 0}


def _run_prepared(request, prepared, context_path):
    """Private deterministic wrapper, not an authority/transport bypass entrypoint."""
    raw_result = engine.cluster_candidates(request, prepared["guarded_image_dna"])
    return {"schema_version": RUN_SCHEMA, "wrapper_version": VERSION,
        "request": deepcopy(request), "request_snapshot": fingerprint(request),
        "exploration_context_path": str(Path(context_path).resolve()),
        "engine_result": raw_result, "engine_result_snapshot": fingerprint(raw_result),
        "stage_audit": deepcopy(prepared["stage_audit"]), "coverage_audits": deepcopy(prepared["coverage_audits"]),
        "clustering_executed": True, "engine_version": engine.VERSION,
        "new_model_calls": 0, "new_API_calls": 0, "real_effectiveness_established": False}


def run_grouping(request, projection_index, *, inventory_path, exploration_context_path):
    """Use the unchanged matcher and attach complete verified stage/obligation audit."""
    prepared = prepare_request_views(request, projection_index, inventory_path=inventory_path,
                                      exploration_context_path=exploration_context_path)
    return _run_prepared(request, prepared, exploration_context_path)
