from copy import deepcopy
import unittest

from prism_runtime.clustering import cluster_candidates
from prism_runtime.clustering.scope_examples import scope_example


def members(result):
    return [(m["image_id"], m["object_id"]) for c in result["clusters"] for m in c["members"]]


class NegativeScopeTests(unittest.TestCase):
    def assert_pending(self, spec, images):
        result = cluster_candidates(spec, images)
        self.assertFalse(members(result))
        self.assertIn(result["status"], ("partial", "needs_input"))
        self.assertTrue(result.get("boundary_members") or result.get("input_errors"))
        return result

    def test_carrier_scope_allows_matte_shell_with_mirror_background(self):
        spec, images = scope_example()
        result = cluster_candidates(spec, images)
        self.assertEqual(result["status"], "complete")
        self.assertEqual(members(result), [("synthetic:phone-scene", "body")])
        check = result["clusters"][0]["members"][0]["negative_constraint_checks"][0]
        self.assertEqual(check["observation_ids"], ["finish"])
        self.assertNotIn("finish", spec["candidate_bindings"][0]["observation_ids"])
        self.assertEqual(result["scoped_negative_preferences"], spec["scoped_negative_preferences"])
        self.assertIn("synthetic:explicit-negative", result["clusters"][0]["evidence_refs"])

    def test_carrier_scope_rejects_mirror_shell_with_matte_background(self):
        spec, images = scope_example(body_finish="mirror", background_finish="matte")
        result = cluster_candidates(spec, images)
        self.assertFalse(members(result))
        self.assertEqual(result["excluded"][0]["reason"], "no_carrier_satisfies_constraints")
        self.assertTrue(any(r["code"] == "known_forbidden_feature" for c in result["carrier_diagnostics"] for r in c["reasons"]))

    def test_image_scope_also_rejects_mirror_background(self):
        spec, images = scope_example("image")
        result = cluster_candidates(spec, images)
        self.assertFalse(members(result))
        self.assertEqual(result["excluded"][0]["reason"], "known_forbidden_feature")
        self.assertEqual(result["excluded"][0]["reasons"][0]["object_id"], "background")

    def test_image_scope_clear_case_checks_all_declared_carriers(self):
        spec, images = scope_example("image", background_finish="matte")
        result = cluster_candidates(spec, images)
        self.assertEqual(result["status"], "complete")
        checks = result["clusters"][0]["members"][0]["negative_constraint_checks"]
        self.assertEqual({c["object_id"] for c in checks}, {"body", "background"})

    def test_three_modes_keep_the_identical_negative_scope(self):
        for mode in ("consensus", "extension", "exploration"):
            for kind, shell, background, allowed in (
                    ("candidate_bindings", "matte", "mirror", True),
                    ("candidate_bindings", "mirror", "matte", False), ("image", "matte", "mirror", False)):
                with self.subTest(mode=mode, kind=kind, shell=shell):
                    spec, images = scope_example(kind, body_finish=shell, background_finish=background, mode=mode)
                    result = cluster_candidates(spec, images)
                    self.assertEqual(bool(members(result)), allowed)
                    self.assertEqual(result["alignment_mode"], mode)
                    self.assertEqual(result["relation_basis"], spec["relation_basis"])

    def test_unknown_or_missing_target_attribute_is_not_certified_clear(self):
        for operation in ("unknown", "missing"):
            with self.subTest(operation=operation):
                spec, images = scope_example()
                if operation == "unknown":
                    images[0]["observations"][2].update(value=None, value_status="unknown")
                else:
                    images[0]["observations"].pop(2)
                self.assert_pending(spec, images)

    def test_unknown_background_only_blocks_image_scope(self):
        for kind in ("candidate_bindings", "image"):
            spec, images = scope_example(kind, background_finish="matte")
            images[0]["observations"][6].update(value=None, value_status="unknown")
            result = cluster_candidates(spec, images)
            self.assertEqual(bool(members(result)), kind == "candidate_bindings")

    def test_missing_background_attribute_blocks_image_scope(self):
        spec, images = scope_example("image", background_finish="matte")
        images[0]["observations"].pop(6)
        self.assert_pending(spec, images)

    def test_scope_missing_unknown_pending_or_unmapped_is_pending(self):
        for replacement in (None, {}, {"kind": "unknown", "status": "resolved"},
                            {"kind": "candidate_bindings", "status": "pending"}):
            with self.subTest(scope=replacement):
                spec, images = scope_example(body_finish="mirror")
                spec["forbidden_features"][0]["scope"] = replacement
                result = self.assert_pending(spec, images)
                self.assertFalse(result["excluded"])  # Ambiguous scope is not confident rejection either.

    def test_scope_requires_its_own_evidence(self):
        spec, images = scope_example()
        spec["forbidden_features"][0]["scope"]["evidence_refs"] = []
        self.assert_pending(spec, images)

    def test_unrecognized_scope_selectors_are_not_silently_ignored(self):
        for kind in ("image", "candidate_bindings"):
            spec, images = scope_example(kind, background_finish="matte")
            scope = spec["forbidden_features"][0]["scope"]
            if kind == "image":
                scope["except_object_ids"] = ["background"]
            else:
                scope["bindings"][0]["observation_ids"] = ["contour"]
            self.assert_pending(spec, images)

    def test_carrier_scope_cannot_escape_whitelist_or_fall_back(self):
        for oid in ("background", "missing", "unknown"):
            with self.subTest(object_id=oid):
                spec, images = scope_example()
                spec["forbidden_features"][0]["scope"]["bindings"][0]["object_id"] = oid
                self.assert_pending(spec, images)

    def test_whitelisted_but_nonexistent_scope_target_is_pending(self):
        spec, images = scope_example()
        spec["candidate_bindings"].append({"image_id": "synthetic:phone-scene", "object_id": "missing"})
        spec["forbidden_features"][0]["scope"]["bindings"][0]["object_id"] = "missing"
        self.assert_pending(spec, images)

    def test_image_scope_cannot_escape_pool_or_use_missing_image(self):
        for add_to_pool in (False, True):
            spec, images = scope_example("image", background_finish="matte")
            if add_to_pool:
                spec["candidate_image_ids"].append("missing-image")
            spec["forbidden_features"][0]["scope"]["image_ids"] = ["missing-image"]
            self.assert_pending(spec, images)

    def test_deleting_raw_audit_cannot_release_pending_negative(self):
        spec, images = scope_example()
        spec["scoped_negative_preferences"] = []
        self.assert_pending(spec, images)

    def test_unmapped_extra_negative_feature_cannot_be_ignored(self):
        spec, images = scope_example()
        spec["scoped_negative_preferences"][0]["features"].append({"parameter_id": "synthetic:palette", "value": "blue"})
        self.assert_pending(spec, images)

    def test_audit_and_rule_links_must_be_bidirectional(self):
        for side in ("audit", "rule"):
            spec, images = scope_example()
            if side == "audit":
                spec["scoped_negative_preferences"][0]["executable_constraint_ids"] = []
            else:
                spec["forbidden_features"][0]["audit_refs"] = ["other-preference"]
            self.assert_pending(spec, images)

    def test_rule_cannot_add_unaudited_forbidden_value_or_drop_source(self):
        for corruption in ("value", "evidence"):
            spec, images = scope_example()
            if corruption == "value":
                spec["forbidden_features"][0]["forbidden_values"].append("matte")
            else:
                spec["forbidden_features"][0]["evidence_refs"] = ["unrelated-reference"]
            self.assert_pending(spec, images)

    def test_same_parameter_different_scopes_do_not_merge(self):
        spec, images = scope_example()
        rule = deepcopy(spec["forbidden_features"][0])
        rule.update(constraint_id="synthetic:ban-glitter", forbidden_values=["glitter"])
        rule["scope"] = {"kind": "image", "status": "resolved", "image_ids": spec["candidate_image_ids"],
                         "evidence_refs": ["synthetic:image-scope-confirmation"]}
        spec["forbidden_features"].append(rule)
        audit = spec["scoped_negative_preferences"][0]
        audit["features"].append({"parameter_id": "synthetic:finish", "value": "glitter"})
        audit["executable_constraint_ids"].append(rule["constraint_id"])
        result = cluster_candidates(spec, images)
        self.assertEqual(result["status"], "complete")
        self.assertEqual(members(result), [("synthetic:phone-scene", "body")])
        self.assertEqual(len(result["negative_scope_plan"]["rules"]), 2)

    def test_duplicate_constraint_identity_is_not_accepted(self):
        spec, images = scope_example()
        spec["forbidden_features"].append(deepcopy(spec["forbidden_features"][0]))
        self.assertEqual(cluster_candidates(spec, images)["status"], "needs_input")

    def test_scope_cannot_override_an_unreviewed_attitude_interpretation(self):
        spec, images = scope_example()
        spec["scoped_negative_preferences"][0]["attitude_lineage"]["interpretation_requires_review"] = True
        spec["review_status"] = "approved"  # A new, unrecognized claim is not an unlock.
        self.assert_pending(spec, images)

    def test_explicit_unconfirmed_or_pending_audit_cannot_be_overridden_by_scope(self):
        for source in ("confirmation", "audit_status"):
            spec, images = scope_example()
            if source == "confirmation":
                spec["forbidden_features"][0]["scope_confirmation"] = {
                    "status": "pending", "confirmed_by": "synthetic:caller", "source_ref": "synthetic:source"}
            else:
                spec["scoped_negative_preferences"][0]["scope_status"] = "pending"
            self.assert_pending(spec, images)

    def test_explicit_population_mismatch_is_pending(self):
        spec, images = scope_example()
        spec["scoped_negative_preferences"][0]["user_ids"] = ["different-user"]
        self.assert_pending(spec, images)

    def test_product_hard_constraint_audit_keeps_its_separate_origin(self):
        spec, images = scope_example()
        aid = "brief:synthetic-brief:negative:0"
        audit = spec["scoped_negative_preferences"][0]
        audit.pop("attitude")
        audit.update(preference_id=aid, source_kind="product_hard_constraint")
        spec["negative_audit_ids"] = [aid]
        spec["forbidden_features"][0]["audit_refs"] = [aid]
        result = cluster_candidates(spec, images)
        self.assertEqual(result["status"], "complete")
        self.assertEqual(result["scoped_negative_preferences"][0]["source_kind"], "product_hard_constraint")

    def test_not_applicable_audit_is_preserved_with_explicit_basis(self):
        spec, images = scope_example(body_finish="mirror")
        audit = spec["scoped_negative_preferences"][0]
        audit.update(context_state="not_applicable", executable_constraint_ids=[])
        spec["forbidden_features"] = []
        result = cluster_candidates(spec, images)
        self.assertEqual(result["status"], "complete")
        self.assertEqual(result["scoped_negative_preferences"], spec["scoped_negative_preferences"])
        audit["conditions"], audit["evaluated_conditions"] = [], []
        self.assert_pending(spec, images)

    def test_not_applicable_population_uses_preserved_original_user_scope(self):
        spec, images = scope_example(body_finish="mirror")
        audit = spec["scoped_negative_preferences"][0]
        audit.update(context_state="not_applicable", executable_constraint_ids=[], user_ids=[],
                     original_user_ids=["different-user"], conditions=[], evaluated_conditions=[])
        spec["forbidden_features"] = []
        result = cluster_candidates(spec, images)
        self.assertEqual(result["status"], "complete")
        self.assertEqual(result["scoped_negative_preferences"], spec["scoped_negative_preferences"])

    def test_new_scope_fields_without_version_do_not_fall_back_to_legacy(self):
        spec, images = scope_example()
        spec.pop("negative_scope_version")
        self.assert_pending(spec, images)

    def test_scope_processing_does_not_modify_source_data_and_is_order_stable(self):
        spec, images = scope_example()
        before = deepcopy((spec, images))
        expected = cluster_candidates(spec, images)
        self.assertEqual((spec, images), before)
        images[0]["observations"].reverse()
        self.assertEqual(cluster_candidates(spec, images), expected)


if __name__ == "__main__":
    unittest.main()
