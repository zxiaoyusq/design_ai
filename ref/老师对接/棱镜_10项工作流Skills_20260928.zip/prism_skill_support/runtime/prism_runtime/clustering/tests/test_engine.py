from copy import deepcopy
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest

from prism_runtime.clustering import cluster_candidates
from prism_runtime.clustering.fixtures import demo, image, observation, request


def clustered(result):
    return {m["image_id"] for group in result["clusters"] for m in group["members"]}


class ClusteringTests(unittest.TestCase):
    def run_images(self, images, **changes):
        spec = request([x["image_id"] for x in images])
        spec.update(changes)
        return cluster_candidates(spec, images)

    def test_known_profiles_form_distinct_groups_with_direct_member_evidence(self):
        spec, images = demo()
        result = cluster_candidates(spec, images)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(clustered(result), {"synthetic:a", "synthetic:b", "synthetic:c", "synthetic:local"})
        self.assertEqual(len(result["clusters"]), 2)
        self.assertEqual(result["summary"]["excluded_images"], 1)
        for group in result["clusters"]:
            self.assertTrue(group["distinguishing_features"])
            for feature in group["shared_features"]:
                self.assertEqual(len(feature["supporting_members"]), len(group["members"]))
                self.assertTrue(all(s["observation_ids"] and s["region_refs"] for s in feature["supporting_members"]))

    def test_input_and_source_observation_order_do_not_change_result(self):
        spec, images = demo()
        expected = cluster_candidates(spec, images)
        random.Random(8).shuffle(images)
        spec["candidate_image_ids"].reverse()
        spec["required_features"].reverse()
        for record in images:
            record["observations"].reverse()
        self.assertEqual(cluster_candidates(spec, images), expected)

    def test_does_not_modify_request_or_dna(self):
        spec, images = demo()
        before = deepcopy((spec, images))
        cluster_candidates(spec, images)
        self.assertEqual((spec, images), before)

    def test_unknown_core_cannot_create_catch_all_cluster(self):
        rows = [image("one"), image("two")]
        for record in rows:
            for o in record["observations"][:2]:
                o.update(value=None, value_status="unknown")
        result = self.run_images(rows)
        self.assertEqual(result["status"], "needs_input")
        self.assertFalse(result["clusters"])

    def test_no_required_features_requires_upstream_input(self):
        result = self.run_images([image("a")], required_features=[])
        self.assertEqual(result["status"], "needs_input")
        self.assertFalse(result["clusters"])

    def test_split_carriers_cannot_be_spliced(self):
        record = image("split")
        record["observations"][1]["object_id"] = "another-object"
        result = self.run_images([record])
        self.assertFalse(result["clusters"])
        self.assertTrue(any(r["code"] == "cross_carrier_evidence_cannot_be_combined"
                            for d in result["carrier_diagnostics"] for r in d["reasons"]))

    def test_local_core_is_admitted_with_original_binding(self):
        record = image("local", object_id="small-detail", region={"synthetic_region_id": "small-detail"})
        result = self.run_images([record])
        member = result["clusters"][0]["members"][0]
        self.assertEqual(member["object_id"], "small-detail")
        self.assertEqual(member["region_refs"], [{"synthetic_region_id": "small-detail"}])

    def test_missing_region_is_not_grounded(self):
        record = image("a")
        for o in record["observations"]:
            o["region_ref"] = None
        self.assertFalse(self.run_images([record])["clusters"])

    def test_missing_evidence_reference_is_not_grounded(self):
        record = image("a")
        record["observations"][0]["evidence_refs"] = []
        self.assertFalse(self.run_images([record])["clusters"])

    def test_region_unknown_markers_and_empty_payload_are_not_grounding(self):
        for region in ({"status": "unknown", "ref": "unresolved"}, {"bbox": None}, {"status": "known"}):
            with self.subTest(region=region):
                record = image("a")
                record["observations"][0]["region_ref"] = region
                self.assertFalse(self.run_images([record])["clusters"])

    def test_unrelated_background_does_not_create_spurious_candidate(self):
        record = image("a")
        record["observations"].append(observation("background", "studio", object_id="background"))
        result = self.run_images([record])
        self.assertEqual(result["status"], "complete")
        self.assertFalse(result["boundary_members"])

    def test_three_modes_preserve_unknown_and_exclusion_rules(self):
        for mode in ("consensus", "extension", "exploration"):
            with self.subTest(mode=mode):
                spec, images = demo()
                spec = request(spec["candidate_image_ids"], mode)
                result = cluster_candidates(spec, images)
                self.assertEqual(result["alignment_mode"], mode)
                self.assertEqual(result["relation_basis"], spec["relation_basis"])
                self.assertEqual(result["hypothesis_refs"], spec["hypothesis_refs"])
                self.assertNotIn("synthetic:forbidden", clustered(result))
                self.assertNotIn("synthetic:unknown-negative", clustered(result))
                self.assertIn("synthetic:forbidden", {x["image_id"] for x in result["excluded"]})

    def test_known_forbidden_on_another_object_is_still_disclosed_conflict(self):
        record = image("a")
        record["observations"].append(observation("finish", "mirror", object_id="other", suffix="-other"))
        result = self.run_images([record])
        self.assertFalse(result["clusters"])
        self.assertEqual(result["excluded"][0]["reason"], "known_forbidden_feature")

    def test_forbidden_clearance_cannot_be_borrowed_from_another_carrier(self):
        record = image("a")
        record["observations"][2]["object_id"] = "another"
        result = self.run_images([record])
        self.assertFalse(result["clusters"])
        self.assertIn("forbidden_absence_unverified", result["boundary_members"][0]["reason"])

    def test_missing_forbidden_observation_does_not_mean_absent(self):
        record = image("a")
        record["observations"].pop(2)
        self.assertFalse(self.run_images([record])["clusters"])

    def test_unknown_and_na_cannot_carry_non_null_values(self):
        for mode in ("consensus", "extension", "exploration"):
            for state in ("unknown", "not_applicable"):
                for value in ("mirror", 0, False, "", [], {}):
                    with self.subTest(mode=mode, state=state, value=value):
                        record = image("a")
                        record["observations"][2].update(value=value, value_status=state)
                        result = cluster_candidates(request(["a"], mode), [record])
                        self.assertFalse(result["clusters"])
                        self.assertEqual(result["boundary_members"][0]["reason"], "invalid_image_dna")
                        self.assertIn("non-null value", str(result["boundary_members"][0]["reasons"]))

    def test_legal_na_forbidden_remains_supported_in_all_modes(self):
        for mode in ("consensus", "extension", "exploration"):
            with self.subTest(mode=mode):
                record = image("a")
                record["observations"][2].update(value=None, value_status="not_applicable")
                result = cluster_candidates(request(["a"], mode), [record])
                self.assertEqual(result["status"], "complete")
                self.assertEqual(clustered(result), {"a"})
                self.assertFalse(result["boundary_members"])

    def test_explicit_region_carrier_conflict_cannot_support_any_feature_role(self):
        for mode in ("consensus", "extension", "exploration"):
            for position in (0, 2, 3):  # required, forbidden clearance, comparison
                with self.subTest(mode=mode, feature_position=position):
                    record = image("a")
                    record["observations"][position]["region_ref"] = {
                        "object_id": "different-object", "bbox_xyxy": [0, 0, 1, 1]}
                    result = cluster_candidates(request(["a"], mode), [record])
                    self.assertFalse(result["clusters"])
                    self.assertEqual(result["boundary_members"][0]["reason"], "invalid_image_dna")
                    self.assertIn("region_ref.object_id conflicts", str(result["boundary_members"][0]["reasons"]))

    def test_consistent_structured_and_opaque_region_references_still_work(self):
        for region in ("synthetic:body/front", {"object_id": "body", "bbox_xyxy": [0, 0, 1, 1]},
                       {"synthetic_region_id": "front"}):
            with self.subTest(region=region):
                record = image("a", region=region)
                result = self.run_images([record])
                self.assertEqual(result["status"], "complete")
                self.assertEqual(clustered(result), {"a"})
                self.assertEqual(result["clusters"][0]["members"][0]["region_refs"], [region])

    def test_invalid_record_does_not_poison_another_valid_image(self):
        valid, invalid = image("valid"), image("invalid")
        invalid["observations"][2]["value_status"] = "not_applicable"
        result = self.run_images([invalid, valid])
        self.assertEqual(result["status"], "partial")
        self.assertEqual(clustered(result), {"valid"})
        self.assertEqual({r["image_id"] for r in result["boundary_members"]}, {"invalid"})

    def test_unknown_comparison_never_groups_with_unknown(self):
        rows = [image("one"), image("two")]
        for record in rows:
            record["observations"][3].update(value=None, value_status="unknown")
        result = self.run_images(rows)
        self.assertFalse(result["clusters"])
        self.assertEqual(result["summary"]["boundary_images"], 2)

    def test_not_applicable_comparison_is_not_positive_shared_feature(self):
        record = image("a")
        record["observations"][3].update(value=None, value_status="not_applicable")
        result = self.run_images([record])
        self.assertEqual(result["status"], "complete")
        self.assertNotIn("synthetic:palette", {f["parameter_id"] for f in result["clusters"][0]["shared_features"]})

    def test_contradictory_values_on_same_region_are_boundary(self):
        record = image("a")
        record["observations"].append(observation("contour", "straight", suffix="-conflict"))
        result = self.run_images([record])
        self.assertFalse(result["clusters"])
        self.assertIn("contradictory_observations", result["boundary_members"][0]["reason"])

    def test_typed_exact_matching_does_not_coerce_bool_to_integer(self):
        record = image("a")
        record["observations"][0]["value"] = True
        spec = request(["a"])
        spec["required_features"][0]["allowed_values"] = [1]
        result = cluster_candidates(spec, [record])
        self.assertEqual(result["status"], "complete")
        self.assertFalse(result["clusters"])

    def test_array_values_are_not_silently_flattened(self):
        record = image("a")
        record["observations"][0]["value"] = ["curved", "straight"]
        self.assertFalse(self.run_images([record])["clusters"])
        spec = request(["a"])
        spec["required_features"][0]["allowed_values"] = [["curved", "straight"]]
        self.assertTrue(cluster_candidates(spec, [record])["clusters"])

    def test_outside_pool_is_not_grouped_or_used_as_support(self):
        result = cluster_candidates(request(["a"]), [image("a"), image("outside", finish="mirror")])
        self.assertEqual(clustered(result), {"a"})
        self.assertEqual(result["summary"]["unused_input_image_ids"], ["outside"])

    def test_duplicate_ids_are_rejected(self):
        record = image("a")
        result = cluster_candidates(request(["a"]), [record, deepcopy(record)])
        self.assertEqual(result["status"], "needs_input")

    def test_synthetic_data_cannot_be_misrepresented_as_real_evidence(self):
        spec = request(["a"])
        spec["provenance"]["mode"] = "real_evidence"
        result = cluster_candidates(spec, [image("a")])
        self.assertEqual(result["status"], "needs_input")
        self.assertFalse(result["clusters"])

    def test_inconsistent_mode_relation_is_not_silently_repaired(self):
        spec = request(["a"])
        spec["relation_basis"] = "exploratory_hypothesis"
        result = cluster_candidates(spec, [image("a")])
        self.assertEqual(result["status"], "needs_input")
        self.assertEqual(result["alignment_mode"], "consensus")

    def test_alignment_modes_allow_narrower_relations_without_rewriting(self):
        allowed = {"consensus": {"direct_support"}, "extension": {"direct_support", "anchored_extension"},
                   "exploration": {"direct_support", "anchored_extension", "exploratory_hypothesis"}}
        for mode, permitted in allowed.items():
            for relation in ("direct_support", "anchored_extension", "exploratory_hypothesis"):
                with self.subTest(mode=mode, relation=relation):
                    spec = request(["a"], mode)
                    spec["relation_basis"] = relation
                    result = cluster_candidates(spec, [image("a")])
                    self.assertEqual(bool(result["clusters"]), relation in permitted)
                    self.assertEqual(result["alignment_mode"], mode)
                    self.assertEqual(result["relation_basis"], relation)

    def test_candidate_bindings_limit_carriers_and_images(self):
        first, decoy = image("a"), image("a", object_id="unselected-decoy")
        for o in decoy["observations"]:
            o["observation_id"] += "-decoy"
        first["observations"].extend(decoy["observations"])
        spec = request(["a", "outside"])
        spec["forbidden_features"] = []
        spec["candidate_bindings"] = [{"image_id": "a", "object_id": "body", "observation_ids": ["contour"],
                                       "region_refs": ["synthetic:body/front"]}]
        result = cluster_candidates(spec, [first, image("outside")])
        members = [m for c in result["clusters"] for m in c["members"]]
        self.assertEqual([(m["image_id"], m["object_id"]) for m in members], [("a", "body")])
        self.assertEqual(members[0]["upstream_candidate_binding"], spec["candidate_bindings"][0])
        self.assertIn("synthetic:palette", {f["parameter_id"] for f in result["clusters"][0]["shared_features"]})
        self.assertEqual(result["excluded"][0]["reason"], "outside_candidate_bindings")
        self.assertEqual(result["status"], "complete")

    def test_empty_unknown_duplicate_or_outside_bindings_are_not_unrestricted(self):
        variants = [[], None, [{"image_id": "a", "object_id": "unknown"}],
                    [{"image_id": "outside", "object_id": "body"}],
                    [{"image_id": "a", "object_id": "body"}] * 2,
                    [{"image_id": "a", "object_id": "body", "region_refs": [{"object_id": "other"}]}]]
        for bindings in variants:
            with self.subTest(bindings=bindings):
                result = self.run_images([image("a")], candidate_bindings=bindings)
                self.assertEqual(result["status"], "needs_input")
                self.assertFalse(result["clusters"])

    def test_missing_selected_carrier_does_not_fall_back_to_matching_carrier(self):
        result = self.run_images([image("a")], forbidden_features=[],
                                 candidate_bindings=[{"image_id": "a", "object_id": "missing"}])
        self.assertFalse(result["clusters"])
        self.assertTrue(any("candidate_binding_object_missing" in m["reason"] for m in result["boundary_members"]))

    def test_unresolvable_upstream_binding_evidence_is_boundary(self):
        for extra in ({"observation_ids": ["missing"]}, {"region_refs": ["synthetic:unseen-region"]}):
            with self.subTest(extra=extra):
                result = self.run_images([image("a")], forbidden_features=[],
                    candidate_bindings=[{"image_id": "a", "object_id": "body", **extra}])
                self.assertFalse(result["clusters"])
                self.assertTrue(any("candidate_binding_" in m["reason"] for m in result["boundary_members"]))

    def test_binding_does_not_silently_define_forbidden_scope(self):
        result = self.run_images([image("a", finish="mirror")],
                                 candidate_bindings=[{"image_id": "a", "object_id": "body"}])
        self.assertFalse(result["clusters"])
        self.assertFalse(result["excluded"])
        self.assertIn("forbidden_scope_unresolved", result["boundary_members"][0]["reason"])

    def test_unresolved_negative_and_context_constraints_remain_boundary(self):
        for extra in ({"scoped_negative_preferences": [{"preference_id": "p", "context_state": "applies"}]},
                      {"pending_context_constraints": [{"reason": "scope unknown"}]}):
            with self.subTest(extra=extra):
                result = self.run_images([image("a")], forbidden_features=[], **extra)
                self.assertFalse(result["clusters"])
                self.assertEqual(result["status"], "partial")
                for key, value in extra.items():
                    self.assertEqual(result[key], value)

    def test_explicit_context_not_applicable_is_preserved_without_new_ban(self):
        negative = [{"preference_id": "p", "context_state": "not_applicable"}]
        result = self.run_images([image("a")], forbidden_features=[], scoped_negative_preferences=negative)
        self.assertEqual(clustered(result), {"a"})
        self.assertEqual(result["scoped_negative_preferences"], negative)

    def test_known_mismatch_can_produce_complete_empty_result(self):
        record = image("a")
        record["observations"][0]["value"] = "straight"
        result = self.run_images([record])
        self.assertEqual(result["status"], "complete")
        self.assertFalse(result["clusters"])
        self.assertEqual(len(result["excluded"]), 1)

    def test_no_final_board_size_limit_or_representative_selection(self):
        rows = [image(f"image-{i}") for i in range(14)]
        result = self.run_images(rows)
        self.assertEqual(len(result["clusters"][0]["members"]), 14)
        self.assertFalse(any(k in result["clusters"][0] for k in ("medoid", "representative", "hero")))

    def test_same_image_can_contribute_two_distinct_grounded_carriers(self):
        first, second = image("a"), image("b", object_id="handle", palette="orange")
        for o in second["observations"]:
            o["observation_id"] += "-handle"
        first["observations"].extend(second["observations"])
        result = self.run_images([first])
        self.assertEqual(len(result["clusters"]), 2)
        self.assertEqual(result["summary"]["clustered_images"], 1)
        self.assertEqual(result["summary"]["carrier_memberships"], 2)

    def test_missing_dna_is_explicit_boundary(self):
        result = cluster_candidates(request(["a", "missing"]), [image("a")])
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["boundary_members"][0]["reason"], "missing_image_dna")

    def test_required_evidence_and_logical_consistency_are_required(self):
        spec = request(["a"])
        spec["required_features"][0]["evidence_refs"] = []
        self.assertEqual(cluster_candidates(spec, [image("a")])["status"], "needs_input")
        spec = request(["a"])
        spec["forbidden_features"].append({"parameter_id": "synthetic:contour", "forbidden_values": ["curved"],
                                           "evidence_refs": ["synthetic:conflict"]})
        self.assertEqual(cluster_candidates(spec, [image("a")])["status"], "needs_input")

    def test_all_shared_features_are_supported_on_each_reported_member(self):
        spec, images = demo()
        originals = {im["image_id"]: {o["observation_id"]: o for o in im["observations"]} for im in images}
        result = cluster_candidates(spec, images)
        for group in result["clusters"]:
            for feature in group["shared_features"]:
                for support in feature["supporting_members"]:
                    self.assertTrue(support["observation_ids"])
                    for oid in support["observation_ids"]:
                        raw = originals[support["image_id"]][oid]
                        self.assertEqual(raw["value"], feature["value"])
                        self.assertEqual(raw["object_id"], support["object_id"])
                        self.assertEqual(raw["value_status"], "known")

    def test_cli_roundtrip_and_input_overwrite_guard(self):
        spec, images = demo()
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            request_path, dna_path, output_path = folder / "request.json", folder / "dna.json", folder / "output.json"
            request_path.write_text(json.dumps(spec, ensure_ascii=False), encoding="utf-8")
            dna_path.write_text(json.dumps({"images": images}, ensure_ascii=False), encoding="utf-8")
            command = [sys.executable, "-B", "-X", "utf8", "-m", "prism_runtime.clustering", "--request", str(request_path),
                       "--dna", str(dna_path), "--output", str(output_path)]
            completed = subprocess.run(command, capture_output=True, encoding="utf-8", check=False)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertEqual(json.loads(output_path.read_text(encoding="utf-8")), cluster_candidates(spec, images))
            original = request_path.read_bytes()
            command[-1] = str(request_path)
            self.assertEqual(subprocess.run(command, capture_output=True, encoding="utf-8").returncode, 2)
            self.assertEqual(request_path.read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
