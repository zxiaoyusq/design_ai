"""Tiny explicitly synthetic fixtures; not images, real interviews or labels."""
from copy import deepcopy


def observation(parameter, value, *, object_id="body", region=None, status="known", suffix=""):
    return {"observation_id": parameter + suffix, "parameter_id": "synthetic:" + parameter,
            "object_id": object_id, "value": value, "value_status": status,
            "region_ref": region if region is not None else "synthetic:body/front",
            "evidence_refs": ["synthetic:observation/" + parameter + suffix]}


def image(identifier, *, palette="blue", finish="matte", object_id="body", region=None):
    return {"schema_version": "prism.image_dna.v0.1", "image_id": identifier,
            "source_kind": "synthetic", "image_path": None,
            "source_ref": "synthetic:fixture/" + identifier,
            "observations": [observation(parameter, value, object_id=object_id, region=region)
                             for parameter, value in (("contour", "curved"), ("surface", "smooth"),
                                                      ("finish", finish), ("palette", palette))],
            "provenance": {"mode": "synthetic", "parser_version": "fixture-v1"}}


def request(ids, mode="consensus"):
    labels = {"consensus": ("共识优先", "direct_support"),
              "extension": ("适度延展", "anchored_extension"),
              "exploration": ("创新探索", "exploratory_hypothesis")}
    return {"schema_version": "prism.grouping_request.v0.1", "request_id": "synthetic:grouping-demo",
            "brief_id": "synthetic:brief", "direction_id": "synthetic:direction",
            "alignment_mode": mode, "alignment_label": labels[mode][0], "relation_basis": labels[mode][1],
            "title": "合成演示：同载体的连续曲面如何按配色区分", "design_axis": "ID",
            "candidate_image_ids": list(ids),
            "required_features": [{"parameter_id": "synthetic:" + parameter, "allowed_values": [value],
                                   "evidence_refs": ["synthetic:trend-anchor", "synthetic:preference-anchor"]}
                                  for parameter, value in (("contour", "curved"), ("surface", "smooth"))],
            "forbidden_features": [{"parameter_id": "synthetic:finish", "forbidden_values": ["mirror"],
                                    "evidence_refs": ["synthetic:explicit-negative"]}],
            "comparison_features": ["synthetic:palette"],
            "preference_refs": ["synthetic:preference-anchor"], "trend_refs": ["synthetic:trend-anchor"],
            "hypothesis_refs": [] if mode == "consensus" else ["synthetic:unverified-extension"],
            "provenance": {"mode": "synthetic", "designer_confirmed": False}}


def demo():
    images = [image("synthetic:a"), image("synthetic:b"), image("synthetic:c", palette="orange"),
              image("synthetic:local", object_id="handle-detail", region={"synthetic_region_id": "handle"}),
              image("synthetic:forbidden", finish="mirror"), image("synthetic:unknown-core"),
              image("synthetic:unknown-negative"), image("synthetic:unknown-comparison"), image("synthetic:split")]
    images[5]["observations"][0].update(value=None, value_status="unknown")
    images[6]["observations"][2].update(value=None, value_status="unknown")
    images[7]["observations"][3].update(value=None, value_status="unknown")
    images[8]["observations"][1].update(object_id="other-object", region_ref="synthetic:other-object")
    return request([record["image_id"] for record in images]), deepcopy(images)
