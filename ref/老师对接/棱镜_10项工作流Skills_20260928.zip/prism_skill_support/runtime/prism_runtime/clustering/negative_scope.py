"""CT-002 negative-scope graph validation and deterministic execution.

This consumes a compiled H02 scope; it cannot confirm a new semantic review or
infer scope from prose. Original audits stay separate from executable rules.
"""
from copy import deepcopy

SCOPE_VERSION = "prism.negative_scope.v0.1"


def _text(value):
    return isinstance(value, str) and bool(value.strip()) and value.strip().casefold() != "unknown"


def _refs(value, nonempty=False):
    return isinstance(value, list) and (bool(value) or not nonempty) and all(_text(v) for v in value)


def _issue(code, **details):
    return {"code": code, **details}


def requested(request):
    if "negative_scope_version" in request or "negative_audit_ids" in request:
        return True
    return (any(isinstance(f, dict) and ("constraint_id" in f or "audit_refs" in f)
                for f in request.get("forbidden_features", []))
            or any(isinstance(a, dict) and "executable_constraint_ids" in a
                   for a in request.get("scoped_negative_preferences", [])))


def _review_pending(record):
    lineage = record.get("attitude_lineage", {})
    return ("interpretation_requires_review" in record and record["interpretation_requires_review"] is not False
            or isinstance(lineage, dict) and "interpretation_requires_review" in lineage
            and lineage["interpretation_requires_review"] is not False)


def _not_applicable_has_basis(audit, request):
    if not _refs(audit.get("evidence_refs"), nonempty=True):
        return False
    # H02 owns evaluation of these conditions; only explicit recorded decisions
    # are consumed here, never a new interpretation of condition prose.
    if _refs(audit.get("conditions"), True) and isinstance(audit.get("evaluated_conditions"), list) and audit["evaluated_conditions"]:
        return True
    users, target = audit.get("original_user_ids", audit.get("user_ids")), request.get("target_user_ids")
    return _refs(users, True) and _refs(target, True) and not set(users).intersection(target)


def _scope_errors(rule, request, images):
    cid, scope = rule.get("constraint_id"), rule.get("scope")
    errors = []
    if not isinstance(scope, dict) or scope.get("status") != "resolved":
        return [_issue("negative_scope_unresolved", constraint_id=cid)]
    unsupported = set(scope) - {"kind", "status", "evidence_refs", "image_ids", "bindings"}
    if unsupported:
        errors.append(_issue("negative_scope_fields_unsupported", constraint_id=cid, fields=sorted(unsupported)))
    if not _refs(scope.get("evidence_refs"), True):
        errors.append(_issue("negative_scope_evidence_missing", constraint_id=cid))
    if "scope_confirmation" in rule:
        confirmation = rule["scope_confirmation"]
        if (not isinstance(confirmation, dict) or confirmation.get("status") != "confirmed"
                or not _text(confirmation.get("confirmed_by")) or not _text(confirmation.get("source_ref"))):
            errors.append(_issue("negative_scope_confirmation_unresolved", constraint_id=cid))
    kind = scope.get("kind")
    pool = set(request["candidate_image_ids"])
    if kind == "image":
        targets = scope.get("image_ids")
        if (not _refs(targets, True) or len(targets) != len(set(targets))
                or not set(targets).issubset(pool) or "bindings" in scope):
            errors.append(_issue("negative_image_scope_invalid", constraint_id=cid))
        elif any(iid not in images for iid in targets):
            errors.append(_issue("negative_scope_image_missing", constraint_id=cid))
    elif kind == "candidate_bindings":
        targets = scope.get("bindings")
        allowed = {(b["image_id"], b["object_id"]) for b in request.get("candidate_bindings", [])}
        if not isinstance(targets, list) or not targets or not allowed or "image_ids" in scope:
            return errors + [_issue("negative_carrier_scope_invalid", constraint_id=cid)]
        seen = set()
        for target in targets:
            if not isinstance(target, dict) or not _text(target.get("image_id")) or not _text(target.get("object_id")):
                errors.append(_issue("negative_scope_target_unknown", constraint_id=cid))
                continue
            if set(target) - {"image_id", "object_id"}:
                errors.append(_issue("negative_scope_carrier_selector_unsupported", constraint_id=cid))
            pair = (target["image_id"], target["object_id"])
            if pair in seen or pair not in allowed:
                errors.append(_issue("negative_scope_outside_candidate_bindings", constraint_id=cid,
                                     image_id=pair[0], object_id=pair[1]))
            seen.add(pair)
            image = images.get(pair[0], {})
            observations = image.get("observations", [])
            if not isinstance(observations, list) or not any(isinstance(o, dict) and o.get("object_id") == pair[1]
                                                           for o in observations):
                errors.append(_issue("negative_scope_carrier_missing", constraint_id=cid,
                                     image_id=pair[0], object_id=pair[1]))
    else:
        errors.append(_issue("negative_scope_kind_unsupported", constraint_id=cid, kind=kind))
    return errors


def compile_scope(request, images, value_key):
    """Validate the complete audit/rule graph. Any graph gap stays pending."""
    pending, audit_index, rule_index, audits_trace = [], {}, {}, []
    plan = {"version": request.get("negative_scope_version"), "rules": [], "pending": pending,
            "audit_trace": audits_trace, "expected_audit_ids": deepcopy(request.get("negative_audit_ids"))}
    if request.get("negative_scope_version") != SCOPE_VERSION:
        pending.append(_issue("negative_scope_version_missing_or_unsupported"))
        return plan
    if request.get("pending_context_constraints"):
        pending.append(_issue("pending_context_constraints", count=len(request["pending_context_constraints"])))
    ids, audits = request.get("negative_audit_ids"), request.get("scoped_negative_preferences")
    if not _refs(ids) or len(ids) != len(set(ids)) or not isinstance(audits, list):
        pending.append(_issue("negative_audit_manifest_invalid"))
        return plan
    for audit in audits:
        if not isinstance(audit, dict) or not _text(audit.get("preference_id")):
            pending.append(_issue("negative_audit_identity_unknown"))
            continue
        aid = audit["preference_id"]
        if aid in audit_index:
            pending.append(_issue("negative_audit_identity_duplicate", preference_id=aid))
        audit_index[aid] = audit
    if set(ids) != set(audit_index):
        pending.append(_issue("negative_audit_manifest_mismatch", missing=sorted(set(ids) - set(audit_index)),
                              undeclared=sorted(set(audit_index) - set(ids))))
    for rule in request["forbidden_features"]:
        cid = rule.get("constraint_id")
        if not _text(cid) or cid in rule_index:
            pending.append(_issue("negative_constraint_identity_invalid", constraint_id=cid))
            continue
        rule_index[cid] = rule
        refs = rule.get("audit_refs")
        if not _refs(refs, True) or len(refs) != len(set(refs)):
            pending.append(_issue("negative_constraint_audit_refs_invalid", constraint_id=cid))
        pending.extend(_scope_errors(rule, request, images))
    for aid, audit in sorted(audit_index.items()):
        mapped = audit.get("executable_constraint_ids")
        if not _refs(mapped) or len(mapped) != len(set(mapped)):
            pending.append(_issue("negative_audit_mapping_invalid", preference_id=aid))
            continue
        state = audit.get("context_state")
        trace = {"preference_id": aid, "context_state": state, "executable_constraint_ids": deepcopy(mapped),
                 "evidence_refs": deepcopy(audit.get("evidence_refs", []))}
        audits_trace.append(trace)
        if _review_pending(audit):
            pending.append(_issue("negative_interpretation_review_pending", preference_id=aid))
        if "scope_status" in audit and audit["scope_status"] != ("not_applicable" if state == "not_applicable" else "resolved"):
            pending.append(_issue("negative_audit_scope_status_unresolved", preference_id=aid))
        if "attitude" in audit and audit["attitude"] != "dislike":
            pending.append(_issue("negative_audit_attitude_conflict", preference_id=aid))
        if state == "not_applicable":
            if mapped or not _not_applicable_has_basis(audit, request):
                pending.append(_issue("negative_not_applicable_basis_unresolved", preference_id=aid))
            continue
        if state != "applies" or not _refs(audit.get("evidence_refs"), True):
            pending.append(_issue("negative_audit_context_or_evidence_unresolved", preference_id=aid))
            continue
        if ("target_user_ids" in request and "user_ids" in audit
                and (not _refs(request["target_user_ids"], True) or not _refs(audit["user_ids"], True)
                     or set(request["target_user_ids"]) != set(audit["user_ids"]))):
            pending.append(_issue("negative_audit_population_mismatch", preference_id=aid))
        features = audit.get("features")
        if not isinstance(features, list) or not features:
            pending.append(_issue("negative_audit_features_missing", preference_id=aid))
            continue
        for cid in mapped:
            rule = rule_index.get(cid)
            if rule is None or not _refs(rule.get("audit_refs")) or aid not in rule["audit_refs"]:
                pending.append(_issue("negative_audit_forward_link_invalid", preference_id=aid, constraint_id=cid))
        for feature in features:
            if not isinstance(feature, dict) or not _text(feature.get("parameter_id")) or feature.get("value") is None:
                pending.append(_issue("negative_audit_feature_unknown", preference_id=aid))
                continue
            matching = [rule_index[cid] for cid in mapped if cid in rule_index
                        and rule_index[cid]["parameter_id"] == feature["parameter_id"]
                        and value_key(feature["value"]) in {value_key(v) for v in rule_index[cid]["forbidden_values"]}]
            if not matching:
                pending.append(_issue("negative_audit_feature_unmapped", preference_id=aid,
                                      parameter_id=feature["parameter_id"], value=deepcopy(feature["value"])))
    for cid, rule in sorted(rule_index.items()):
        if not _refs(rule.get("audit_refs"), True):
            continue
        supported_values = set()
        for aid in rule["audit_refs"]:
            audit = audit_index.get(aid)
            if (audit is None or not _refs(audit.get("executable_constraint_ids"))
                    or cid not in audit["executable_constraint_ids"] or audit.get("context_state") != "applies"):
                pending.append(_issue("negative_constraint_reverse_link_invalid", constraint_id=cid, preference_id=aid))
                continue
            if not _refs(audit.get("evidence_refs"), True) or not set(audit["evidence_refs"]).issubset(rule["evidence_refs"]):
                pending.append(_issue("negative_constraint_source_refs_missing", constraint_id=cid, preference_id=aid))
            for feature in audit.get("features", []) if isinstance(audit.get("features"), list) else []:
                if isinstance(feature, dict) and feature.get("parameter_id") == rule["parameter_id"] and feature.get("value") is not None:
                    supported_values.add(value_key(feature["value"]))
        if not {value_key(v) for v in rule["forbidden_values"]}.issubset(supported_values):
            pending.append(_issue("negative_constraint_value_not_in_audits", constraint_id=cid))
    # An incomplete graph is never repaired by dropping a raw negative. No rule
    # executes on ambiguous scope/lineage, including as a confident exclusion.
    if not pending:
        plan["rules"] = [deepcopy(rule_index[cid]) for cid in sorted(rule_index)]
    return plan


def _check(rule, image_id, object_id, rows, facts, value_key):
    parameter = rule["parameter_id"]
    all_rows, known, na, uncertain, contradictory = facts(rows, parameter)
    prohibited = {value_key(v) for v in rule["forbidden_values"]}
    matches = [o for o in known if value_key(o["value"]) in prohibited]
    base = {"constraint_id": rule["constraint_id"], "parameter_id": parameter,
            "audit_refs": deepcopy(rule["audit_refs"]), "scope": deepcopy(rule["scope"]),
            "image_id": image_id, "object_id": object_id}
    if matches:
        return [_issue("known_forbidden_feature", **base,
                       observation_ids=sorted(o["observation_id"] for o in matches),
                       evidence_refs=sorted(set(rule["evidence_refs"]) | {r for o in matches for r in o["evidence_refs"]}))], [], []
    if not all_rows or uncertain or contradictory or (known and na):
        return [], [_issue("forbidden_absence_unverified", **base)], []
    checked = known + na
    check = {**base, "check": "no_forbidden_value_in_declared_scope_observations",
             "observation_ids": sorted(o["observation_id"] for o in checked),
             "region_refs": [deepcopy(o["region_ref"]) for o in sorted(checked, key=lambda o: o["observation_id"])],
             "evidence_refs": sorted(set(rule["evidence_refs"]) | set(rule["scope"]["evidence_refs"])
                                     | {r for o in checked for r in o["evidence_refs"]})}
    return [], [], [check]


def check_image(rules, image, facts, value_key, grounded):
    conflicts, uncertainties, checks = [], [], []
    observations, image_id = image["observations"], image["image_id"]
    carriers = sorted({o["object_id"] for o in observations if _text(o.get("object_id"))})
    for rule in rules:
        if rule["scope"]["kind"] != "image":
            continue
        if image_id not in rule["scope"]["image_ids"]:
            checks.append({"constraint_id": rule["constraint_id"], "audit_refs": rule["audit_refs"],
                           "check": "outside_declared_image_scope", "evidence_refs": rule["scope"]["evidence_refs"]})
            continue
        if not carriers:
            uncertainties.append(_issue("negative_image_carriers_unknown", constraint_id=rule["constraint_id"]))
        if any(o["parameter_id"] == rule["parameter_id"] and not grounded(o) for o in observations):
            uncertainties.append(_issue("negative_image_unbound_observation", constraint_id=rule["constraint_id"]))
        # Whole-image scope checks every declared carrier, including backgrounds.
        # Missing attribute coverage on one is uncertainty, never certified absence.
        for oid in carriers:
            c, u, k = _check(rule, image_id, oid, [o for o in observations if o.get("object_id") == oid], facts, value_key)
            conflicts.extend(c); uncertainties.extend(u); checks.extend(k)
    return conflicts, uncertainties, checks


def check_carrier(rules, image_id, object_id, rows, facts, value_key):
    conflicts, uncertainties, checks = [], [], []
    for rule in rules:
        if rule["scope"]["kind"] != "candidate_bindings":
            continue
        targets = {(b["image_id"], b["object_id"]) for b in rule["scope"]["bindings"]}
        if (image_id, object_id) not in targets:
            checks.append({"constraint_id": rule["constraint_id"], "audit_refs": rule["audit_refs"],
                           "check": "outside_declared_carrier_scope", "evidence_refs": rule["scope"]["evidence_refs"]})
            continue
        c, u, k = _check(rule, image_id, object_id, rows, facts, value_key)
        conflicts.extend(c); uncertainties.extend(u); checks.extend(k)
    return conflicts, uncertainties, checks
