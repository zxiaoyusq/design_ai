"""Evidence-bound conditional clustering. No model or image transformation calls."""

from .engine import VERSION, cluster_candidates

__all__ = ["VERSION", "cluster_candidates"]
