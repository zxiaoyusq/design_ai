"""Deterministic, exact-profile baseline for GroupingRequest v0.1.

Required features are existential on ONE carrier, with original region evidence.
Complete known comparison profiles partition admitted carriers. Missing values
are never filled, distances are not invented, and no final-board selection runs.
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
import hashlib
import json
import math

from . import negative_scope

VERSION = "0.2.0"
MODES = {
    "consensus": ("共识优先", ("direct_support",)),
    "extension": ("适度延展", ("direct_support", "anchored_extension")),
    "exploration": ("创新探索", ("direct_support", "anchored_extension", "exploratory_hypothesis")),
}
SOURCE_KINDS = {"trend", "research", "generated", "calibration", "synthetic"}
STATUSES = {"known", "unknown", "not_applicable"}


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def _refs(value, nonempty=False):
    return isinstance(value, list) and (not nonempty or bool(value)) and all(_text(x) for x in value)


def _json_value(value):
    if value is None or isinstance(value, (str, bool, int)):
        return True
    if isinstance(value, float):
        return math.isfinite(value)
    if isinstance(value, list):
        return all(_json_value(x) for x in value)
    if isinstance(value, dict):
        return all(isinstance(k, str) and _json_value(v) for k, v in value.items())
    return False


def _key(value):
    # JSON literals retain types: true, 1, 1.0 and "1" are distinct.
    # Arrays are whole typed values, not implicit any-of or unordered sets.
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _unique(values):
    indexed = {_key(x): x for x in values}
    return [deepcopy(indexed[k]) for k in sorted(indexed)]


def _carrier(value):
    return _text(value) and value.strip().casefold() != "unknown"


def _region(value):
    if isinstance(value, str):
        return _carrier(value)
    # v0.1 does not prescribe geometry syntax; retain original region objects.
    if not isinstance(value, dict) or not value or not _json_value(value):
        return False
    if any(value.get(field) in ("unknown", "not_applicable") for field in ("status", "state", "value_status")):
        return False
    metadata = {"status", "state", "value_status", "confidence", "schema_version"}
    return any(key not in metadata and item is not None and item != "" and item != [] and item != {}
               for key, item in value.items())


def _region_carrier_consistent(observation):
    region = observation.get("region_ref")
    return (not isinstance(region, dict) or "object_id" not in region
            or region["object_id"] == observation.get("object_id"))


def _grounded(observation):
    return (_carrier(observation.get("object_id")) and _region(observation.get("region_ref"))
            and _region_carrier_consistent(observation)
            and _refs(observation.get("evidence_refs"), nonempty=True))


def _reason(code, parameter_id=None, **extra):
    return {"code": code, **({"parameter_id": parameter_id} if parameter_id else {}), **extra}


def _validate(request, images):
    errors = []
    if not isinstance(request, dict):
        return ["request must be an object"]
    if not _json_value(request):
        return ["request must contain only finite JSON values"]
    if request.get("schema_version") != "prism.grouping_request.v0.1":
        errors.append("unsupported GroupingRequest schema_version")
    for field in ("request_id", "brief_id", "direction_id", "title"):
        if not _text(request.get(field)):
            errors.append(f"{field} must be a nonempty string")
    mode = request.get("alignment_mode")
    if not isinstance(mode, str) or mode not in MODES:
        errors.append("alignment_mode must be supplied by handshake")
    elif request.get("alignment_label") != MODES[mode][0] or request.get("relation_basis") not in MODES[mode][1]:
        errors.append("alignment_label/relation_basis do not agree with alignment_mode")
    if request.get("design_axis") not in ("ID", "CMF"):
        errors.append("design_axis must be ID or CMF")
    ids = request.get("candidate_image_ids")
    if not _refs(ids):
        errors.append("candidate_image_ids must be a list of nonempty strings")
    elif len(ids) != len(set(ids)):
        errors.append("duplicate candidate_image_ids")
    if "candidate_bindings" in request:
        bindings = request["candidate_bindings"]
        if not isinstance(bindings, list) or not bindings:
            errors.append("candidate_bindings must be a nonempty explicit carrier list when provided")
        else:
            seen_bindings = set()
            for index, binding in enumerate(bindings):
                prefix = f"candidate_bindings[{index}]"
                if not isinstance(binding, dict) or not _text(binding.get("image_id")) or not _carrier(binding.get("object_id")):
                    errors.append(f"{prefix} requires known image_id and object_id")
                    continue
                pair = (binding["image_id"], binding["object_id"])
                if pair in seen_bindings:
                    errors.append(f"{prefix} duplicates an explicit image/object binding")
                seen_bindings.add(pair)
                if _refs(ids) and binding["image_id"] not in ids:
                    errors.append(f"{prefix}.image_id is outside candidate_image_ids")
                if "observation_ids" in binding and not _refs(binding["observation_ids"], nonempty=True):
                    errors.append(f"{prefix}.observation_ids must be a nonempty reference list")
                if "region_refs" in binding:
                    regions = binding["region_refs"]
                    if not isinstance(regions, list) or not regions or any(not _region(r) for r in regions):
                        errors.append(f"{prefix}.region_refs must retain valid original region references")
                    elif any(isinstance(r, dict) and "object_id" in r and r["object_id"] != binding["object_id"] for r in regions):
                        errors.append(f"{prefix}.region_refs conflict with the selected object_id")
    for field in ("preference_refs", "trend_refs", "hypothesis_refs", "comparison_features"):
        if not _refs(request.get(field)):
            errors.append(f"{field} must be a list of nonempty strings")
    for field in ("pending_context_constraints", "scoped_negative_preferences"):
        if field in request and (not isinstance(request[field], list) or not _json_value(request[field])):
            errors.append(f"{field} must be a JSON list when provided")
    for field, value_field in (("required_features", "allowed_values"),
                               ("forbidden_features", "forbidden_values")):
        features = request.get(field)
        if not isinstance(features, list):
            errors.append(f"{field} must be a list")
            continue
        seen = set()
        for index, feature in enumerate(features):
            prefix = f"{field}[{index}]"
            if not isinstance(feature, dict) or not _text(feature.get("parameter_id")):
                errors.append(f"{prefix} must have parameter_id")
                continue
            identity_key = ("constraint_id" if field == "forbidden_features"
                            and request.get("negative_scope_version") == negative_scope.SCOPE_VERSION else "parameter_id")
            identity = feature.get(identity_key)
            if not _text(identity):
                errors.append(f"{prefix}.{identity_key} must be a nonempty string")
            elif identity in seen:
                errors.append(f"duplicate {prefix}.{identity_key}; do not merge different scopes implicitly")
            if isinstance(identity, str):
                seen.add(identity)
            values = feature.get(value_field)
            if not isinstance(values, list) or not values or any(v is None or not _json_value(v) for v in values):
                errors.append(f"{prefix}.{value_field} requires explicit non-null JSON values")
            if not _refs(feature.get("evidence_refs"), nonempty=True):
                errors.append(f"{prefix}.evidence_refs must identify upstream evidence")
    provenance = request.get("provenance")
    if not isinstance(provenance, dict) or provenance.get("mode") not in ("synthetic", "real_evidence"):
        errors.append("request provenance.mode must be synthetic or real_evidence")
    if not isinstance(images, list):
        errors.append("images must be a list of ImageDNA objects")
    else:
        image_ids = []
        for index, record in enumerate(images):
            if not isinstance(record, dict) or not _text(record.get("image_id")):
                errors.append(f"images[{index}] must have an image_id")
            else:
                image_ids.append(record["image_id"])
        if len(image_ids) != len(set(image_ids)):
            errors.append("duplicate ImageDNA image_id")
    return errors


def _image_errors(image, request):
    errors = []
    if image.get("schema_version") != "prism.image_dna.v0.1":
        errors.append("unsupported ImageDNA schema_version")
    if not isinstance(image.get("source_kind"), str) or image.get("source_kind") not in SOURCE_KINDS:
        errors.append("source_kind must come from explicit provenance")
    provenance = image.get("provenance")
    if not isinstance(provenance, dict) or provenance.get("mode") not in ("synthetic", "existing_model_output"):
        errors.append("invalid ImageDNA provenance.mode")
    elif request["provenance"]["mode"] == "real_evidence" and (
            provenance["mode"] == "synthetic" or image.get("source_kind") == "synthetic"):
        errors.append("synthetic ImageDNA cannot support a real_evidence request")
    if not _text(image.get("source_ref")):
        errors.append("source_ref must preserve the original output identity")
    observations = image.get("observations")
    if not isinstance(observations, list):
        return errors + ["observations must be a list"]
    seen = set()
    for index, observation in enumerate(observations):
        prefix = f"observations[{index}]"
        if not isinstance(observation, dict):
            errors.append(f"{prefix} must be an object")
            continue
        oid = observation.get("observation_id")
        if not _text(oid) or oid in seen:
            errors.append(f"{prefix} has missing/duplicate observation_id")
        if isinstance(oid, str):
            seen.add(oid)
        if not _text(observation.get("parameter_id")):
            errors.append(f"{prefix} has no parameter_id")
        state = observation.get("value_status")
        if not isinstance(state, str) or state not in STATUSES:
            errors.append(f"{prefix} has invalid value_status")
        if not _json_value(observation.get("value")):
            errors.append(f"{prefix} has a non-JSON or nonfinite value")
        if state == "known" and observation.get("value") is None:
            errors.append(f"{prefix} has known status with null value")
        if state in ("unknown", "not_applicable") and observation.get("value") is not None:
            errors.append(f"{prefix} has {state} status with non-null value")
        if not _region_carrier_consistent(observation):
            errors.append(f"{prefix}.region_ref.object_id conflicts with object_id")
        if not _refs(observation.get("evidence_refs")):
            errors.append(f"{prefix} has invalid evidence_refs")
    return errors


def _facts(observations, parameter):
    rows = [o for o in observations if o["parameter_id"] == parameter]
    known = [o for o in rows if o["value_status"] == "known" and _grounded(o)]
    na = [o for o in rows if o["value_status"] == "not_applicable" and _grounded(o)]
    uncertain = [o for o in rows if o["value_status"] == "unknown" or not _grounded(o)]
    regions = defaultdict(set)
    for observation in known + na:
        regions[_key(observation["region_ref"])].add(
            (observation["value_status"], _key(observation.get("value"))))
    contradictory = any(len(values) > 1 for values in regions.values())
    return rows, known, na, uncertain, contradictory


def _binding(parameter, rows, role):
    return {"parameter_id": parameter, "role": role,
            "values": _unique(o["value"] for o in rows),
            "observation_ids": sorted(o["observation_id"] for o in rows),
            "region_refs": _unique(o["region_ref"] for o in rows),
            "evidence_refs": sorted({ref for o in rows for ref in o["evidence_refs"]})}


def _candidate_binding_errors(binding, observations):
    rows = [o for o in observations if o.get("object_id") == binding["object_id"]]
    reasons = []
    if not rows:
        return [_reason("candidate_binding_object_missing")]
    by_id = {o["observation_id"]: o for o in observations}
    anchors = rows
    if "observation_ids" in binding:
        anchors = []
        for oid in binding["observation_ids"]:
            o = by_id.get(oid)
            if o is None or o.get("object_id") != binding["object_id"] or not _grounded(o):
                reasons.append(_reason("candidate_binding_observation_unresolved", observation_id=oid))
            else:
                anchors.append(o)
    actual_regions = {_key(o["region_ref"]) for o in anchors if _grounded(o)}
    for region in binding.get("region_refs", []):
        if _key(region) not in actual_regions:
            reasons.append(_reason("candidate_binding_region_unresolved", region_ref=region))
    return reasons


def _forbidden_scope_unresolved(request, feature):
    # CT-001 defines candidate carrier selection, but no machine-readable
    # negative-scope operator. Never infer that scope from carrier selection.
    return ("candidate_bindings" in request
            or any(key in feature for key in ("scope", "object_scope", "conditions", "target_object_ids")))


def _evaluate_carrier(observations, required, forbidden, comparisons):
    conflicts, uncertainties, profiles, bindings, support = [], [], [], [], []
    for feature in required:
        parameter = feature["parameter_id"]
        rows, known, na, unclear, contradictory = _facts(observations, parameter)
        allowed = {_key(v) for v in feature["allowed_values"]}
        matches = [o for o in known if _key(o["value"]) in allowed]
        if contradictory:
            uncertainties.append(_reason("contradictory_observations", parameter))
        elif matches:
            profiles.append({"parameter_id": parameter, "role": "required", "state": "known",
                             "values": _unique(o["value"] for o in matches)})
            bindings.append(_binding(parameter, matches, "required"))
            support.extend(matches)
        elif not rows or unclear:
            uncertainties.append(_reason("required_feature_unknown_or_unbound", parameter))
        else:
            conflicts.append(_reason("required_feature_mismatch" if known else "required_feature_not_applicable", parameter,
                                     observed_values=_unique(o["value"] for o in known)))
    for feature in forbidden:
        parameter = feature["parameter_id"]
        rows, known, na, unclear, contradictory = _facts(observations, parameter)
        prohibited = {_key(v) for v in feature["forbidden_values"]}
        if any(_key(o["value"]) in prohibited for o in known):
            conflicts.append(_reason("known_forbidden_feature", parameter))
        elif not rows or unclear or contradictory or (known and na):
            uncertainties.append(_reason("forbidden_absence_unverified", parameter))
        else:
            bindings.append({**_binding(parameter, known + na, "forbidden_check"),
                             "check": "no_forbidden_value_in_declared_carrier_observations"})
    for parameter in comparisons:
        rows, known, na, unclear, contradictory = _facts(observations, parameter)
        if not rows or unclear or contradictory or (known and na):
            uncertainties.append(_reason("comparison_feature_unknown_or_conflicting", parameter))
        elif known:
            profiles.append({"parameter_id": parameter, "role": "comparison", "state": "known",
                             "values": _unique(o["value"] for o in known)})
            bindings.append(_binding(parameter, known, "comparison"))
            support.extend(known)
        else:
            # This applicability marker never appears as positive shared evidence.
            profiles.append({"parameter_id": parameter, "role": "comparison", "state": "not_applicable", "values": []})
            bindings.append({**_binding(parameter, na, "comparison_applicability"), "values": []})
    return conflicts, uncertainties, profiles, bindings, support


def cluster_candidates(request, images):
    """Return CandidateClusters; invalid/ungrounded input returns needs_input.

    This checks supplied structured evidence. It does not inspect pixels,
    authenticate a citation, infer preferences, or verify real-world truth.
    """
    request = deepcopy(request)
    images = deepcopy(images)
    header = request if isinstance(request, dict) else {}
    result = {"schema_version": "prism.candidate_clusters.v0.1", "algorithm_version": VERSION,
              "request_id": header.get("request_id"), "alignment_mode": header.get("alignment_mode"),
              "alignment_label": header.get("alignment_label"), "relation_basis": header.get("relation_basis"),
              "brief_id": header.get("brief_id"), "direction_id": header.get("direction_id"),
              "title": header.get("title"), "design_axis": header.get("design_axis"),
              "preference_refs": header.get("preference_refs", []), "trend_refs": header.get("trend_refs", []),
              "hypothesis_refs": header.get("hypothesis_refs", []),
              "clusters": [], "boundary_members": [], "excluded": [], "carrier_diagnostics": [],
              "status": "needs_input", "provenance": header.get("provenance", {}),
              "method": {"name": "same_carrier_exact_profile", "value_comparison": "typed_exact_json",
                         "forbidden_scope": "image_conflicts_then_carrier_clearance",
                         "selection": "all_supported_carriers_in_requested_pool", "model_calls": 0,
                         "pixel_verification": "not_performed", "customer_validation": "not_performed"}}
    for field in ("candidate_bindings", "pending_context_constraints", "scoped_negative_preferences",
                  "negative_scope_version", "negative_audit_ids",
                  "theme_id", "theme_selection_id", "target_user_ids", "hypotheses", "semantic_status"):
        if field in header:
            result[field] = deepcopy(header[field])
    errors = _validate(request, images)
    if not errors and not request["required_features"]:
        errors = ["At least one evidence-linked required feature is necessary; no catch-all cluster is permitted."]
    if not errors:
        forbidden_values = {f["parameter_id"]: {_key(v) for v in f["forbidden_values"]}
                            for f in request["forbidden_features"] if not _forbidden_scope_unresolved(request, f)}
        for feature in request["required_features"]:
            if {_key(v) for v in feature["allowed_values"]} <= forbidden_values.get(feature["parameter_id"], set()):
                errors.append(f"Required values are all forbidden: {feature['parameter_id']}")
    if errors:
        result["input_errors"] = errors
        return result
    required = sorted(request["required_features"], key=lambda f: f["parameter_id"])
    forbidden = sorted(request["forbidden_features"], key=lambda f: f["parameter_id"])
    effective_forbidden, scope_uncertainties = [], []
    ct002 = negative_scope.requested(request)
    scoped_rules = []
    if ct002:
        plan = negative_scope.compile_scope(request, {im["image_id"]: im for im in images}, _key)
        scoped_rules, scope_uncertainties = plan["rules"], plan["pending"]
        result["negative_scope_plan"] = deepcopy(plan)
        result["forbidden_features"] = deepcopy(request["forbidden_features"])
        result["method"]["forbidden_scope"] = "ct002_explicit_image_or_candidate_carrier"
    else:
        for feature in forbidden:
            if _forbidden_scope_unresolved(request, feature):
                scope_uncertainties.append(_reason("forbidden_scope_unresolved", feature["parameter_id"],
                                                   evidence_refs=feature["evidence_refs"]))
            else:
                effective_forbidden.append(feature)
        if request.get("pending_context_constraints"):
            scope_uncertainties.append(_reason("pending_context_constraints", count=len(request["pending_context_constraints"])))
        for index, negative in enumerate(request.get("scoped_negative_preferences", [])):
            if isinstance(negative, dict) and negative.get("context_state") == "not_applicable":
                continue  # Preserve the upstream explicit context exclusion; do not reinterpret it.
            scope_uncertainties.append(_reason("scoped_negative_scope_unresolved", constraint_index=index,
                preference_id=negative.get("preference_id") if isinstance(negative, dict) else None))
    if scope_uncertainties:
        result["unresolved_request_constraints"] = deepcopy(scope_uncertainties)
        result["deferred_forbidden_features"] = [deepcopy(f) for f in forbidden if ct002 or _forbidden_scope_unresolved(request, f)]
        result["method"]["forbidden_scope"] = "unresolved_constraints_remain_boundary"
    comparisons = sorted(set(request["comparison_features"]))
    req_parameters = {f["parameter_id"] for f in required}
    by_id = {image["image_id"]: image for image in images}
    scoped = "candidate_bindings" in request
    selected_bindings = defaultdict(dict)
    for binding in request.get("candidate_bindings", []):
        selected_bindings[binding["image_id"]][binding["object_id"]] = binding
    if scoped:
        result["method"]["selection"] = "explicit_candidate_image_object_bindings"
    groups, grounded_required = {}, 0

    def boundary(image_id, reasons, object_id=None, **extra):
        result["boundary_members"].append({"image_id": image_id, "object_id": object_id,
            "reason": "; ".join(r["code"] for r in reasons), "reasons": reasons, **extra})

    for image_id in sorted(request["candidate_image_ids"]):
        if scoped and image_id not in selected_bindings:
            result["excluded"].append({"image_id": image_id, "reason": "outside_candidate_bindings",
                                       "reasons": [_reason("outside_candidate_bindings")]})
            continue
        image = by_id.get(image_id)
        if image is None:
            boundary(image_id, [_reason("missing_image_dna")])
            continue
        errors = _image_errors(image, request)
        if errors:
            boundary(image_id, [_reason("invalid_image_dna", details=errors)])
            continue
        observations = image["observations"]
        selected_observations = [o for o in observations if not scoped or o.get("object_id") in selected_bindings[image_id]]
        grounded_required += sum(o["parameter_id"] in req_parameters and o["value_status"] == "known"
                                 and _grounded(o) for o in selected_observations)
        hard_conflicts, global_uncertainty = [], deepcopy(scope_uncertainties)
        for feature in effective_forbidden:
            values = {_key(v) for v in feature["forbidden_values"]}
            for o in observations:
                if o["parameter_id"] != feature["parameter_id"]:
                    continue
                if o["value_status"] == "known" and _key(o["value"]) in values and _grounded(o):
                    hard_conflicts.append(_reason("known_forbidden_feature", feature["parameter_id"],
                        object_id=o["object_id"], observation_id=o["observation_id"],
                        region_ref=o["region_ref"], evidence_refs=o["evidence_refs"]))
                elif o["value_status"] == "unknown" or not _grounded(o):
                    global_uncertainty.append(_reason("forbidden_absence_unverified", feature["parameter_id"],
                                                     observation_id=o["observation_id"]))
        image_scope_checks = []
        if ct002:
            c, u, image_scope_checks = negative_scope.check_image(scoped_rules, image, _facts, _key, _grounded)
            hard_conflicts.extend(c)
            global_uncertainty.extend(u)
        if hard_conflicts:
            result["excluded"].append({"image_id": image_id, "reason": "known_forbidden_feature", "reasons": hard_conflicts})
            continue
        carriers = defaultdict(list)
        unbound_required = []
        for o in selected_observations:
            if _carrier(o.get("object_id")):
                carriers[o["object_id"]].append(o)
            if o["parameter_id"] in req_parameters and not _grounded(o):
                unbound_required.append(o["observation_id"])
        carriers = {oid: rows for oid, rows in carriers.items()
                    if any(o["parameter_id"] in req_parameters for o in rows)}
        global_uncertainty = _unique(global_uncertainty)
        admitted, possible, image_conflicts = 0, False, []
        invalid_bound_objects = set()
        if scoped:
            for oid, selected in sorted(selected_bindings[image_id].items()):
                binding_errors = _candidate_binding_errors(selected, observations)
                if binding_errors:
                    invalid_bound_objects.add(oid)
                    possible = True
                    boundary(image_id, binding_errors, oid, upstream_candidate_binding=selected)
            for oid in sorted({o["object_id"] for o in observations if _carrier(o.get("object_id"))} - set(selected_bindings[image_id])):
                result["carrier_diagnostics"].append({"image_id": image_id, "object_id": oid, "status": "outside_scope",
                                                     "reasons": [_reason("outside_candidate_bindings")]})
        for object_id, rows in sorted(carriers.items()):
            if object_id in invalid_bound_objects:
                continue
            conflicts, uncertainties, profile, bindings, support = _evaluate_carrier(rows, required, effective_forbidden, comparisons)
            carrier_scope_checks = []
            if ct002:
                c, u, carrier_scope_checks = negative_scope.check_carrier(scoped_rules, image_id, object_id, rows, _facts, _key)
                conflicts.extend(c)
                uncertainties.extend(u)
            if conflicts:
                image_conflicts.extend(conflicts)
                result["carrier_diagnostics"].append({"image_id": image_id, "object_id": object_id,
                                                     "status": "excluded", "reasons": conflicts + uncertainties})
                continue
            uncertainties.extend(global_uncertainty)
            if uncertainties:
                possible = True
                boundary(image_id, uncertainties, object_id, known_bindings=bindings)
                continue
            admitted += 1
            signature = _key(profile)
            group = groups.setdefault(signature, {"profile": profile, "members": []})
            member = {"image_id": image_id, "object_id": object_id,
                      "observation_ids": sorted({o["observation_id"] for o in support}),
                      "region_refs": _unique(o["region_ref"] for o in support), "feature_bindings": bindings,
                      "source_kind": image["source_kind"], "source_ref": image["source_ref"],
                      "image_path": image.get("image_path"), "provenance": image["provenance"]}
            if scoped:
                member["upstream_candidate_binding"] = deepcopy(selected_bindings[image_id][object_id])
            if ct002:
                member["negative_constraint_checks"] = _unique(image_scope_checks + carrier_scope_checks)
            group["members"].append(member)
        if unbound_required:
            possible = True
            boundary(image_id, [_reason("unbound_required_evidence", observation_ids=sorted(unbound_required))])
        if not carriers:
            possible = True
            if not unbound_required:
                boundary(image_id, [_reason("no_identifiable_carrier")])
        if not admitted and not possible:
            result["excluded"].append({"image_id": image_id, "reason": "no_carrier_satisfies_constraints" if ct002 else "no_carrier_satisfies_required_features",
                                       "reasons": _unique(image_conflicts)})
        if not admitted and len(carriers) > 1:
            matches_somewhere = all(any(o["parameter_id"] == f["parameter_id"] and o["value_status"] == "known"
                and _grounded(o) and _key(o["value"]) in {_key(v) for v in f["allowed_values"]}
                for o in selected_observations) for f in required)
            same_carrier_matches = any(all(any(o["parameter_id"] == f["parameter_id"] and o["value_status"] == "known"
                and _grounded(o) and _key(o["value"]) in {_key(v) for v in f["allowed_values"]}
                for o in rows) for f in required) for rows in carriers.values())
            if matches_somewhere and not same_carrier_matches:
                result["carrier_diagnostics"].append({"image_id": image_id, "object_id": None,
                    "status": "not_combined", "reasons": [_reason("cross_carrier_evidence_cannot_be_combined")]})

    upstream_refs = {ref for f in required + forbidden for ref in f["evidence_refs"]}
    profiles_by_field = defaultdict(set)
    for group in groups.values():
        for part in group["profile"]:
            profiles_by_field[(part["role"], part["parameter_id"])].add(_key([part["state"], part["values"]]))
    for signature, group in sorted(groups.items()):
        cluster_id = "C-" + hashlib.sha256(_key([request["request_id"], signature]).encode("utf-8")).hexdigest()[:16]
        members = sorted(group["members"], key=lambda m: (m["image_id"], m["object_id"]))
        shared = {}
        for part in group["profile"]:
            if part["state"] != "known":
                continue
            for value in part["values"]:
                feature_key = (part["parameter_id"], _key(value))
                feature = shared.setdefault(feature_key, {"parameter_id": part["parameter_id"], "value": value,
                                                         "roles": [], "supporting_members": []})
                feature["roles"].append(part["role"])
        for feature in shared.values():
            for member in members:
                rows = [o for o in by_id[member["image_id"]]["observations"]
                        if o["observation_id"] in member["observation_ids"] and o["parameter_id"] == feature["parameter_id"]
                        and _key(o["value"]) == _key(feature["value"])]
                feature["supporting_members"].append({"image_id": member["image_id"], "object_id": member["object_id"],
                    "observation_ids": sorted(o["observation_id"] for o in rows),
                    "region_refs": _unique(o["region_ref"] for o in rows),
                    "evidence_refs": sorted({ref for o in rows for ref in o["evidence_refs"]})})
        distinctions = [part for part in group["profile"]
                        if len(profiles_by_field[(part["role"], part["parameter_id"])]) > 1]
        terms = "; ".join(f"{f['parameter_id']}={_key(f['value'])}" for f in shared.values())
        distinction_text = ("组间区别见 distinguishing_features 中的实际值或适用状态。" if distinctions
                            else "本次没有其他完整已知组合可供组间比较。")
        result["clusters"].append({"cluster_id": cluster_id, "shared_features": list(shared.values()),
            "members": members, "comparison_profile": group["profile"], "distinguishing_features": distinctions,
            "explanation": "各成员在同一载体上满足核心条件，共同可见特征：" + terms + "。" + distinction_text,
            "evidence_refs": sorted(upstream_refs | {ref for member in members for binding in member["feature_bindings"]
                                                     for ref in binding["evidence_refs"]}
                                    | {ref for member in members for check in member.get("negative_constraint_checks", [])
                                       for ref in check["evidence_refs"]}),
            "unique_image_count": len({m["image_id"] for m in members}), "carrier_count": len(members),
            "singleton": len({m["image_id"] for m in members}) == 1})
    result["clusters"].sort(key=lambda c: c["cluster_id"])
    for field in ("boundary_members", "excluded", "carrier_diagnostics"):
        for entry in result[field]:
            if "reasons" in entry:
                entry["reasons"] = _unique(entry["reasons"])
        result[field] = _unique(result[field])
    result["status"] = "needs_input" if not grounded_required else "partial" if result["boundary_members"] else "complete"
    if not grounded_required:
        result["input_errors"] = ["No known required-feature observation has a carrier, region and evidence reference."]
    result["summary"] = {"candidate_images": len(request["candidate_image_ids"]), "clusters": len(result["clusters"]),
        "clustered_images": len({m["image_id"] for c in result["clusters"] for m in c["members"]}),
        "carrier_memberships": sum(len(c["members"]) for c in result["clusters"]),
        "boundary_images": len({m["image_id"] for m in result["boundary_members"]}),
        "excluded_images": len(result["excluded"]), "grounded_required_observations": grounded_required,
        "unused_input_image_ids": sorted(set(by_id) - set(request["candidate_image_ids"]))}
    return result
