"""Scope-safe local-CMF transport; the frozen clustering engine stays unchanged."""
from .bridge import load_verified_projection, prepare_guarded_view, prepare_pid_view
from .ledger import reconcile_inventory

VERSION = "local-cmf-bridge-v1"
__all__ = ["VERSION", "load_verified_projection", "prepare_guarded_view", "prepare_pid_view", "reconcile_inventory"]
