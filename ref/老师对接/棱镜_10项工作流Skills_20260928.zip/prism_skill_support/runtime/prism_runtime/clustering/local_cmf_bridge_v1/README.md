# Local CMF consumption sidecar v1

This is a separate transport/accounting layer. The ten frozen clustering 0.2.0 source files, its exact-value matching, CT-001 and CT-002 remain unchanged. It makes no model/API calls and never creates an H02 approval.

## Input sequence

1. Root obtains a persisted `cmf.image-dna.json` through `dna.local_cmf_v1` primary/review acceptance.
2. The sidecar calls `pipeline.verify_projection(path)`. It requires the owner's actual reconstruction and matching file identity; an `admitted` cache or shape-only schema check is insufficient.
3. For real references, the sidecar revalidates the source-bound T01 registry and original corpus identity. A request cannot exceed the existing nine registered images. Calibration and the other 51 trend images cannot enter this reference request merely because CMF or D03 passed.
4. Root must first obtain a valid H02 request via the handshake owner, including its actual selection/admission checks. The sidecar checks request identity fields but **does not authenticate designer confirmation or replace `validate_selection`**. User-authorized AI decisions retain `user_delegated_ai` provenance; neither broad H01 intent nor reference qualification alone is that H02 decision.
5. Prepare guarded transport, then Root invokes the unchanged engine with that view.

```python
from prism_runtime.clustering import cluster_candidates
from prism_runtime.clustering.local_cmf_bridge_v1 import prepare_guarded_view

# request must already be produced/validated by the handshake owner.
prepared = prepare_guarded_view(request, projection_path, inventory_path=inventory_path)
result = cluster_candidates(request, [prepared["image_dna"]])
```

For multiple images, prepare each original request candidate and pass their views together. Do not silently omit a missing/failed projection; keep it pending and record its reason. Do not feed these transport guards back into an LLM as visual evidence.

Before H02 compilation, `prepare_pid_view(projection_path, parameter_ids)` returns the same scope-aware transport for an explicit list of original PIDs. It can inspect calibration records for proposal-only work without relabelling them. `audit.original_admission` preserves the full ledger. It creates no GroupingRequest, reference qualification, user confirmation or execution permission. Final executable requests must be revalidated with `prepare_guarded_view` using all their required/comparison/forbidden fields after the handshake owner's gates. Root's expressly delegated choices must retain `user_delegated_ai` origin, not human-designer approval.

Root has explicitly accepted v1.1's isolation/dependency protocol (19 independent checks plus associated regressions). `accepted_producers.json` pins that approval and exact source hashes. The loader explicitly registers only `r17-local-cmf-v1` and `r17-local-cmf-v1.1`, verifies the relevant source pins before importing the fixed owner verifier, and requires matching profile declarations and persisted reconstruction. Unknown versions or changed dependencies fail without downgrade/fallback. v1.1's real reviewed projection remains a separate data qualification; 119 program candidates do not become a visual PASS. Original full-R17 errors/isolation ledgers remain visible; local usefulness never rewrites full216 PASS.

## Why the guards exist

The producer exports only dual-passed known CMF observations. It also retains all original objects and the full CMF audit. Passing only the sparse positives to the old engine could omit an uncertain background and accidentally certify a whole-image negative condition.

The sidecar preserves every positive observation unchanged. For each original carrier and each field actually used by this request, absent or withheld coverage is represented by an explicitly named consumer guard: `value_status=unknown`, `value=null`, `region_ref=null`, `evidence_refs=[]`, `not_a_source_observation=true`. A guard never supplies a positive feature, a similarity match or evidence. Its metadata points to the original state/disposition or states that carrier-field coverage is missing. Unknown, NA, contradicted, unsupported and missing are retained in the audit; none is converted into a trusted absence.

The guarded view is **not a producer export**. Source-only `cmf_admission`, dictionary counts and source-validation descriptors are not incorrectly advertised on the enriched observation array. The returned audit retains the original admission ledger, and `consumer_scope` records the derivation and original projection identity. Original files and hashes are unchanged.

Unrelated unknown fields do not block a usable local core. A known admitted carrier can coexist with boundary carriers. Explicit whole-image negative scope remains pending if any relevant declared carrier lacks qualified coverage. The conservative treatment includes original frame/container objects; it does not invent that they are optically irrelevant. H02 must not quietly substitute carrier scope for a requested image scope.

All original PIDs, values, references and dependency identities remain unchanged. Numeric tolerance, new semantic distance, subset matching and implicit changes of scale are not introduced.

## CLI and audit

```text
python -B -X utf8 -m prism_runtime.clustering.local_cmf_bridge_v1 prepare-view --request REQUEST.json --projection PATH/cmf.image-dna.json --inventory INVENTORY.json --output-dir NEW_DIR
python -B -X utf8 -m prism_runtime.clustering.local_cmf_bridge_v1 prepare-pids --projection PATH/cmf.image-dna.json --parameter-ids COL-006 OPT-002 --output-dir NEW_DIR
python -B -X utf8 -m prism_runtime.clustering.local_cmf_bridge_v1 ledger --inventory INVENTORY.json --projection-index INDEX.json --grouping-runs RUNS.json --output-dir NEW_DIR
```

`INDEX.json` maps each available original image ID to its persisted projection path. Missing entries remain pending. `RUNS.json` is optional and contains `{request, result}` pairs from Root's owner-validated H02 executions; result may be null when a request is pending. The ledger is reporting, not a new selection authority. It rechecks positive member IDs against producer-qualified observations and rejects pool expansion.

Every original image has one primary disposition: local_pending, parsed_not_reference_pool, excluded, ungrouped, singleton or grouped. The counts total 120. Per-request boundaries/exclusions and carrier-level audit remain separate, so one image can be grouped while retaining a boundary carrier. Grouping and display coverage are not parsing accuracy.

`load_verified_projection(path)` can inspect any genuine source kind for auditing. `prepare_guarded_view` only prepares qualified trend references (or explicitly synthetic producer fixtures); it cannot turn a calibration record into a trend reference.

## Verification limits

Synthetic guard/accounting tests and the official synthetic persistence control are in the separate closure delivery. The persistence control reuses the owner's historical R17 camera example and supplies an explicitly ARTIFICIAL review. It verifies codecs, hashes, dependencies and consumer transport, not visual correctness or a real CMF pass. There are no owner model calls.

The sidecar still depends on upstream image/region and visual-review quality. Exact grouping can remain sparse. Source-bound reference qualification is not H02 selection, semantic truth or business-effect approval. Real reviewed projections and actual H02 scope remain Root-owned prerequisites.
