"""Local verification/transport preparation only. No grouping or approval."""
import argparse
import json
from pathlib import Path

from . import prepare_guarded_view, prepare_pid_view, reconcile_inventory


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare-view")
    prepare.add_argument("--request", required=True, type=Path)
    prepare.add_argument("--projection", required=True, type=Path)
    prepare.add_argument("--inventory", type=Path)
    prepare.add_argument("--output-dir", required=True, type=Path)
    pids = sub.add_parser("prepare-pids")
    pids.add_argument("--projection", required=True, type=Path)
    pids.add_argument("--parameter-ids", required=True, nargs="+")
    pids.add_argument("--output-dir", required=True, type=Path)
    ledger = sub.add_parser("ledger")
    ledger.add_argument("--inventory", required=True, type=Path)
    ledger.add_argument("--projection-index", required=True, type=Path)
    ledger.add_argument("--grouping-runs", type=Path)
    ledger.add_argument("--output-dir", required=True, type=Path)
    args = p.parse_args()
    output = args.output_dir.resolve()
    if output.exists() and any(output.iterdir()):
        p.error("Choose a new empty output directory")
    read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
    if args.command in ("prepare-view", "prepare-pids"):
        if args.command == "prepare-pids":
            result = prepare_pid_view(args.projection, args.parameter_ids)
        else:
            result = prepare_guarded_view(read(args.request), args.projection, inventory_path=args.inventory)
        summary = {"status": "transport_prepared", "clustering_executed": False,
                   "positive_observations": len(result["audit"]["positive_observation_ids"]), "guards": len(result["audit"]["guards"])}
        filename = "guarded-view.json"
    else:
        result = reconcile_inventory(args.inventory, read(args.projection_index), read(args.grouping_runs) if args.grouping_runs else [])
        summary, filename = result["summary"], "ledger.json"
    output.mkdir(parents=True, exist_ok=True)
    (output / filename).write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({**summary, "output": str(output / filename)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
