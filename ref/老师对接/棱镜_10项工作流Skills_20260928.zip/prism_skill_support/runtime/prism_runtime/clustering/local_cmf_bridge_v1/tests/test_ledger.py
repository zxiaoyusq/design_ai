"""Accounting fixtures; authority/source replay is verified separately."""
from collections import Counter
from unittest.mock import patch
import unittest

from prism_runtime.clustering.local_cmf_bridge_v1 import ledger
from prism_runtime.clustering.local_cmf_bridge_v1.bridge import _match_corpus_identity


def inventory_fixture():
    records = {f"I{i:03d}": {"image_id": f"I{i:03d}", "source_kind": "trend" if i <= 60 else "calibration"}
               for i in range(1, 121)}
    rows = [{**r, "original_image": {"path": "synthetic", "sha256": "fixture"}} for r in records.values()]
    return {"records": rows}, records, {"eligible_image_ids": [f"I{i:03d}" for i in range(1, 10)]}


def document(iid, kind):
    return {"image_id": iid, "source_kind": kind, "objects": [{"object_id": "body"}, {"object_id": "other"}],
            "observations": [{"observation_id": "positive", "object_id": "body"}],
            "cmf_admission": {"all_cmf_units": [
                {"observation_id": "positive", "object_id": "body", "admitted": True, "disposition": "accepted"},
                {"observation_id": "unknown", "object_id": "other", "admitted": False, "disposition": "unknown"}]}}


class LedgerTests(unittest.TestCase):
    def run_fixture(self, index, runs=()):
        fixture = inventory_fixture()
        def load(path):
            return document(path, fixture[1][path]["source_kind"]), {"passed": True, "fixture_only": True}
        with patch.object(ledger, "_inventory_data", return_value=fixture), \
             patch.object(ledger, "load_verified_projection", side_effect=load), \
             patch.object(ledger, "_match_corpus_identity"):
            return ledger.reconcile_inventory("synthetic-inventory", index, runs)

    def test_complete_coverage_does_not_mean_all_parsed(self):
        result = self.run_fixture({})
        self.assertEqual(len(result["records"]), 120)
        self.assertEqual(result["summary"]["primary_disposition_counts"], {"local_pending": 120})
        self.assertEqual(result["summary"]["verified_projection_count"], 0)

    def test_nonreference_and_calibration_do_not_upgrade_when_parsed(self):
        result = self.run_fixture({"I001": "I001", "I010": "I010", "I061": "I061"})
        rows = {r["image_id"]: r for r in result["records"]}
        self.assertEqual(rows["I001"]["primary_disposition"], "ungrouped")
        self.assertEqual(rows["I010"]["primary_disposition"], "parsed_not_reference_pool")
        self.assertEqual(rows["I061"]["primary_disposition"], "parsed_not_reference_pool")
        self.assertEqual(rows["I061"]["source_kind"], "calibration")
        self.assertEqual(result["summary"]["source_counts"], {"trend": 60, "calibration": 60})

    def test_singleton_and_boundary_can_coexist_without_double_counting_image(self):
        request = {"request_id": "R", "candidate_image_ids": ["I001"], "theme_selection_id": "fixture-selection",
                   "admission_snapshot": "fixture-snapshot", "alignment_mode": "consensus"}
        result = {"request_id": "R", "alignment_mode": "consensus", "status": "partial",
                  "clusters": [{"cluster_id": "C", "members": [{"image_id": "I001", "object_id": "body", "observation_ids": ["positive"]}]}],
                  "boundary_members": [{"image_id": "I001", "object_id": "other", "reason": "unknown"}], "excluded": []}
        report = self.run_fixture({"I001": "I001"}, [{"request": request, "result": result}])
        row = report["records"][0]
        self.assertEqual(row["primary_disposition"], "singleton")
        self.assertTrue(row["has_boundary_carriers"])
        self.assertEqual(sum(report["summary"]["primary_disposition_counts"].values()), 120)

    def test_nonregistered_request_is_rejected_even_without_output(self):
        with self.assertRaises(ValueError):
            self.run_fixture({}, [{"request": {"request_id": "R", "candidate_image_ids": ["I010"]}, "result": None}])

    def test_calibration_identity_cannot_be_relabelled(self):
        with self.assertRaises(ValueError):
            _match_corpus_identity({"image_id": "I061", "source_kind": "trend"},
                                   {"I061": {"source_kind": "calibration"}})


if __name__ == "__main__":
    unittest.main()
