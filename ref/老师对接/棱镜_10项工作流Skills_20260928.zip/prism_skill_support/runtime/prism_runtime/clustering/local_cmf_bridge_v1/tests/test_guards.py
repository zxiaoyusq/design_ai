"""Synthetic guard logic only; persisted producer replay is a separate example."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from prism_runtime.clustering import cluster_candidates
from prism_runtime.clustering.fixtures import image, request
from prism_runtime.clustering.local_cmf_bridge_v1.bridge import _derive_view, load_verified_projection
from prism_runtime.clustering.scope_examples import scope_example


def projection(background_status="unknown", *, body_status="accepted"):
    spec, original = scope_example()
    doc = original[0]
    doc["objects"] = [{"object_id": oid, "region": [0, 0, 1, 1]} for oid in ("body", "background")]
    positives, units = [], []
    for o in doc["observations"]:
        o.update(reference_object_id=o["object_id"], dependency_object_ids=[o["object_id"]], dependency_observation_ids=[])
        accepted = o["object_id"] == "body" and body_status == "accepted"
        state = "known" if accepted or background_status == "contradicted" else "unknown"
        review = {"verdict": "supported" if accepted else "contradicted" if background_status == "contradicted" else "uncertain",
                  "carrier_ok": True, "reference_ok": True, "origin_ok": True, "evidence": "SYNTHETIC ONLY"}
        unit = {**deepcopy(o), "value_status": state, "value": o["value"] if state == "known" else None,
                "admitted": accepted, "program_eligible": accepted, "program_errors": [],
                "disposition": "accepted" if accepted else background_status, "model_review": review}
        units.append(unit)
        if accepted:
            positives.append(o)
    doc["observations"] = positives
    doc["cmf_admission"] = {"projection_only": True, "requires_scope_aware_consumer": True,
        "all_original_objects_preserved": True, "full_image_admission": False, "complete_216_visual_qualified": False,
        "only_reviewed_known_in_observations": True, "all_cmf_units": units,
        "not_checked_parameter_ids": [], "out_of_scope_parameter_ids": []}
    return spec, doc


class GuardTests(unittest.TestCase):
    def test_local_body_can_pass_while_background_remains_unavailable(self):
        spec, doc = projection()
        view = _derive_view(spec, doc)
        result = cluster_candidates(spec, [view["image_dna"]])
        self.assertEqual(result["summary"]["clustered_images"], 1)
        self.assertTrue(any(g["object_id"] == "background" for g in view["audit"]["guards"]))

    def test_admitted_and_boundary_carriers_can_coexist_in_one_image(self):
        spec, doc = projection()
        spec["candidate_bindings"].append({"image_id": doc["image_id"], "object_id": "background"})
        result = cluster_candidates(spec, [_derive_view(spec, doc)["image_dna"]])
        self.assertEqual(result["summary"]["clustered_images"], 1)
        self.assertTrue(any(m.get("object_id") == "background" for m in result["boundary_members"]))

    def test_three_alignment_modes_and_request_are_preserved(self):
        for mode in ("consensus", "extension", "exploration"):
            spec, doc = projection()
            mode_request, _ = scope_example(mode=mode)
            for field in ("alignment_mode", "alignment_label", "relation_basis", "hypothesis_refs"):
                spec[field] = mode_request[field]
            original = deepcopy(spec)
            result = cluster_candidates(spec, [_derive_view(spec, doc)["image_dna"]])
            self.assertEqual(spec, original)
            self.assertEqual(result["alignment_mode"], mode)
            self.assertEqual(result["relation_basis"], original["relation_basis"])
            self.assertEqual(result["summary"]["clustered_images"], 1)

    def test_sparse_projection_cannot_certify_whole_image_absence(self):
        spec, doc = projection()
        spec["forbidden_features"][0]["scope"] = {"kind": "image", "status": "resolved",
            "image_ids": spec["candidate_image_ids"], "evidence_refs": ["synthetic:scope"]}
        self.assertEqual(cluster_candidates(spec, [doc])["summary"]["clustered_images"], 1)
        guarded = cluster_candidates(spec, [_derive_view(spec, doc)["image_dna"]])
        self.assertFalse(guarded["clusters"])
        self.assertTrue(guarded["boundary_members"])

    def test_unreviewed_known_value_does_not_become_a_confident_conflict(self):
        spec, doc = projection("contradicted")
        spec["forbidden_features"][0]["scope"] = {"kind": "image", "status": "resolved",
            "image_ids": spec["candidate_image_ids"], "evidence_refs": ["synthetic:scope"]}
        result = cluster_candidates(spec, [_derive_view(spec, doc)["image_dna"]])
        self.assertFalse(result["clusters"])
        self.assertFalse(result["excluded"])
        self.assertTrue(result["boundary_members"])

    def test_na_is_not_reintroduced_as_negative_clearance(self):
        spec, doc = projection()
        for u in doc["cmf_admission"]["all_cmf_units"]:
            if u["object_id"] == "background":
                u.update(value_status="not_applicable", disposition="not_applicable")
        guards = _derive_view(spec, doc)["audit"]["guards"]
        self.assertTrue(all(g["value_status"] == "unknown" and g["value"] is None for g in guards))
        self.assertTrue(any(r.get("original_value_status") == "not_applicable" for g in guards for r in g["unavailable_reasons"]))

    def test_empty_carrier_inventory_coverage_is_not_silently_omitted(self):
        spec, doc = projection()
        doc["objects"].append({"object_id": "unobserved", "region": [0, 0, 1, 1]})
        view = _derive_view(spec, doc)
        self.assertTrue(any(g["object_id"] == "unobserved" for g in view["audit"]["guards"]))

    def test_all_unknown_never_becomes_successful_group(self):
        spec, doc = projection(body_status="unknown")
        result = cluster_candidates(spec, [_derive_view(spec, doc)["image_dna"]])
        self.assertEqual(result["status"], "needs_input")
        self.assertFalse(result["clusters"])

    def test_positives_and_input_are_unchanged_and_guards_cannot_be_evidence(self):
        spec, doc = projection()
        before = deepcopy(doc)
        prepared = _derive_view(spec, doc)
        self.assertEqual(doc, before)
        original_ids = {o["observation_id"] for o in doc["observations"]}
        view = prepared["image_dna"]
        self.assertEqual([o for o in view["observations"] if o["observation_id"] in original_ids], doc["observations"])
        self.assertTrue(all(g["evidence_refs"] == [] and g["not_a_source_observation"] for g in prepared["audit"]["guards"]))
        self.assertNotIn("cmf_admission", view)
        result = cluster_candidates(spec, [view])
        self.assertTrue(all(set(m["observation_ids"]) <= original_ids for c in result["clusters"] for m in c["members"]))

    def test_dependency_failure_or_changed_original_cannot_be_promoted(self):
        for corruption in ("dependency", "value", "review"):
            spec, doc = projection()
            u = doc["cmf_admission"]["all_cmf_units"][0]
            if corruption == "dependency":
                u["dependency_observation_ids"] = ["missing"]
            elif corruption == "value":
                doc["observations"][0]["value"] = "changed"
            else:
                u["model_review"]["carrier_ok"] = False
            with self.assertRaises(ValueError): _derive_view(spec, doc)

    def test_request_field_outside_original_dictionary_is_rejected(self):
        spec, doc = projection()
        spec["comparison_features"].append("invented:field")
        with self.assertRaises(ValueError): _derive_view(spec, doc)

    def test_unknown_versions_do_not_import_or_fall_back(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "cmf.image-dna.json"
            for profile in ("not-a-supported-producer", "r17-local-cmf-v99"):
                path.write_text(json.dumps({"provenance": {"parser_version": profile},
                                            "cmf_admission": {"profile": profile}}), encoding="utf-8")
                with patch("prism_runtime.clustering.local_cmf_bridge_v1.bridge.importlib.import_module") as imported:
                    with self.assertRaises(ValueError): load_verified_projection(path)
                    imported.assert_not_called()

    def test_changed_registered_dependency_is_rejected_before_import(self):
        from prism_runtime.clustering.local_cmf_bridge_v1.bridge import _registered_verifier
        with patch("prism_runtime.clustering.local_cmf_bridge_v1.bridge._identity", return_value={"path": "changed", "sha256": "wrong"}), \
             patch("prism_runtime.clustering.local_cmf_bridge_v1.bridge.importlib.import_module") as imported:
            with self.assertRaises(ValueError): _registered_verifier("r17-local-cmf-v1.1")
            imported.assert_not_called()


if __name__ == "__main__":
    unittest.main()
