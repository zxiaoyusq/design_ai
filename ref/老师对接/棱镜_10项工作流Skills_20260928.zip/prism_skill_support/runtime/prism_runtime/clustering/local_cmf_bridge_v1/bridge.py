"""Replay the producer verifier, then preserve unavailable scope explicitly.

Guards are unknown/null, carry no evidence, and cannot become positive facts.
This module never infers theme selection or calls a model/review service.
"""
from copy import deepcopy
import hashlib
import importlib
import json
from pathlib import Path


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _key(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _identity(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def _registered_verifier(profile):
    modules = {"r17-local-cmf-v1": "prism_runtime.dna.local_cmf_v1.pipeline",
               "r17-local-cmf-v1.1": "prism_runtime.dna.local_cmf_v1_1.pipeline"}
    _require(isinstance(profile, str) and profile in modules, "Unsupported producer profile; no downgrade or fallback")
    registry = json.loads(Path(__file__).with_name("accepted_producers.json").read_text(encoding="utf-8"))
    entry = registry["profiles"].get(profile)
    _require(entry and entry.get("module") == modules[profile], "Verifier is not explicitly registered")
    for ref in registry["authority_refs"] + entry["source_pins"]:
        _require(_identity(ref["path"]) == ref, "Root-accepted verifier dependency changed: " + ref["path"])
    return importlib.import_module(modules[profile]).verify_projection


def load_verified_projection(path):
    """Use the owner's persisted-file replay; never trust cached admitted flags."""
    path = Path(path).resolve()
    before = _identity(path)
    header = json.loads(path.read_text(encoding="utf-8-sig"))
    profile = header.get("provenance", {}).get("parser_version")
    _require(header.get("cmf_admission", {}).get("profile") == profile, "Producer profile declarations conflict")
    verify_projection = _registered_verifier(profile)
    receipt = verify_projection(path)
    raw = path.read_bytes()
    _require(receipt.get("passed") is True and receipt.get("model_calls") == 0,
             "Producer verifier did not return a zero-inference acceptance")
    _require(before == receipt.get("projection_identity") == _identity(path), "Projection changed during verification")
    _require(hashlib.sha256(raw).hexdigest() == before["sha256"], "Projection read is not the verified bytes")
    document = json.loads(raw.decode("utf-8-sig"))
    _require(document.get("image_id") == receipt.get("image_id"), "Projection image identity mismatch")
    _require(document.get("cmf_admission", {}).get("profile") == receipt.get("version"), "Producer profile mismatch")
    _require(receipt.get("accepted_count") == len(document.get("observations", [])), "Projection count mismatch")
    return document, receipt


def _inventory_data(inventory_path):
    """Revalidate the original T01 identity/pool; an inventory is not authority."""
    from prism_runtime.handshake.admission import reference_pool
    inventory = json.loads(Path(inventory_path).read_text(encoding="utf-8-sig"))
    _require(inventory.get("schema_version") == "prism.clustering_closure_preparation.v0.1", "Closure inventory required")
    sources = inventory["sources"]
    payloads = {}
    for key in ("manifest", "bundle", "admission_context", "h01_confirmation"):
        ref = sources[key]
        _require(_identity(ref["path"]) == ref, "Closure source changed: " + key)
        payloads[key] = json.loads(Path(ref["path"]).read_text(encoding="utf-8-sig"))
    bundle = payloads["bundle"]
    pool = reference_pool(bundle, [t["theme_id"] for t in bundle["themes"]], payloads["admission_context"])
    _require(pool["eligible_image_ids"] == inventory["reference_qualification"]["eligible_image_ids"],
             "Registered reference pool changed; do not expand it implicitly")
    records = {r["image_id"]: r for r in payloads["manifest"]["records"]}
    _require(len(records) == 120 and len(payloads["manifest"]["records"]) == 120, "Complete unique corpus is required")
    return inventory, records, pool


def _match_corpus_identity(document, records):
    iid = document["image_id"]
    _require(iid in records, "Image is outside the original corpus")
    record = records[iid]
    _require(document.get("source_kind") == record["source_kind"], "Source kind must not be reclassified")
    _require(Path(document["image_path"]).resolve() == Path(record["path"]).resolve(), "Original image path mismatch")
    _require(document["provenance"]["image_sha256"] == record["sha256"] == _identity(record["path"])["sha256"],
             "Original image bytes mismatch")


def _registered_identity(inventory_path, document):
    _, records, pool = _inventory_data(inventory_path)
    _match_corpus_identity(document, records)
    iid = document["image_id"]
    record = records[iid]
    _require(iid in pool["eligible_image_ids"] and record["source_kind"] == "trend",
             "Parsed or quality-passed image is not an authorized current trend reference")
    return {"image_id": iid, "reference_eligible": True, "eligible_image_ids": pool["eligible_image_ids"],
            "admission_snapshot": pool["admission_snapshot"], "h02_approval_verified_here": False,
            "note": "Reference eligibility does not grant H02 selection or scope approval."}


def _derive_view(request, document):
    """Pure transport construction, internal for unit tests; not an admission API."""
    iid = document["image_id"]
    _require(iid in request.get("candidate_image_ids", []), "Image is outside the given request pool")
    admission = document.get("cmf_admission", {})
    for field, expected in (("projection_only", True), ("requires_scope_aware_consumer", True),
                            ("all_original_objects_preserved", True), ("full_image_admission", False),
                            ("complete_216_visual_qualified", False), ("only_reviewed_known_in_observations", True)):
        _require(admission.get(field) is expected, "Unsupported CMF admission contract: " + field)
    objects = document.get("objects", [])
    _require(isinstance(objects, list) and all(isinstance(o, dict) and isinstance(o.get("object_id"), str) for o in objects),
             "Complete original object inventory required")
    by_object = {o["object_id"]: o for o in objects}
    _require(len(by_object) == len(objects), "Duplicate original carrier identity")
    units = admission["all_cmf_units"]
    by_unit = {u["observation_id"]: u for u in units}
    _require(len(by_unit) == len(units), "Duplicate original CMF unit identity")
    positives = document.get("observations", [])
    positive_ids = {o["observation_id"] for o in positives}
    _require(len(positive_ids) == len(positives), "Duplicate projected observation identity")
    _require(positive_ids == {u["observation_id"] for u in units if u.get("admitted") is True},
             "Projection and original admission ledger differ")
    for o in positives:
        u = by_unit[o["observation_id"]]
        _require(o.get("value_status") == u.get("value_status") == "known", "Only reviewed known values are positive")
        _require(o["object_id"] in by_object and o.get("reference_object_id") in by_object, "Carrier/reference dependency missing")
        for field in ("parameter_id", "object_id", "reference_object_id", "value", "value_status"):
            _require(_key(o.get(field)) == _key(u.get(field)), "Original observation changed: " + field)
        _require(not u.get("program_errors") and u.get("program_eligible") is True, "Program-ineligible observation projected")
        review = u.get("model_review", {})
        _require(review.get("verdict") == "supported" and all(review.get(k) is True for k in ("carrier_ok", "reference_ok", "origin_ok")),
                 "Observation does not have a complete local review")
        _require(set(u.get("dependency_object_ids", [])) <= set(by_object), "Object dependency absent")
        _require(set(u.get("dependency_observation_ids", [])) <= positive_ids, "Observation dependency unadmitted")
    pids = sorted(set(request.get("comparison_features", [])) |
                  {f["parameter_id"] for f in request.get("required_features", []) + request.get("forbidden_features", [])})
    original_pids = ({u["parameter_id"] for u in units} | set(admission.get("not_checked_parameter_ids", []))
                     | set(admission.get("out_of_scope_parameter_ids", [])))
    _require(set(pids) <= original_pids, "Request contains fields outside the original dictionary ledger")
    view, guards = deepcopy(document), []
    # The guarded transport is NOT another producer export. Its extra unknown
    # rows must not coexist with a misleading 'only known in observations' flag.
    for source_only in ("cmf_admission", "dictionary_contract", "source_validation"):
        view.pop(source_only, None)
    for oid in sorted(by_object):
        for pid in pids:
            local = [u for u in units if u["object_id"] == oid and u["parameter_id"] == pid]
            unresolved = [u for u in local if u.get("admitted") is not True]
            if local and not unresolved:
                continue
            reasons = [{"original_observation_id": u["observation_id"], "original_value_status": u["value_status"],
                        "disposition": u.get("disposition"), "program_errors": deepcopy(u.get("program_errors", [])),
                        "audit_pointer": "/cmf_admission/all_cmf_units/" + str(units.index(u))} for u in unresolved]
            if not local:
                reasons = [{"reason": "no_reviewed_carrier_field_coverage", "original_observation_id": None}]
            gid = "cmf-unavailable:" + hashlib.sha256(_key([iid, oid, pid]).encode("utf-8")).hexdigest()[:20]
            _require(gid not in positive_ids, "Guard identity collides with a real observation")
            guard = {"observation_id": gid, "parameter_id": pid, "object_id": oid,
                     "reference_object_id": None, "value": None, "value_status": "unknown", "region_ref": None,
                     "evidence_refs": [], "consumer_scope_guard": True, "not_a_source_observation": True,
                     "unavailable_reasons": reasons}
            view["observations"].append(guard)
            guards.append(deepcopy(guard))
    view["provenance"]["consumer_view"] = "local-cmf-bridge-v1"
    view["provenance"]["positive_observations_unchanged"] = True
    view["provenance"]["guards_are_not_visual_evidence"] = True
    view["consumer_scope"] = {"schema_version": "prism.local_cmf_consumer_view.v0.1",
                              "not_a_producer_export": True, "positive_observation_ids": sorted(positive_ids),
                              "guard_observation_ids": [g["observation_id"] for g in guards],
                              "whole_image_admission_created": False}
    return {"image_dna": view, "audit": {"image_id": iid, "positive_observation_ids": sorted(positive_ids),
            "complete_object_ids": sorted(by_object), "request_parameter_ids": pids,
            "guards": guards, "original_admission": deepcopy(admission),
            "has_reviewed_local_cmf": bool(positive_ids), "reference_or_h02_approval_created": False,
            "whole_image_qualification_created": False}}


def prepare_guarded_view(request, projection_path, *, inventory_path=None):
    """Return transport only. Root must validate H02 before invoking clustering.

    Production references are checked against the original closure inventory.
    Synthetic producer fixtures may omit that inventory, never real records.
    """
    document, receipt = load_verified_projection(projection_path)
    if document.get("source_kind") == "synthetic":
        _require(document.get("provenance", {}).get("mode") == "synthetic"
                 and request.get("provenance", {}).get("mode") == "synthetic", "Fixture identity mismatch")
        qualification = {"purpose": "synthetic_fixture_only", "h02_selected": False}
    else:
        _require(inventory_path is not None, "Source-bound reference inventory is required")
        qualification = _registered_identity(inventory_path, document)
        _require(set(request.get("candidate_image_ids", [])) <= set(qualification["eligible_image_ids"]),
                 "Request attempts to expand beyond registered references")
        _require(request.get("theme_selection_id") and request.get("admission_snapshot"),
                 "Only an H02-produced request with selection/admission identity is consumable")
    output = _derive_view(request, document)
    output["image_dna"]["consumer_scope"]["source_projection_identity"] = receipt["projection_identity"]
    output["audit"].update(producer_verification=receipt, reference_qualification=qualification)
    return output


def prepare_pid_view(projection_path, parameter_ids):
    """Proposal-only coverage transport, never reference/selection authority.

    This can inspect calibration sources without relabelling them. It does not
    create a GroupingRequest and cannot substitute for the execution guard.
    """
    _require(isinstance(parameter_ids, list) and parameter_ids
             and all(isinstance(pid, str) and pid for pid in parameter_ids)
             and len(parameter_ids) == len(set(parameter_ids)), "Explicit unique original PIDs are required")
    document, receipt = load_verified_projection(projection_path)
    query = {"candidate_image_ids": [document["image_id"]], "required_features": [],
             "forbidden_features": [], "comparison_features": parameter_ids}
    output = _derive_view(query, document)
    output["image_dna"]["consumer_scope"].update(source_projection_identity=receipt["projection_identity"],
        purpose="proposal_only_pid_coverage", execution_admission_granted=False)
    output["audit"].update(producer_verification=receipt, purpose="proposal_only_pid_coverage",
        reference_qualification_created=False, user_confirmation_created=False,
        must_revalidate_complete_executable_request=True)
    return output
