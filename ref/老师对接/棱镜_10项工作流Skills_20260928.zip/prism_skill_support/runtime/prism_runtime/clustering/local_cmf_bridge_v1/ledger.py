"""Source-preserving disposition accounting, never a selection authority."""
from collections import Counter
from copy import deepcopy

from .bridge import _inventory_data, _match_corpus_identity, _require, load_verified_projection


def reconcile_inventory(inventory_path, projection_index, grouping_runs=()):
    """Account for all corpus images. Only owner-validated H02 runs belong here.

    projection_index maps image_id to a persisted cmf.image-dna.json path.
    grouping_runs contains {request: GroupingRequest, result: CandidateClusters}
    or result=None for an explicitly pending request. This reports executions;
    it neither signs an H02 confirmation nor invokes the clustering engine.
    """
    inventory, originals, pool = _inventory_data(inventory_path)
    _require(isinstance(projection_index, dict) and set(projection_index) <= set(originals), "Projection index is outside the original corpus")
    eligible = set(pool["eligible_image_ids"])
    template = {r["image_id"]: r for r in inventory["records"]}
    _require(set(template) == set(originals) and len(inventory["records"]) == len(originals), "Incomplete inventory rows")
    rows, documents = {}, {}
    for iid, source in sorted(originals.items()):
        row = deepcopy(template[iid])
        _require(row["source_kind"] == source["source_kind"], "Inventory source reclassified")
        row.update(cmf_status="projection_not_provided", cmf_verification=None, cmf_observation_counts=None,
                   admitted_carrier_ids=[], carrier_cmf_audit=[], request_outcomes=[], group_memberships=[],
                   singletons=[], exclusions=[], boundaries=[], primary_disposition="local_pending")
        row["reason_codes"] = ["awaiting_verified_local_cmf_export"]
        if projection_index.get(iid):
            try:
                document, receipt = load_verified_projection(projection_index[iid])
                _require(document["image_id"] == iid, "Projection index image mismatch")
                _match_corpus_identity(document, originals)
                documents[iid] = document
                admission = document["cmf_admission"]
                positives = document["observations"]
                row.update(cmf_status="verified_useful_local" if positives else "verified_no_useful_local",
                           cmf_verification=receipt, admitted_carrier_ids=sorted({o["object_id"] for o in positives}),
                           cmf_observation_counts=dict(Counter(u.get("disposition", "unspecified") for u in admission["all_cmf_units"])))
                for obj in document["objects"]:
                    units = [u for u in admission["all_cmf_units"] if u["object_id"] == obj["object_id"]]
                    row["carrier_cmf_audit"].append({"object_id": obj["object_id"],
                        "admitted_observation_ids": sorted(u["observation_id"] for u in units if u.get("admitted") is True),
                        "withheld_dispositions": dict(Counter(u.get("disposition", "unspecified") for u in units if u.get("admitted") is not True))})
                if positives:
                    row["primary_disposition"] = "ungrouped" if iid in eligible else "parsed_not_reference_pool"
                    row["reason_codes"] = ["no_confirmed_H02_execution_supplied" if iid in eligible else "parsed_but_not_in_current_reference_pool"]
                else:
                    row["reason_codes"] = ["no_reviewed_known_CMF; output existence is not useful success"]
            except Exception as exc:
                row.update(cmf_status="verification_failed", cmf_error=type(exc).__name__ + ": " + str(exc))
                row["reason_codes"] = ["producer_verification_or_source_identity_failed"]
        rows[iid] = row
    seen = set()
    for run in grouping_runs:
        request, result = run["request"], run.get("result")
        rid = request["request_id"]
        _require(rid not in seen, "Duplicate request outcome")
        seen.add(rid)
        selected = set(request["candidate_image_ids"])
        _require(selected <= eligible, "Grouping request expands beyond registered references")
        _require(request.get("theme_selection_id") and request.get("admission_snapshot"), "H02 selection/admission identity required")
        for iid in selected:
            rows[iid]["request_outcomes"].append({"request_id": rid, "status": result.get("status") if result else "not_executed"})
        if result is None:
            continue
        _require(result.get("request_id") == rid and result.get("alignment_mode") == request["alignment_mode"], "Request/result identity changed")
        for cluster in result["clusters"]:
            unique_images = {m["image_id"] for m in cluster["members"]}
            for member in cluster["members"]:
                iid = member["image_id"]
                _require(iid in selected and iid in documents, "Grouping member lacks a verified candidate projection")
                available = {o["observation_id"]: o for o in documents[iid]["observations"]}
                _require(member["observation_ids"] and set(member["observation_ids"]) <= set(available),
                         "Unreviewed or guard observation cannot count as a group member's positive evidence")
                _require(all(available[oid]["object_id"] == member["object_id"] for oid in member["observation_ids"]), "Member splices carriers")
                key = "group_memberships" if len(unique_images) > 1 else "singletons"
                rows[iid][key].append({"request_id": rid, "cluster_id": cluster["cluster_id"], **deepcopy(member)})
        for field, output in (("excluded", "exclusions"), ("boundary_members", "boundaries")):
            for entry in result[field]:
                _require(entry["image_id"] in selected, "Outcome outside candidate pool")
                rows[entry["image_id"]][output].append({"request_id": rid, **deepcopy(entry)})
    for iid, row in rows.items():
        if row["group_memberships"]:
            row.update(primary_disposition="grouped", reason_codes=["member_of_multi_image_candidate_group"])
        elif row["singletons"]:
            row.update(primary_disposition="singleton", reason_codes=["single_image_candidate_not_forced_into_larger_group"])
        elif row["boundaries"] or any(o["status"] in ("not_executed", "needs_input", "partial") for o in row["request_outcomes"]):
            row.update(primary_disposition="local_pending", reason_codes=["unresolved_local_or_request_scope"])
        elif row["exclusions"] and any(e.get("reason") != "outside_candidate_bindings" for e in row["exclusions"]):
            row.update(primary_disposition="excluded", reason_codes=["explicit_exclusion_in_supplied_request_scope"])
        row["has_boundary_carriers"] = bool(row["boundaries"])
        row["h02_authorization_granted_by_ledger"] = False
    counts = dict(Counter(r["primary_disposition"] for r in rows.values()))
    _require(sum(counts.values()) == 120, "Not every original image has one primary disposition")
    return {"schema_version": "prism.clustering_closure_ledger.v0.1", "status": "partial",
            "evaluation_scope": "supplied_verified_projections_and_owner_validated_H02_results_only",
            "summary": {"total_images": 120, "all_images_accounted_for": True, "reference_eligible_images": len(eligible),
                "source_counts": dict(Counter(r["source_kind"] for r in rows.values())), "primary_disposition_counts": counts,
                "verified_projection_count": len(documents), "request_count": len(seen),
                "new_model_calls": 0, "new_API_calls": 0, "real_effectiveness_established": False},
            "records": list(rows.values()), "source_inventory": str(inventory_path)}
