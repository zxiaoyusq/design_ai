"""Write reproducible, explicitly synthetic examples in the selected directory."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time

from .engine import VERSION, cluster_candidates
from .fixtures import demo, request


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args(argv)
    root = args.output_dir.resolve()
    if root.exists() and any(root.iterdir()):
        parser.error("Choose an empty output directory; previous verification records are preserved.")
    root.mkdir(parents=True, exist_ok=True)
    base_request, images = demo()
    write(root / "image_dna.json", images)
    reports = []
    for mode in ("consensus", "extension", "exploration"):
        spec = request(base_request["candidate_image_ids"], mode)
        spec["request_id"] += ":" + mode
        write(root / f"request-{mode}.json", spec)
        started = time.perf_counter()
        result = cluster_candidates(spec, deepcopy(images))
        elapsed = time.perf_counter() - started
        write(root / f"clusters-{mode}.json", result)
        reports.append({"alignment_mode": mode, "status": result["status"], "summary": result["summary"],
                        "elapsed_seconds": elapsed, "result_file": str(root / f"clusters-{mode}.json")})
    manifest = {"status": "offline_pass", "algorithm_version": VERSION,
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "data_kind": "synthetic", "new_paid_calls": 0,
                "interpretation": "Partial results are intentional: four synthetic images contain uncertainty or split-carrier evidence.",
                "runs": reports,
                "file_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob("*.json"))}}
    write(root / "manifest.json", manifest)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
