"""Local JSON CLI. Outputs are atomic; input files cannot be overwritten."""
import argparse
import json
from pathlib import Path
import tempfile

from .engine import cluster_candidates


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result

    def nonfinite(value):
        raise ValueError(f"Nonfinite JSON constant: {value}")

    return json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=pairs, parse_constant=nonfinite)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", required=True, type=Path)
    parser.add_argument("--dna", required=True, nargs="+", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    output = args.output.resolve()
    if output in {p.resolve() for p in [args.request, *args.dna]}:
        parser.error("output must not overwrite an input file")
    try:
        request = read_json(args.request)
        images = []
        for path in args.dna:
            document = read_json(path)
            if isinstance(document, list):
                images.extend(document)
            elif isinstance(document, dict) and isinstance(document.get("images"), list):
                images.extend(document["images"])
            elif isinstance(document, dict) and document.get("schema_version") == "prism.image_dna.v0.1":
                images.append(document)
            else:
                raise ValueError("DNA JSON must be an ImageDNA object, a list, or {images: [...]} envelope")
        result = cluster_candidates(request, images)
        output.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", newline="\n", dir=output.parent,
                                             prefix=".clustering-", suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
                stream.write("\n")
            temporary.replace(output)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
        print(json.dumps({"status": result["status"], "output": str(output),
                          "summary": result.get("summary"), "input_errors": result.get("input_errors", [])},
                         ensure_ascii=False))
        return 2 if result["status"] == "needs_input" else 0
    except (OSError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "needs_input", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
