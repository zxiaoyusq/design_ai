# 握手后条件聚类原型 v0.2.0

输入为上游 `GroupingRequest v0.1` 与 `ImageDNA v0.1`，支持 CT-001 和 CT-002 补充约定。输出为 `CandidateClusters v0.1`，终点是候选子图库和可复核的分组依据。本模块不重新抽取偏好、不调用模型或 review API、不选择最终代表图、不裁剪或排版，也不设置组数或每组图片数。

## 导入接口

```python
from prism_runtime.clustering import cluster_candidates

result = cluster_candidates(request, images)
```

`request` 是一个字典；`images` 是 ImageDNA 字典列表。函数不修改输入，不读图像像素、不访问网络、不读写文件。图片数据可以多于候选池，但仅 `candidate_image_ids` 内的记录参与规则判断；其余 ID 列入 `summary.unused_input_image_ids`。重复图片 ID 会返回 `needs_input`，不会隐式覆盖。

输出保留 `alignment_mode`、`alignment_label`、`relation_basis`、上下游证据及假设引用。按照接口决议 CT-001，三档是允许范围：共识优先允许 `direct_support`；适度延展允许 `direct_support / anchored_extension`；创新探索允许全部三种关系。更宽的档位保留已有直接支持，不强制将其升级为探索假设。原档位和原关系均不改写，低档收到超出范围的关系时返回输入问题。

可选 `candidate_bindings` 若提供，必须是非空的明确载体列表，每项至少有 `image_id` 和 `object_id`。只有这些图片／载体对可以成为成员；空、未知、重复或超出图片池的绑定不作为无限制。可选的 `observation_ids / region_refs` 要能回查到同一载体的原观察；它们是上游依据锚点，不会把对比特征读取限制为这几个观察 ID。绑定存在但指向的载体、观察或区域缺失时保留边界，不退回同图的另一个载体。没有该字段的旧请求维持原行为。

## 可复核的规则

1. **核心条件同载体成立。** 每项必需特征均需有已知值命中 `allowed_values`，并保留对象 ID、区域引用及证据引用。多项核心条件必须存在于同一个 `object_id`，不能把两个对象的属性拼起来。条件表示“在该载体上存在此局部表达”，不要求覆盖整张图。
2. **类型明确的精确匹配。** 以规范化 JSON 值比较，字典键顺序不影响结果；布尔值、整数、浮点数和字符串保持不同，列表是完整有序值，不隐式作子集匹配。需要数值容差、区间、集合包含或语义同义词时，须先扩展上游比较约定。
3. **禁用条件不变成偏好。** CT-002 新请求按下述完整审计及明确范围执行。未采用新契约的旧请求保持既有逻辑：没有载体范围或额外作用域声明时使用图片级已知冲突和载体自身检查；带 `candidate_bindings` 但禁用作用域未定义时保留边界。未知或无绑定属性始终不证明禁用值不存在。
4. **对比特征形成细分组。** 准入后，按实际命中的核心值与完整已知的对比特征值组合精确分组。相同载体上不同区域的多个已知值保持完整；同一区域、同一字段出现互相矛盾的值则为边界项。
5. **缺失不产生相似支持。** 核心特征不能确认、对比特征未知、禁用条件不能确认，都保留原因与已有绑定，进入 `boundary_members`。`unknown` 和 `not_applicable` 必须使用 JSON `null` 值，携带具体值属于非法状态组合，图片保留为 `invalid_image_dna` 边界项，不据此证明禁用项不存在。合法、已绑定的 `not_applicable` 继续可用于适用性检查；明确不适用的对比项不出现在正向 `shared_features` 中。
6. **保留全部合格候选。** 单图组也保留；同图的不同载体可以分别成为成员，图片数量与载体数量分别统计。来源和同源关系由输入证据保留，模块不做最后成板选图。

`shared_features` 的每个实际值附每个成员的观察 ID、区域和证据。`distinguishing_features` 表示本轮不同组间实际不同的字段值或适用状态。`carrier_diagnostics` 保留未通过的载体、未获上游选择的载体，以及跨载体无法合并的原因。图像有一个合格载体和另一个不确定载体时，可以同时出现在候选组和边界记录中，两者的 `object_id` 区分用途。显式选中的成员另保留 `upstream_candidate_binding`。

这是一条刻意简单的基线：没有学习距离、隐藏权重、视觉嵌入或固定图片白名单。完全相同的特征组合较保守，可能把人认为相近的表达拆得过细；它用于验证握手条件能否被 DNA 落实，不代表感知聚类最优。

## 状态和证据边界

- `complete`：本轮规定条件已被确定处理，可以是零个候选组；不代表设计师或消费者验收。
- `partial`：仍有边界图片，例如已知核心条件但对比字段未知。
- `needs_input`：请求结构不成立、没有核心条件，或候选中没有带对象、区域及引用的已知核心属性；禁止返回一个全包簇。

“有绑定”仅指所提供的对象／区域／引用结构完整。有效区域字符串或含实际载荷的区域对象原样保存，明确 unknown 或只有空载荷的区域对象不能提供支持。结构化 `region_ref` 如果明确带有 `object_id`，该身份必须与观察的 `object_id` 完全一致；矛盾的图片保留为输入错误边界项。没有对象字段的原区域对象和字符串引用保持兼容，不推断其身份。本模块没有证明区域几何、图像像素和文字描述真实一致。该项依赖上游解析与独立复核，输出 `pixel_verification=not_performed`。不同区域是否相邻或重叠也未推断，当前只保证同一对象，不声称多项条件位于同一像素区域。

结果中的 `provenance` 继承请求。真实证据请求不能由合成 ImageDNA 支持；合成用例一律标记 synthetic。没有推算用户喜欢概率、真实材料、风格年代或市场结论。

## CT-002：明确范围与完整负向审计

启用字段为 `negative_scope_version: "prism.negative_scope.v0.1"`。原 `scoped_negative_preferences` 完整保留，`negative_audit_ids` 列出其全部 `preference_id`，包括 pending 和 not_applicable。每条审计的 `executable_constraint_ids` 指向可执行约束。产品硬约束可使用 `brief:<brief_id>:negative:<index>` 审计 ID，并明确 `source_kind=product_hard_constraint`；不把它伪装成用户喜恶。

`forbidden_features` 的每项增加以下字段（节选；完整请求见交付样例）：

```json
{
  "constraint_id": "negative-P3-finish",
  "audit_refs": ["P3"],
  "parameter_id": "OPT-002",
  "forbidden_values": ["镜面外观"],
  "evidence_refs": ["R3"],
  "scope": {
    "kind": "candidate_bindings",
    "status": "resolved",
    "evidence_refs": ["R3"],
    "bindings": [{"image_id": "I1", "object_id": "shell"}]
  }
}
```

- `kind=image` 使用非空 `image_ids`，必须属于候选图片池。在指定图片上检查所有已声明载体，包括背景；已知禁用值触发整图排除，某个载体的相关属性缺失或未知则不能确认整图满足禁用条件。
- `kind=candidate_bindings` 使用非空 `bindings`，每个 `image_id/object_id` 必须是请求白名单的明确子集且确实存在。只检查列出的对象，但读取该对象的全部相关观察，不限于白名单条目的核心 `observation_ids`。因此“哑光后壳＋镜面背景”可以通过后壳范围，“镜面后壳＋哑光背景”会排除后壳。
- 新契约按 `constraint_id` 唯一校验，同一参数可以有不同范围的多条约束，不合并成全图禁用。旧请求仍保留参数不能重复的原规则。
- 必须双向关联：原审计的每一个 `(parameter_id, value)` 都要有映射；约束的每个禁用值必须来自所关联的原审计，原引用不得丢失。缺少原审计、缺少单个负向特征的映射、孤立链接或扩大禁用值都保留 pending。不能通过删审计、只映射一部分或把 scope 标成 resolved 消除这些问题。
- `status` 只有 resolved 才可执行；范围缺失、未知、未确认、目标不存在、选择器不受支持，均保留边界。scope 只支持文档列出的字段，不默默忽略额外的范围运算。
- 审计中明确存在的未复核态度、pending scope、与目标不符的人群，以及请求的 pending_context_constraints 继续阻断。scope_confirmation 若提供，其 status、确认来源必须完整；此检查不认证确认者身份，也不代替语义评审。
- not_applicable 保留原记录，要求原证据及既有条件判定，或可明确判定的人群不相交；不能只给一个 not_applicable 标签就删除负向。

结果保留完整原审计、原约束及 `negative_scope_plan`。合格成员的 `negative_constraint_checks` 标明具体规则、对象、实际检查的观察和引用。若新 scope 图存在未决内容，所有该图的规则暂停执行，候选保留边界，不把未确认的排斥当作已证实冲突。

H02 的独立调用方负责 scope 确认和原资料快照校验；本模块只消费编译结果。全图检查覆盖的是 DNA **已声明**的载体，不能证明解析遗漏的背景或对象也已被检查。字符串区域及引用仍未做像素核验。

## CLI

从工程根目录执行；`PYTHON` 指向可用 Python 3.12+：

```text
PYTHON -B -X utf8 -m prism_runtime.clustering --request REQUEST.json --dna IMAGES.json --output RESULT.json
```

`--dna` 可提供多个文件；每个文件可以是单个 ImageDNA、ImageDNA 数组，或 `{"images": [...]}`。输出以 UTF-8 原子写入；禁止覆盖输入文件。完整或部分结果退出码为 0，`needs_input` 或文件／JSON 错误为 2。调用方须读取 `status`，不能把退出码 0 当成全部图片已成功归类。

## 离线验证与样例

```text
PYTHON -B -X utf8 -m unittest discover -s prism_runtime/clustering/tests -v
PYTHON -B -X utf8 -m prism_runtime.clustering.demo --output-dir NEW_EMPTY_DIRECTORY
```

测试使用微型合成夹具，覆盖局部共性、跨对象拼接、未知禁用条件、同区域矛盾、类型混淆、模式传递、重复 ID、输入不变、输入顺序不变、来源范围、CLI 和无成板张数限制。

演示生成 9 张**合成记录**，三个模式分别得到 2 个候选组、4 张入组、4 张边界和 1 张明确冲突。组内分别为蓝色组合 3 张、橙色组合 1 张。这里没有真实图片或用户反馈，`partial` 是预先构造的未知与跨对象反例的如实结果。

本轮交付位于 `outputs/prism-algorithm-loop-20260926/modules/clustering/`，以 `handoff.json` 中的实际验证记录为准。演示脚本要求空输出目录，避免覆盖旧轮记录；生成后的请求和 DNA 可通过主 CLI 重复计算。

## 待上游讨论的契约扩展

保持共享契约未修改；建议在后续版本讨论：

- `forbidden_features` 增加明确的图像／目标载体／目标区域范围。当前保守图像级冲突会排除部分“主体合适、背景出现禁用元素”的图片。
- CT-002 已支持图片级和明确候选载体级禁用范围；区域内部子范围、复杂空间关系、额外条件运算仍需新的明确约定，不能静默当作当前范围执行。
- 为数值范围、数值容差、多选集合和有序类别指定比较操作符与单位；当前精确值比较不猜这些含义。
- 约定区域引用的可解析格式及来源解析器的坐标有效性检查。当前模块无法独立验证任意引用是否真实指向原图。
- 对于要求多项属性共处同一区域或存在特定空间关系的方向，增加显式关系条件；不能把同载体自动升级为同区域。

真实数据接入后需由协调任务回查请求依据与候选结果，再用独立图片和设计师分组验证效果。当前模块交付的验证等级仅为 `offline_pass`。

## v0.1.1 修复记录

依据 CLUSTER-EVAL-R1，补足非已知状态必须为 null，以及显式区域载体与观察载体一致性检查；合法 NA、字符串区域和同载体结构化区域保持支持。同批落实 CT-001 的模式允许范围和 `candidate_bindings`。本模块 44 项检查通过；重放验收方的 20 个模块输入，其中 18 个既有通过项输出除版本号外未变，2 个错误准入已修复。另有 7 个 H02 对接样例被正确接收并保留作用域边界。重放属于作者回归，不是新的独立验收或聚类效果验证。完整记录见交付目录 `repair-r1-v0.1.1/`。

## v0.2.0 验证范围

CT-002 新增 28 项负向范围检查，连同原 44 项共 72 项通过。直接只读接入握手 owner 的 10 份完整 JSON：3 份可执行请求得到预期正反结果，其余 7 份保留上游 pending 和原负向审计，聚类未启动。原 20 个模块输入及 7 个 CT-001 对接例也完成作者回归。交付目录为 `ct002-v0.2.0/`。这些材料为合成协议例和已披露回归资料，不是未知留出或真实审美效果验证；Root 尚需冻结新版本独立复验。
