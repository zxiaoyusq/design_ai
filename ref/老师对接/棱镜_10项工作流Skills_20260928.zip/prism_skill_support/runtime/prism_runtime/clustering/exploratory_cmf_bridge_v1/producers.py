"""Explicit Root-accepted v1.2 routing; the original v1/v1.1 registry is untouched."""
import hashlib
import importlib
import json
from pathlib import Path

from ..local_cmf_bridge_v1 import bridge as legacy

PROFILE = "r17-local-cmf-v1.2"
MODULE = "prism_runtime.dna.local_cmf_v1_2.pipeline"
_require = legacy._require


def projection_profile(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig")).get("provenance", {}).get("parser_version")


def _registered_verifier():
    registry = json.loads(Path(__file__).with_name("accepted_producers.json").read_text(encoding="utf-8"))
    _require(registry.get("profile") == PROFILE and registry.get("module") == MODULE, "v1.2 is not explicitly registered")
    for name in ("root_acceptance", "root_freeze"):
        ref = registry[name]
        _require(legacy._identity(ref["path"]) == ref, "Root v1.2 acceptance/freeze changed")
    acceptance = json.loads(Path(registry["root_acceptance"]["path"]).read_text(encoding="utf-8-sig"))
    _require(acceptance.get("passed") is True and acceptance.get("new_model_calls") == 0
             and acceptance.get("checks") and all(c.get("passed") is True for c in acceptance["checks"]),
             "Root v1.2 independent acceptance is not valid")
    freeze = json.loads(Path(registry["root_freeze"]["path"]).read_text(encoding="utf-8-sig"))
    _require(freeze.get("version") == PROFILE and len(freeze.get("files", [])) == registry["source_pin_count"],
             "Root v1.2 freeze scope changed")
    for entry in freeze["files"]:
        _require(legacy._identity(entry["source"])["sha256"] == entry["sha256"],
                 "Root-accepted v1.2 dependency changed: " + entry["source"])
    return importlib.import_module(MODULE).verify_projection


def load_verified_projection(path):
    """Audit any original source kind; this alone grants no reference qualification."""
    path = Path(path).resolve()
    before = legacy._identity(path)
    header = json.loads(path.read_text(encoding="utf-8-sig"))
    profile = header.get("provenance", {}).get("parser_version")
    if profile in {"r17-local-cmf-v1", "r17-local-cmf-v1.1"}:
        return legacy.load_verified_projection(path)
    _require(profile == PROFILE, "Unsupported producer profile; no downgrade or fallback")
    _require(header.get("cmf_admission", {}).get("profile") == profile, "Producer profile declarations conflict")
    receipt = _registered_verifier()(path)
    raw = path.read_bytes()
    _require(receipt.get("passed") is True and receipt.get("model_calls") == 0,
             "Producer verifier did not return zero-inference acceptance")
    _require(before == receipt.get("projection_identity") == legacy._identity(path)
             and hashlib.sha256(raw).hexdigest() == before["sha256"], "Projection changed during verification")
    document = json.loads(raw.decode("utf-8-sig"))
    _require(document.get("image_id") == receipt.get("image_id") and receipt.get("version") == PROFILE,
             "Projection image/profile mismatch")
    _require(receipt.get("accepted_count") == len(document.get("observations", [])), "Projection count mismatch")
    return document, receipt


def prepare_pid_view(projection_path, parameter_ids):
    """Proposal-only original-PID coverage, with v1.2 invalid-encoding audit intact."""
    _require(isinstance(parameter_ids, list) and parameter_ids
             and all(isinstance(pid, str) and pid for pid in parameter_ids)
             and len(parameter_ids) == len(set(parameter_ids)), "Explicit unique original PIDs are required")
    document, receipt = load_verified_projection(projection_path)
    query = {"candidate_image_ids": [document["image_id"]], "required_features": [],
             "forbidden_features": [], "comparison_features": parameter_ids}
    output = legacy._derive_view(query, document)
    output["image_dna"]["consumer_scope"].update(source_projection_identity=receipt["projection_identity"],
        purpose="proposal_only_pid_coverage", execution_admission_granted=False)
    output["audit"].update(producer_verification=receipt, purpose="proposal_only_pid_coverage",
        reference_qualification_created=False, user_confirmation_created=False,
        must_revalidate_complete_executable_request=True)
    return output
