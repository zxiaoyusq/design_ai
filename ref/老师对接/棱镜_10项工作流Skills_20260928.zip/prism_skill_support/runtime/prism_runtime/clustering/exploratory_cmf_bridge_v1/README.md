# Explicit exploration context consumer

Separate CLOSURE-REF-001 sidecar. It leaves clustering 0.2.0 and `local_cmf_bridge_v1` unchanged, including the original nine-image default gate. No selection, confirmation, model call, API call, or clustering execution happens here.

## Entry points

```python
from prism_runtime.clustering.exploratory_cmf_bridge_v1 import (
    prepare_guarded_view, prepare_request_views, reconcile_inventory,
    load_verified_projection, prepare_pid_view,
)

prepared = prepare_request_views(
    owner_validated_request,
    projection_index,  # Original image_id -> persistent official projection path.
    inventory_path=original_inventory,
    exploration_context_path=confirmed_context_path,
)
# Only after the upstream decisions are complete, the caller may explicitly run:
# cluster_candidates(owner_validated_request, prepared["guarded_image_dna"])
```

For a single image, `prepare_guarded_view(request, projection_path, *, inventory_path, exploration_context_path=None)` returns the same `image_dna`/`audit` shape as the previous bridge. Without a context it delegates exactly to the previous entry; unavailable, invalid or rejected contexts never trigger a fallback.

With a context, the consumer requires CMF + exploration and invokes the fixed owner API `prism_runtime.handshake.exploratory_reference_v1.verify_context(context_path, request=request, inventory_path=inventory_path)`. The owner must replay actual H01, the H02 proposal, Root's separately recorded delegated decision, original-corpus/D03 qualification, official usable CMF, and the full compiled request, including CT002. A cached `passed` or a self-declared JSON authority is insufficient. This consumer does not replace that replay.

The replay receipt must contain `passed`, `model_calls`, `context_identity`, `context_id`, the complete `request_snapshot`, `authority_kind=user_delegated_ai`, `human_designer_actually_reviewed=false`, `candidate_pool_kind=approved_closed_exploration_library`, and `selected_references`. Here `selected_references` is **Root's explicitly approved closed exploration library**, not the H02 model's typical examples. Every library image must appear in the executable request; carrier bindings are the deterministic expansion of Root's approved carrier rule. Qualification must not pre-filter library images by the desired H02 features. The unchanged engine decides matches, exclusions, singletons and boundaries.

Each approved library reference has `image_id`, `role=user_delegated_ai_selected_exploratory_reference`, `projection_identity`, `bindings[{object_id,observation_ids}]`, and a separate `original_T01_reference_role={globally_registered,theme_ids}`. The owner keeps source/D03/H01/draft/decision identities and separately binds the H02 example observations that define original PID/value/scale features. The context binds the entire request hash; the request carries `exploration_context_id` without a cyclic file hash. Any added projection, including a future accepted v1.2 recovery, requires a new explicitly approved library snapshot.

The consumer independently checks context bytes before/after replay, exact request identity, original trend identity, official projection replay/identity, usable reviewed image CMF, approved image/carrier membership, any declared observation anchors, and the unchanged original T01 roles. A library carrier need not already match required features. No original value, object, scale or evidence reference is rewritten.

`load_verified_projection` and proposal-only `prepare_pid_view` now explicitly support Root-accepted v1.2. The new `accepted_producers.json` pins Root's independent codec acceptance and complete source freeze; all 39 frozen dependencies are checked before importing the fixed v1.2 verifier. v1/v1.1 still delegate to their original registered verifier. Unknown versions, changed acceptance/source pins and failed replay reject without fallback. The old no-context execution entry and registry remain untouched; v1.2 execution uses the new explicit exploration context. Producer acceptance alone grants no image, library or H02 approval.

The v1.2 complete audit retains `invalid_encoding`, original raw slots and dependency-blocked observations. Consumer unknown/null guards are separately identified transport rows, never relabelled original facts. Encoding failures, failed visual review and absent reference qualification remain distinct from designer judgments about typicality. Neither recovered encoding nor projection-file existence establishes usable CMF; a reviewed projection can legitimately contain zero positives.

## Full scope stays visible

Observation anchors are not a deletion whitelist, and approved carrier bindings may omit them or use an empty list. Any supplied IDs must be official observations on that carrier; no per-image anchor is required just to evaluate a library member. Transport retains **all** officially reviewed positives, all original objects and the previous bridge's unknown/null guards for all requested fields. Background, NA, withheld, unreviewed and missing coverage cannot certify whole-image absence. All complete original CMF audit remains attached. Grouping members must be on approved carriers with official positive observations on the request's required/comparison PIDs; extra negative-check facts are not relabelled as user preferences.

The new role means a delegated design-exploration selection, never new original T01 visual evidence or a human design review. Original global registration is retained separately and does not imply qualification for a different theme. No calibration or research record can enter this new execution path.

The official receipt retains the separately approved `carrier_rule` object, which this consumer copies unchanged into qualification and per-request ledger membership. The rule's deterministic expansion and Root's exact approval are verified by the owner. Excluding the original O19 frame/container type from positive candidate bindings does **not** remove its original objects, observations or unknown guards from whole-image negative evaluation. This consumer never independently authorizes an object-type exclusion.

## Complete 120-image ledger

```python
ledger = reconcile_inventory(original_inventory, projection_index, [
    {"request": request, "result": actual_result_or_none,
     "exploration_context_path": confirmed_context_path},
])
```

Runs without a context use the original ledger gate. New-context runs replay qualification and retain per-request `exploratory_library_memberships`, original source/registration fields, all exclusions and boundary carriers. Images outside an approved library retain their previous status; every original image still has one primary disposition and counts total 120. A singleton with boundary carriers remains a singleton plus explicit boundaries. An unexecuted request remains pending. Results that drop the request's negative audit or claim unapproved members are rejected. This ledger grants no H02 authorization and does not run the engine.

Inventory-only accounting can include new v1.2 projections before any library approval. Those rows use the new official loader and retain `original_cmf_admission`, including codec failure details; their original T01 membership stays unchanged. An unapproved parsed image remains outside the reference pool. This is implemented without modifying or monkey-patching any legacy module globals.

```text
python -B -X utf8 -m prism_runtime.clustering.exploratory_cmf_bridge_v1 prepare-request --request REQUEST.json --projection-index INDEX.json --inventory INVENTORY.json --context CONTEXT.json --output-dir NEW_DIR
python -B -X utf8 -m prism_runtime.clustering.exploratory_cmf_bridge_v1 ledger --inventory INVENTORY.json --projection-index INDEX.json --grouping-runs RUNS.json --output-dir NEW_DIR
```

## Validation limits

`tests.py` contains synthetic consumer boundary cases with the authority/corpus/producer loaders explicitly mocked. The old guard and engine execute in the scope cases. These checks cannot establish actual source replay, actual model quality, real H02 approval, or clustering effectiveness. Integration against the owner's real context verifier and Root's independent acceptance remain separate evidence. No fallback path is provided while that dependency is unavailable.
