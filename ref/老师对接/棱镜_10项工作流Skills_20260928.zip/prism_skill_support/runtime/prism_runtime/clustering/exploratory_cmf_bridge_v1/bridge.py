"""Consume an owner-replayed exploratory choice without issuing one.

No model calls, selection authority, positive-value edits, or engine changes.
The owner verifier is a fixed module, never a context-supplied import path.
"""
from copy import deepcopy

from prism_runtime.handshake.common import fingerprint
from ..engine import MODES
from ..local_cmf_bridge_v1 import bridge as legacy
from .producers import load_verified_projection

VERSION = "exploratory-cmf-bridge-v1"
EXPLORATORY_ROLE = "user_delegated_ai_selected_exploratory_reference"
_require = legacy._require


def _verify_owner(context_path, request, inventory_path):
    # Deliberately lazy: no-context users do not load a new authority mechanism.
    from prism_runtime.handshake.exploratory_reference_v1 import verify_context
    return verify_context(context_path, request=request, inventory_path=inventory_path)


def _checked_context(request, context_path, inventory_path):
    _require(inventory_path is not None, "Original source-bound inventory is required")
    _require(request.get("alignment_mode") == "exploration", "Supplemental references are exploration-only")
    _require(request.get("alignment_label") == MODES["exploration"][0]
             and request.get("relation_basis") in MODES["exploration"][1], "Exploration policy identity changed")
    _require(request.get("design_axis") == "CMF", "Supplemental context is limited to local CMF")
    before = legacy._identity(context_path)
    receipt = _verify_owner(context_path, request, inventory_path)
    _require(receipt.get("passed") is True and receipt.get("model_calls") == 0,
             "Exploratory context lacks official zero-inference replay")
    _require(before == receipt.get("context_identity") == legacy._identity(context_path), "Context identity changed")
    _require(receipt.get("request_snapshot") == fingerprint(request), "Context is not bound to the complete request")
    _require(receipt.get("context_id") and receipt["context_id"] == request.get("exploration_context_id"), "Request context ID changed")
    _require(receipt.get("authority_kind") == "user_delegated_ai"
             and receipt.get("human_designer_actually_reviewed") is False, "Explicit delegated authority is required")
    _require(receipt.get("candidate_pool_kind") == "approved_closed_exploration_library",
             "H02 examples cannot substitute for the approved closed exploration library")
    _require(isinstance(receipt.get("carrier_rule"), dict) and receipt["carrier_rule"],
             "The separately approved carrier rule must remain explicit")
    inventory, originals, pool = legacy._inventory_data(inventory_path)
    original_roles = {r["image_id"]: r.get("reference_theme_ids", []) for r in inventory["records"]}
    refs = receipt.get("selected_references")
    _require(isinstance(refs, list) and refs, "No explicit selected references")
    selected = {entry["image_id"]: entry for entry in refs}
    candidates = request.get("candidate_image_ids", [])
    _require(len(selected) == len(refs) and len(candidates) == len(set(candidates))
             and set(selected) == set(candidates), "Context and request selected images differ")
    pairs = [(b["image_id"], b["object_id"]) for b in request.get("candidate_bindings", [])]
    approved = [(r["image_id"], b["object_id"]) for r in refs for b in r.get("bindings", [])]
    _require(pairs and len(pairs) == len(set(pairs)) and len(approved) == len(set(approved))
             and set(pairs) == set(approved), "Context and request selected carriers differ")
    for iid, entry in selected.items():
        _require(iid in originals and originals[iid]["source_kind"] == "trend", "Only original trend images are consumable")
        _require(entry.get("role") == EXPLORATORY_ROLE, "Supplemental role cannot impersonate original T01 registration")
        role = entry.get("original_T01_reference_role", {})
        _require(isinstance(role, dict) and role.get("globally_registered") is (iid in pool["eligible_image_ids"])
                 and sorted(role.get("theme_ids", [])) == sorted(original_roles[iid]), "Original T01 reference role changed")
    return {"receipt": receipt, "selected": selected, "originals": originals, "pool": pool}


def _prepare(request, projection_path, checked):
    document, producer_receipt = load_verified_projection(projection_path)
    legacy._match_corpus_identity(document, checked["originals"])
    iid = document["image_id"]
    _require(iid in checked["selected"], "Image was not explicitly selected for this request")
    entry = checked["selected"][iid]
    _require(document.get("source_kind") == "trend" and document.get("observations"),
             "A selected reference requires usable reviewed trend CMF")
    _require(entry.get("projection_identity") == producer_receipt.get("projection_identity"),
             "Selected projection identity changed")
    positives = {o["observation_id"]: o for o in document["observations"]}
    objects = {o["object_id"] for o in document["objects"]}
    for binding in entry["bindings"]:
        ids = binding.get("observation_ids", [])
        _require(binding["object_id"] in objects, "Approved carrier is not an original object")
        _require(isinstance(ids, list) and len(ids) == len(set(ids)) and set(ids) <= set(positives),
                 "Selected observation is missing, unreviewed, or a consumer guard")
        _require(all(positives[oid]["object_id"] == binding["object_id"] for oid in ids),
                 "Selected observations splice carriers")
        requested = next(b for b in request["candidate_bindings"] if b["image_id"] == iid and b["object_id"] == binding["object_id"])
        _require(set(requested.get("observation_ids", [])) <= set(ids), "Request observation anchor was not selected")
    # Keep all reviewed positives and all original objects, not only selected
    # observations. CT002 must still inspect the complete requested scope.
    output = legacy._derive_view(request, document)
    qualification = {"image_id": iid, "role": entry["role"],
        "original_registered_reference_global": iid in checked["pool"]["eligible_image_ids"],
        "original_T01_reference_role": deepcopy(entry.get("original_T01_reference_role")),
        "global_registration_is_not_current_theme_selection": True,
        "original_reference_pool_unchanged": True,
        "purpose": "design_exploration",
        "candidate_pool_kind": checked["receipt"]["candidate_pool_kind"],
        "approved_carrier_rule": deepcopy(checked["receipt"]["carrier_rule"]),
        "carrier_rule_does_not_filter_whole_image_negative_scope": True,
        "library_member_is_not_a_preselected_cluster_member": True,
        "new_T01_visual_evidence_created": False, "human_designer_actually_reviewed": False,
        "context_identity": deepcopy(checked["receipt"]["context_identity"]),
        "request_snapshot": checked["receipt"]["request_snapshot"],
        "approved_carrier_bindings": deepcopy(entry["bindings"]), "approval_created_here": False}
    output["image_dna"]["consumer_scope"].update(source_projection_identity=producer_receipt["projection_identity"],
        exploratory_reference_qualification=deepcopy(qualification))
    output["audit"].update(producer_verification=producer_receipt, reference_qualification=qualification,
        exploratory_context_verification=deepcopy(checked["receipt"]))
    return output


def prepare_guarded_view(request, projection_path, *, inventory_path=None, exploration_context_path=None):
    """Prepare one image after exact-context replay; absent context uses old rules."""
    if exploration_context_path is None:
        return legacy.prepare_guarded_view(request, projection_path, inventory_path=inventory_path)
    checked = _checked_context(request, exploration_context_path, inventory_path)
    return _prepare(request, projection_path, checked)


def prepare_request_views(request, projection_index, *, inventory_path, exploration_context_path=None):
    """Verify context once and prepare every requested image; never omit a failure."""
    ids = request.get("candidate_image_ids", [])
    _require(isinstance(projection_index, dict) and set(ids) <= set(projection_index), "A candidate projection is missing")
    if exploration_context_path is None:
        views = [legacy.prepare_guarded_view(request, projection_index[iid], inventory_path=inventory_path) for iid in ids]
    else:
        checked = _checked_context(request, exploration_context_path, inventory_path)
        views = [_prepare(request, projection_index[iid], checked) for iid in ids]
    _require([v["image_dna"]["image_id"] for v in views] == ids, "Projection index image mismatch")
    return {"request_id": request["request_id"], "guarded_image_dna": [v["image_dna"] for v in views],
            "coverage_audits": [v["audit"] for v in views], "clustering_executed": False,
            "new_model_calls": 0, "new_API_calls": 0}
