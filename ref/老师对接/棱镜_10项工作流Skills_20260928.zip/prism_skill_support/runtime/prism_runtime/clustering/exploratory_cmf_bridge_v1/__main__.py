"""Offline context verification, guarded transport, and complete-corpus accounting."""
import argparse
import json
from pathlib import Path

from . import prepare_guarded_view, prepare_request_views, reconcile_inventory


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    single = sub.add_parser("prepare-view")
    single.add_argument("--projection", required=True, type=Path)
    batch = sub.add_parser("prepare-request")
    batch.add_argument("--projection-index", required=True, type=Path)
    for command in (single, batch):
        command.add_argument("--request", required=True, type=Path)
        command.add_argument("--context", type=Path)
    ledger = sub.add_parser("ledger")
    ledger.add_argument("--projection-index", required=True, type=Path)
    ledger.add_argument("--grouping-runs", type=Path)
    for command in (single, batch, ledger):
        command.add_argument("--inventory", required=True, type=Path)
        command.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    if output.exists() and any(output.iterdir()):
        parser.error("Choose a new empty output directory")
    read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
    if args.command == "ledger":
        result = reconcile_inventory(args.inventory, read(args.projection_index), read(args.grouping_runs) if args.grouping_runs else [])
        filename = "ledger.json"
        summary = result["summary"]
    else:
        kwargs = {"inventory_path": args.inventory, "exploration_context_path": args.context}
        if args.command == "prepare-view":
            result = prepare_guarded_view(read(args.request), args.projection, **kwargs)
            filename = "guarded-view.json"
            count = 1
        else:
            result = prepare_request_views(read(args.request), read(args.projection_index), **kwargs)
            filename = "guarded-transports.json"
            count = len(result["guarded_image_dna"])
        summary = {"status": "transport_prepared", "image_count": count, "clustering_executed": False,
                   "new_model_calls": 0, "new_API_calls": 0}
    output.mkdir(parents=True, exist_ok=True)
    (output / filename).write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({**summary, "output": str(output / filename)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
