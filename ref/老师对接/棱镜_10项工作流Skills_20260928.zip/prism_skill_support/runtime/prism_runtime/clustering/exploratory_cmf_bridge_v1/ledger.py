"""Add request-scoped exploratory dispositions without changing original T01 roles."""
from collections import Counter
from copy import deepcopy

from ..local_cmf_bridge_v1 import ledger as legacy
from ..local_cmf_bridge_v1 import bridge as legacy_bridge
from .bridge import _require, prepare_request_views
from .producers import PROFILE, load_verified_projection, projection_profile


def _add_v1_2_rows(report, inventory_path, projection_index):
    """Use the new registered loader for new-version audit rows, without patching legacy globals."""
    _, originals, pool = legacy_bridge._inventory_data(inventory_path)
    rows = {r["image_id"]: r for r in report["records"]}
    for iid, path in projection_index.items():
        row = rows[iid]
        try:
            document, receipt = load_verified_projection(path)
            _require(document["image_id"] == iid, "Projection index image mismatch")
            legacy_bridge._match_corpus_identity(document, originals)
            units, positives = document["cmf_admission"]["all_cmf_units"], document["observations"]
            row.update(cmf_status="verified_useful_local" if positives else "verified_no_useful_local",
                cmf_verification=receipt, admitted_carrier_ids=sorted({o["object_id"] for o in positives}),
                cmf_observation_counts=dict(Counter(u.get("disposition", "unspecified") for u in units)))
            row["carrier_cmf_audit"] = [{"object_id": obj["object_id"],
                "admitted_observation_ids": sorted(u["observation_id"] for u in units if u["object_id"] == obj["object_id"] and u.get("admitted") is True),
                "withheld_dispositions": dict(Counter(u.get("disposition", "unspecified") for u in units if u["object_id"] == obj["object_id"] and u.get("admitted") is not True))}
                for obj in document["objects"]]
            row["original_cmf_admission"] = deepcopy(document["cmf_admission"])
            if positives:
                row["primary_disposition"] = "ungrouped" if iid in pool["eligible_image_ids"] else "parsed_not_reference_pool"
                row["reason_codes"] = ["no_confirmed_H02_execution_supplied" if iid in pool["eligible_image_ids"] else "parsed_but_not_in_current_reference_pool"]
            else:
                row["reason_codes"] = ["no_reviewed_known_CMF; output existence is not useful success"]
        except Exception as exc:
            row.update(cmf_status="verification_failed", cmf_error=type(exc).__name__ + ": " + str(exc))
            row["reason_codes"] = ["producer_verification_or_source_identity_failed"]


def reconcile_inventory(inventory_path, projection_index, grouping_runs=()):
    """Runs optionally carry exploration_context_path; each such context is replayed."""
    runs = list(grouping_runs)
    ids = [run["request"]["request_id"] for run in runs]
    _require(len(ids) == len(set(ids)), "Duplicate request outcome")
    _require(isinstance(projection_index, dict), "Explicit original-image projection index required")
    new_index = {}
    for iid, path in projection_index.items():
        try:
            if projection_profile(path) == PROFILE:
                new_index[iid] = path
        except (OSError, ValueError, TypeError, AttributeError):
            pass  # Legacy accounting records this unreadable input as pending.
    old = [run for run in runs if run.get("exploration_context_path") is None]
    _require(not any(set(run["request"]["candidate_image_ids"]) & set(new_index) for run in old),
             "v1.2 execution requires the new explicit exploratory context; the old entry remains unchanged")
    report = legacy.reconcile_inventory(inventory_path, {iid: p for iid, p in projection_index.items() if iid not in new_index}, old)
    rows = {r["image_id"]: r for r in report["records"]}
    _require(set(projection_index) <= set(rows), "Projection index is outside the original corpus")
    if new_index:
        _add_v1_2_rows(report, inventory_path, new_index)
    for row in rows.values():
        row["exploratory_library_memberships"] = []
    for run in runs:
        if run.get("exploration_context_path") is None:
            continue
        request, result = run["request"], run.get("result")
        rid = request["request_id"]
        prepared = prepare_request_views(request, projection_index, inventory_path=inventory_path,
                                         exploration_context_path=run["exploration_context_path"])
        documents = {d["image_id"]: d for d in prepared["guarded_image_dna"]}
        for audit in prepared["coverage_audits"]:
            iid = audit["image_id"]
            _require(rows[iid]["cmf_status"] == "verified_useful_local", "Context selection lacks a verified useful inventory projection")
            rows[iid]["exploratory_library_memberships"].append({"request_id": rid, **deepcopy(audit["reference_qualification"])})
            rows[iid]["request_outcomes"].append({"request_id": rid, "status": result.get("status") if result else "not_executed"})
        if result is None:
            continue
        _require(result.get("request_id") == rid and result.get("alignment_mode") == request["alignment_mode"]
                 and result.get("relation_basis") == request["relation_basis"], "Request/result policy identity changed")
        for field in ("candidate_bindings", "negative_scope_version", "negative_audit_ids", "scoped_negative_preferences", "pending_context_constraints"):
            if field in request:
                _require(result.get(field) == request[field], "Result dropped or changed request scope: " + field)
        if request.get("negative_scope_version") and "input_errors" not in result:
            _require(result.get("forbidden_features") == request["forbidden_features"], "Result dropped CT002 forbidden features")
        pairs = {(b["image_id"], b["object_id"]) for b in request["candidate_bindings"]}
        positive_pids = set(request.get("comparison_features", [])) | {f["parameter_id"] for f in request.get("required_features", [])}
        for cluster in result["clusters"]:
            multi = len({m["image_id"] for m in cluster["members"]}) > 1
            for member in cluster["members"]:
                iid, oid = member["image_id"], member["object_id"]
                _require((iid, oid) in pairs and iid in documents, "Group member was not explicitly selected")
                positives = {o["observation_id"]: o for o in documents[iid]["observations"] if not o.get("consumer_scope_guard")}
                mids = member.get("observation_ids", [])
                _require(mids and set(mids) <= set(positives) and all(positives[mid]["object_id"] == oid for mid in mids),
                         "Group member splices carriers or uses unreviewed/guard evidence")
                _require(all(positives[mid]["parameter_id"] in positive_pids for mid in mids), "Member positive PID is outside request")
                field = "group_memberships" if multi else "singletons"
                rows[iid][field].append({"request_id": rid, "cluster_id": cluster["cluster_id"], **deepcopy(member)})
        for source_field, row_field in (("excluded", "exclusions"), ("boundary_members", "boundaries")):
            for entry in result[source_field]:
                _require(entry["image_id"] in documents, "Outcome outside explicit request selection")
                rows[entry["image_id"]][row_field].append({"request_id": rid, **deepcopy(entry)})
    for row in rows.values():
        if not row["exploratory_library_memberships"]:
            continue
        if row["group_memberships"]:
            status, reason = "grouped", "member_of_multi_image_candidate_group"
        elif row["singletons"]:
            status, reason = "singleton", "single_image_candidate_not_forced_into_larger_group"
        elif row["boundaries"] or any(o["status"] in ("not_executed", "needs_input", "partial") for o in row["request_outcomes"]):
            status, reason = "local_pending", "unresolved_local_or_request_scope"
        elif any(e.get("reason") != "outside_candidate_bindings" for e in row["exclusions"]):
            status, reason = "excluded", "explicit_exclusion_in_supplied_request_scope"
        else:
            status, reason = "ungrouped", "approved_exploratory_library_member_without_candidate_group"
        row.update(primary_disposition=status, reason_codes=[reason], has_boundary_carriers=bool(row["boundaries"]))
    counts = dict(Counter(row["primary_disposition"] for row in rows.values()))
    _require(len(rows) == 120 and sum(counts.values()) == 120, "Complete unique original corpus required")
    report["schema_version"] = "prism.exploratory_clustering_closure_ledger.v0.1"
    report["summary"].update(primary_disposition_counts=counts, request_count=len(runs),
        verified_projection_count=sum(row["cmf_status"] in {"verified_useful_local", "verified_no_useful_local"} for row in rows.values()),
        exploratory_context_request_count=len(runs) - len(old),
        approved_exploration_library_images=sum(bool(row["exploratory_library_memberships"]) for row in rows.values()),
        original_reference_pool_unchanged=True)
    return report
