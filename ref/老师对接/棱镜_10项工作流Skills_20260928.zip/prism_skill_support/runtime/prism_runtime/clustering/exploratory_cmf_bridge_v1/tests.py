"""Synthetic consumer boundary tests; owner/source replay is mocked explicitly.

These do not certify real H01/H02 choices, D03/CMF accuracy, or user approval.
"""
from contextlib import ExitStack
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from prism_runtime.handshake.common import fingerprint
from prism_runtime.clustering import cluster_candidates
from prism_runtime.clustering.scope_examples import scope_example
from prism_runtime.clustering.local_cmf_bridge_v1.tests.test_guards import projection
from prism_runtime.clustering.local_cmf_bridge_v1.tests.test_ledger import inventory_fixture
from . import bridge, ledger, producers


class ConsumerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.context = Path(self.tmp.name) / "synthetic-context.json"
        self.context.write_text('{"synthetic_protocol_fixture":true}', encoding="utf-8")
        self.spec, self.doc = projection()
        mode, _ = scope_example(mode="exploration")
        for key in ("alignment_mode", "alignment_label", "relation_basis", "hypothesis_refs"):
            self.spec[key] = mode[key]
        iid = "I010"
        self.doc.update(image_id=iid, source_kind="trend")
        self.spec["candidate_image_ids"] = [iid]
        self.spec["candidate_bindings"][0]["image_id"] = iid
        self.spec["forbidden_features"][0]["scope"]["bindings"][0]["image_id"] = iid
        self.spec.update(theme_selection_id="synthetic:selected", admission_snapshot="synthetic:admission", design_axis="CMF")
        self.spec["exploration_context_id"] = "synthetic:closed-library-context"
        self.path = Path(self.tmp.name) / "synthetic-projection.json"
        self.path.write_text(json.dumps(self.doc), encoding="utf-8")
        self.producer = {"passed": True, "model_calls": 0, "projection_identity": bridge.legacy._identity(self.path)}
        self.receipt = {"passed": True, "model_calls": 0, "context_identity": bridge.legacy._identity(self.context),
            "context_id": self.spec["exploration_context_id"],
            "request_snapshot": fingerprint(self.spec), "authority_kind": "user_delegated_ai",
            "candidate_pool_kind": "approved_closed_exploration_library",
            "carrier_rule": {"kind": "all_original_objects_with_reviewed_local_cmf", "exclude_object_type_ids": ["O19"]},
            "human_designer_actually_reviewed": False,
            "selected_references": [{"image_id": iid, "role": bridge.EXPLORATORY_ROLE,
                "projection_identity": self.producer["projection_identity"],
                "original_T01_reference_role": {"globally_registered": False, "theme_ids": []},
                "bindings": [{"object_id": "body", "observation_ids": [o["observation_id"] for o in self.doc["observations"] if o["parameter_id"] != "synthetic:finish"]}]}]}
        self.inventory = inventory_fixture()

    def mocks(self, owner_error=None):
        stack = ExitStack()
        stack.enter_context(patch.object(bridge, "_verify_owner", side_effect=owner_error,
                                        return_value=deepcopy(self.receipt)))
        stack.enter_context(patch.object(bridge.legacy, "_inventory_data", return_value=self.inventory))
        stack.enter_context(patch.object(bridge, "load_verified_projection", return_value=(self.doc, self.producer)))
        stack.enter_context(patch.object(bridge.legacy, "_match_corpus_identity"))
        return stack

    def prepare(self):
        return bridge.prepare_guarded_view(self.spec, self.path, inventory_path="synthetic-inventory",
                                            exploration_context_path=self.context)

    def test_no_context_delegates_exactly_to_frozen_entry(self):
        with patch.object(bridge.legacy, "prepare_guarded_view", return_value={"old": True}) as original, \
             patch.object(bridge, "_verify_owner") as owner:
            result = bridge.prepare_guarded_view(self.spec, self.path, inventory_path="inventory")
        self.assertEqual(result, {"old": True})
        original.assert_called_once_with(self.spec, self.path, inventory_path="inventory")
        owner.assert_not_called()

    def test_guarded_local_candidate_preserves_complete_input_and_original_roles(self):
        original = deepcopy((self.spec, self.doc))
        with self.mocks():
            output = self.prepare()
        self.assertEqual((self.spec, self.doc), original)
        self.assertFalse(output["audit"]["reference_qualification"]["original_registered_reference_global"])
        self.assertTrue(output["audit"]["reference_qualification"]["original_reference_pool_unchanged"])
        self.assertEqual(output["image_dna"]["objects"], self.doc["objects"])
        self.assertEqual(output["image_dna"]["observations"][:len(self.doc["observations"])], self.doc["observations"])
        self.assertTrue(any(g["object_id"] == "background" for g in output["audit"]["guards"]))
        result = cluster_candidates(self.spec, [output["image_dna"]])
        self.assertEqual(result["summary"]["clustered_images"], 1)

    def test_whole_image_unknown_still_blocks_the_candidate(self):
        next(o for o in self.doc["objects"] if o["object_id"] == "background")["object_type_id"] = "O19"
        self.spec["forbidden_features"][0]["scope"] = {"kind": "image", "status": "resolved",
            "image_ids": ["I010"], "evidence_refs": ["synthetic:scope"]}
        self.receipt["request_snapshot"] = fingerprint(self.spec)
        with self.mocks():
            output = self.prepare()
        self.assertTrue(any(o.get("object_type_id") == "O19" for o in output["image_dna"]["objects"]))
        self.assertTrue(any(g["object_id"] == "background" for g in output["audit"]["guards"]))
        result = cluster_candidates(self.spec, [output["image_dna"]])
        self.assertFalse(result["clusters"])
        self.assertTrue(result["boundary_members"])
        self.assertEqual(result["scoped_negative_preferences"], self.spec["scoped_negative_preferences"])

    def test_consensus_and_extension_cannot_use_supplemental_context(self):
        with self.mocks():
            for mode in ("consensus", "extension"):
                self.spec["alignment_mode"] = mode
                with self.assertRaisesRegex(ValueError, "exploration-only"):
                    self.prepare()

    def test_owner_rejecting_D03_or_authority_never_falls_back(self):
        for error in ("D03 failed", "missing Root authority", "H01 draft snapshot mismatch"):
            with self.mocks(ValueError(error)), patch.object(bridge.legacy, "prepare_guarded_view") as fallback:
                with self.assertRaisesRegex(ValueError, error):
                    self.prepare()
                fallback.assert_not_called()

    def test_context_or_request_snapshot_mismatch_rejected(self):
        for target in ("context_identity", "request_snapshot"):
            with self.subTest(target=target):
                good = deepcopy(self.receipt[target])
                self.receipt[target] = "changed"
                with self.mocks(), self.assertRaises(ValueError): self.prepare()
                self.receipt[target] = good

    def test_confirmation_must_remain_AI_delegated(self):
        self.receipt["human_designer_actually_reviewed"] = True
        with self.mocks(), self.assertRaisesRegex(ValueError, "delegated authority"):
            self.prepare()
        self.receipt["human_designer_actually_reviewed"] = False
        self.receipt.pop("carrier_rule")
        with self.mocks(), self.assertRaisesRegex(ValueError, "approved carrier rule"):
            self.prepare()

    def test_original_calibration_and_synthetic_cannot_enter_new_context(self):
        for kind in ("calibration", "research", "synthetic"):
            self.inventory[1]["I010"]["source_kind"] = kind
            with self.mocks(), self.assertRaisesRegex(ValueError, "original trend"):
                self.prepare()

    def test_reference_cannot_impersonate_original_T01_registration(self):
        self.receipt["selected_references"][0]["role"] = "original_registered_reference"
        with self.mocks(), self.assertRaisesRegex(ValueError, "original T01"):
            self.prepare()

    def test_unselected_image_or_carrier_is_rejected(self):
        for field, value in (("candidate_image_ids", ["I010", "I011"]),
                             ("candidate_bindings", [{"image_id": "I010", "object_id": "background"}])):
            original = deepcopy(self.spec[field])
            self.spec[field] = value
            self.receipt["request_snapshot"] = fingerprint(self.spec)
            with self.mocks(), self.assertRaises(ValueError): self.prepare()
            self.spec[field] = original

    def test_changed_projection_and_unusable_projection_rejected(self):
        self.receipt["selected_references"][0]["projection_identity"] = {"path": "changed", "sha256": "changed"}
        with self.mocks(), self.assertRaisesRegex(ValueError, "projection identity"):
            self.prepare()
        self.receipt["selected_references"][0]["projection_identity"] = self.producer["projection_identity"]
        self.doc["observations"] = []
        with self.mocks(), self.assertRaisesRegex(ValueError, "usable reviewed"):
            self.prepare()

    def test_missing_unreviewed_or_cross_carrier_observation_rejected(self):
        binding = self.receipt["selected_references"][0]["bindings"][0]
        binding["observation_ids"] = ["not-admitted"]
        with self.mocks(), self.assertRaisesRegex(ValueError, "missing, unreviewed"):
            self.prepare()
        binding["observation_ids"] = [self.doc["observations"][0]["observation_id"]]
        self.doc["observations"][0]["object_id"] = "background"
        with self.mocks(), self.assertRaisesRegex(ValueError, "splice carriers"):
            self.prepare()

    def test_batch_requires_every_projection_and_verifies_context_once(self):
        with self.mocks():
            with self.assertRaisesRegex(ValueError, "projection is missing"):
                bridge.prepare_request_views(self.spec, {}, inventory_path="synthetic", exploration_context_path=self.context)
            with patch.object(bridge, "_verify_owner", return_value=self.receipt) as owner:
                output = bridge.prepare_request_views(self.spec, {"I010": self.path}, inventory_path="synthetic", exploration_context_path=self.context)
                owner.assert_called_once()
        self.assertEqual(len(output["guarded_image_dna"]), 1)
        self.assertFalse(output["clustering_executed"])

    def test_H02_examples_alone_are_not_an_approved_library(self):
        self.receipt["candidate_pool_kind"] = "H02_typical_examples"
        with self.mocks(), self.assertRaisesRegex(ValueError, "H02 examples"):
            self.prepare()

    def test_full_library_reaches_engine_including_a_nonmatching_nonexample(self):
        # The second image has usable CMF, but its contour does not match the
        # H02 feature. Library qualification must not pre-filter it away.
        other = deepcopy(self.doc)
        other["image_id"] = "I011"
        for obs in other["observations"] + other["cmf_admission"]["all_cmf_units"]:
            if obs["object_id"] == "body" and obs["parameter_id"] == "synthetic:contour":
                obs["value"] = "angular"
        path = Path(self.tmp.name) / "nonexample.json"
        path.write_text(json.dumps(other), encoding="utf-8")
        proof = {"passed": True, "model_calls": 0, "projection_identity": bridge.legacy._identity(path)}
        self.spec["candidate_image_ids"].append("I011")
        self.spec["candidate_bindings"].append({"image_id": "I011", "object_id": "body"})
        self.spec["forbidden_features"][0]["scope"]["bindings"].append({"image_id": "I011", "object_id": "body"})
        self.receipt["selected_references"].append({"image_id": "I011", "role": bridge.EXPLORATORY_ROLE,
            "original_T01_reference_role": {"globally_registered": False, "theme_ids": []}, "projection_identity": proof["projection_identity"],
            "bindings": [{"object_id": "body", "observation_ids": []}]})
        self.receipt["request_snapshot"] = fingerprint(self.spec)
        def load(p):
            return (other, proof) if Path(p) == path else (self.doc, self.producer)
        with self.mocks(), patch.object(bridge, "load_verified_projection", side_effect=load):
            output = bridge.prepare_request_views(self.spec, {"I010": self.path, "I011": path},
                inventory_path="synthetic", exploration_context_path=self.context)
        self.assertEqual([d["image_id"] for d in output["guarded_image_dna"]], ["I010", "I011"])
        result = cluster_candidates(self.spec, output["guarded_image_dna"])
        self.assertEqual({m["image_id"] for c in result["clusters"] for m in c["members"]}, {"I010"})
        self.assertTrue(any(d["image_id"] == "I011" and d["status"] == "excluded" for d in result["carrier_diagnostics"]))

    def run_ledger(self, result):
        def load(path):
            return self.doc, self.producer
        with self.mocks(), patch.object(ledger.legacy, "_inventory_data", return_value=self.inventory), \
             patch.object(ledger.legacy, "load_verified_projection", side_effect=load), \
             patch.object(ledger.legacy, "_match_corpus_identity"):
            return ledger.reconcile_inventory("synthetic", {"I010": self.path}, [
                {"request": self.spec, "result": result, "exploration_context_path": self.context}])

    def test_ledger_full_120_preserves_original_pool_and_new_role(self):
        report = self.run_ledger(None)
        self.assertEqual(sum(report["summary"]["primary_disposition_counts"].values()), 120)
        self.assertEqual(report["summary"]["reference_eligible_images"], 9)
        self.assertEqual(report["summary"]["approved_exploration_library_images"], 1)
        rows = {r["image_id"]: r for r in report["records"]}
        self.assertEqual(rows["I010"]["source_kind"], "trend")
        self.assertEqual(rows["I010"]["primary_disposition"], "local_pending")
        self.assertEqual(rows["I010"]["exploratory_library_memberships"][0]["role"], bridge.EXPLORATORY_ROLE)
        self.assertEqual(rows["I010"]["exploratory_library_memberships"][0]["approved_carrier_rule"], self.receipt["carrier_rule"])
        self.assertEqual(rows["I011"]["exploratory_library_memberships"], [])
        self.assertFalse(rows["I010"]["h02_authorization_granted_by_ledger"])

    def test_ledger_actual_synthetic_output_preserves_singleton_and_boundary(self):
        with self.mocks(): output = self.prepare()
        result = cluster_candidates(self.spec, [output["image_dna"]])
        result["boundary_members"].append({"image_id": "I010", "object_id": "background", "reason": "synthetic_unknown"})
        report = self.run_ledger(result)
        row = next(r for r in report["records"] if r["image_id"] == "I010")
        self.assertEqual(row["primary_disposition"], "singleton")
        self.assertTrue(row["has_boundary_carriers"])

    def test_ledger_rejects_unselected_member_and_guard_evidence(self):
        with self.mocks(): output = self.prepare()
        original = cluster_candidates(self.spec, [output["image_dna"]])
        for field, value in (("image_id", "I011"), ("object_id", "background"),
                             ("observation_ids", ["cmf-unavailable:fake"]), ("observation_ids", ["finish"])):
            result = deepcopy(original)
            result["clusters"][0]["members"][0][field] = value
            with self.assertRaises(ValueError): self.run_ledger(result)

    def test_ledger_rejects_result_with_deleted_negative_audit(self):
        with self.mocks(): output = self.prepare()
        result = cluster_candidates(self.spec, [output["image_dna"]])
        result["scoped_negative_preferences"] = []
        with self.assertRaisesRegex(ValueError, "dropped or changed request scope"):
            self.run_ledger(result)

    def test_v1_2_accounting_keeps_codec_failure_distinct_without_expanding_pool(self):
        self.doc["provenance"]["parser_version"] = producers.PROFILE
        self.doc["cmf_admission"]["codec_recovery"] = {"status": "recovered_unaffected_observations_only", "fixture_only": True}
        unit = next(u for u in self.doc["cmf_admission"]["all_cmf_units"] if u["object_id"] == "background")
        unit.update(value_status="invalid_encoding", value=None, disposition="program_error",
                    encoding_failure={"raw_token": -1, "pointer": "/synthetic/slot", "error": "invalid code"})
        self.path.write_text(json.dumps(self.doc), encoding="utf-8")
        with self.mocks(), patch.object(ledger.legacy, "_inventory_data", return_value=self.inventory), \
             patch.object(ledger, "load_verified_projection", return_value=(self.doc, self.producer)):
            report = ledger.reconcile_inventory("synthetic", {"I010": self.path})
        row = next(r for r in report["records"] if r["image_id"] == "I010")
        self.assertEqual(row["primary_disposition"], "parsed_not_reference_pool")
        self.assertEqual(row["original_cmf_admission"], self.doc["cmf_admission"])
        self.assertEqual(report["summary"]["reference_eligible_images"], 9)
        self.assertEqual(report["summary"]["verified_projection_count"], 1)
        with patch.object(producers, "load_verified_projection", return_value=(self.doc, self.producer)):
            view = producers.prepare_pid_view(self.path, [unit["parameter_id"]])
        self.assertEqual(view["audit"]["original_admission"], self.doc["cmf_admission"])
        self.assertTrue(any(r.get("original_value_status") == "invalid_encoding" for g in view["audit"]["guards"] for r in g["unavailable_reasons"]))


class ProducerRegistryTests(unittest.TestCase):
    def test_unknown_profile_cannot_import_or_fall_back(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "unknown.json"
            path.write_text(json.dumps({"provenance": {"parser_version": "r17-local-cmf-v99"}}), encoding="utf-8")
            with patch.object(producers.importlib, "import_module") as imported, \
                 patch.object(producers.legacy, "load_verified_projection") as fallback:
                with self.assertRaisesRegex(ValueError, "Unsupported producer profile"):
                    producers.load_verified_projection(path)
                imported.assert_not_called()
                fallback.assert_not_called()

    def test_changed_Root_acceptance_is_rejected_before_import(self):
        with patch.object(producers.legacy, "_identity", return_value={"path": "changed", "sha256": "changed"}), \
             patch.object(producers.importlib, "import_module") as imported:
            with self.assertRaisesRegex(ValueError, "acceptance/freeze changed"):
                producers._registered_verifier()
            imported.assert_not_called()

    def test_old_versions_use_the_original_verifier(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "old.json"
            for profile in ("r17-local-cmf-v1", "r17-local-cmf-v1.1"):
                path.write_text(json.dumps({"provenance": {"parser_version": profile}}), encoding="utf-8")
                with patch.object(producers.legacy, "load_verified_projection", return_value=("old", "receipt")) as old, \
                     patch.object(producers, "_registered_verifier") as new:
                    self.assertEqual(producers.load_verified_projection(path), ("old", "receipt"))
                    old.assert_called_once_with(path.resolve())
                    new.assert_not_called()


if __name__ == "__main__":
    unittest.main()
