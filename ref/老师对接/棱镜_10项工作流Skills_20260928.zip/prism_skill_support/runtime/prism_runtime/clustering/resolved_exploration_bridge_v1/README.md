# Bounded H02 design-resolution consumer

This separate adapter consumes only the explicitly registered context schema and version from `prism_runtime.handshake.design_resolution_v1.verify_context`. It never falls back to an old context verifier. The 26 Root-frozen consumer sources and the original clustering engine remain unchanged.

```python
from prism_runtime.clustering.resolved_exploration_bridge_v1 import prepare_request_views
from prism_runtime.clustering import cluster_candidates

prepared = prepare_request_views(
    request, final_projection_index,
    inventory_path=original_inventory,
    exploration_context_path=registered_actual_context,
)
result = cluster_candidates(request, prepared['guarded_image_dna'])
```

`registered_context.json` binds the exact context schema, owner algorithm version, Root's stored `Root-design-resolution-v2.json` identity and the existing consumer source freeze. A pending registration cannot execute. Owner modules and functions are fixed in code, not supplied by input documents.

The owner leaf verifier must replay the original H02 responses, prepared inputs, Root's bounded simulation decision, the derived audit and the separate final direction/library confirmation. The consumer checks the complete request hash, decision identity, physical-scale unknown status, exploration-only CMF mode, all 39 library images and all 495 approved carriers. It independently preserves original trend/T01 roles and delegates transport to the unchanged `_prepare` guard. No positive observation, value, region, negative condition or unknown coverage is edited by this adapter.

The Root decision only permits the three recorded preference/evidence/condition/scene mappings for this simulation, reference-region-only comparison while physical scale stays unknown, and declaration of TR036/o4 for the two already-selected comparison observations. The adapter does not independently make those decisions, authenticate a human designer, or expand them to other inputs. Invalid identities or an unregistered schema/version reject without fallback.

No new model or API call, no confirmation, no new grouping method, no rerun of the complete 120-image ledger. Actual context-to-consumer-to-engine replay is separate from the earlier synthetic boundary tests.
