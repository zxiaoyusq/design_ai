"""Thin, fixed-route consumer of the bounded Root H02 design resolution.

No old context fallback, source edits, authorizations, inference or new matcher.
"""
from copy import deepcopy
import json
from pathlib import Path

from prism_runtime.handshake.common import fingerprint
from ..exploratory_cmf_bridge_v1 import bridge as frozen

CONTEXT_SCHEMA = "prism.exploratory_reference_context_design_resolution.v1"
OWNER_MODULE = "prism_runtime.handshake.design_resolution_v1"
VERSION = "resolved-exploration-cmf-bridge-v1"
_require = frozen._require
_identity = frozen.legacy._identity


def _registration():
    registry = json.loads(Path(__file__).with_name("registered_context.json").read_text(encoding="utf-8"))
    _require(registry.get("status") == "registered" and registry.get("context_schema") == CONTEXT_SCHEMA
             and registry.get("owner_module") == OWNER_MODULE and registry.get("algorithm_version"),
             "Design-resolution context version is not explicitly registered")
    for key in ("design_resolution_identity", "consumer_freeze_identity"):
        ref = registry[key]
        _require(_identity(ref["path"]) == ref, "Registered Root identity changed: " + key)
    freeze = json.loads(Path(registry["consumer_freeze_identity"]["path"]).read_text(encoding="utf-8-sig"))
    for entry in freeze["files"]:
        _require(_identity(entry["source"])["sha256"] == entry["sha256"], "Frozen consumer source changed")
    decision = json.loads(Path(registry["design_resolution_identity"]["path"]).read_text(encoding="utf-8-sig"))
    _require(decision.get("authority_kind") == "user_delegated_ai" and decision.get("human_designer_actually_reviewed") is False
             and decision.get("simulation_only") is True and decision["scale_decision"]["mode"] == "reference_region_only"
             and decision["scale_decision"]["physical_scale_status"] == "unknown"
             and decision["scale_decision"]["new_metric_values"] == [], "Root decision scope is not the registered local simulation")
    return registry


def _checked_context(request, context_path, inventory_path):
    _require(context_path is not None and inventory_path is not None, "Explicit new context and original inventory are required")
    registry = _registration()
    before = _identity(context_path)
    header = json.loads(Path(context_path).read_text(encoding="utf-8-sig"))
    _require(header.get("schema_version") == CONTEXT_SCHEMA and header.get("algorithm_version") == registry["algorithm_version"],
             "Unsupported design-resolution schema/version; no fallback")
    _require(request.get("alignment_mode") == "exploration" and request.get("design_axis") == "CMF"
             and request.get("alignment_label") == frozen.MODES["exploration"][0]
             and request.get("relation_basis") in frozen.MODES["exploration"][1], "Exploration CMF policy changed")
    # Fixed import, never a module or entrypoint taken from a context document.
    from prism_runtime.handshake.design_resolution_v1 import verify_context
    receipt = verify_context(context_path, request=request, inventory_path=inventory_path)
    _require(receipt.get("passed") is True and receipt.get("model_calls") == 0, "Official design-resolution replay did not pass")
    _require(receipt.get("algorithm_version") == registry["algorithm_version"]
             and receipt.get("context_schema_version") == CONTEXT_SCHEMA, "Owner receipt schema/version changed")
    _require(before == receipt.get("context_identity") == _identity(context_path), "Context changed during replay")
    _require(receipt.get("request_snapshot") == fingerprint(request)
             and receipt.get("context_id") == request.get("exploration_context_id"), "Complete request/context binding changed")
    _require(receipt.get("design_resolution_identity") == registry["design_resolution_identity"]
             and receipt.get("physical_scale_status") == "unknown" and receipt.get("scale_mode") == "reference_region_only",
             "Registered decision or physical unknown state changed")
    _require(receipt.get("authority_kind") == "user_delegated_ai" and receipt.get("human_designer_actually_reviewed") is False,
             "Context cannot claim a human decision")
    _require(receipt.get("candidate_pool_kind") == "approved_closed_exploration_library"
             and isinstance(receipt.get("carrier_rule"), dict) and receipt["carrier_rule"], "Approved library/rule is absent")
    inventory, originals, pool = frozen.legacy._inventory_data(inventory_path)
    original_roles = {r["image_id"]: r.get("reference_theme_ids", []) for r in inventory["records"]}
    refs = receipt.get("selected_references", [])
    selected = {r["image_id"]: r for r in refs}
    candidates = request.get("candidate_image_ids", [])
    _require(len(refs) == len(selected) == len(candidates) == registry["expected_library_image_count"]
             and set(selected) == set(candidates), "The approved 39-image library changed")
    approved = [(r["image_id"], b["object_id"]) for r in refs for b in r.get("bindings", [])]
    requested = [(b["image_id"], b["object_id"]) for b in request.get("candidate_bindings", [])]
    _require(len(approved) == len(set(approved)) == len(requested) == len(set(requested)) == registry["expected_carrier_count"]
             and set(approved) == set(requested), "The approved 495-carrier enumeration changed")
    for iid, entry in selected.items():
        _require(iid in originals and originals[iid]["source_kind"] == "trend" and entry.get("role") == frozen.EXPLORATORY_ROLE,
                 "Unqualified source or reference-role substitution")
        role = entry.get("original_T01_reference_role", {})
        _require(isinstance(role, dict) and role.get("globally_registered") is (iid in pool["eligible_image_ids"])
                 and sorted(role.get("theme_ids", [])) == sorted(original_roles[iid]), "Original T01 role changed")
    _require(_identity(registry["design_resolution_identity"]["path"]) == registry["design_resolution_identity"],
             "Root decision changed during replay")
    return {"receipt": receipt, "selected": selected, "originals": originals, "pool": pool}


def _prepare(request, projection_path, checked):
    output = frozen._prepare(request, projection_path, checked)
    qualification = output["audit"]["reference_qualification"]
    qualification.update(design_resolution_identity=deepcopy(checked["receipt"]["design_resolution_identity"]),
                         physical_scale_status="unknown", source_observations_modified=False)
    output["image_dna"]["consumer_scope"]["exploratory_reference_qualification"] = deepcopy(qualification)
    return output


def prepare_guarded_view(request, projection_path, *, inventory_path, exploration_context_path):
    checked = _checked_context(request, exploration_context_path, inventory_path)
    return _prepare(request, projection_path, checked)


def prepare_request_views(request, projection_index, *, inventory_path, exploration_context_path):
    checked = _checked_context(request, exploration_context_path, inventory_path)
    ids = request["candidate_image_ids"]
    _require(isinstance(projection_index, dict) and set(ids) <= set(projection_index), "A library projection is missing")
    views = [_prepare(request, projection_index[iid], checked) for iid in ids]
    _require([v["image_dna"]["image_id"] for v in views] == ids, "Projection index image mismatch")
    _require(_identity(exploration_context_path) == checked["receipt"]["context_identity"], "Context changed during transport preparation")
    return {"request_id": request["request_id"], "guarded_image_dna": [v["image_dna"] for v in views],
            "coverage_audits": [v["audit"] for v in views], "consumer_adapter": VERSION,
            "clustering_executed": False, "new_model_calls": 0, "new_API_calls": 0}
