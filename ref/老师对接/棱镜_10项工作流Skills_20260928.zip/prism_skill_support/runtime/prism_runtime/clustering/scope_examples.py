"""Synthetic CT-002 examples, with no real interview or approval claims."""
from .fixtures import image, request
from .negative_scope import SCOPE_VERSION


def scope_example(kind="candidate_bindings", *, body_finish="matte", background_finish="mirror", mode="consensus"):
    iid = "synthetic:phone-scene"
    body_region = {"object_id": "body", "synthetic_region_id": "phone-back"}
    background_region = {"object_id": "background", "synthetic_region_id": "background"}
    record = image(iid, finish=body_finish, region=body_region)
    background = image(iid, finish=background_finish, object_id="background", region=background_region)
    for observation in background["observations"]:
        observation["observation_id"] += "-background"
    record["observations"].extend(background["observations"])
    spec = request([iid], mode)
    spec["request_id"] = "synthetic:scope-demo:" + mode + ":" + kind
    spec["title"] = "合成范围测试：圆润后壳与镜面排斥"
    spec["target_user_ids"] = ["synthetic:user"]
    spec["candidate_bindings"] = [{"image_id": iid, "object_id": "body",
                                   "observation_ids": ["contour", "surface"], "region_refs": [body_region]}]
    spec["negative_scope_version"] = SCOPE_VERSION
    spec["negative_audit_ids"] = ["synthetic:negative-pref"]
    spec["scoped_negative_preferences"] = [{
        "preference_id": "synthetic:negative-pref", "attitude": "dislike", "context_state": "applies",
        "user_ids": ["synthetic:user"], "conditions": ["合成办公场景"],
        "evaluated_conditions": [{"field": "scene", "operator": "eq", "value": "synthetic-office"}],
        "evidence_refs": ["synthetic:explicit-negative"],
        "attitude_lineage": {"interpretation_requires_review": False, "mode": "synthetic"},
        "features": [{"parameter_id": "synthetic:finish", "value": "mirror",
                      "evidence_refs": ["synthetic:explicit-negative"]}],
        "executable_constraint_ids": ["synthetic:ban-mirror"],
    }]
    scope = {"kind": kind, "status": "resolved", "evidence_refs": ["synthetic:scope-confirmation"]}
    if kind == "image":
        scope["image_ids"] = [iid]
    else:
        scope["bindings"] = [{"image_id": iid, "object_id": "body"}]
    spec["forbidden_features"] = [{
        "constraint_id": "synthetic:ban-mirror", "audit_refs": ["synthetic:negative-pref"],
        "parameter_id": "synthetic:finish", "forbidden_values": ["mirror"],
        "evidence_refs": ["synthetic:explicit-negative"], "scope": scope,
    }]
    return spec, [record]
