"""Download explicitly selected article illustrations for pixel-level research QA."""
import hashlib
import io
import json
import math
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageOps, ImageDraw, ImageFont
from .collect_pilot import OUT

PICKS={'A01':[9,23,45,67],'A02':[0],'A03':[1,2,4,5],'A04':[2,3,4,5],
       'A05':[2,4,5],'A06':[4,6,7,10,11],'A07':[0,2,3,4],
       'A08':[0,4,11],'A09':[0,1,3],'A10':[0,1,3]}

def main():
    (OUT/'images').mkdir(exist_ok=True)
    jobs=[]
    for aid,indices in PICKS.items():
        source=json.loads((OUT/(aid+'-retrieval.json')).read_text(encoding='utf-8'))
        for n,i in enumerate(indices,1):
            im=source['images'][i]
            jobs.append({'image_id':f'{aid}-I{n:02}','article_id':aid,'source_kind':'trend',
                         'source_url':im['src'],'original_dom_index':i,'caption':im['caption'],
                         'heading':im['heading'],'credit':im.get('caption') or source['publisher']})
    def fetch(im):
        iid=im['image_id'];path=OUT/'images'/(iid+'.img')
        try:
            if path.exists(): raw=path.read_bytes()
            else:
                req=urllib.request.Request(im['source_url'],headers={'User-Agent':'Mozilla/5.0'})
                with urllib.request.urlopen(req,timeout=30) as r: raw=r.read(15_000_001)
                if len(raw)>15_000_000:raise ValueError('image too large')
                Image.open(io.BytesIO(raw)).verify();path.write_bytes(raw)
            img=Image.open(io.BytesIO(raw));im.update(sha256=hashlib.sha256(raw).hexdigest(),
                image_path=str(path.resolve()),width=img.width,height=img.height,download_status='ok')
        except Exception as e: im.update(download_status='failed',error=str(e))
        return im
    with ThreadPoolExecutor(max_workers=5) as pool: images=list(pool.map(fetch,jobs))
    (OUT/'image-manifest.json').write_text(json.dumps(images,ensure_ascii=False,indent=2),encoding='utf-8')
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',20)
    for aid in PICKS:
        ims=[x for x in images if x['article_id']==aid and x['download_status']=='ok']
        cols=min(2,len(ims)); rows=math.ceil(len(ims)/cols) if cols else 0
        if not rows:continue
        sheet=Image.new('RGB',(cols*600,rows*510),'#f4f3ef'); draw=ImageDraw.Draw(sheet)
        for i,im in enumerate(ims):
            pic=ImageOps.contain(Image.open(im['image_path']).convert('RGB'),(590,470))
            x=(i%cols)*600;y=(i//cols)*510
            sheet.paste(pic,(x+(600-pic.width)//2,y+30+(470-pic.height)//2))
            draw.text((x+10,y+5),im['image_id'],font=font,fill='#222222')
        sheet.save(OUT/'images'/(aid+'-inspection.jpg'),quality=92)
    print(json.dumps({'images':len(images),'downloaded':sum(x['download_status']=='ok' for x in images),
                      'failures':[x for x in images if x['download_status']!='ok']},ensure_ascii=False))

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');main()
