"""Read public pages in our BrowserAct session; retain provenance, not full articles."""
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/prism-algorithm-loop-20260926/modules/trends/pilot'
SOURCES = [
    ('A01', 'British Vogue', 'Conde Nast', 'trend_analysis', 'https://www.vogue.co.uk/article/autumn-winter-2026-fashion-trends'),
    ('A02', 'Vogue Business', 'Conde Nast', 'trend_forecast', 'https://www.vogue.com/article/bye-bye-clean-girl-6-trend-predictions-for-spring-summer-2027'),
    ('A03', 'Vogue Runway', 'Conde Nast', 'runway_review', 'https://www.vogue.com/fashion-shows/spring-2027-ready-to-wear/diane-von-furstenberg'),
    ('A04', 'WGSN', 'WGSN', 'trend_forecast', 'https://www.wgsn.com/en/blog/what-do-trend-forecasters-expect-see-s-s-27-womenswear-catwalks'),
    ('A05', 'ELLE', 'Hearst', 'design_analysis', 'https://www.elle.com/culture/art-design/a73486810/fashion-furniture-trend-2026/'),
    ('A06', 'ELLE Decor', 'Hearst', 'design_analysis', 'https://www.elledecor.com/design-decorate/a73464790/fall-fashion-furniture-trends/'),
    ('A07', 'Rolls-Royce PressClub', 'BMW Group', 'brand_primary_case', 'https://www.press.rolls-roycemotorcars.com/rolls-royce-motor-cars-pressclub/article/detail/T0460764EN/unveiling-phantom-hummingbird:-the-first-rolls-royce-in-history-with-abalone-shell-marquetry'),
    ('A08', 'Wallpaper*', 'Future', 'design_case', 'https://www.wallpaper.com/transportation/lume-ranger-caravan'),
    ('A09', 'Wallpaper*', 'Future', 'design_case', 'https://www.wallpaper.com/design-interiors/faye-toogood-mutina-tiles-faces-and-figures'),
    ('A10', 'Wallpaper*', 'Future', 'design_case', 'https://www.wallpaper.com/design-interiors/rdai-creative-matters-rugs-zoometry-mouvements-modernes-2026'),
]

JS = r"""(() => {
 const root = document.querySelector('.article-detail') || [...document.querySelectorAll('article, main')].sort((a,b)=>b.innerText.length-a.innerText.length)[0] || document.body;
 let heading=''; const blocks=[]; const images=[];
 for(const e of root.querySelectorAll('h1,h2,h3,h4,p,img')) {
   if(/^H/.test(e.tagName)){heading=e.innerText; blocks.push({tag:e.tagName,text:e.innerText});}
   else if(e.tagName==='P' && e.innerText.trim()){blocks.push({tag:'P',heading,text:e.innerText});}
   else if(e.tagName==='IMG'){const src=e.currentSrc||e.getAttribute('data-src')||e.src;
     if(src && !src.startsWith('data:')) images.push({src,alt:e.alt,heading,caption:e.closest('figure')?.querySelector('figcaption')?.innerText||'',width:e.naturalWidth,height:e.naturalHeight});}
 }
 if(document.querySelector('.article-detail')) for(const e of document.querySelectorAll('[style]')) {
   const src=e.style.backgroundImage.match(/url\("?([^"\)]+)/)?.[1];
   if(src && src.includes('hummingbird') && !images.some(i=>i.src===src))images.push({src,alt:'Phantom Hummingbird official article media',heading:'Article media',caption:'Rolls-Royce',width:0,height:0});
 }
 const meta={}; for(const m of document.querySelectorAll('meta[property],meta[name]')){
   const k=m.getAttribute('property')||m.name;if(/published|modified|date|author/.test(k))meta[k]=m.content;
 }
 return JSON.stringify({title:document.title,url:location.href,meta,times:[...document.querySelectorAll('time')].map(e=>({text:e.innerText,date:e.dateTime})),blocks,images});
})()"""

def cli(*args):
    r = subprocess.run(['browser-act', '--session', 'prism-t01-trends-0926', *args], capture_output=True, text=True, encoding='utf-8', timeout=60)
    if r.returncode:
        raise RuntimeError(r.stderr or r.stdout)
    return r.stdout

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for sid,publisher,group,kind,url in SOURCES:
        path=OUT / (sid+'-retrieval.json')
        if path.exists() and not (sid=='A07' and not json.loads(path.read_text(encoding='utf-8')).get('images')):
            continue
        cli('navigate',url)
        raw=cli('eval',JS)
        data=json.loads(raw[raw.index('{'):])
        paragraphs=[b for b in data.pop('blocks') if b.get('text')]
        data.update(article_id=sid,publisher=publisher,publisher_group=group,source_type=kind,retrieved_at=datetime.now(timezone.utc).isoformat(),access_method='browser-act public rendered DOM')
        data['blocks']=[{**{k:v for k,v in b.items() if k!='text'},'index':i,'sha256':hashlib.sha256(b['text'].encode()).hexdigest(),'chars':len(b['text'])} for i,b in enumerate(paragraphs)]
        data['body_sha256']=hashlib.sha256('\n'.join(b['text'] for b in paragraphs).encode()).hexdigest()
        data['body_chars']=sum(len(b['text']) for b in paragraphs)
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        # Source text is read transiently for analysis, not redistributed in delivery.
        selected=[b['text'] for b in paragraphs if len(b['text'])>110]
        print(json.dumps({'id':sid,'title':data['title'],'meta':data['meta'],'times':data['times'],'body':'\n'.join(selected)[:12000],'image_count':len(data['images'])},ensure_ascii=False),flush=True)

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
