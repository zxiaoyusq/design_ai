"""Bounded SOURCE-IDENTITY-001 replay. No media processing or model call."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from .api import ALGORITHM_VERSION, SourceIdentityConflict, prepare, accept

ROOT=Path(__file__).resolve().parents[2]
MODULE=ROOT/'outputs/prism-algorithm-loop-20260926/modules/trends'
OUT=MODULE/'repairs/SOURCE-IDENTITY-001'
INTAKE=ROOT/'outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/simulation-120-20260926'
SOURCE=INTAKE/'identity-tests'
ARCHIVE=MODULE/'versions/v0.1.1-da0d90e4'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def origin(p):return next(e['claim_origin_id'] for e in p['evidence'] if e['evidence_id']=='E1')
def rejected(bundle):
    snapshot=copy.deepcopy(bundle)
    try:prepare(bundle)
    except SourceIdentityConflict as exc:
        assert snapshot==bundle
        return {'status':'source_identity_conflict','code':exc.code,'details':exc.details,'input_unchanged':True}
    raise AssertionError('conflicting import must not produce a prepared request')

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    original_hashes={str(p.relative_to(SOURCE)):sha(p) for p in SOURCE.iterdir() if p.is_file()}
    materials=[p for side in ['trend','research'] for p in (INTAKE/side/'images').iterdir() if p.is_file()]
    assert len(materials)==120
    material_hashes={str(p.relative_to(INTAKE)):sha(p) for p in materials}
    case=read(SOURCE/'source-identity-counterexample.json')
    spec=importlib.util.spec_from_file_location('trends_v011_identity_baseline',ARCHIVE/'prism_runtime/trends/api.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    before_old=old.prepare(case['baseline_input']);after_old=old.prepare(case['variant_input'])
    assert origin(before_old)=='ORIGIN-ONE' and origin(after_old)=='UNTRUSTED-SECOND-ORIGIN'
    before=prepare(case['baseline_input']);assert origin(before)=='ORIGIN-ONE'
    assert before==before_old
    rejection=rejected(case['variant_input'])
    assert rejection['details']['preferred_source_group_id'] is None
    assert next(e['claim_origin_id'] for e in rejection['details']['evidence_claim_origins'] if e['evidence_id']=='E1')=='ORIGIN-ONE'
    write(OUT/'inputs/minimal-original.json',case)
    write(OUT/'outputs/minimal-baseline-prepared.json',before)
    write(OUT/'outputs/minimal-variant-conflict.json',rejection)
    variants=[]
    for copy_id in ['A-COPY','ZZZ-COPY']:
        bundle=copy.deepcopy(case['variant_input']);bundle['articles'][1]['article_id']=copy_id;bundle['evidence'][1]['article_id']=copy_id
        for reverse in [False,True]:
            if reverse:bundle['articles'].reverse();bundle['evidence'].reverse()
            result=rejected(bundle)
            variants.append({'copy_id':copy_id,'reversed':reverse,'status':result['status'],'original_origin_preserved':True})
    # A consistent duplicate is a separate explicit synthetic scenario, not a
    # correction of the original failing input and not an assertion of its truth.
    same=copy.deepcopy(case['variant_input']);same['articles'][1]['source_group_id']='ORIGIN-ONE'
    same['provenance']['purpose']='Separate valid-alias fixture; does not resolve the conflicting original case.'
    same_p=prepare(same);assert {a['source_group_id'] for a in same_p['articles']}=={'ORIGIN-ONE'}
    assert all(e['claim_origin_id']=='ORIGIN-ONE' for e in same_p['evidence'])
    write(OUT/'inputs/valid-same-origin-alias-synthetic.json',same)
    write(OUT/'outputs/valid-same-origin-alias-prepared.json',same_p)
    real_base=read(SOURCE/'baseline-input.json');real_variant=read(SOURCE/'renamed-import-input.json')
    real_p=prepare(real_base);assert real_p==old.prepare(real_base)
    real_rejection=rejected(real_variant)
    write(OUT/'outputs/material-intake-baseline-prepared.json',real_p)
    write(OUT/'outputs/material-intake-renamed-conflict.json',real_rejection)
    pilot=MODULE/'pilot';p=prepare(read(pilot/'corpus.json'))
    assert p==read(pilot/'prepared.json')
    assert accept(p,read(pilot/'proposal.json'))==read(pilot/'themes.json')
    # Regression of the prior two quality handoff counterexamples, without
    # overwriting their historical result files or reexecuting semantic work.
    quality=[]
    for name in ['synthetic-quality-pass-not-reference','quality-route-error-preserves-text']:
        b=read(MODULE/'repairs/TREND-EVAL-R1/inputs'/(name+'.json'))['corpus'];qprep=prepare(b)
        im=next(i for i in qprep['images'] if i['image_id']==b['quality_decisions'][0]['image_id'])
        assert im['reference_eligible'] is False and im['quality_record']==b['quality_decisions'][0]
        quality.append({'case_id':name,'passed':True})
    assert original_hashes=={str(p.relative_to(SOURCE)):sha(p) for p in SOURCE.iterdir() if p.is_file()}
    assert all(sha(INTAKE/path)==value for path,value in material_hashes.items())
    archived=read(ARCHIVE/'original-files.sha256.json')
    assert all(sha(ARCHIVE/x['path'])==x['sha256'] for x in archived['files'])
    result={'dispatch_id':'SOURCE-IDENTITY-001','repair_cycle':1,'algorithm_version':ALGORITHM_VERSION,
       'api_sha256':sha(ROOT/'prism_runtime/trends/api.py'),'status':'author_regression_pass',
       'baseline_failure_reproduced':{'before':origin(before_old),'after':origin(after_old),'failure':'origin identity drift, not extra count'},
       'fixed_behavior':'reject conflicting same-canonical origin assertions with preserved audit details; no preferred origin',
       'minimal_case_passed':True,'sort_and_order_variants':variants,'consistent_alias_passed':True,
       'material_intake_original_unchanged':True,'material_variant_conflict_audited':True,
       'original_pilot_replay':'byte-equivalent JSON','quality_regressions':quality,
       'source_fixture_files_verified':len(original_hashes),'original_120_image_hashes_unchanged':True,
       'archive_files_verified':len(archived['files']),'new_paid_calls':0,
       'H01_H02_executed':False,'semantic_producer_reexecuted':False,'independent_reverification':'pending'}
    write(OUT/'source-fixture-hashes.json',original_hashes)
    write(OUT/'material-120-hashes.json',material_hashes)
    write(OUT/'regression-result.json',result)
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
