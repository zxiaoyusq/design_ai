import argparse
import json
import sys
from pathlib import Path
from .api import VERSION, prepare, accept, SourceIdentityConflict

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def main():
    p=argparse.ArgumentParser(description='T01 semantic request / validated TrendTheme compiler')
    sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('prepare');a.add_argument('bundle');a.add_argument('--start');a.add_argument('--end');a.add_argument('--date-basis',choices=['published_at','updated_at']);a.add_argument('--out',required=True)
    a=sub.add_parser('accept');a.add_argument('prepared');a.add_argument('proposal');a.add_argument('--out',required=True)
    args=p.parse_args()
    exit_code=0
    if args.command=='prepare':
        bundle=read(args.bundle);scope=bundle.get('scope',{}).copy()
        for k,v in [('start_date',args.start),('end_date',args.end),('date_basis',args.date_basis)]:
            if v is not None:scope[k]=v
        try:
            result=prepare(bundle,scope)
        except SourceIdentityConflict as exc:
            result={'schema_version':VERSION,'status':'source_identity_conflict',
                    'error':{'code':exc.code,'details':exc.details}}
            exit_code=2
    else:result=accept(read(args.prepared),read(args.proposal))
    path=Path(args.out);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'output':str(path),'metrics':result.get('metrics')},ensure_ascii=True))
    return exit_code

if __name__=='__main__': sys.exit(main())
