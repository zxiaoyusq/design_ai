"""Offline replay and integrity check of the frozen pilot, not a new semantic run."""
import hashlib
import json
from pathlib import Path
from .api import prepare,accept
from .collect_pilot import OUT

def main():
    read=lambda name:json.loads((OUT/name).read_text(encoding='utf-8'))
    b=read('corpus.json');p=prepare(b);r=accept(p,read('proposal.json'))
    assert r==read('themes.json'),'frozen output differs from replay'
    checked=0
    for im in b['images']:
        # Relative fallback allows a frozen bundle to be moved to an audit directory.
        path=OUT/'images'/Path(im['image_path']).name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==im['sha256'],im['image_id']
        checked+=1
    date_checks=[]
    for start in ['2026-03-26','2026-06-26','2026-08-26']:
        q=prepare(b,{**b['scope'],'start_date':start})
        date_checks.append({'start_date':start,'end_date':b['scope']['end_date'],
                            'eligible_articles':len(q['articles']),'excluded':q['excluded_articles']})
    observed={x['start_date']:x['eligible_articles'] for x in date_checks}
    assert observed=={'2026-03-26':10,'2026-06-26':10,'2026-08-26':8}
    result={'scope':'frozen proposal replay and source/image identity, not independent semantic accuracy',
       'result':'pass','image_hashes_verified':checked,'date_checks':date_checks,'metrics':r['metrics'],
       'new_paid_api_calls':0,'semantic_reexecuted':False,'independent_semantic_validation':False}
    (OUT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
