# T01 · 首次趋势图文语义聚类

本模块位于趋势资料接入之后、H01 主题握手之前。唯一职责是按时间范围从文章和关联图像发现趋势语义主题，输出共享契约 `TrendTheme`；不推断用户偏好、不执行后段条件图片聚类。

当前算法版本 `prism.trends.v0.1.2`，共享 schema 仍为 `prism.trends.v0.1`，提供可替换的 **prepare → 语义生产者 → accept** 流程。代码没有把原标签分组冒充语义聚类，也没有虚构向量或距离。首轮生产者是当前 Codex 宿主：读公开文章并实际检查 34 张图后提出语义主题。`accept` 校验与编译这份提案，不再次执行语义模型，不证明语义正确。

## 可复跑入口

以下命令在项目根目录执行。`python` 指 Python 3.12+；本机可用运行时见本目录交付 `handoff.json`。

```text
python -m unittest prism_runtime.trends.test_api -v
python -m prism_runtime.trends prepare outputs/prism-algorithm-loop-20260926/modules/trends/pilot/corpus.json --start 2026-03-26 --end 2026-09-26 --out outputs/prism-algorithm-loop-20260926/modules/trends/pilot/prepared.json
python -m prism_runtime.trends accept outputs/prism-algorithm-loop-20260926/modules/trends/pilot/prepared.json outputs/prism-algorithm-loop-20260926/modules/trends/pilot/proposal.json --out outputs/prism-algorithm-loop-20260926/modules/trends/pilot/themes.json
python -m prism_runtime.trends.verify_pilot
python -B -m prism_runtime.trends.verify_source_identity_repair
```

改变日期或输入后，原提案的 `input_digest` 不匹配，必须重新进行语义分析。可调用 `prepare(bundle, scope=None)` 与 `accept(prepared, proposal)`。没有默认外部 API、后台循环、模型下载或费用。

## 输入

`corpus.json` 是完整实例。顶层含 `provenance.mode`（real_evidence / synthetic）、`scope`、`articles`、`evidence`、`images`、`quality_decisions`。

- Article：`article_id`、`source_group_id`、`published_at`、`updated_at`、`title`、`url`、`publisher`、`publisher_group`；品牌一手案例与编辑趋势判断分别记录。地区是文章覆盖元数据，不能由刊物总部推断受众。
- Evidence：`evidence_id`、`article_id`、`text`、`text_kind`（source_text / source_paraphrase / synthetic）、`locator`、`image_ids`，可选 `claim_origin_id` 指向已登记原始来源。生产使用可以输入全文分段；本次保存精简转述与原文位置，不复制整篇文章。
- Image：`image_id`、`article_id` 或 `article_ids`、`source_kind`、原图路径/网址/哈希、中性 `visual_observations`。本次轻量像素观察不冒充公共 216/148 ImageDNA；完整 DNA 缺失如实标记。已有 DNA 可通过 observation 的 `basis=existing_image_dna` 与可追溯 `region_ref` 引用。
- Quality：只处理明确的趋势图片身份。正式参考图要求真实数据范围、非合成图片来源、已完成 PASS、`provenance.mode=existing_model_output`、`production_admission is True`，并且 applicable 不能为 false/未知、calibration_only 不能为 true/未知。缺少生产准入或来源的旧 PASS 仍保留审美标签，但只作证据图。
- 接收上游 `prism.quality_route.v0.1` 的 `decision=null` 与 execution_error / invalid_input / invalid_output / needs_confirmation / incomplete / not_applicable。保留 `quality_status`、`quality_error` 及完整 `quality_record`，不改为审美 FAIL，不删除文本或中断语义提案。`accept` 再检查原始质量记录；不能仅凭旧请求中的 reference_eligible=true 正式准入。最终输出的 `quality_routes` 保留这些交接记录。

日期范围两端包含，默认使用首次发表日期。未知日期进入排除清单；更新日期不偷换成首发日期。允许显式 `--date-basis updated_at`，该模式下无更新日期仍为未知。

### 来源身份与冲突

同一canonical URL且声明相同source_group_id的记录可以保留article alias；代表article_id只承担去重索引，不被视为“更可信的原始来源”。所有已有 `evidence.claim_origin_id` 原样保留，包括指向另一个已登记来源的转载关系。缺少该字段时不由alias写入一个假显式来源。

同一canonical URL若声明不同source_group_id，v0.1.2拒绝本次冲突输入，抛出 `SourceIdentityConflict`（TrendError子类），不选择排序靠前或导入较早的声明，也不重写任一来源。`.code` 为 `conflicting_canonical_source_identity`，`.details` 保留网址、各article的来源声明、证据的显式来源或null、未裁定状态。调用方应将冲突交给上游来源核对，不把异常当作“该来源无趋势”。

CLI `prepare` 遇此冲突会将审计JSON写入 `--out`，status为 `source_identity_conflict`，退出码2；该文件不是可提交accept的prepared请求。合法且无冲突的旧输入/输出结构、来源ID与指纹不变；没有引入新的规范化来源ID，也不按相似标题猜测同源。

## 语义生产者协议

`prepare` 返回冻结输入、提示、排除记录及摘要指纹。生产者应从文章中的设计主张分解出可引用的语义片段，读取绑定图片像素或已有 DNA，允许一文多主题；先形成成员和反例，再给主题命名。不预设主题数量或信源权重。

`proposal.json` 包含 `input_digest`、`producer`、`themes`、`unassigned`。每个主题含 `members`：原文证据、实际看过的图片、图像观察引用、text_and_image / text_only / visual_extension、理由与不确定性。每个片段必须归组或给出未归组理由。缺图、文字和像素冲突不得偷偷补全。图片查看声明由生产者负责；代码只能检查记录的一致性。

## 输出

`themes.json.themes` 可交给 H01，保留共享契约要求的 theme_id/title/summary/evidence_refs/image_ids/source_group_ids/scope/provenance。额外字段区分独立主张来源、出版集团、成员依据、迁移条件、正式参考图与证据图。

文章数、图片数与来源数描述采样覆盖，不是趋势热度、增速、准确率或市场高潜概率。单来源方向可保留或列为未归组，不能为凑数强并。

## 本轮边界

v0.1.2 修复 SOURCE-IDENTITY-001：新增同源接入模拟揭示更名副本会覆盖原证据来源，虽然来源总数未增加。此前v0.1.1的11/11独立检查收据保持其原限定范围；本次新增的是来源身份稳定性。v0.1.1 的93份冻结文件已保存在 `modules/trends/versions/v0.1.1-da0d90e4/`；新结果见 `modules/trends/repairs/SOURCE-IDENTITY-001/`。当前38项模块检查通过，新增最小反例/排序变体及原quality反例均通过本地回归，等待Root独立复验。两侧120张原始图片与原反例不改，不进行120图聚类。

v0.1 独立复测发现两项 quality 交接问题（合成 PASS 准入、null 技术错误中断），v0.1.1 修复这两个门控后已收到11/11独立检查通过收据。原 v0.1 的 80 个文件按冻结哈希完整保存在 `outputs/prism-algorithm-loop-20260926/modules/trends/versions/v0.1-83001f6b/`。改良单、最小反例、新输出与复验记录在 `modules/trends/repairs/TREND-EVAL-R1/`。原 10 篇语料、34 张图、语义提案和主题结果没有改写；该历史记录不替代新增来源完整性范围的验收。

接口反例通过与首轮真实材料跑通分别记录。独立设计师标注、盲评、语义稳定性、规模/成本基准、完整公共 DNA 和 D03 均未完成，因此总体状态为 partial，效果待评审。10 篇属于人工目的采样，不能代表全球市场。

`collect_pilot.py` / `download_pilot_images.py` 是本次来源获取记录，固定 BrowserAct 会话属于本任务，不是无人值守采集器。其他任务不得复用该会话；新采集先按 BrowserAct 技能建立自己的会话。`author_pilot.py` 仅导出本次宿主已经做出的观察与提案，不是自动发现新文章趋势的算法。复测应使用冻结 JSON 与 `verify_pilot`，不重新下载网页、不重跑外部模型。
