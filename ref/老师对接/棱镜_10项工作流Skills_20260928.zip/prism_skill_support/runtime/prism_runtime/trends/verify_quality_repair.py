"""Offline reproduction of TREND-EVAL-R1 against archived and repaired code."""
import copy
import hashlib
import importlib.util
import json
from .api import ALGORITHM_VERSION, prepare, accept
from .collect_pilot import ROOT, OUT

FOLDER=OUT.parent/'repairs/TREND-EVAL-R1'
INPUTS=ROOT/'outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop/runs/trends-27383546927e/inputs'
ARCHIVE=OUT.parent/'versions/v0.1-83001f6b'
CASES=['synthetic-quality-pass-not-reference','quality-route-error-preserves-text']

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    FOLDER.mkdir(parents=True,exist_ok=True)
    baseline_path=ARCHIVE/'prism_runtime/trends/api.py'
    baseline_spec=importlib.util.spec_from_file_location('trends_baseline_v01',baseline_path)
    baseline=importlib.util.module_from_spec(baseline_spec);baseline_spec.loader.exec_module(baseline)
    original_proposal=read(OUT/'proposal.json')
    cases=[]
    for name in CASES:
        source=INPUTS/(name+'.json');source_sha=sha(source)
        envelope=read(source);bundle=envelope['corpus'];iid=bundle['quality_decisions'][0]['image_id']
        before=copy.deepcopy(bundle)
        write(FOLDER/'inputs'/(name+'.json'),envelope)
        try:
            old=baseline.prepare(bundle)
            observed=next(i for i in old['images'] if i['image_id']==iid)
            baseline_result={'reference_eligible':observed['reference_eligible']}
        except ValueError as exc:
            baseline_result={'error_type':type(exc).__name__,'message':str(exc)}
        p=prepare(bundle);im=next(i for i in p['images'] if i['image_id']==iid)
        assert im['reference_eligible'] is False
        assert im['quality_record']==bundle['quality_decisions'][0]
        assert p['evidence']==before['evidence']
        assert len(p['articles'])==10 and len(p['evidence'])==26 and len(p['images'])==34
        if name==CASES[0]:
            assert baseline_result.get('reference_eligible') is True
            assert im['quality_decision']=='PASS' and im['quality_record']['provenance']['mode']=='synthetic'
        else:
            assert baseline_result.get('error_type')=='TrendError'
            assert im['quality_decision'] is None and im['quality_status']=='execution_error'
            assert im['quality_error']=='saved_execution_failure'
        # Rebind a copy only for this explicit route counterexample. The host's
        # theme judgments and original proposal remain unchanged; no model runs.
        q=copy.deepcopy(original_proposal);q['input_digest']=p['input_digest']
        r=accept(p,q)
        assert r['metrics']['admitted_reference_images']==0
        assert r['themes']==read(OUT/'themes.json')['themes']
        assert r['quality_routes'][0]['quality_record']==bundle['quality_decisions'][0]
        assert bundle==before and sha(source)==source_sha
        for suffix,value in [('prepared',p),('proposal-rebound',q),('result',r)]:
            write(FOLDER/'outputs'/(name+'-'+suffix+'.json'),value)
        cases.append({'case_id':name,'passed':True,'baseline_failure_reproduced':baseline_result,
            'input_source':str(source),'input_sha256':source_sha,
            'after':{k:im[k] for k in ['quality_decision','quality_status','quality_error','reference_eligible','reference_exclusion_reasons']},
            'articles':len(p['articles']),'evidence_units':len(p['evidence']),'themes':len(r['themes']),
            'upstream_record_preserved':True,'source_input_unchanged':True,
            'proposal_rebind':'Only input_digest copied for this labelled route counterexample; semantic producer not rerun.'})
    pilot=read(OUT/'corpus.json');p=prepare(pilot)
    assert p==read(OUT/'prepared.json')
    assert accept(p,original_proposal)==read(OUT/'themes.json')
    old_manifest=read(ARCHIVE/'original-files.sha256.json')
    assert all(sha(ARCHIVE/x['path'])==x['sha256'] for x in old_manifest['files'])
    originals=['pilot/corpus.json','pilot/prepared.json','pilot/proposal.json','pilot/themes.json']
    assert all(sha(OUT.parent/x)==sha(ARCHIVE/(OUT.parent/x).relative_to(ROOT)) for x in originals)
    result={'dispatch_id':'TREND-EVAL-R1','repair_cycle':1,'algorithm_version':ALGORITHM_VERSION,
        'code_sha256':sha(ROOT/'prism_runtime/trends/api.py'),'status':'author_regression_pass',
        'cases':cases,'summary':{'cases':len(cases),'passed':sum(x['passed'] for x in cases),'failed':0},
        'baseline_archive_files_verified':len(old_manifest['files']),
        'original_pilot_inputs_proposal_outputs_unchanged':True,'original_pilot_replay':'identical',
        'upstream_adapter_sha256':sha(ROOT/'prism_runtime/quality/adapter.py'),
        'semantic_producer_reexecuted':False,'new_paid_calls':0,'independent_reverification':'pending'}
    write(FOLDER/'regression-result.json',result)
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
