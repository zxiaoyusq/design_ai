"""Package this bounded pilot for independent loop review."""
import hashlib
import json
import re
from pathlib import Path
from .collect_pilot import ROOT,OUT
from .report_pilot import main as render

def write(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    folder=OUT.parent;code=ROOT/'prism_runtime/trends'
    log=(OUT/'module-tests.txt').read_text(encoding='utf-8-sig')
    count=int(re.search(r'Ran (\d+) tests',log).group(1))
    assert '\nOK' in log
    # Bring readable reports in line with the observed test log.
    path=folder/'首轮测试报告.md'
    path.write_text(path.read_text(encoding='utf-8').replace('19 项通过',f'{count} 项通过').replace('19项程序测试',f'{count}项程序测试'),encoding='utf-8')
    from . import report_pilot
    report_pilot.TEMPLATE=report_pilot.TEMPLATE.replace('19 项模块测试',f'{count} 项模块测试')
    render()
    verify=json.loads((OUT/'verification.json').read_text(encoding='utf-8'))
    codehash=hashlib.sha256((code/'api.py').read_bytes()).hexdigest()
    version='prism.trends.v0.1+sha256:'+codehash
    runtime='C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
    ui={'status':'pass','viewport_width':1894,'themes':6,'sources':10,'unassigned_signals':8,
        'rendered_image_instances':24,'loaded_image_instances':24,'broken_images':0,'horizontal_overflow':False,
        'date_filter_observed':['10 / 10','8 / 10','invalid range rejected','reset 10 / 10'],
        'screenshots':['pilot/review-desktop.png','pilot/review-evidence.png'],'mobile_tested':False,
        'scope':'static local review page, not a production application'}
    write(OUT/'ui-verification.json',ui)
    limitations=['Semantic judgments were made by the current host; no independent designer/holdout validation.',
        'Frozen replay compiles the saved proposal; it does not rerun a multimodal model.',
        'No automatic hosted model provider, full ImageDNA, D03 admission, scale or cost benchmark.',
        'All 10 articles were used for exploratory interpretation and self-review, not held out.',
        '34 images are evidence only; zero D03-PASS reference images.',
        'T02/T03 may be too broad; T05 is text-led and lacks clear sheer-material pixel support.',
        'Purposeful sample of 10 articles across 7 domains and 5 publisher/institution groups; not market-representative.']
    handoff={'module':'trends','status':'partial','contract_version':'0.1','algorithm_version':version,
       'owner_thread_id':'01a0dd0d-97b0-7e90-b7b1-d0dcd666cd66','runtime':runtime,
       'entrypoint':'python -m prism_runtime.trends prepare <bundle.json> --start YYYY-MM-DD --end YYYY-MM-DD --out <prepared.json>; then python -m prism_runtime.trends accept <prepared.json> <proposal.json> --out <themes.json>',
       'python_api':['prism_runtime.trends.prepare(bundle, scope=None)','prism_runtime.trends.accept(prepared, proposal)'],
       'files':[str(p.relative_to(ROOT)) for p in sorted(code.glob('*')) if p.is_file()],
       'fixture_or_existing_output':['outputs/prism-algorithm-loop-20260926/modules/trends/pilot/corpus.json',
          'outputs/prism-algorithm-loop-20260926/modules/trends/pilot/prepared.json',
          'outputs/prism-algorithm-loop-20260926/modules/trends/pilot/proposal.json',
          'outputs/prism-algorithm-loop-20260926/modules/trends/pilot/themes.json'],
       'verification':{'command':'python -m unittest prism_runtime.trends.test_api -v; python -m prism_runtime.trends.verify_pilot',
         'result':f'{count} unit tests passed; frozen real-evidence replay and 34 image hashes passed; date filter 10/10/8.',
         'log':'pilot/module-tests.txt','interface_qualified':True,'independent_algorithm_effect_qualified':False},
       'new_paid_calls':0,'metrics':verify['metrics'],'limitations':limitations,
       'upstream':['docs/prism/核心工作流.md#T01','prism_runtime/CONTRACT.md#TrendTheme',
                   'D01 article/date/source identity; D02 optional existing DNA; D03 optional trend-only quality'],
       'downstream':['H01: consume themes[]; retain text-only support and unknowns',
                     'C01/H02: only after theme selection; reference_image_ids currently empty'],
       'frontend':'outputs/prism-algorithm-loop-20260926/modules/trends/report.html',
       'production_app_modified':False,'shared_contract_modified':False,
       'freeze_manifest':'files.sha256.json','self_assessment':'self-assessment.json'}
    write(folder/'handoff.json',handoff)
    assessment={'module':'trends','owner_thread_id':handoff['owner_thread_id'],'status':'partial',
       'assessed_scope':'prepare/accept deterministic contract checks pass; real-source host pilot completed; semantic quality not independently qualified',
       'algorithm_version':version,'entrypoint':'python -m prism_runtime.trends.verify_pilot',
       'input_examples':handoff['fixture_or_existing_output'][:3],'output_examples':handoff['fixture_or_existing_output'][3:],
       'self_assessment':{'qualified':False,'interface_qualified':True,'algorithm_effect_qualified':False,
          'criteria':['date/source and image links validated','unknowns and negative quality preserve text','fresh semantic themes rather than old labels','independent semantic evaluation'],
          'actual_results':[f'{count} module tests pass',verify,ui],
          'known_failures':['T02/T03 granularity remains subjective and unreviewed.','T05 sheer subclaim lacks pixel support.','No automatic model adapter wired.']},
       'source_materials':[str(folder/'算法编排.md'),str(folder/'首轮测试报告.md'),str(OUT/'corpus.json'),str(OUT/'image-manifest.json')],
       'holdout_description':'None. All 10 articles and 34 images were used for this exploratory interpretation and self-review; no claimed generalization.',
       'paid_calls_required_for_retest':0,'limitations':limitations,'handoff_ref':str(folder/'handoff.json')}
    write(folder/'self-assessment.json',assessment)
    files=[p for base in [code,folder] for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='files.sha256.json']
    manifest=[{'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)]
    write(folder/'files.sha256.json',{'algorithm_version':version,'files':manifest})
    print(json.dumps({'status':'partial','tests':count,'frozen_files':len(manifest),'code_sha256':codehash},ensure_ascii=False))

if __name__=='__main__':main()
