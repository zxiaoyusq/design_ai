import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from .api import prepare,accept,TrendError,SourceIdentityConflict,digest

def fixture():
    return {'provenance':{'mode':'synthetic'},'scope':{'start_date':'2026-09-01','end_date':'2026-09-26'},
      'articles':[{'article_id':'a','title':'旧标签：汽车','source_group_id':'original-a','url':'https://source.test/a','published_at':'2026-09-01','updated_at':'2026-09-26'},
                  {'article_id':'b','title':'旧标签：秀场','source_group_id':'original-b','url':'https://source.test/b','published_at':'2026-09-26'}],
      'evidence':[{'evidence_id':'e1','article_id':'a','text':'蓝绿色虹彩细节','text_kind':'synthetic','image_ids':['i1'],'clustering_label':'汽车'},
                  {'evidence_id':'e2','article_id':'b','text':'蓝绿色光泽装饰','text_kind':'synthetic','image_ids':[],'clustering_label':'秀场'}],
      'images':[{'image_id':'i1','article_id':'a','source_kind':'trend','visual_observations':[
          {'observation_id':'o1','text':'主体表面有蓝绿色反光','status':'known','basis':'host_pixel_observation','region_ref':'主体局部'}]}]}

def proposal(p):
    return {'input_digest':p['input_digest'],'producer':{'method':'synthetic_fixture','model':'fixture only','inspected_image_ids':['i1']},
            'themes':[{'theme_id':'t1','title':'虹彩细节','summary':'新的跨品类主题，与原标签不同','members':[
                {'evidence_refs':['e1'],'image_ids':['i1'],'visual_observation_refs':['o1'],'relation':'text_and_image','rationale':'图文支持'},
                {'evidence_refs':['e2'],'image_ids':[],'relation':'text_only','rationale':'无图文本仍有效'}]}],'unassigned':[]}

def simulated_real_envelope():
    """Unit-test data simulating a real envelope, never actual source evidence."""
    b=fixture();b['provenance']={'mode':'real_evidence','unit_test_only':True}
    for e in b['evidence']:e['text_kind']='source_paraphrase'
    return b

def production_pass():
    return {'schema_version':'prism.trend_quality.v0.1','image_id':'i1','source_kind':'trend',
        'decision':'PASS','status':'complete','applicable':True,'calibration_only':False,
        'production_admission':True,'provenance':{'mode':'existing_model_output'},
        'reason':'Unit-test simulated verdict only','evidence_refs':['unit-test-only']}

def real_envelope_proposal(p):
    q=proposal(p);q['producer']['method']='host_multimodal'
    q['producer']['model']='simulated unit-test producer, no model call'
    return q

class TrendTests(unittest.TestCase):
    def test_new_semantic_theme_and_text_only_survive(self):
        p=prepare(fixture());r=accept(p,proposal(p));self.assertEqual(r['themes'][0]['title'],'虹彩细节');self.assertEqual(r['metrics']['articles'],2)
        self.assertEqual(r['themes'][0]['reference_image_ids'],[])

    def test_date_boundaries_inclusive(self):
        self.assertEqual(len(prepare(fixture())['articles']),2)

    def test_update_is_not_publication(self):
        b=fixture();b['articles'][0]['published_at']='2020-01-01'
        p=prepare(b);self.assertEqual([a['article_id'] for a in p['articles']],['b'])
        self.assertEqual(len(prepare(b,{'start_date':'2026-09-01','end_date':'2026-09-26','date_basis':'updated_at'})['articles']),1)

    def test_unknown_date_is_excluded_without_invention(self):
        b=fixture();b['articles'][0].pop('published_at');p=prepare(b)
        self.assertEqual(p['excluded_articles'][0]['reason'],'unknown_published_at')

    def test_invalid_and_reversed_dates(self):
        for scope in [{'start_date':'banana'},{'start_date':'2026-10-01','end_date':'2026-09-01'}]:
            with self.assertRaises(TrendError):prepare(fixture(),scope)

    def test_unknown_evidence_and_unrelated_image_rejected(self):
        p=prepare(fixture())
        for change in ['reference','image']:
            q=proposal(p)
            if change=='reference':q['themes'][0]['members'][0]['evidence_refs']=['invented']
            else:q['themes'][0]['members'][0]['evidence_refs']=['e2']
            with self.assertRaises(TrendError):accept(p,q)

    def test_unknown_or_unseen_visuals_do_not_support(self):
        for case in ['unknown','unseen','missing_region','caption_only']:
            b=fixture()
            obs=b['images'][0]['visual_observations'][0]
            if case=='unknown':obs['status']='unknown'
            if case=='missing_region':obs['region_ref']=None
            if case=='caption_only':obs['basis']='caption'
            p=prepare(b);q=proposal(p)
            if case=='unseen':q['producer']['inspected_image_ids']=[]
            with self.assertRaises(TrendError):accept(p,q)

    def test_fail_and_error_keep_text_and_evidence_image(self):
        for decision in ['FAIL','ERROR']:
            b=fixture();b['quality_decisions']=[{'image_id':'i1','source_kind':'trend','decision':decision}]
            p=prepare(b);r=accept(p,proposal(p));t=r['themes'][0]
            self.assertEqual(t['evidence_refs'],['e1','e2']);self.assertEqual(t['reference_image_ids'],[])
            self.assertEqual(t['evidence_only_image_ids'],['i1'])

    def test_pass_is_separate_admission(self):
        b=simulated_real_envelope();b['quality_decisions']=[production_pass()]
        p=prepare(b);r=accept(p,real_envelope_proposal(p))
        self.assertEqual(r['themes'][0]['reference_image_ids'],['i1'])
        self.assertEqual(r['quality_routes'][0]['quality_record'],b['quality_decisions'][0])

    def test_synthetic_pass_is_never_a_production_admission(self):
        for flag in [False,True]:
            b=simulated_real_envelope();q=production_pass();q['production_admission']=flag;q['provenance']['mode']='synthetic'
            b['quality_decisions']=[q];p=prepare(b);r=accept(p,real_envelope_proposal(p))
            self.assertFalse(p['images'][0]['reference_eligible'])
            self.assertEqual(r['themes'][0]['reference_image_ids'],[])
            self.assertEqual(r['themes'][0]['evidence_only_image_ids'],['i1'])
            self.assertEqual(r['quality_routes'][0]['quality_record']['provenance']['mode'],'synthetic')

    def test_synthetic_dataset_or_image_provenance_cannot_admit(self):
        b=fixture();b['quality_decisions']=[production_pass()]
        self.assertFalse(prepare(b)['images'][0]['reference_eligible'])
        b=simulated_real_envelope();b['images'][0]['provenance']={'mode':'synthetic'}
        b['quality_decisions']=[production_pass()]
        self.assertFalse(prepare(b)['images'][0]['reference_eligible'])

    def test_admission_flags_and_provenance_fail_closed(self):
        changes=[('production_admission',False),('production_admission','true'),('production_admission',None),
                 ('applicable',False),('applicable',None),('calibration_only',True),
                 ('provenance',{}),('provenance',{'mode':'unknown'}),('status','needs_confirmation')]
        for key,value in changes:
            with self.subTest(key=key,value=value):
                b=simulated_real_envelope();q=production_pass();q[key]=value;b['quality_decisions']=[q]
                p=prepare(b);self.assertFalse(p['images'][0]['reference_eligible'])
                self.assertEqual(len(p['evidence']),2)

    def test_bare_legacy_pass_keeps_evidence_but_has_no_admission(self):
        b=simulated_real_envelope();b['quality_decisions']=[{'image_id':'i1','source_kind':'trend','decision':'PASS'}]
        p=prepare(b);r=accept(p,real_envelope_proposal(p))
        self.assertEqual(p['images'][0]['quality_decision'],'PASS')
        self.assertEqual(r['themes'][0]['reference_image_ids'],[])

    def test_invalid_explicit_status_is_not_inferred_complete(self):
        for value in [None,False,'']:
            b=simulated_real_envelope();q=production_pass();q['status']=value;b['quality_decisions']=[q]
            with self.assertRaises(TrendError):prepare(b)

    def test_quality_route_null_errors_and_pending_keep_text(self):
        for status in ['execution_error','invalid_input','invalid_output','needs_confirmation','incomplete','not_applicable']:
            with self.subTest(status=status):
                b=simulated_real_envelope();q={'schema_version':'prism.quality_route.v0.1','image_id':'i1',
                    'source_kind':'trend','decision':None,'status':status,'production_admission':False,
                    'error':'test_original_error','evidence_refs':['original-failed-result.json']}
                b['quality_decisions']=[q];p=prepare(b);r=accept(p,real_envelope_proposal(p))
                self.assertEqual(p['images'][0]['quality_status'],status)
                self.assertIsNone(p['images'][0]['quality_decision'])
                self.assertEqual(r['quality_routes'][0]['quality_record'],q)
                self.assertEqual(r['themes'][0]['evidence_refs'],['e1','e2'])
                self.assertEqual(r['themes'][0]['reference_image_ids'],[])

    def test_accept_rechecks_legacy_prepared_admission(self):
        p=prepare(fixture());p['images'][0]['quality_decision']='PASS';p['images'][0]['reference_eligible']=True
        p['input_digest']=digest({k:v for k,v in p.items() if k!='input_digest'})
        r=accept(p,proposal(p))
        self.assertEqual(r['themes'][0]['reference_image_ids'],[])
        self.assertEqual(r['quality_routes'][0]['reference_exclusion_reasons'],['no_quality_record'])

    def test_stale_quality_fields_in_image_cannot_override_current_route(self):
        b=simulated_real_envelope();b['images'][0].update(quality_record=production_pass(),reference_eligible=True)
        p=prepare(b);r=accept(p,real_envelope_proposal(p))
        self.assertNotIn('quality_record',p['images'][0])
        self.assertEqual(r['themes'][0]['reference_image_ids'],[])

    def test_actual_upstream_quality_adapter_shapes(self):
        from prism_runtime.quality.adapter import export_existing_result
        for case in ['pass','error','pending','synthetic']:
            with self.subTest(case=case):
                b=simulated_real_envelope();im=b['images'][0]
                record={'image_id':'i1','source_kind':'trend','valid':True,'decision':'PASS',
                        'version':'unit-fixture-v1','reason':'Simulated test only'}
                if case=='error':record['http_status']=503
                if case=='pending':record['status']='needs_confirmation'
                q=export_existing_result(im,record,source_ref='unit-fixture-only.json',
                    provenance_mode='synthetic' if case=='synthetic' else 'existing_model_output')
                b['quality_decisions']=[q];p=prepare(b);r=accept(p,real_envelope_proposal(p))
                self.assertEqual(p['images'][0]['reference_eligible'],case=='pass')
                self.assertEqual(r['quality_routes'][0]['quality_record'],q)
                self.assertEqual(len(p['evidence']),2)

    def test_canonical_url_dedup(self):
        b=fixture();b['articles'][1]['url']='https://source.test/a?utm_source=copy'
        b['articles'][1]['source_group_id']='original-a'
        p=prepare(b);t=accept(p,proposal(p))['themes'][0]
        self.assertEqual(len(t['source_group_ids']),1);self.assertEqual(t['support_level'],'single_origin_signal')

    def test_conflicting_url_origins_rejected_independent_of_id_sort(self):
        for copy_id in ['A-COPY','ZZZ-COPY']:
            with self.subTest(copy_id=copy_id):
                b=fixture();b['articles'][0]['article_id']='M-ORIGINAL';b['evidence'][0]['article_id']='M-ORIGINAL'
                b['images'][0]['article_id']='M-ORIGINAL';b['evidence'][0]['claim_origin_id']='original-a'
                b['articles'][1]['article_id']=copy_id;b['evidence'][1]['article_id']=copy_id
                b['articles'][1]['url']='https://source.test/a?utm_source=copy'
                original=copy.deepcopy(b)
                with self.assertRaises(SourceIdentityConflict) as raised:prepare(b)
                self.assertEqual(b,original)
                d=raised.exception.details
                self.assertEqual(d['declared_source_group_ids'],['original-a','original-b'])
                self.assertIsNone(d['preferred_source_group_id'])
                self.assertEqual(d['evidence_claim_origins'][0]['claim_origin_id'],'original-a')

    def test_source_conflict_diagnostics_ignore_input_order(self):
        b=fixture();b['articles'][1]['url']='https://source.test/a?utm_source=copy';diagnostics=[]
        for _ in range(2):
            with self.assertRaises(SourceIdentityConflict) as raised:prepare(b)
            diagnostics.append(raised.exception.details)
            b['articles'].reverse();b['evidence'].reverse()
        self.assertEqual(diagnostics[0],diagnostics[1])

    def test_cli_writes_auditable_conflict_and_nonzero_exit(self):
        b=fixture();b['articles'][1]['url']='https://source.test/a?utm_source=copy'
        with tempfile.TemporaryDirectory(prefix='.identity-cli-',dir=Path(__file__).parent) as directory:
            inp=Path(directory)/'input.json';out=Path(directory)/'output.json'
            inp.write_text(json.dumps(b),encoding='utf-8');before=inp.read_bytes()
            completed=subprocess.run([sys.executable,'-B','-m','prism_runtime.trends','prepare',str(inp),'--out',str(out)],
                cwd=Path(__file__).resolve().parents[2],capture_output=True,text=True)
            self.assertEqual(completed.returncode,2)
            r=json.loads(out.read_text(encoding='utf-8'))
            self.assertEqual(r['status'],'source_identity_conflict')
            self.assertEqual(r['error']['code'],'conflicting_canonical_source_identity')
            self.assertEqual(r['error']['details']['declared_source_group_ids'],['original-a','original-b'])
            self.assertEqual(inp.read_bytes(),before)

    def test_alias_preserves_explicit_external_reprint_origin(self):
        b=fixture()
        b['articles'].append({'article_id':'upstream','source_group_id':'external-original','url':'https://upstream.test/story','published_at':'2026-09-01'})
        b['articles'][1]['source_group_id']='original-a';b['articles'][1]['url']='https://source.test/a?utm_source=copy'
        for e in b['evidence']:e['claim_origin_id']='external-original'
        p=prepare(b);r=accept(p,proposal(p))
        self.assertEqual([e['claim_origin_id'] for e in p['evidence']],['external-original']*2)
        self.assertEqual(r['themes'][0]['claim_origin_ids'],['external-original'])

    def test_same_origin_different_publishers_remain_one_origin(self):
        b=fixture();b['articles'][1]['source_group_id']='original-a'
        b['articles'][0]['publisher_group']='Publisher One';b['articles'][1]['publisher_group']='Publisher Two'
        for e in b['evidence']:e['claim_origin_id']='original-a'
        p=prepare(b);r=accept(p,proposal(p));t=r['themes'][0]
        self.assertEqual(t['source_group_ids'],['original-a'])
        self.assertEqual(t['publisher_groups'],['Publisher One','Publisher Two'])
        self.assertEqual(t['claim_origin_ids'],['original-a'])

    def test_same_title_is_not_source_identity(self):
        b=fixture()
        for a in b['articles']:a['title']='Identical title, different actual sources'
        p=prepare(b);r=accept(p,proposal(p))
        self.assertEqual(p['article_aliases'],{})
        self.assertEqual(r['metrics']['original_source_groups'],2)

    def test_missing_claim_link_is_not_filled_from_alias(self):
        b=fixture();b['articles'][1]['source_group_id']='original-a';b['articles'][1]['url']='https://source.test/a?utm_source=copy'
        p=prepare(b)
        self.assertTrue(all('claim_origin_id' not in e for e in p['evidence']))
        b['articles'][1]['source_group_id']='conflicting-assertion'
        with self.assertRaises(SourceIdentityConflict) as raised:prepare(b)
        self.assertTrue(all(x['claim_origin_id'] is None for x in raised.exception.details['evidence_claim_origins']))

    def test_multiple_images_and_same_id_duplicate_are_different_cases(self):
        b=fixture();im=copy.deepcopy(b['images'][0]);im['image_id']='i2';im['visual_observations'][0]['observation_id']='o2'
        b['images'].append(im);b['evidence'][0]['image_ids'].append('i2')
        p=prepare(b);self.assertEqual(len(p['images']),2)
        self.assertEqual(accept(p,proposal(p))['metrics']['original_source_groups'],2)
        b['articles'].append(copy.deepcopy(b['articles'][0]))
        with self.assertRaisesRegex(TrendError,'duplicate article_id'):prepare(b)

    def test_shared_claim_origin_dedup(self):
        b=fixture();b['evidence'][1]['claim_origin_id']='original-a'
        p=prepare(b);self.assertEqual(accept(p,proposal(p))['themes'][0]['support_level'],'single_origin_signal')

    def test_unknown_origin_rejected(self):
        b=fixture();b['evidence'][1]['claim_origin_id']='invented'
        with self.assertRaises(TrendError):prepare(b)

    def test_nontrend_image_rejected(self):
        b=fixture();b['images'][0]['source_kind']='research'
        with self.assertRaises(TrendError):prepare(b)

    def test_stale_or_mutated_input_rejected(self):
        p=prepare(fixture());q=proposal(p);p['scope']['end_date']='2026-09-20'
        with self.assertRaises(TrendError):accept(p,q)
        p=prepare(fixture());q['input_digest']='stale'
        with self.assertRaises(TrendError):accept(p,q)

    def test_coverage_and_empty_results(self):
        p=prepare(fixture());q=proposal(p);q['themes'][0]['members'].pop()
        with self.assertRaises(TrendError):accept(p,q)
        q['unassigned']=[{'evidence_id':'e2','reason':'没有找到合适主题'}]
        self.assertEqual(accept(p,q)['metrics']['unassigned_units'],1)
        q['themes']=[];q['unassigned'].append({'evidence_id':'e1','reason':'暂不合并'})
        self.assertEqual(accept(p,q)['status'],'needs_data')

    def test_overlapping_topics_allowed_without_duplicate_count(self):
        p=prepare(fixture());q=proposal(p);other=copy.deepcopy(q['themes'][0]);other['theme_id']='t2';q['themes'].append(other)
        r=accept(p,q);self.assertEqual(r['metrics']['articles'],2);self.assertEqual(r['metrics']['supported_images'],1)

    def test_real_data_cannot_be_validated_by_synthetic_fixture(self):
        b=fixture();b['provenance']['mode']='real_evidence'
        for e in b['evidence']:e['text_kind']='source_paraphrase'
        p=prepare(b)
        with self.assertRaises(TrendError):accept(p,proposal(p))

    def test_synthetic_text_article_or_image_not_relabelled_real(self):
        for kind in ['text','article','image']:
            b=fixture();b['provenance']['mode']='real_evidence'
            for e in b['evidence']:e['text_kind']='source_paraphrase'
            if kind=='text':b['evidence'][0]['text_kind']='synthetic'
            if kind=='article':b['articles'][0]['source_kind']='synthetic'
            if kind=='image':b['images'][0]['source_kind']='synthetic'
            with self.assertRaises(TrendError):prepare(b)

    def test_existing_dna_needs_a_traceable_source(self):
        b=fixture();obs=b['images'][0]['visual_observations'][0];obs['basis']='existing_image_dna'
        p=prepare(b)
        with self.assertRaises(TrendError):accept(p,proposal(p))
        obs['source_ref']='fixture-only-dna.json#/observations/0';p=prepare(b)
        self.assertEqual(accept(p,proposal(p))['metrics']['supported_images'],1)

    def test_missing_body_and_duplicate_ids_rejected(self):
        for kind in ['text','id']:
            b=fixture()
            if kind=='text':b['evidence'][0]['text']=''
            else:b['evidence'][1]['evidence_id']='e1'
            with self.assertRaises(TrendError):prepare(b)

    def test_order_does_not_change_semantic_input(self):
        b=fixture();p=prepare(b)
        b['articles'].reverse();b['evidence'].reverse();b['images'].reverse()
        self.assertEqual(p['input_digest'],prepare(b)['input_digest'])

if __name__=='__main__':unittest.main()
