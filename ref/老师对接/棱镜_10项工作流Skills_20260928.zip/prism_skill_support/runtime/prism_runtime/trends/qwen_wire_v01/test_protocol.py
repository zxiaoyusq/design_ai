"""Synthetic protocol fixtures only. No Qwen request or semantic evidence."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
import protocol as w

def fixture(second_known=False):
    obs=lambda oid:{'observation_id':oid,'status':'known','basis':'existing_image_dna',
        'region_ref':{'synthetic_region':'fixture-only'},'text':'synthetic fixture value',
        'source_ref':'synthetic://not-real-dna'}
    b={'provenance':{'mode':'synthetic','purpose':'wire tests only'},
       'articles':[{'article_id':'fx-a','source_group_id':'fx-origin','published_at':'2026-09-01','url':'https://example.invalid/fixture'}],
       'evidence':[{'evidence_id':'fx-e1','article_id':'fx-a','text':'synthetic text 1','text_kind':'synthetic','image_ids':['fx-i1']},
                   {'evidence_id':'fx-e2','article_id':'fx-a','text':'synthetic text 2','text_kind':'synthetic','image_ids':['fx-i2']}],
       'images':[{'image_id':'fx-i1','article_id':'fx-a','source_kind':'trend','image_path':'synthetic-fixture-1.png','visual_observations':[obs('fx-o1')]},
                 {'image_id':'fx-i2','article_id':'fx-a','source_kind':'trend','image_path':'synthetic-fixture-2.png','visual_observations':[obs('fx-o2')] if second_known else []}]}
    return w.baseline().prepare(b)

def reply(p,visual=True):
    first={'evidence_refs':['fx-e1'],'image_ids':['fx-i1'] if visual else [],
        'visual_observation_refs':['fx-o1'] if visual else [],'relation':'text_and_image' if visual else 'text_only',
        'rationale':'Synthetic protocol fixture, not semantic inference.'}
    second={'evidence_refs':['fx-e2'],'image_ids':[],'visual_observation_refs':[],'relation':'text_only',
        'rationale':'Synthetic text-only fixture.'}
    return {'input_digest':p['input_digest'],'producer':{'method':w.METHOD,'model':w.MODEL,'inspected_image_ids':['fx-i1','fx-i2']},
        'themes':[{'theme_id':'fx-theme','title':'Synthetic test only','summary':'Not a real model result.','members':[first,second],
            'unknowns':['Synthetic fixture'],'transfer_conditions':[]}],'unassigned':[]}

def rehash(p):p['input_digest']=w.digest({k:v for k,v in p.items() if k!='input_digest'});return p

def call_fixture(folder,p,q):
    pack=w.build(p);bundle=folder/'bundle';call=folder/'call'
    for name,value in [('bound-prepared',p),('request',pack['request']),('context',pack['context'])]:w.write_new(bundle/(name+'.json'),value)
    req=pack['request'];content=[{'text':json.dumps({k:v for k,v in req.items() if k!='prompt'})}]
    for im in req['images']:content.extend([{'text':'Bound image_id: '+im['image_id']},{'image':'data:image/png;base64,SYNTHETIC_TEST_NOT_AN_IMAGE'}])
    payload={'model':w.MODEL,'input':{'messages':[{'role':'system','content':[{'text':req['prompt']}]},{'role':'user','content':content}]}}
    w.write_new(call/'request.json',payload)
    text=json.dumps(q,ensure_ascii=False)
    provider={'ok':True,'http_status':200,'data':{'request_id':'synthetic-fixture-only','output':{'choices':[{'message':{'role':'assistant','content':[{'text':text}]}}]}}}
    receipt={'model':w.MODEL,'call_id':'synthetic-test-only','request_sha256':w.file_sha(call/'request.json'),
        'state':'response_recorded','http_status':200,'decode_error':None,'output_is_object':True,'synthetic_fixture_only':True}
    w.write_new(call/'provider-response.json',provider);w.write_new(call/'result.json',receipt);w.write_new(call/'output.json',q)
    (call/'output.txt').write_text(text,encoding='utf8')
    return bundle,call

def rewrite(path,value):path.write_text(json.dumps(value),encoding='utf8')

class ProtocolTests(unittest.TestCase):
    def test_build_preserves_input_and_explicit_contract(self):
        p=fixture();before=copy.deepcopy(p);pack=w.build(p)
        self.assertEqual(p,before);self.assertEqual(pack['request']['input_digest'],p['input_digest'])
        self.assertEqual(pack['request']['provenance'],p['provenance'])
        self.assertEqual(pack['schema']['properties']['producer']['properties']['method']['const'],'model_multimodal')
        self.assertEqual(pack['schema']['properties']['producer']['properties']['model']['const'],'qwen3.8-flash')
        self.assertIn('fx-o1',pack['eligibility']['eligible_observations'])
        self.assertEqual(len(pack['request']['images']),2)

    def test_missing_projection_fields_are_not_repaired(self):
        p=fixture();o=p['images'][0]['visual_observations'][0];o.pop('status');o['source_output_ref']=o.pop('source_ref');rehash(p)
        before=copy.deepcopy(p);pack=w.build(p)
        self.assertEqual(pack['eligibility']['eligible_observations'],{})
        self.assertEqual(p,before)
        self.assertEqual(pack['eligibility']['excluded_observations'][0]['reasons'],['status_not_known','missing_source_ref'])

    def test_wrong_method_or_model_stays_rejected(self):
        for key,value in [('method','T01_semantic_decomposition'),('model','T01')]:
            p=fixture();q=reply(p);q['producer'][key]=value;before=copy.deepcopy(q)
            with self.assertRaises(w.WireError):w.accept_raw(p,q)
            self.assertEqual(q,before)

    def test_free_prose_is_not_an_observation_id(self):
        p=fixture();q=reply(p);q['themes'][0]['members'][0]['visual_observation_refs']=['fx-i1: polished surface']
        with self.assertRaises(w.WireError):w.accept_raw(p,q)

    def test_unknown_id_and_unknown_image_cannot_support(self):
        p=fixture()
        for key,value in [('visual_observation_refs',['invented']),('image_ids',['invented'])]:
            q=reply(p);q['themes'][0]['members'][0][key]=value
            with self.assertRaises(w.WireError):w.accept_raw(p,q)

    def test_unbound_image_rejected_by_unchanged_accept(self):
        p=fixture(True);q=reply(p);m=q['themes'][0]['members'][0];m['image_ids']=['fx-i2'];m['visual_observation_refs']=['fx-o2']
        with self.assertRaisesRegex(ValueError,'unrelated image'):w.accept_raw(p,q)

    def test_observation_of_another_image_rejected(self):
        p=fixture(True);q=reply(p);q['themes'][0]['members'][0]['visual_observation_refs']=['fx-o2']
        with self.assertRaisesRegex(ValueError,'unrelated visual observation'):w.accept_raw(p,q)

    def test_uninspected_image_rejected(self):
        p=fixture();q=reply(p);q['producer']['inspected_image_ids']=[]
        with self.assertRaisesRegex(ValueError,'inspected pixels'):w.accept_raw(p,q)

    def test_no_observation_stays_text_only_or_unassigned(self):
        p=fixture();p['images'][0]['visual_observations']=[];rehash(p)
        q=reply(p,False);self.assertEqual(w.accept_raw(p,q)['metrics']['supported_images'],0)
        q['themes'][0]['members'].pop();q['unassigned']=[{'evidence_id':'fx-e2','reason':'Synthetic missing-evidence case'}]
        self.assertEqual(w.accept_raw(p,q)['metrics']['unassigned_units'],1)
        with self.assertRaises(w.WireError):w.accept_raw(p,reply(p,True))

    def test_text_only_cannot_smuggle_visual_references(self):
        p=fixture();q=reply(p);q['themes'][0]['members'][0]['relation']='text_only'
        with self.assertRaises(w.WireError):w.accept_raw(p,q)

    def test_coverage_missing_or_overlap_rejected(self):
        p=fixture();q=reply(p);q['themes'][0]['members'].pop()
        with self.assertRaisesRegex(ValueError,'every evidence'):w.accept_raw(p,q)
        q=reply(p);q['unassigned']=[{'evidence_id':'fx-e1','reason':'fixture'}]
        with self.assertRaisesRegex(ValueError,'both grouped'):w.accept_raw(p,q)

    def test_stale_prepared_and_proposal_rejected(self):
        p=fixture();q=reply(p);q['input_digest']='stale'
        with self.assertRaises(w.WireError):w.accept_raw(p,q)
        p['scope']['region']='changed'
        with self.assertRaises(w.WireError):w.build(p)

    def test_base_source_hash_pin_is_enforced(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='.wire-test-') as td:
            p=Path(td)/'not-api.py';p.write_text('raise RuntimeError("must not execute")',encoding='utf8')
            with self.assertRaisesRegex(w.WireError,'hash mismatch'):w.baseline(p)

    def test_duplicate_observation_id_blocks_ambiguous_registry(self):
        p=fixture(True);p['images'][1]['visual_observations'][0]['observation_id']='fx-o1';rehash(p)
        with self.assertRaises(w.WireError):w.build(p)

    def test_eligible_ref_without_region_or_source_is_excluded(self):
        for field in ['region_ref','source_ref']:
            p=fixture();p['images'][0]['visual_observations'][0].pop(field);rehash(p)
            self.assertEqual(w.build(p)['eligibility']['eligible_observations'],{})

    def test_transport_attestation_uses_request_receipt_and_preserves_reply(self):
        p=fixture();q=reply(p)
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='.wire-test-') as td:
            bd,cd=call_fixture(Path(td),p,q);hashes={f.name:w.file_sha(f) for f in cd.iterdir()}
            r=w.accept_call(bd,cd)
            self.assertEqual(r['producer'],q['producer']);self.assertFalse(r['transport_provenance']['semantic_payload_rewritten'])
            self.assertEqual(hashes,{f.name:w.file_sha(f) for f in cd.iterdir()})

    def test_actual_transport_model_mismatch_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='.wire-test-') as td:
            p=fixture();bd,cd=call_fixture(Path(td),p,reply(p));receipt=w.read(cd/'result.json');receipt['model']='other-model';rewrite(cd/'result.json',receipt)
            with self.assertRaisesRegex(w.WireError,'executor model mismatch'):w.accept_call(bd,cd)

    def test_receipt_hash_and_http_errors_rejected(self):
        for field,value in [('request_sha256','wrong'),('http_status',503),('decode_error','bad_json')]:
            with tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='.wire-test-') as td:
                p=fixture();bd,cd=call_fixture(Path(td),p,reply(p));r=w.read(cd/'result.json');r[field]=value;rewrite(cd/'result.json',r)
                with self.assertRaises(w.WireError):w.accept_call(bd,cd)

    def test_provider_reply_cannot_be_hand_edited(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='.wire-test-') as td:
            p=fixture();bd,cd=call_fixture(Path(td),p,reply(p));r=w.read(cd/'output.json');r['themes'][0]['title']='tampered';rewrite(cd/'output.json',r)
            with self.assertRaisesRegex(w.WireError,'differs from provider'):w.accept_call(bd,cd)

    def test_prompt_marker_or_missing_image_rejected(self):
        for mutation in ['prompt','marker','missing']:
            with tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='.wire-test-') as td:
                p=fixture();bd,cd=call_fixture(Path(td),p,reply(p));r=w.read(cd/'request.json')
                if mutation=='prompt':r['input']['messages'][0]['content'][0]['text']='changed'
                if mutation=='marker':r['input']['messages'][1]['content'][1]['text']='Bound image_id: wrong'
                if mutation=='missing':r['input']['messages'][1]['content'].pop()
                rewrite(cd/'request.json',r);receipt=w.read(cd/'result.json');receipt['request_sha256']=w.file_sha(cd/'request.json');rewrite(cd/'result.json',receipt)
                with self.assertRaises(w.WireError):w.accept_call(bd,cd)

    def test_request_metadata_tampering_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='.wire-test-') as td:
            p=fixture();bd,cd=call_fixture(Path(td),p,reply(p));r=w.read(bd/'context.json');r['expected_model']='T01';rewrite(bd/'context.json',r)
            with self.assertRaisesRegex(w.WireError,'bundle modified'):w.accept_call(bd,cd)

if __name__=='__main__':unittest.main(verbosity=2)
