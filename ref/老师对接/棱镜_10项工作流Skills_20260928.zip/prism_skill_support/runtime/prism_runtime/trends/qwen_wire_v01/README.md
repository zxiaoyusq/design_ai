# Qwen T01 线协议 sidecar v0.1

该目录是新增的离线协议层，不修改已有 `trends/api.py`、包入口、调用器或共享契约。固定调用原 v0.1.2 accept，源码 SHA-256 为 `a739d7364f4ffd54646c0a82cfe0a68e7b79ae10d046e9a644a6e03c0adbafc5`。哈希不一致即拒绝加载。

## 本轮实际诊断

原T01真实调用的HTTP请求和账本均为 `qwen3.8-flash`，HTTP 200，保存的output.json与provider-response消息一致。原回复仍保持拒绝，没有修改任何主题、成员或语义：

- producer.method 返回 `T01_semantic_decomposition`，不在原accept的合法枚举内；producer.model 返回 `T01`，它是阶段名，不是实际执行模型。
- 13处 visual_observation_refs 是自由描述，不是已注册的观察ID。
- 49条输入证据还漏覆盖 `QWEN-SOURCE-009`；不由宿主将其补到任何主题或unassigned。
- 原输入412条观察缺status、使用source_output_ref，导致可用视觉观察为0。这是Root输入映射错误，和模块提示/协议缺失分开记账。

Root已提供projection-v2。我们只核对并消费：412条原有观察的ID、文本/值、basis和区域不变；status/source_ref由Root机械修正。当前新请求仍含60张图片、49条证据；**仅9张图具备412条合法已注册观察，另51张没有可引用的观察**。D03 PASS不补足该缺口。

## 新协议

冻结accept的producer.method全集为 `host_multimodal / model_multimodal / host_text_only / synthetic_fixture`。本Qwen执行协议只允许 `model_multimodal`，model固定 `qwen3.8-flash`。实际模型身份还要和HTTP请求、调用账本一致，不能由模型自称成立。

`build`产生以下独立文件：

- `bound-prepared.json`：完整、未修改的已准备输入快照，用于冻结accept。
- `request.json`：模型请求，含明确规则、输出schema、原文章/证据、全部图片路径、evidence→image绑定和合法观察注册表。
- `output-schema.json`：该输入专用的JSON Schema，producer为const，引用字段为实际ID枚举。CLI当前使用json_object，因此该schema作为提示的一部分并在返回后离线校验，不宣称提供方已经强制执行JSON Schema。
- `context.json`：输入指纹、请求/schema/提示哈希、固定执行模型和全部图号。
- `eligibility.json`：已有合法观察与排除原因，不把缺字段或unknown变known。

请求投影保留articles/evidence全文字段和合法原观察，不改写这些语义；不把质量模型的raw_evidence、用量账本等重复塞进语义请求。完整质量路由仍保留在bound-prepared，最终由原accept处理。

视觉成员必须引用注册表的精确观察ID。不得把图号、caption、自由文字或新构造的区域当观察引用；观察必须属于成员图片，成员图片必须绑定到其原文证据。每个成员图片至少有一条引用观察。

没有合法观察的图片，可以继续作为绑定输入交给Qwen看，但不能仅凭“看过”宣称具备可验收视觉支持。对应记录只能依文章文字输出 `text_only`（image_ids和visual_observation_refs均为[]），或明确unassigned；不能把刚从像素想到的说法伪装成文字依据。

本次没有新增中性观察生产接口，也没有将Qwen自由描述转换成host_pixel_observation或完整ImageDNA。若要51图都进入可引用的视觉证据，需要另行完成有来源的观察供给；这超出本轮线协议修复范围。

## 接入方式

Python 3.12+，仅标准库，无外部API、模型SDK、凭证读取、自动重试或定时器。推荐使用本机已知的bundle Python。复制到其他冻结目录时，显式传入 `--frozen-api`；仍必须满足上述源码哈希。

```text
python -B -X utf8 prism_runtime/trends/qwen_wire_v01/protocol.py build --prepared NEW_PREPARED.json --out-dir NEW_WIRE_BUNDLE
python -B -X utf8 prism_runtime/trends/qwen_wire_v01/protocol.py diagnose --prepared ORIGINAL_PREPARED.json --raw-output ORIGINAL_OUTPUT.json --out NEW_DIAGNOSIS.json
python -B -X utf8 prism_runtime/trends/qwen_wire_v01/protocol.py accept-call --bundle-dir NEW_WIRE_BUNDLE --call-dir NEW_CALL_DIR --out NEW_ACCEPTED_RESULT.json
python -B -X utf8 prism_runtime/trends/qwen_wire_v01/test_protocol.py
```

输出采用独占创建，拒绝覆盖已有调用或诊断。显式冻结路径写在子命令之前，例如 `protocol.py --frozen-api FROZEN_API.py build ...`。

Root负责在其允许的LOOP新run目录保存bundle并执行新的一次有界调用；本模块不执行。现有Qwen CLI可识别request的 `prism.trends.*` schema：把prompt放入system，其他request字段放入首个user文本块，再按images顺序追加 `Bound image_id: ID` 与图像数据。必须保留所有60个图像槽位，不能追加宿主手拟风格答案。

`accept-call`读取现有调用目录的 request.json/result.json/provider-response.json/output.json，验证：实际模型、请求文件哈希、成功状态、系统提示与请求一致、图号和图像槽位完整、保存的JSON回复等于提供方消息。随后做显式格式校验并调用原冻结accept。没有改producer、改引用、改主题或补unassigned的“修好后接收”路径。

图像传输转换及原图→传输字节的证明仍归执行器负责；sidecar核对绑定标记/顺序，不能证明模型实际看懂图片。账本来自可信Root执行器，不是外部模型自报，也不是提供方签名认证。

## 本轮交付状态

21项合成协议测试通过，测试中的provider文件为明确模拟的接口夹具，不是真实Qwen结果。原真实回复在新旧验证下均未接收。projection-v2已生成新的可复核wire bundle，但没有执行新模型调用。总体partial：接口补足本地自评通过；真实Qwen重试、跨图语义效果和后续人工确认均未由本sidecar建立。

模块交付位于 `outputs/prism-algorithm-loop-20260926/modules/trends/sidecars/qwen-wire-v0.1/`。其中original-input-diagnostic-bundle仅说明旧输入在本协议下没有可用视觉引用，禁止把它误当本轮正确输入；Root应使用projection-v2-wire-bundle或从其新的正确prepared重建。
