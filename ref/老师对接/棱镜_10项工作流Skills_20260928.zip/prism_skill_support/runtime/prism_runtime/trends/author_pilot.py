"""Export this session's frozen host observations and semantic proposal.

This is a case-specific research record, NOT a general-purpose clustering model.
New articles require a new semantic producer via prepare/accept.
"""
import json
from pathlib import Path
from .collect_pilot import OUT
from .api import prepare,accept

OBS = {
 'A01-I01':('拼图中各套服装','灰、米白和红色套装，收腰与宽松下装并置；不能从图证明日常舒适度。'),
 'A01-I02':('拼图中裙装表面','黑金纵向链状装饰、亮点、流苏与浅色薄层并置；不同小图并非同一种材质。'),
 'A01-I03':('中央背心及周围腰线、裙摆','长背心、错位腰线、腰部外扩与不对称垂坠形成不同体量关系。'),
 'A01-I04':('中央与左下服装表面','深棕金纹样与黑底花卉反复出现，图案附着于衣物主体。'),
 'A02-I01':('整张编辑拼贴','橙色套装、粉发、黑色蕾丝等被拼在同一封面；缺少单一方向的清晰对应，未用于主题视觉支撑。'),
 'A03-I01':('连衣裙主体','深底黄褐色不规则斑点、V形交叠开口与收束腰部；斑点视觉存在，物种与年代需正文。'),
 'A03-I02':('西装与内搭','高饱和绿色西装配深色细密文字状图案内搭，柔长裤腿与正式翻领并存。'),
 'A03-I03':('上衣和下装','橙红上衣与玫红亮面下装形成大面积相邻撞色，黑色鞋不主导配色。'),
 'A03-I04':('针织上衣与裙子','黄黑菱格状上衣与黑白密集图案裙叠搭，存在明确的异图案混搭。'),
 'A04-I01':('马甲、裤子与内搭','黑色亮面无袖外层、金属点状细节与黑色裤装，内搭有细纹样；不从外观推断真实皮革。'),
 'A04-I02':('外套、黄色内搭与粉色下装','绿色格纹、粉色花卉、黄色褶边与粉色裤装并置，是可见的图案和颜色碰撞。'),
 'A04-I03':('衬衫、背心与棕色短裙','浅色针织外观背心叠条纹衬衫，棕色裙装配黑包；下摆叠层可见。'),
 'A04-I04':('米白无袖服装主体','浅色花形细节、褶边领和不规则下缘可见；当前图不能可靠证明整体透明。'),
 'A05-I01':('画面下部成排立方座椅','琥珀、绿色及深色的半透明块状座椅，面有波动反光；真实玻璃来自正文声明。'),
 'A05-I02':('模特身上板状服装','长方形织毯状服装保留粗边与对称多色纹样，肩部方直突出；不是普通花卉印花。'),
 'A05-I03':('折叠凳本体','三角形黑色软面与细杆折叠支架，强方向性阴影来自照明。'),
 'A06-I01':('浅色异形坐墩及手袋','浅色几何坐墩具有切角、凹边与柔软织物外观；手袋线条较紧凑。'),
 'A06-I02':('橙色椅子和条纹靴','大面积橙色弧面座椅与玫红条纹靴搭配，蓝灰地毯作为背景。'),
 'A06-I03':('深色座椅、蓝包与细扶手','厚实深色织物包裹方形坐体，细杆扶手与编织纹蓝包形成纹理对照。'),
 'A06-I04':('浅色沙发主体','米白粗纹理表面包裹连续圆弧靠背，绿色花饰鞋是局部点缀。'),
 'A06-I05':('桌面及黄色眼镜','高反射桌面映出眼镜轮廓；镜面视觉成立，金属种类须依据原文。'),
 'A07-I01':('木纹桌板上的蜂鸟与花形嵌饰','浅棕旋涡木纹之上，蜂鸟羽片有蓝绿紫亮斑，花形边缘清晰；虹彩随角度变化无法凭静态图验证。'),
 'A07-I02':('汽车车身','酒红与浅银双色车身、亮色格栅；缩略图仅支持整体配色。'),
 'A07-I03':('车身腰线附近','浅色蜂鸟和枝花轮廓沿细线展开，装饰面积较小。'),
 'A07-I04':('尾灯旁车身面','酒红亮面与浅银面由细线分隔；局部高光不可当作涂层性能证明。'),
 'A08-I01':('房车外壳与伸出的厨房模块','银白连续壳体、圆角矩形窗门与横向抽出模块，表面分缝简洁。'),
 'A08-I02':('车厢座椅、墙面与木色桌面','棕灰织物外观、木色弧边桌与暖光形成包裹感；实际触感未知。'),
 'A08-I03':('抽出式厨房工作台','银色平直台面、嵌入水槽和黑色灶头，功能分区与外露抽拉结构清楚。'),
 'A09-I01':('浅色瓷砖及其表面凸起','浅色矩形板上出现耳、鼻、唇状浅浮雕，细微起伏与手抹般表面痕迹可见。'),
 'A09-I02':('整面浅色砖墙','重复矩形网格中散布低对比凸起；人体运动模糊属于背景。'),
 'A09-I03':('墙面砖的高光与浮雕','近似奶油色网格内交替出现较亮与较哑表面，耳鼻形凸起打断平面。'),
 'A10-I01':('画面下半部的三张地毯，不含寺院建筑','蓝、深红、浅桃色地毯呈细密重复线条和渐变；背景建筑不作为地毯的文化风格证据。'),
 'A10-I02':('底部三张平铺地毯','浅桃、深红和蓝灰表面的细线与色域渐变可见；微生物灵感不能从图片独立证明。'),
 'A10-I03':('建筑门洞中白色矩形地毯','浅底地毯上有稀疏细线；画面中大面积红金装饰属于建筑，不归到地毯。'),
}

# Concise paraphrases of the actual article sections read in this session.
# No source paragraphs are republished; locators retain an auditable route back.
UNITS = [
 ('A01','01','A new-era ladylike','经典套装通过宽松搭配与比例调整进入日常。',[1]),
 ('A01','02','Art Deco evening','晚装重新使用珠饰、流苏和装饰艺术语汇。',[2]),
 ('A01','03','Playful proportions','腰线、裙摆和上下身体量成为设计变量。',[3]),
 ('A01','04','Down to earth','乡野意象转为深色、细密的花卉表面。',[4]),
 ('A02','01','Messy girl summer','预测自由拼搭、异图案叠加和颜色碰撞。',[]),
 ('A02','02','Sheer romance and whimsymaxxing','预测轻柔、蕾丝、薄透和不规则浪漫表达。',[]),
 ('A02','03','Gardening-core','园艺生活被转为围裙、工装与草编的着装参照。',[]),
 ('A02','04','The modern goddess','古典女神联想带出垂坠、不对称与宽松体积。',[]),
 ('A03','01','Collection review; vivid colourblocking','新系列通过鲜亮大色块更新经典服装。',[2,3]),
 ('A03','02','Collection review; pattern combinations','不同图案与纹样尺度被放在同一套着装中。',[4]),
 ('A03','03','Collection review; wrap construction','裹身结构保留，并被移植到不同廓形。',[1]),
 ('A04','01','New Glam','暗色光泽、贴身线条和摇滚细节构成预测方向。',[1]),
 ('A04','02','Free-Style Expression','格纹、花卉与居家联想通过自由搭配重组。',[2]),
 ('A04','03','Put-together City Dressing','城市经典服装以柔和叠搭连接工作和休闲。',[3]),
 ('A04','04','Romantic Vintage','细节、柔软边缘和浅薄层次延续浪漫方向。',[4]),
 ('A05','01','Institution and Hodakova; carpet garments','织毯和家具构件被移到服装；强调收藏与延续使用。',[2,3]),
 ('A05','02','6:AM for Bottega Veneta','玻璃凳成排构成秀场空间，展示设计跨品类合作。',[1]),
 ('A06','01','Sculptural forms and photographic cases','座椅与配饰通过明确体量和轮廓形成焦点。',[1,4]),
 ('A06','02','Saturated colour and photographic pairing','鲜明色彩与图形线条在时装和家具中呼应。',[2]),
 ('A06','03','Texture gives forms depth','织物、绒感与编织表面为几何形体增加温和感。',[3,4]),
 ('A07','01','Marquetry: capturing nature iridescence','蜂鸟和植物意象以贝材嵌饰呈现在木饰面上。',[1,3]),
 ('A07','02','Finishing details','酒红与浅色双色车身承接定制叙事。',[2,4]),
 ('A08','01','Exterior and slide-out kitchen','金属外壳和抽出厨房将紧凑功能整合为简洁轮廓。',[1,3]),
 ('A08','02','Interior equipment','织物墙面、木地板和照明软化房车内部。',[2]),
 ('A09','01','Faces and Figures; industrial handmade appearance','工业砖面保留手塑外观，并加入人体部位浮雕。',[1,2,3]),
 ('A10','01','Zoometry microscopic structures','生物微观结构被转译为细线、渐变和织结图案。',[1,2,3]),
]

THEMES = [
 ('T01','饱和撞色与自由混搭','用色块碰撞、异图案叠加表达主动而不拘整齐的个性。',
  ['A02-E01','A03-E01','A03-E02','A04-E02','A06-E02'],
  ['WGSN预测被Vogue转述，不能重复计作两条独立趋势判断。','颜色强烈不意味着目标用户认可。'],
  ['跨到产品时须区分主体配色与背景，限定纹样尺度和主次。']),
 ('T02','自然意象的精细表面','把自然来源转成可阅读的表面组织：具象花鸟与抽象细线是不同分支。',
  ['A01-E04','A07-E01','A10-E01'],
  ['具象花鸟与微观抽象仅共享语义方向，尚不构成同一视觉风格子图库。','生物灵感和真实工艺来自文字，不能全部由照片证明。'],
  ['交给C01时分别处理具象图案、细密线条与局部嵌饰，不直接混成板。']),
 ('T03','雕塑感的比例与起伏','让轮廓、体量或局部凸起成为主要表达，弱化单靠平面印花的方式。',
  ['A01-E03','A06-E01','A09-E01'],
  ['服装比例、家具体块和砖面浅浮雕是三种尺度，需设计师确认是否保留共同上位主题。'],
  ['只迁移形体关系；局部浮雕不能自动放大为整个产品造型。']),
 ('T04','经典廓形的松弛重组','保留熟悉的套装、裹身和城市衣橱结构，以宽松比例、叠层和材质更新。',
  ['A01-E01','A03-E03','A04-E03'],
  ['当前证据集中于服装；照片不能证明真实舒适度或工作场景适用性。'],
  ['跨品类迁移仍是假设，需要识别哪些结构使经典感可辨。']),
 ('T05','轻柔浪漫与细节装饰','浅色、细部装饰和柔软边缘构成文字主导的浪漫候选。',
  ['A02-E02','A04-E04'],
  ['只有一张明确章节配图参与；轻透这一子主张缺少本轮像素支持。','本主题保留为较弱候选，不能报告为视觉充分验证。'],
  ['先补薄透与层次的明确案例，再进入视觉分组。']),
 ('T06','柔和触感包裹实用形体','在清楚的功能形体外用织物外观、低对比表面和温和色调增加包裹感。',
  ['A06-E03','A08-E02'],
  ['仅有两篇设计案例；图片只支持触感外观，不证明真实手感。'],
  ['迁移时分别检查形体、表面和光照，不把摄影暖色当材料属性。']),
]

REASONS = {
 'A01-E02':'珠饰与Art Deco是有效单篇信号；未因同属装饰就强并入自然主题。',
 'A02-E03':'园艺偏向生活与功能语义，不等于自然纹样；保留待补图。',
 'A02-E04':'垂坠预测未采到明确对应图，暂不以文字联想强并入雕塑形体。',
 'A04-E01':'黑色摇滚光泽只有一组明确来源，保留单源信号。',
 'A05-E01':'跨品类使用是方法性信号；地毯服装与折叠凳并不共享一个视觉风格。',
 'A05-E02':'彩色半透明块体是清楚的单例，当前缺少同方向独立案例。',
 'A07-E02':'单台定制车配色不能推出流行趋势；不因酒红色与其他图片相似就合并。',
 'A08-E01':'紧凑金属功能外壳缺少第二个独立同方向案例，保留原始信号。',
}

def write(name,data):
    (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    articles=[]
    for path in sorted(OUT.glob('A*-retrieval.json')):
        s=json.loads(path.read_text(encoding='utf-8'));aid=s['article_id'];meta=s['meta']
        published=meta.get('article:published_time') or {'A04':'2026-08-25','A07':'2026-09-15'}[aid]
        articles.append({'article_id':aid,'source_kind':'trend','title':s['title'],'url':s['url'],
          'publisher':s['publisher'],'publisher_group':s['publisher_group'],'source_group_id':aid+'-original',
          'source_type':s['source_type'],'published_at':published,'updated_at':meta.get('article:modified_time') or None,
          'date_evidence':'rendered time/press date' if aid in {'A04','A07'} else 'article:published_time metadata',
          'regions':['global'],'region_note':'Global-source sample, not representative regional coverage.',
          'retrieved_at':s['retrieved_at'],'retrieval_ref':path.name,'body_sha256':s['body_sha256'],
          'source_quality_basis':('专业趋势预测机构的署名分析' if aid=='A04' else '品牌设计与工艺的一手发布；存在营销立场' if aid=='A07' else '专业时尚/设计媒体署名的编辑分析或作品报道'),
          'text_access_note':('浏览器仅展示开头；其余正文通过公开网页检索读取，未绕过登录。' if aid=='A02' else '浏览器正文与公开网页交叉核对；不复制全文。')})
    images=json.loads((OUT/'image-manifest.json').read_text(encoding='utf-8'))
    for im in images:
        iid=im['image_id'];region,description=OBS[iid]
        im.update(visual_status='inspected_by_host',dna_ref=None,dna_status='not_run',
            inspection_artifact='images/'+im['article_id']+'-inspection.jpg',
            visual_observations=[{'observation_id':iid+'-O1','status':'known','basis':'host_pixel_observation',
                                 'region_ref':region,'text':description}],
            unknowns=['完整ImageDNA未运行；未做D03高级感判标。'])
    evidence=[]
    for aid,n,loc,txt,nums in UNITS:
        evidence.append({'evidence_id':aid+'-E'+n,'article_id':aid,'text':txt,'text_kind':'source_paraphrase',
          'locator':loc,'image_ids':[f'{aid}-I{x:02}' for x in nums],
          'claim_origin_id':'A04-original' if aid=='A02' and n=='01' else aid+'-original',
          'existing_labels':[],'extraction_method':'current_host_source_reading',
          'limitations':['首轮按设计相关章节选取，不宣称覆盖文章全部主张。']})
    # Preserve inspected cover and auxiliary pixels even when not used as theme support.
    evidence[4]['image_ids']=['A02-I01']
    # A06 mirror tabletop is retained with its own article evidence but no thematic claim.
    evidence[19]['image_ids'].append('A06-I05')
    # Every selected image belongs to an evidence record, though membership may use a subset.
    bundle={'schema_version':'prism.trend_input.v0.1','scope':{'start_date':'2026-03-26','end_date':'2026-09-26','date_basis':'published_at','region':'global'},
      'provenance':{'mode':'real_evidence','sampling':'purposive_high_design_source_pilot',
                    'date_scope_authority':'pilot_default_pending_user_change','new_paid_api_calls':0,
                    'text_representation':'source-linked host paraphrases; articles read during session',
                    'visual_representation':'actual pixel observations by current host; not full ImageDNA'},
      'articles':articles,'evidence':evidence,'images':images,'quality_decisions':[]}
    prepared=prepare(bundle)
    emap={e['evidence_id']:e for e in evidence}
    proposal={'input_digest':prepared['input_digest'],
              'producer':{'method':'host_multimodal','model':'Codex current GPT-6 host',
                          'inspected_image_ids':[i['image_id'] for i in prepared['images']],
                          'semantic_run_id':'t01-host-pilot-20260926-v1','independent_reviewer':False},
              'themes':[],'unassigned':[]}
    for tid,title,summary,eids,unknowns,transfer in THEMES:
        members=[]
        for eid in eids:
            imgs=emap[eid]['image_ids'][:]
            if eid.startswith('A02'):imgs=[]
            if eid=='A06-E03':imgs=[i for i in imgs if i!='A06-I05']
            members.append({'evidence_refs':[eid],'image_ids':imgs,
               'visual_observation_refs':[i+'-O1' for i in imgs],
               'relation':'text_and_image' if imgs else 'text_only',
               'rationale':emap[eid]['text'],
               'uncertainty':'仅支持可见装饰；轻透未获像素支持。' if eid=='A04-E04' else '首轮宿主归纳，待设计师复核。'})
        proposal['themes'].append({'theme_id':tid,'title':title,'summary':summary,'members':members,'unknowns':unknowns,'transfer_conditions':transfer})
    proposal['unassigned']=[{'evidence_id':eid,'reason':reason} for eid,reason in REASONS.items()]
    result=accept(prepared,proposal)
    for name,obj in [('corpus.json',bundle),('prepared.json',prepared),('proposal.json',proposal),('themes.json',result)]:write(name,obj)
    print(json.dumps(result['metrics'],ensure_ascii=False))

if __name__=='__main__':main()
