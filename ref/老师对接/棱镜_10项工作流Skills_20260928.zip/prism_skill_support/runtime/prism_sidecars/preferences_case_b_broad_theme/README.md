# Case B：宽主题对照的最小输入准备

只准备输入及完整输出格式，调用现有preferences0.3.1函数。代码不调用模型、不创建偏好答案、不批准审阅，不修改case A或公共接口。

用户指定主题为印度设计语境下的奢华、金色、宗教与仪式文化。输入是一位虚构表达者的三条作者编写陈述。它们是design hypotheses及synthetic过程测试，不是印度受访者样本、市场共识或真实偏好证据。

交付目录：

    D:\Codex\传音AI创客营\outputs\prism-algorithm-loop-20260926\modules\preferences\sidecars\CASE-B-BROAD-THEMES

bundle-input.json是三条模拟来源模板；正式串联使用bundle-case-b.json，后者在Root既有bundle副本上保留10趋势主题、120图、181条旧证据和12旧用户，再新增B用户/来源、替换B测试brief。新target_tags及research_project_ids只选中B，旧A负向没有被删除，也没有被带入B的模型提取消息。

已有source.context_schema=prism.business-context.v1，context只有scene与region。合成身份、作者信息、设计假设ID在来源顶层，避免被误当业务条件。brief.region=印度表示设计语境，与原图拍摄/来源地区无关。

## 提取输入

已准备prepared-extraction.json和extraction-reply.schema.json。只有一个request，ID为case-b-preference-001；带完整原文及快照digest。theme/image层原规则不变，此case限定theme、features=[]、image_ids=[]。态度不预填like，也不填supported。

重新准备须明确基底与输出，冻结之后再调用：

    python -B -X utf8 prism_sidecars/preferences_case_b_broad_theme/prepare.py prepare --bundle <bundle-input.json> --base-bundle <原10主题120图完整bundle> --output <新目录/prepared-extraction.json>

程序同时写新目录/bundle-case-b.json，不修改base。若需改变brief或context，应在真实提取前完成，之后重新生成input_digest。不要边调用边改输入。

## 正式接收仍走原入口

Root使用Astra标准CLI实际执行prepared-extraction.json内messages，保存未经修复的原始请求、回复及执行记录。用现有schema检查器检查extraction-reply.schema.json，再调用：

    from prism_runtime.preferences import accept_batches
    candidate_profile = accept_batches(
        bundle, prepared, [actual_reply],
        extraction_context=actual_case_b_extraction_context,
    )

actual_case_b_extraction_context由Root真实执行元数据填写，模板在交付目录。不能用模型自产的身份或空run_id。覆盖状态须完整，受访者仍为SYN-B-U01；所有已提取记录必须theme、features=[]、image_ids=[]。没有产生的主题不能由宿主补写。

实际candidate_profile生成之前，本交付没有profile.json。不要用A profile或旧supported缓存代替它。

## 独立审阅

实际候选接收后，用原prepare_semantic_review准备独立上下文，并附完整类型说明：

    python -B -X utf8 prism_sidecars/preferences_case_b_broad_theme/prepare.py prepare-review --bundle <同一正式bundle-case-b.json> --profile <Root实际candidate-profile.json> --output <Root新目录/prepared-review.json>

新request_id为case-b-preference-review-001，带输入与候选摘要。它复用原审阅规则及已有完整审阅wire格式；没有Qwen专属模型校验，实际Astra传输与身份绑定由Root标准CLI负责。

Root先检查review-reply.schema.json、request_id/input_digest以及items恰好覆盖prepared-review.preference_ids。quotes必须保留模型输出的原文对象；不得补引文、改裁决或借用旧回执。真实审阅者与提取者ID及independence_group均独立。

真实执行元数据包在外层，不由模型填写：

    from prism_runtime.preferences.review import apply_semantic_reviews, validate_reviewed_profile
    reviewed = apply_semantic_reviews(bundle, candidate_profile, actual_envelope,
                                     reviewer_registry=actual_case_b_registry)
    verified = validate_reviewed_profile(bundle, reviewed,
                                        reviewer_registry=actual_case_b_registry)

这就是H01/H02消费B画像的唯一可信入口。B独立registry模板和空envelope模板仅供Root登记真实执行，不代表已有审阅。首次接收后冻结B登记快照，A登记表保持原样。

## 下游范围

- 使用同一个冻结B bundle中的10原趋势主题与120原图片身份，由握手/聚类owner重新绑定B的inventory及admission。不能仅因复制了原图就继承A的整套bundle快照资格。
- B来源没有绑定具体图像；H01负责由宽主题探索已有主题/图池，不能把theme文本当作用户对某张图或某个PID的已知支持。
- 新profile的条件和态度以实际提取/审阅为准；不能为了握手而删除条件。
- execution_scope_context由握手owner按已有context_sidecar API建立。本准备器没有伪造已批准context、theme选择或H02确认。
- B brief没有设置负向测试题，无负向只是该输入构造；A的179候选、58负向与9阻断保持原状态。
- Root预算拟最多6次，提取/复核/H01/H02及至多2次明确修复。owner新模型/API调用为0，辅助脚本不管理调用循环。
