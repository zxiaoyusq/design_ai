"""Prepare case B with existing preference0.3.1 APIs. No model calls or semantic answers."""
from copy import deepcopy
import argparse
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from prism_runtime.preferences import prepare_requests, prepare_semantic_review, select_users
from prism_runtime.preferences.validation import validate_bundle
from prism_sidecars.preferences_qwen_p01_wire_001.p01_wire import read, write, require, sha_bytes, _schema_check

OUT=ROOT/"outputs/prism-algorithm-loop-20260926/modules/preferences/sidecars/CASE-B-BROAD-THEMES"
EXTRA="""本请求是独立case B宽主题对照，资料均为用户指定设计假设的模拟表达，不是实际印度用户研究。
只提取theme层；features=[]、image_ids=[]，不生成原216视觉参数或材料事实。印度是本轮设计语境，不能概括为印度人共同喜欢。
三条来源覆盖奢华/庆典、金色/珠宝、宗教/仪式文化；具体主题措辞、态度和条件由你忠实提取，不要求固定like或复用作者答案。
保留“这次探索”“具体传统与场景”等来源范围，条件性兴趣不能升为无条件群体共识。
这三条来源中没有专门设置负向对照，不代表负向不存在；不得修改或解释为旧case A的58负向和9条阻断已解决。
逐条来源通常可形成一个主题，不为凑数编造解释；不能解释时按原dispositions规则报告。
返回完整JSON对象request_id/input_digest/findings/dispositions。quotes为evidence_id/text对象数组，逐字引用。
不要输出Markdown、身份、自我通过标记或profile。具体类型按附后的schema，绑定值逐字复制。"""


def check_bundle(bundle):
    validate_bundle(bundle)
    require(bundle["brief"]["case_id"]==bundle["provenance"]["case_id"]=="B","independent case B required")
    require(bundle["provenance"]["mode"]=="synthetic","case B must remain synthetic")
    selection=select_users(bundle)
    require(selection["selected_user_ids"]==["SYN-B-U01"],"one selected fictional case B expression holder")
    require(set(selection["eligible_evidence_ids"])=={
        "SYN-B-E01-LUXURY","SYN-B-E02-GOLD","SYN-B-E03-RITUAL"},"exact three case B sources")
    selected=[e for e in bundle["evidence"] if e["evidence_id"] in selection["eligible_evidence_ids"]]
    require(all(not e.get("image_id") for e in selected),"case B theme sources cannot claim image or visual measurement bindings")


def merge_base(source_brief,base):
    """New immutable branch data; retain every original theme/image/evidence/user record."""
    require(len(base.get("images",[]))==120 and len(base.get("themes",[]))==10,
            "case B H01/H02 base must retain the original120 images and10 themes")
    result=deepcopy(base)
    require(not({u["user_id"] for u in result["users"]}&{u["user_id"] for u in source_brief["users"]}),"case B user already present")
    require(not({e["evidence_id"] for e in result["evidence"]}&{e["evidence_id"] for e in source_brief["evidence"]}),"case B sources already present")
    result["users"]+=deepcopy(source_brief["users"])
    result["evidence"]+=deepcopy(source_brief["evidence"])
    result["brief"]=deepcopy(source_brief["brief"])
    result["provenance"]={**deepcopy(base["provenance"]),**deepcopy(source_brief["provenance"])}
    check_bundle(result)
    return result


def prepare_extraction(bundle):
    check_bundle(bundle)
    prepared=prepare_requests(bundle)
    require(len(prepared["requests"])==1,"case B must stay one bounded extraction request")
    schema=deepcopy(read(HERE.parent/"preferences_qwen_p01_wire_001/reply-schema.json"))
    schema["title"]="Case B synthetic theme-only response using existing P01 contract"
    finding=schema["$defs"]["finding"]["properties"]
    finding["level"]={"type":"string","enum":["theme"]}
    finding["features"]={"type":"array","maxItems":0}
    finding["image_ids"]={"type":"array","maxItems":0}
    schema["properties"]["findings"]["maxItems"]=3
    request=prepared["requests"][0]
    request["request_id"]="case-b-preference-001"
    binding={"request_id":request["request_id"],"input_digest":request["input_digest"]}
    request["messages"][0]["content"]+="\n\n"+EXTRA+"\n绑定："+json.dumps(binding,ensure_ascii=False)+"\nJSON Schema："+json.dumps(schema,ensure_ascii=False)
    request["message_chars"]=sum(len(m["content"]) for m in request["messages"])
    prepared["case_id"]="B"
    prepared["contract_note"]="Original accept_batches and review consumer; this is source/request preparation only."
    prepared["new_model_calls"]=0
    prepared["existing_case_a_state_inherited"]=False
    return prepared,schema


def prepare_review(bundle,profile):
    check_bundle(bundle)
    expected=prepare_requests(bundle)
    require(profile["input_digest"]==expected["input_digest"],"review profile is not bound to case B sources")
    require(profile["provenance"]["mode"]=="synthetic" and profile["provenance"].get("case_id")=="B","case B provenance required")
    require(0<len(profile["preferences"])<=3,"only bounded fresh case B findings")
    for f in profile["preferences"]:
        require(f["level"]=="theme" and f["features"]==[] and f["image_ids"]==[],"case B is theme-only")
        require(f["user_ids"]==["SYN-B-U01"],"case B cannot inherit case A users")
    request=prepare_semantic_review(bundle,profile)
    schema=read(HERE.parent/"preferences_qwen_review_wire_001/reply-schema.json")
    wire=(HERE.parent/"preferences_qwen_review_wire_001/WIRE_PROMPT.md").read_text(encoding="utf-8")
    request["request_id"]="case-b-preference-review-001"
    binding={"request_id":request["request_id"],"input_digest":request["input_digest"],
             "candidate_bindings":[{"preference_id":f["preference_id"],
                                    "candidate_digest":f["semantic_assessment"]["candidate_digest"]}
                                   for f in profile["preferences"]]}
    request["messages"][0]["content"]+=(
        "\n\n本包仅是case B合成设计假设的独立语义核对；不得把印度设计语境写成真实印度用户共同偏好。"
        "三条主题不等于三位受访者，无负向只因本B brief未设计负向测试，不能抹去case A。"
        "\n"+wire+"\n绑定："+json.dumps(binding,ensure_ascii=False)+"\nJSON Schema："+json.dumps(schema,ensure_ascii=False))
    request["message_chars"]=sum(len(m["content"]) for m in request["messages"])
    request["case_id"]="B";request["new_model_calls"]=0
    return request


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=["prepare","prepare-review"])
    p.add_argument("--bundle",default=str(OUT/"bundle-input.json"))
    p.add_argument("--profile");p.add_argument("--output");p.add_argument("--base-bundle")
    a=p.parse_args()
    bundle=read(a.bundle)
    if a.action=="prepare":
        if a.base_bundle:
            bundle=merge_base(bundle,read(a.base_bundle))
        result,schema=prepare_extraction(bundle)
        destination=Path(a.output or OUT/"prepared-extraction.json")
        if a.base_bundle:
            write(destination.parent/"bundle-case-b.json",bundle)
        write(destination,result)
        write(destination.parent/"extraction-reply.schema.json",schema)
        write(destination.parent/"review-reply.schema.json",read(HERE.parent/"preferences_qwen_review_wire_001/reply-schema.json"))
    else:
        require(a.profile and a.output,"actual Root candidate profile and new output path required")
        destination=Path(a.output)
        write(destination,prepare_review(bundle,read(a.profile)))
    print(json.dumps({"status":"prepared_only","path":str(destination),"new_model_calls":0},ensure_ascii=False))


if __name__=="__main__":main()
