# CLOSURE-PREF-001 · 用研偏好字段边界诊断

本轮终态：诊断完成，映射仍为partial，9条候选均不可执行。原算法preferences0.3.1保持不变；没有新的语义映射consumer，没有模型/API调用，没有启动计时器。

现有文件：

- hypotheses.json：9条负向的14个feature分量之诊断假设，保留条件、复合关系、软态度与非排斥对象。作者分析不是独立审阅结果。
- diagnose.py：已运行一次的只读诊断程序，核查6次原Qwen提取调用、原216字典和原审阅链；保存完整原候选/来源，重现正式边界拒绝和防篡改等机械对照。只写用研任务自己的新交付目录。
- MAPPING_CONTRACT_PROPOSAL.md：下一轮最小合同建议，不是已实现接口。

交付目录：

    D:\Codex\传音AI创客营\outputs\prism-algorithm-loop-20260926\modules\preferences\sidecars\CLOSURE-PREF-001

其中report.md面向同事阅读，constraint-status.json供握手记录正式阻断，mapping-proposals.json保存9条完整候选和原始来源，prompt-audit.json记录实际提示/schema，source-review-validation.json记录旧画像可信验证，mechanical-replay.json记录本轮机械复现，acceptance-cases.json明确尚未执行的新映射语义验收，source-manifest.json记录输入及源文件哈希，self-assessment.json与handoff.json给出终态。

本轮已执行的命令（不建议为了归档重复运行）：

    python -B -X utf8 prism_sidecars/preferences_closure_pref_001/diagnose.py

唯一可信的旧画像入口仍是 prism_runtime.preferences.review.validate_reviewed_profile；新映射没有获批，所以不存在可提供给H02的字段/值转换函数。当前产物只能用于解释阻断与下轮审阅。
