"""CLOSURE-PREF-001: read-only source diagnosis and advisory hypotheses; no mapping consumer or API."""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from prism_runtime.preferences.review import validate_reviewed_profile, candidate_digest
from prism_runtime.preferences.validation import validate_feature
from prism_runtime.clustering.exploratory_cmf_bridge_v1 import prepare_pid_view
from prism_sidecars.preferences_qwen_p01_wire_001.p01_wire import _schema_check

LOOP=ROOT/"outputs/01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de/prism-evaluation-loop"
CHAIN=LOOP/"qwen-cli-20260927/runs/full120-qwen-v1-20260927/semantic-chain"
DEFAULT_OUTPUT=ROOT/"outputs/prism-algorithm-loop-20260926/modules/preferences/sidecars/CLOSURE-PREF-001"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")).hexdigest()


def write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")


def require(ok,message):
    if not ok:raise ValueError(message)


def probe(action):
    try:
        result=action()
        return {"rejected":False,"result":result}
    except (ValueError,TypeError,KeyError,AttributeError) as exc:
        return {"rejected":True,"error_type":type(exc).__name__,"error":str(exc)}


def run(output):
    out=Path(output).resolve()
    require(out.is_relative_to(ROOT/"outputs/prism-algorithm-loop-20260926/modules/preferences"),
            "diagnosis output must stay in preference owner's own output directory")
    out.mkdir(parents=True,exist_ok=True)
    ce_path=LOOP/"closure-20260927/h02/noncanonical-preference-counterexample.json"
    bundle_path=CHAIN/"inputs/combined-bundle-input-v2.json"
    profile_path=CHAIN/"review-wire001-recovery/validated-profile.json"
    registry_path=CHAIN/"review-wire001-recovery/reviewer-registry.json"
    manifest_path=CHAIN/"P01-wire002/responses-manifest.json"
    ce=read(ce_path);bundle=read(bundle_path);profile=read(profile_path);registry=read(registry_path)
    projection_path=Path(ce["projection"])
    projection=read(projection_path)
    dictionary_path=Path(projection["dictionary_contract"]["dictionary_ref"])
    dictionary=read(dictionary_path)
    require(sha(dictionary_path)==projection["dictionary_contract"]["dictionary_sha256"],
            "dictionary must be the exact original projection dictionary")
    dictionary_by_id={p["parameter_id"]:p for p in dictionary["parameters"]}
    require(len(dictionary_by_id)==216,"expected original216 dictionary")
    scopes=ce["affected_target_negatives"]
    require(len(scopes)==9,"only the dispatched9 negatives may be diagnosed")
    target_ids=[x["preference_id"] for x in scopes]
    request_ids={x.split(":",1)[0] for x in target_ids}
    calls=[e for e in read(manifest_path)["responses"] if e["request_id"] in request_ids]
    require(len(calls)==6,"original six extraction calls must be found")
    paths=[
        ce_path,bundle_path,profile_path,registry_path,manifest_path,projection_path,dictionary_path,
        CHAIN/"P01-wire002/candidate-profile.json",
        LOOP/"dispatches/CLOSURE-PREF-001.md",
        ROOT/"docs/prism/核心工作流.md",
        ROOT/"prism_runtime/contracts.py",
        ROOT/"prism_runtime/clustering/local_cmf_bridge_v1/bridge.py",
        ROOT/"prism_runtime/clustering/exploratory_cmf_bridge_v1/producers.py",
    ]
    paths+=list((ROOT/"prism_runtime/preferences").glob("*.py"))
    paths+=list((ROOT/"prism_runtime/preferences").glob("*.md"))
    for name in ("preferences_qwen_p01_wire_001","preferences_qwen_p01_wire_002"):
        paths+=list((HERE.parent/name).glob("*.py"))
        paths+=list((HERE.parent/name).glob("*.json"))
        paths+=list((HERE.parent/name).glob("*.md"))
    for call in calls:
        paths.extend(ROOT/Path(call[k]) for k in ("provider_request_path","provider_response_path"))
    paths=sorted({p.resolve() for p in paths})
    baseline=[{"path":str(p),"sha256":sha(p),"bytes":p.stat().st_size} for p in paths]
    write(out/"protected-before.json",{"scope":"only dispatched sources, original consumers, prompts and actual calls","files":baseline})

    # The original, sole trusted profile consumer revalidates the complete existing receipt ledger.
    checked=validate_reviewed_profile(bundle,profile,reviewer_registry=registry)
    by_id={f["preference_id"]:f for f in checked["preferences"]}
    source_by_id={e["evidence_id"]:e for e in bundle["evidence"]}
    images_by_id={im["image_id"]:im for im in bundle["images"]}
    specs={h["evidence_id"]:h for h in read(HERE/"hypotheses.json")["items"]}
    raw_findings={}
    prompt_audit=[]
    for call in calls:
        native_path=ROOT/Path(call["provider_request_path"])
        response_path=ROOT/Path(call["provider_response_path"])
        native=read(native_path);response=read(response_path)
        messages=native["input"]["messages"]
        message_text=lambda m:"".join(block["text"] for block in m["content"])
        user=json.loads(message_text(messages[1]))
        system=message_text(messages[0])
        choice=response["data"]["output"]["choices"][0]
        require(choice["finish_reason"]=="stop","original saved call must be complete")
        reply=json.loads(message_text(choice["message"]))
        raw_findings.update({call["request_id"]+":"+f["preference_id"]:f for f in reply["findings"]})
        sidecar_name="preferences_qwen_p01_wire_002" if "wire002" in call["request_id"] else "preferences_qwen_p01_wire_001"
        schema_path=HERE.parent/sidecar_name/"reply-schema.json"
        schema=read(schema_path)
        schema_literal=json.dumps(schema,ensure_ascii=False,separators=(",",":"))
        dna=user.get("image_dna",[])
        pids=sorted({o["parameter_id"] for im in dna for o in im["observations"]})
        prompt_audit.append({
            "request_id":call["request_id"],"actual_model":native["model"],
            "request_path":str(native_path.resolve()),"request_sha256":sha(native_path),
            "response_path":str(response_path.resolve()),"response_sha256":sha(response_path),
            "system_sha256":digest(system),"user_payload_keys":list(user),
            "supplied_dictionary_catalog_section":any(k in user for k in ("dictionary","parameters","parameter_catalog","aliases","value_mappings")),
            "actual_prompt_contains_inspected_full_wire_schema":schema_literal in system,
            "parameter_id_schema":schema["$defs"]["feature"]["properties"]["parameter_id"],
            "value_schema":schema["$defs"]["feature"]["properties"]["value"],
            "image_dna_unique_parameter_count":len(pids),
            "images":[{"image_id":im["image_id"],"observation_count":len(im["observations"]),
                       "known_count":sum(o.get("value_status")=="known" for o in im["observations"])} for im in dna],
            "system_has_OPT002_definition":dictionary_by_id["OPT-002"]["definition"] in system,
            "system_has_TEX009_definition":dictionary_by_id["TEX-009"]["definition"] in system,
            "source_capability_table_present":"实际来源归因能力" in system,
            "note":"Observations and source capability tables are not a field definition/value mapping registry.",
        })
    require(all(p["actual_prompt_contains_inspected_full_wire_schema"] for p in prompt_audit),
            "actual prompt schema differs; inspect before diagnosing the producer contract")

    candidates=[]
    for number,scope in enumerate(scopes,1):
        f=by_id[scope["preference_id"]]
        require(f["features"]==scope["features"] and f["conditions"]==scope["conditions"],"dispatched candidate changed")
        require(f["features"]==raw_findings[f["preference_id"]]["features"],"original Qwen feature fields differ from compiled profile")
        require(len(f["evidence_refs"])==1,"unexpected multi-source candidate")
        eid=f["evidence_refs"][0];spec=specs[eid];source=source_by_id[eid]
        require({p["feature_index"] for p in spec["parts"]}==set(range(len(f["features"]))),"every original feature needs a diagnostic disposition")
        require(all(q in source["text"] for q in spec["must_preserve"]),"diagnostic exclusion text must remain verbatim")
        hypotheses=[]
        for part in spec["parts"]:
            before=f["features"][part["feature_index"]]
            hypotheses.append({
                **deepcopy(part),"original_feature":deepcopy(before),
                "original_parameter_in_216":before["parameter_id"] in dictionary_by_id,
                "dictionary_candidates":[deepcopy(dictionary_by_id[pid]) for pid in part["parameter_candidates"]],
                "mapping_semantic_status":"not_independently_reviewed",
                "candidate_value_is_design_diagnostic_only":True,"executable":False,
            })
        candidates.append({
            "proposal_id":f"CLOSURE-PREF-001-{number:02d}",
            "source_scene":scope["scene"],"source_preference_id":f["preference_id"],
            "source_candidate_digest":f["semantic_assessment"]["candidate_digest"],
            "source_review_status_from_validated_ledger":f["semantic_assessment"]["status"],
            "source_review_ids":f["semantic_assessment"]["review_ids"],
            "original_candidate":deepcopy(f),"full_original_source_records":[deepcopy(source)],
            "diagnosis":spec["diagnosis"],"field_hypotheses":hypotheses,
            "predicate_to_review":spec["predicate_to_review"],
            "condition_candidate_quote":spec.get("condition_candidate_quote"),
            "modality_to_review":spec.get("modality_to_review"),
            "non_rejected_or_positive_context_quotes":spec["must_preserve"],
            "carrier_issue":spec["carrier_issue"],"review_questions":spec["review_questions"],
            "registered_target_object_id":source.get("target_object_id"),
            "registered_target_region_ref":source.get("target_region_ref"),
            "new_mapping_review_status":"pending_separate_semantic_review",
            "old_supported_does_not_approve_mapping":True,
            "execution_eligible":False,"executable_constraints":None,
        })
    noncanonical=sorted({f["parameter_id"] for x in scopes for f in x["features"] if f["parameter_id"] not in dictionary_by_id})
    require(len(noncanonical)==10,"unexpected noncanonical namespace scope")
    proposal={
        "schema_version":"prism.preference_mapping_diagnostic.v0.1",
        "issue_id":"CLOSURE-PREF-001","status":"partial_proposal_only",
        "prepared_at":datetime.now(timezone.utc).isoformat(),
        "author_role":"bounded diagnostic host; no new model/API execution",
        "source_profile":{"path":str(profile_path),"sha256":sha(profile_path),"input_digest":profile["input_digest"]},
        "dictionary":{"path":str(dictionary_path),"sha256":sha(dictionary_path),"schema_version":dictionary["schema_version"],"parameter_count":216},
        "source_provenance":deepcopy(profile["provenance"]),
        "noncanonical_names":noncanonical,"candidate_count":9,
        "executable_mapping_count":0,"execution_eligible":False,
        "mapping_consumer_version":"not_implemented; original preference consumer validates parents only",
        "candidates":candidates,
    }
    write(out/"mapping-proposals.json",proposal)
    write(out/"prompt-audit.json",{"actual_extraction_calls":prompt_audit,
          "shared_design_intent_ref":str(ROOT/"docs/prism/核心工作流.md"),
          "formal_alias_registry_found_in_audited_P01_contract":False,
          "diagnosis":"Open text concepts are allowed upstream, but no explicit canonical parameter/value/relation mapping contract was supplied or enforced."})
    write(out/"source-review-validation.json",{
        "entrypoint":"prism_runtime.preferences.review.validate_reviewed_profile",
        "entrypoint_sha256":sha(ROOT/"prism_runtime/preferences/review.py"),
        "profile_path":str(profile_path),"profile_sha256":sha(profile_path),
        "bundle_path":str(bundle_path),"bundle_sha256":sha(bundle_path),
        "registry_path":str(registry_path),"registry_sha256":sha(registry_path),
        "validated_receipt_ids":checked["review_state_integrity"]["validated_receipt_ids"],
        "cached_state_changed_preference_ids":checked["review_state_integrity"]["cached_state_changed_preference_ids"],
        "target_statuses":{pid:by_id[pid]["semantic_assessment"]["status"] for pid in target_ids},
        "applies_only_to_original_candidates":True,"mapping_or_constraint_semantics_approved":False,
    })

    mechanical={}
    mechanical["original_noncanonical_projection_rejection"]=probe(lambda:prepare_pid_view(str(projection_path),["gloss_level"]))
    require(mechanical["original_noncanonical_projection_rejection"].get("error")=="Request contains fields outside the original dictionary ledger",
            "official repro did not reach the dispatched original-dictionary boundary")
    gloss=candidates[2]["original_candidate"]["features"][0]
    mechanical["synonym_value_shape_only"]={
        "original_value":gloss["value"],"candidate_parameter_id":"OPT-002","candidate_value":"高光",
        "original_value_passes_string_type":not probe(lambda:_schema_check(gloss["value"],dictionary_by_id["OPT-002"]["value_schema"],{}))["rejected"],
        "original_value_equals_candidate":gloss["value"]=="高光",
        "reference_values_are_closed_enum":False,
        "semantic_equivalence_established":False,
        "finding":"A valid string and a nearby field name do not establish ordinal value equivalence.",
    }
    mechanical["qualitative_density_to_numeric"]=probe(lambda:_schema_check("too_dense",dictionary_by_id["TEX-009"]["value_schema"],{}))
    # Demonstrate current explicit_text boundary: source-link validation is not dictionary mapping.
    f0=by_id[target_ids[0]]
    mechanical["reason_field_current_attribution_check"]=probe(lambda:validate_feature(
        f0["features"][1],f0["evidence_refs"],[source_by_id[r] for r in f0["evidence_refs"]],images_by_id))
    altered=deepcopy(profile)
    changed=next(f for f in altered["preferences"] if f["preference_id"]==target_ids[0])
    changed["features"][0]["parameter_id"]="OPT-002"
    changed["features"][0]["value"]="高光"
    mechanical["changed_mapping_cannot_reuse_cached_supported"]=probe(
        lambda:validate_reviewed_profile(bundle,altered,reviewer_registry=registry))
    changed["semantic_assessment"]["candidate_digest"]=candidate_digest(changed,altered["input_digest"],altered["extraction_context"])
    mechanical["rehashing_candidate_does_not_reapprove_old_receipt"]=probe(
        lambda:validate_reviewed_profile(bundle,altered,reviewer_registry=registry))
    from prism_runtime.preferences.demo import build_fixture
    fixture,_=build_fixture()
    row=next(r for r in fixture["evidence"] if r["evidence_id"]=="e6")
    row["target_object_id"]="different-fixture-carrier"
    row["target_region_ref"]={"fixture_region":"different-edge"}
    test_feature={"parameter_id":"GEO-001","value":"圆弧","attribution":"pointed_image_feature",
                  "evidence_refs":["e6"],"observation_refs":[{"image_id":"research-r1","observation_id":"o-contour"}]}
    mechanical["cross_carrier_synthetic_control"]=probe(lambda:validate_feature(
        test_feature,["e6"],[row],{im["image_id"]:im for im in fixture["images"]}))
    mechanical["cross_carrier_synthetic_control"]["fixture_only"]=True
    require(mechanical["qualitative_density_to_numeric"]["rejected"],"numeric type boundary unexpectedly passed")
    require(not mechanical["reason_field_current_attribution_check"]["rejected"],"existing attribution behavior changed")
    require(mechanical["changed_mapping_cannot_reuse_cached_supported"]["rejected"],"changed candidate reused cached support")
    require(mechanical["rehashing_candidate_does_not_reapprove_old_receipt"]["rejected"],"old receipt accepted new mapping")
    require(mechanical["cross_carrier_synthetic_control"]["rejected"],"wrong fixture carrier unexpectedly accepted")
    write(out/"mechanical-replay.json",{
        "scope":"Existing guards and typed-value contrasts only; no new mapping consumer or semantic verdict.",
        "probes":mechanical,"new_model_calls":0,"old_source_files_mutated":False,
    })
    acceptance=[
        {"case":"same_concept_different_value","sources":["SYN-IMG-R035-SYN-U11"],"contrast":"gloss_level='high reflection / glossy edge' vs OPT-002='高光'",
         "required_behavior":"Validate field meaning, ordinal value and carrier separately; type-valid strings are not semantic equality.",
         "current_evidence":"mechanical-replay.json#synonym_value_shape_only","future_mapping_semantic_test":"not_run"},
        {"case":"reason_not_visual_parameter","sources":["SYN-IMG-R005-SYN-U11"],"contrast":"visual_distraction vs optical gloss",
         "required_behavior":"Keep distraction as reason and cooccurrence context, never substitute OPT-002 solely by name.",
         "current_evidence":"Existing attribution check accepts the source-linked reason field; this proves the missing mapping boundary, not correct visual attribution.",
         "future_mapping_semantic_test":"not_run"},
        {"case":"multi_layer_and_density_conjunction","sources":["SYN-IMG-R038-SYN-U11","SYN-IMG-R047-SYN-U11","SYN-IMG-R049-SYN-U11"],
         "contrast":"two-layer repeated bars vs one allowed layer; dense triangles/ridges vs isolated components",
         "required_behavior":"Preserve the combined trigger, participants and explicit non-rejections. Never split into unconditional forbidden fields; do not turn too_dense into numeric TEX-009.",
         "current_evidence":"Full original text and field hypotheses; numeric type mismatch reproduced.","future_mapping_semantic_test":"not_run"},
        {"case":"scenario_and_canonical_pid_counterfactual","sources":["SYN-IMG-R027-SYN-U11","SYN-IMG-R003-SYN-U09","SYN-IMG-R025-SYN-U09"],
         "contrast":"tool desk/commute context; lawful COL-006 with missing dark/low-reflection surroundings and uncertain choice",
         "required_behavior":"Preserve scenario plus conjunction and modality. Legal PID does not license an unconditional gold ban; empty old conditions cannot erase conditions in full text.",
         "current_evidence":"Original conditions/full source preserved; semantic question explicitly pending.","future_mapping_semantic_test":"not_run"},
        {"case":"cross_carrier","sources":["SYN-IMG-R027-SYN-U11","SYN-IMG-R035-SYN-U11","SYN-IMG-R059-SYN-U11","SYN-IMG-R025-SYN-U09"],
         "contrast":"annotation carrier vs negatively discussed carrier; separate relationship participants",
         "required_behavior":"No automatic region_id-to-DNA-object binding or cross-carrier reuse. Unknown binding must remain unresolved.",
         "current_evidence":"Source annotation and negative wording retained; existing pointed-image rule rejects a separate synthetic mismatched-carrier control.",
         "future_mapping_semantic_test":"not_run"},
        {"case":"old_review_signature","sources":[scopes[0]["evidence_refs"][0]],
         "contrast":"original candidate vs remapped PID/value, with cached supported and with recomputed candidate digest",
         "required_behavior":"Both attempts fail under original consumer. New mapping needs a separately versioned, parent-bound independent review.",
         "current_evidence":"Both actual in-memory original-consumer probes reject; input files unchanged.","future_mapping_semantic_test":"not_run"},
    ]
    write(out/"acceptance-cases.json",{"cases":acceptance,"cases_passed_as_new_mapping_algorithm":0,
                                    "note":"Required semantic acceptance cases are specified, not reported as completed."})
    protected=[{**x,"after_sha256":sha(x["path"]),"unchanged":sha(x["path"])==x["sha256"]} for x in baseline]
    require(all(x["unchanged"] for x in protected),"protected source changed during diagnosis")
    write(out/"source-manifest.json",{
        "protected_files":protected,"all_unchanged":True,
        "new_sidecar_files":[{"path":str(p),"sha256":sha(p)} for p in sorted(HERE.iterdir()) if p.is_file()],
        "mapping_proposal_sha256":sha(out/"mapping-proposals.json"),
    })
    write(out/"self-assessment.json",{
        "issue_id":"CLOSURE-PREF-001","status":"partial","diagnostic_scope_complete":True,
        "source_candidates":9,"feature_assertions":sum(len(s["features"]) for s in scopes),
        "noncanonical_name_count":10,"canonical_id_with_semantic_issue":"COL-006",
        "actual_extraction_calls_inspected":6,"original_review_ledger_revalidated":True,
        "official_rejection_reproduced":True,"executable_mapping_count":0,
        "new_model_calls":0,"new_paid_calls":0,"new_API_calls":0,
        "new_independent_mapping_semantic_reviews":0,"mapping_consumer_implemented":False,
        "old_profile_or_review_receipts_modified":False,"original_dictionary_modified":False,
        "root_directory_modified":False,"timer_restarted":False,
        "protected_file_count":len(protected),"protected_files_unchanged":True,
        "remaining":"Agree explicit mapping contract and implement a versioned review entry; independently verify semantics before any executable constraint or clustering.",
        "real_user_effect_validated":False,
    })
    write(out/"handoff.json",{
        "issue_id":"CLOSURE-PREF-001","repair_cycle":1,"status":"partial_diagnosis_and_advisory_proposals_only",
        "owner_thread_id":"01a0dcdc-049e-75d3-b956-94c091a4f063","root_thread_id":"01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de",
        "report":str(out/"report.md"),"proposals":str(out/"mapping-proposals.json"),
        "contract_design":str(HERE/"MAPPING_CONTRACT_PROPOSAL.md"),"prompt_audit":str(out/"prompt-audit.json"),
        "replay":str(out/"mechanical-replay.json"),"acceptance_cases":str(out/"acceptance-cases.json"),
        "self_assessment":str(out/"self-assessment.json"),"manifest":str(out/"source-manifest.json"),
        "ready_for_review":True,"ready_for_H02_or_clustering":False,
        "html_status_sentence":"用户偏好原话已保留且旧审阅链可验证；开放概念到216字典的参数、值、对象、条件及组合关系尚未独立核定，本轮没有最终聚类组。",
        "new_executable_constraints":0,"new_model_or_API_calls":0,
        "next_step_scope":"Review this minimum contract proposal first; no automatic new batch or execution requested.",
    })
    return {"status":"partial","candidate_count":9,"feature_assertions":sum(len(s["features"]) for s in scopes),
            "noncanonical_names":noncanonical,"protected_files":len(protected),"all_protected_unchanged":True,
            "actual_calls_audited":6,"executable_mappings":0,"new_API_calls":0,"output":str(out)}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--output",default=str(DEFAULT_OUTPUT))
    args=p.parse_args()
    print(json.dumps(run(args.output),ensure_ascii=False,indent=2))
