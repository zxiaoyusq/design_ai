"""Explicit synthetic protocol fixtures only; never write answers for the actual B run."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest
import wire
from prism_runtime.preferences.review import CHECKED_ASPECTS, POLICY_VERSION, validate_reviewed_profile
from prism_runtime.handshake.common import fingerprint


class Cases(unittest.TestCase):
    def setUp(self):
        ids=["SYN-B-E01-LUXURY","SYN-B-E02-GOLD","SYN-B-E03-RITUAL"]
        self.bundle={
            "brief":{"brief_id":"protocol-fixture-only","case_id":"B","target_tags":{"case_scope":["B"]},
                     "research_project_ids":["protocol-fixture"],"scene":"测试场景","region":"测试地区"},
            "users":[{"user_id":"SYN-B-U01","tags":{"case_scope":"B"}}],
            "evidence":[{"evidence_id":eid,"user_id":"SYN-B-U01","source_kind":"research",
                "project_id":"protocol-fixture","evidence_role":"user_statement",
                "text":f"仅在测试场景中，我愿意探索测试主题{i}。","context_schema":"prism.business-context.v1",
                "context":{"scene":"测试场景","region":"测试地区"}}
                for i,eid in enumerate(ids,1)],"images":[],
            "provenance":{"mode":"synthetic","case_id":"B","fixture_only":True,"not_an_actual_case_B_answer":True}}
        self.prepared=wire.prepare_extraction(self.bundle)
        req=self.prepared["requests"][0]
        self.reply={"request_id":req["request_id"],"input_digest":req["input_digest"],"findings":[],"dispositions":[]}
        for i,e in enumerate(self.bundle["evidence"],1):
            self.reply["findings"].append({"preference_id":f"fixture-p{i}","level":"theme","topic_key":f"fixture-topic-{i}",
                "title":"协议夹具","summary":"仅用于接口协议的合成条件示例","attitude":"conditional",
                "user_ids":["SYN-B-U01"],"evidence_refs":[e["evidence_id"]],"image_ids":[],"features":[],
                "conditions":["仅在测试场景中"],"quotes":[{"evidence_id":e["evidence_id"],"text":e["text"]}],
                "condition_bindings":[{"source_condition":"仅在测试场景中","evidence_refs":[e["evidence_id"]],
                    "predicates":[{"field":"scene","operator":"eq","value":"测试场景"}],
                    "review_status":"pending_independent_review"}]})
        self.context={"producer_id":"fixture-producer","independence_group":"fixture-extraction","run_id":"fixture-only"}
        self.profile=wire.accept_extraction(self.bundle,self.prepared,self.reply,self.context)
        self.request=wire.prepare_review(self.bundle,self.profile)
        self.registry={"registry_id":"fixture-binding-registry","registry_version":"1","issued_by":"synthetic-protocol-test",
            "reviewers":[{"reviewer_id":"fixture-reviewer","actor_type":"synthetic_fixture",
                          "independence_group":"fixture-review","allowed_dataset_modes":["synthetic"]}]}
        self.meta={"schema_version":POLICY_VERSION,"input_digest":self.profile["input_digest"],"review_id":"fixture-review",
            "reviewer_id":"fixture-reviewer","reviewed_at":"2026-09-27T00:00:00Z","review_artifact_ref":"fixture://not-a-real-execution"}
        byid={f["preference_id"]:f for f in self.profile["preferences"]}
        self.review={"request_id":self.request["request_id"],"input_digest":self.profile["input_digest"],
            "items":[{"preference_id":f["preference_id"],"candidate_digest":f["semantic_assessment"]["candidate_digest"],
                "verdict":"supported","reason":"Explicit synthetic protocol fixture, not independent real review.",
                "quotes":deepcopy(f["quotes"]),"record_refs":[],"checked_aspects":sorted(CHECKED_ASPECTS)}
                for f in self.profile["preferences"]],"condition_binding_reviews":[]}
        for b in self.request["binding_manifest"]:
            self.review["condition_binding_reviews"].append({
                **{k:b[k] for k in ("preference_id","candidate_digest","binding_index","binding_digest")},
                "verdict":"supported","reason":"Explicit synthetic binding protocol fixture.",
                "quotes":deepcopy(byid[b["preference_id"]]["quotes"]),"checked_aspects":wire.MAPPING_ASPECTS})

    def register(self,reply=None,registry=None):
        return wire.register_review(self.bundle,self.profile,self.request,self.review if reply is None else reply,
                                    self.meta,self.registry if registry is None else registry)

    def test_original_consumer_and_full_final_binding_hash(self):
        before=deepcopy((self.bundle,self.profile,self.review))
        result=self.register()
        for f in result["profile"]["preferences"]:
            b=f["condition_bindings"][0]
            self.assertEqual(b["review_status"],"reviewed")
            self.assertEqual(b["reviewer"],"fixture-reviewer")
            self.assertEqual(result["review_context"]["approved_condition_binding_hashes"][f["preference_id"]],[fingerprint(b)])
        validate_reviewed_profile(self.bundle,result["profile"],reviewer_registry=self.registry)
        self.assertEqual((self.bundle,self.profile,self.review),before)

    def test_pending_proposal_whole_object_is_review_bound(self):
        for b in self.request["binding_manifest"]:
            self.assertEqual(b["binding_digest"],fingerprint(b["proposed_binding"]))
        bad=deepcopy(self.review);bad["condition_binding_reviews"][0]["binding_digest"]="not-the-original-object"
        with self.assertRaises(ValueError):self.register(bad)

    def test_semantic_support_does_not_approve_insufficient_mapping(self):
        changed=deepcopy(self.review)
        for r in changed["condition_binding_reviews"]:r["verdict"]="insufficient"
        result=self.register(changed)
        self.assertEqual(result["review_context"]["approved_condition_binding_hashes"],{})
        self.assertTrue(all(f["condition_bindings"][0]["review_status"]=="pending_independent_review" for f in result["profile"]["preferences"]))

    def test_mapping_support_does_not_override_contradicted_parent(self):
        changed=deepcopy(self.review)
        for r in changed["items"]:r["verdict"]="contradicted"
        result=self.register(changed)
        self.assertEqual(result["review_context"]["approved_condition_binding_hashes"],{})

    def test_nonliteral_condition_and_invented_context_rejected(self):
        bad=deepcopy(self.reply)
        bad["findings"][0]["conditions"]=["在别的场景"]
        with self.assertRaises(ValueError):wire.accept_extraction(self.bundle,self.prepared,bad,self.context)
        bad=deepcopy(self.reply)
        bad["findings"][0]["condition_bindings"][0]["predicates"][0]["value"]="已经选定具体传统"
        with self.assertRaises(ValueError):wire.accept_extraction(self.bundle,self.prepared,bad,self.context)

    def test_extractor_cannot_self_mark_reviewed(self):
        bad=deepcopy(self.reply);bad["findings"][0]["condition_bindings"][0]["review_status"]="reviewed"
        with self.assertRaises(ValueError):wire.accept_extraction(self.bundle,self.prepared,bad,self.context)

    def test_missing_mapping_review_or_same_identity_rejected(self):
        bad=deepcopy(self.review);bad["condition_binding_reviews"].pop()
        with self.assertRaises(ValueError):self.register(bad)
        registry=deepcopy(self.registry);registry["reviewers"][0]["independence_group"]="fixture-extraction"
        with self.assertRaises(ValueError):self.register(registry=registry)

    def test_empty_binding_is_not_filled_by_registration(self):
        raw=deepcopy(self.reply)
        for f in raw["findings"]:f.pop("condition_bindings")
        p=wire.accept_extraction(self.bundle,self.prepared,raw,self.context)
        req=wire.prepare_review(self.bundle,p)
        self.assertEqual(req["binding_manifest"],[])
        self.assertTrue(all(not f.get("condition_bindings") for f in p["preferences"]))


if __name__=="__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Cases))
    if len(sys.argv)>1:
        wire.write(sys.argv[1],{"fixture_only":True,"not_actual_case_B_semantics":True,"tests_run":result.testsRun,
            "all_passed":result.wasSuccessful(),"failures":[str(t) for t,_ in result.failures],
            "errors":[str(t) for t,_ in result.errors],"new_model_calls":0})
    sys.exit(0 if result.wasSuccessful() else 1)
