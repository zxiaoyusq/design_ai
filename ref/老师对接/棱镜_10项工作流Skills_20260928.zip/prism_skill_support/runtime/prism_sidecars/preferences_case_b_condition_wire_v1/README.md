# B-condition-wire-v1 · 现有合同下的两次定点修复

本侧车只补producer消息/schema和Root的数据登记步骤，复用原preferences0.3.1及现有handshake条件绑定合同。它不调用模型，不更改已冻结的B bundle、三条原话、首轮画像/审阅或case A。

两次实际调用由Root执行：一次修复提取；一次新的独立审阅，同时审P01解释和condition bindings。之后H01/H02各一次仍由Root原计划控制。不能表达的条件继续unknown，不强制like、清空conditions或补造传统/材料已确定。

## 为什么两份批准

P01的candidate_digest不包含condition_bindings。原P01 items.supported不能单独批准新绑定。现有context_sidecar要求：

- source_condition等于原conditions，并在该候选引用的原话中逐字出现。
- evidence_refs归属正确；predicates有效。
- binding.review_status=reviewed，有可信reviewer。
- fingerprint(整个最终binding)列入review_context.approved_condition_binding_hashes[完整prefID]。

此侧车先用真实独立review审批整个pending binding，包含source_condition、evidence_refs、predicates和pending状态。Root只在该绑定和父候选均被新审阅supported时登记review_status/reviewer，并计算整个最终binding的批准哈希。原候选语义字段不因登记而改写，原consumer再校验一次。

登记前后的两个哈希含义不同：模型复制的是完整待审binding_digest；下游approved_condition_binding_hashes使用带真实审阅身份的最终完整对象哈希。必须使用register结果中的review_context，不要把前一个哈希直接当后一个。

## 已准备的实际输入

目录：

    D:\Codex\传音AI创客营\outputs\prism-algorithm-loop-20260926\modules\preferences\sidecars\CASE-B-CONDITION-WIRE-V1

prepared-extraction.json只含一个新的case-b-preference-repair-001请求，原3条source及input_digest未变；完整原文和阶段限度都保留。extraction-reply.schema.json允许可选condition_bindings，且只能是pending_independent_review，不能由提取模型自报已审。

修复条件要求引用原文准确子串。summary/quotes必须保留后续比较与未决内容。已知scene/region只限制可用值，不意味着可以把所有未来边界硬映射为当前scene。

## Root调用顺序

1. 冻结本sidecar和schema，使用原B bundle；由Astra标准CLI逐字发送prepared-extraction中的messages并保存原始请求/回复。Root自行验证真实执行身份与消息一致性。

2. 使用新的真实extraction_context接收；run_id必须属于此次实际调用，不使用旧首轮上下文记录冒充新执行：

    python -B -X utf8 prism_sidecars/preferences_case_b_condition_wire_v1/wire.py accept --bundle <冻结B-bundle> --prepared <prepared-extraction.json> --raw-reply <实际修复回复JSON> --extraction-context <真实新执行context.json> --output <新的candidate-profile.json>

accept调用原accept_batches并检查绑定边界。不会改引文或补条件。原source的缺口仍可通过既有dispositions表达，未覆盖来源不能被无声跳过。

3. 从实际新候选准备独立审阅：

    python -B -X utf8 prism_sidecars/preferences_case_b_condition_wire_v1/wire.py prepare-review --bundle <冻结B-bundle> --profile <新的candidate-profile.json> --output <新的prepared-review.json>

新review请求ID为case-b-preference-repair-review-001。Root再调用一次全新的Astra审阅上下文，原样保存响应。回复包含：

- 原items数组：原P01五项审阅协议保持不变。
- condition_binding_reviews数组：按候选和binding_index恰好覆盖全部绑定；无绑定则空数组。每项包含candidate_digest、完整pending binding_digest、verdict、reason、quotes、四项checked_aspects。

4. Root根据真实执行填写envelope metadata：schema_version、review_id、reviewer_id、input_digest、reviewed_at（带时区）、review_artifact_ref。这个metadata文件不能含items；items必须来自模型原始返回。使用实际独立登记表。

    python -B -X utf8 prism_sidecars/preferences_case_b_condition_wire_v1/wire.py register --bundle <冻结B-bundle> --profile <新的candidate-profile.json> --review-request <新的prepared-review.json> --raw-reply <实际新review回复JSON> --envelope-metadata <真实执行metadata.json> --registry <实际B独立registry.json> --output <新的registered-review.json>

register复用原apply_semantic_reviews和validate_reviewed_profile，并在可信Root边界登记单独的binding审批。返回：

- profile：新的审阅画像副本，保留原条件/态度/摘要，仅为实际通过的binding登记审阅元数据。
- review_context：包含原reviewer_registry和approved_condition_binding_hashes；供现有ContextSession使用。
- condition_binding_receipt：新原始review对象和最终批准哈希的对应关系，包含请求/回复fingerprint及实际artifact ref。

Root分别把这些部分写到新的文件，再让握手owner依据新profile和review_context重新prepare scope/H01。完整profile快照会改变，不能把旧H01 token补进新回复。原B首轮画像/回执不覆盖。

## 仍然会阻断的情况

修复回复的条件不逐字、绑定把未知业务值当已知、独立审阅拒绝/不足、父候选未通过、或没有给出可信绑定，均不能取得当前上下文支持。宗教传统未选等项目允许仍为gap。新supported不是H01/H02审批；具体设计边界不能因为本轮探索而消失。

脚本依赖可信Root提供真实执行元数据和登记表，不声称密码学身份认证。不要在实际调用前拿模板或自填review结论调用register。

8项独立合成协议夹具已验证：全对象哈希、原consumer兼容、旧supported不能批准不足映射、父候选矛盾不能被绑定通过覆盖、非逐字条件/虚构场景拒绝、自我标reviewed拒绝、漏审/同组身份拒绝、无绑定不补造。它们不是本次实际B语义效果验证。
