"""Case B condition repair wire; existing P01 and handshake approval contracts, no model calls."""
from copy import deepcopy
import argparse
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from prism_runtime.preferences import prepare_requests, prepare_semantic_review, accept_batches
from prism_runtime.preferences.review import apply_semantic_reviews, validate_reviewed_profile
from prism_runtime.handshake.common import fingerprint
from prism_runtime.preferences.validation import validate_quote
from prism_sidecars.preferences_qwen_p01_wire_001.p01_wire import _schema_check, require, read, write
from prism_sidecars.preferences_case_b_broad_theme.prepare import check_bundle, EXTRA

VERSION="case-b-condition-wire-v1"
STRING={"type":"string","minLength":1}
PREDICATE={"type":"object","additionalProperties":False,"required":["field","operator","value"],
           "properties":{"field":{"enum":["scene","region"]},"operator":{"enum":["eq"]},"value":STRING}}
BINDING={"type":"object","additionalProperties":False,
         "required":["source_condition","evidence_refs","predicates","review_status"],
         "properties":{"source_condition":STRING,
            "evidence_refs":{"type":"array","minItems":1,"uniqueItems":True,"items":STRING},
            "predicates":{"type":"array","minItems":1,"items":PREDICATE},
            "review_status":{"enum":["pending_independent_review"]}}}
MAPPING_ASPECTS=["meaning","source_scope","known_business_context","no_added_facts"]
REPAIR_PROMPT="""这是同一case B原始资料上的一次定点重提取。旧画像和旧审阅保留，但不是本次答案或审批。
不得为了握手把态度强制改like、删条件或将具体传统/材质/产品已经确定设置为true。
按原文区分：本轮探索适用范围、未来具体设计尚待确定的阶段边界、真正的兴趣前置条件。
summary和quotes必须完整保留兴趣的限度、未来比较安排和未决内容。没有把握的前置条件保留conditions，不要为少字段丢弃。
conditions中的每个字符串必须是引用原文中的准确连续子串；不要用改写句充当可绑定原话。
可选condition_bindings只用于有明确文字依据、可无损解释为已有scene或region等值谓词的条件。
source_condition必须等于某条conditions，并出现在对应quotes.text中；evidence_refs必须引用自己的原来源。
predicates只可用field=scene或region、operator=eq，value必须逐字等于对应来源context中的现有值。
这只是字段取值范围限制，不能因此把任何阶段边界都硬解释成scene。未来选传统/材质等未知事项不能通过scene等值偷渡为已完成。
不能准确绑定时不输出该binding；保留原条件，由后续标unknown。
所有binding.review_status只能pending_independent_review，不输出reviewer或任何自我通过标记。
theme、features=[]、image_ids=[]和合成设计假设身份不变。仅修复本请求的3条来源，不增加事实或人工答案。
返回完整JSON，按本次request_id/input_digest和完整schema。"""
REVIEW_EXTRA="""这次同时独立核对两部分：items用于原P01审阅；condition_binding_reviews用于另行审核条件解释。
旧P01 candidate_digest不覆盖condition_bindings，不能只因items=supported就批准binding。
先读完整原话，再核对新的summary/attitude/conditions是否保留真实限度；逐字条件仍可能被解释错。
每个列出的binding恰好给一个独立结论，复制候选摘要和binding_digest。
逐项检查meaning/source_scope/known_business_context/no_added_facts；不能因scene/region值存在就判映射语义成立。
未来比较、传统未选、材料未定不能伪装成当前已满足的scene等值。错误判contradicted，不能确定判insufficient。
condition_binding_reviews.quotes必须从对应原来源逐字引用。没有binding时输出空数组。
不要修改原候选或给修复答案。不要输出真实执行身份、时间或审批哈希；Root基于实际执行另行登记。"""


def extraction_schema():
    schema=deepcopy(read(ROOT/"outputs/prism-algorithm-loop-20260926/modules/preferences/sidecars/CASE-B-BROAD-THEMES/extraction-reply.schema.json"))
    schema["title"]=VERSION+"; source statements unchanged"
    schema["$defs"]["finding"]["properties"]["condition_bindings"]={"type":"array","items":BINDING}
    return schema


def review_schema():
    schema=deepcopy(read(HERE.parent/"preferences_qwen_review_wire_001/reply-schema.json"))
    item={"type":"object","additionalProperties":False,
          "required":["preference_id","candidate_digest","binding_index","binding_digest","verdict","reason","quotes","checked_aspects"],
          "properties":{"preference_id":STRING,"candidate_digest":STRING,"binding_index":{"type":"integer"},
            "binding_digest":STRING,"verdict":{"enum":["supported","contradicted","insufficient"]},
            "reason":STRING,"quotes":{"type":"array","minItems":1,"items":{"$ref":"#/$defs/quote"}},
            "checked_aspects":{"type":"array","minItems":4,"maxItems":4,"uniqueItems":True,"items":{"enum":MAPPING_ASPECTS}}}}
    schema["required"].append("condition_binding_reviews")
    schema["properties"]["condition_binding_reviews"]={"type":"array","items":item}
    return schema


def semantic_binding_content(binding):
    # The reviewer binds the whole proposed object, including its mandatory pending status.
    return deepcopy(binding)


def check_bindings(bundle,profile):
    evidence={e["evidence_id"]:e for e in bundle["evidence"]}
    rows=[]
    for f in profile["preferences"]:
        bindings=f.get("condition_bindings",[])
        require(isinstance(bindings,list),"condition_bindings must be an array")
        names=[b["source_condition"] for b in bindings]
        require(len(names)==len(set(names)),"one binding per exact source condition")
        for i,b in enumerate(bindings):
            _schema_check(b,BINDING,BINDING)
            require(b["source_condition"] in f["conditions"],"binding does not refer to an existing exact condition")
            refs=b["evidence_refs"]
            require(set(refs)<=set(f["evidence_refs"]),"binding outside candidate sources")
            require(any(b["source_condition"] in q["text"] for q in f["quotes"] if q["evidence_id"] in refs),
                    "condition mapping does not retain its quote")
            require(all(b["source_condition"] in evidence[eid]["text"] for eid in refs),"binding condition absent in original text")
            for p in b["predicates"]:
                require(all(evidence[eid].get("context_schema")=="prism.business-context.v1"
                            and evidence[eid].get("context",{}).get(p["field"])==p["value"] for eid in refs),
                        "binding invents or changes a registered source business value")
            rows.append({"preference_id":f["preference_id"],"candidate_digest":f["semantic_assessment"]["candidate_digest"],
                         "binding_index":i,"binding_digest":fingerprint(semantic_binding_content(b)),
                         "proposed_binding":deepcopy(b)})
    return rows


def prepare_extraction(bundle):
    check_bundle(bundle)
    result=prepare_requests(bundle)
    require(len(result["requests"])==1,"one bounded three-source repair request")
    req=result["requests"][0];req["request_id"]="case-b-preference-repair-001"
    req["messages"][0]["content"]+="\n\n"+EXTRA+"\n"+REPAIR_PROMPT+"\n绑定："+json.dumps(
        {"request_id":req["request_id"],"input_digest":req["input_digest"]},ensure_ascii=False
    )+"\nJSON Schema："+json.dumps(extraction_schema(),ensure_ascii=False)
    req["message_chars"]=sum(len(m["content"]) for m in req["messages"])
    result.update(producer_wire=VERSION,new_model_calls=0,source_changed=False)
    return result


def accept_extraction(bundle,prepared,raw_reply,extraction_context):
    expected=prepare_extraction(bundle)
    require(prepared==expected,"extraction request must be the exact frozen repair request")
    schema=extraction_schema();_schema_check(raw_reply,schema,schema)
    for f in raw_reply["findings"]:
        for condition in f["conditions"]:
            require(any(condition in q["text"] for q in f["quotes"]),"repair condition must retain an exact source quote")
    result=accept_batches(bundle,prepared,[raw_reply],extraction_context=extraction_context)
    require(result["coverage"]["status"]=="complete","all three source records require an explicit disposition")
    check_bindings(bundle,result)
    return result


def prepare_review(bundle,profile):
    check_bundle(bundle)
    require(profile["input_digest"]==prepare_requests(bundle)["input_digest"],"fresh repair profile must bind unchanged B sources")
    require(all(f["level"]=="theme" and f["features"]==[] and f["image_ids"]==[] for f in profile["preferences"]),"theme-only repair")
    bindings=check_bindings(bundle,profile)
    req=prepare_semantic_review(bundle,profile)
    req["request_id"]="case-b-preference-repair-review-001"
    req["binding_manifest"]=bindings
    req["messages"][0]["content"]+="\n\n"+(
        HERE.parent/"preferences_qwen_review_wire_001/WIRE_PROMPT.md").read_text(encoding="utf-8")
    # Override the old wire's top-level key list explicitly; all original item fields stay identical.
    req["messages"][0]["content"]+="\n本轮完整顶层还必须有condition_binding_reviews，下面的新完整schema为准。\n"+REVIEW_EXTRA
    req["messages"][0]["content"]+="\n绑定："+json.dumps(
        {"request_id":req["request_id"],"input_digest":req["input_digest"],"bindings":bindings},ensure_ascii=False)
    req["messages"][0]["content"]+="\nJSON Schema："+json.dumps(review_schema(),ensure_ascii=False)
    req["producer_wire"]=VERSION;req["message_chars"]=sum(len(m["content"]) for m in req["messages"])
    return req


def register_review(bundle,candidate_profile,review_request,raw_reply,envelope_metadata,registry):
    """Trusted Root registration only after real fresh review; no invented approval.

    Binding semantic decisions come solely from the independent reply. Original P01
    review uses its existing consumer. Final binding hashes use the existing handshake
    caller-approved registry path, never the old P01 candidate digest.
    """
    expected=prepare_review(bundle,candidate_profile)
    require(review_request==expected,"saved review request does not bind this candidate/bindings")
    schema=review_schema();_schema_check(raw_reply,schema,schema)
    require(raw_reply["request_id"]==expected["request_id"] and raw_reply["input_digest"]==expected["input_digest"],"review response binding mismatch")
    ids={f["preference_id"] for f in candidate_profile["preferences"]}
    require(len(raw_reply["items"])==len(ids) and {x["preference_id"] for x in raw_reply["items"]}==ids,
            "new P01 review must cover this complete fresh candidate scope")
    manifest={(b["preference_id"],b["binding_index"]):b for b in expected["binding_manifest"]}
    decisions=raw_reply["condition_binding_reviews"]
    require(len(decisions)==len(manifest) and {(r["preference_id"],r["binding_index"]) for r in decisions}==set(manifest),
            "binding review scope missing, duplicate or foreign")
    byid={f["preference_id"]:f for f in candidate_profile["preferences"]}
    evidence={e["evidence_id"]:e for e in bundle["evidence"]}
    for item in decisions:
        m=manifest[(item["preference_id"],item["binding_index"])]
        require(item["candidate_digest"]==m["candidate_digest"] and item["binding_digest"]==m["binding_digest"],"binding review changed content")
        require(item["reason"].strip(),"binding review reason required")
        binding=m["proposed_binding"]
        for q in item["quotes"]:
            require(q["evidence_id"] in binding["evidence_refs"],"binding review quote outside its sources")
            validate_quote(q,evidence)
        require({q["evidence_id"] for q in item["quotes"]}>=set(binding["evidence_refs"]),"each binding source must be quoted")
    require("items" not in envelope_metadata,"caller metadata cannot replace model review items")
    envelope={**deepcopy(envelope_metadata),"items":deepcopy(raw_reply["items"])}
    require(envelope.get("input_digest")==expected["input_digest"],"caller envelope must bind the actual repair input")
    reviewed=apply_semantic_reviews(bundle,candidate_profile,envelope,reviewer_registry=registry)
    reviewed=validate_reviewed_profile(bundle,reviewed,reviewer_registry=registry)
    accepted={};receipts=[]
    for item in decisions:
        f=next(f for f in reviewed["preferences"] if f["preference_id"]==item["preference_id"])
        b=f["condition_bindings"][item["binding_index"]]
        approved=item["verdict"]=="supported" and f["semantic_assessment"]["status"]=="supported"
        if approved:
            b["review_status"]="reviewed"
            b["reviewer"]=envelope["reviewer_id"]  # Real caller-registered reviewer, not extractor-authored.
            final_hash=fingerprint(b)
            accepted.setdefault(f["preference_id"],[]).append(final_hash)
        else:final_hash=None
        receipts.append({"preference_id":f["preference_id"],"binding_index":item["binding_index"],
             "binding_content_digest":item["binding_digest"],"actual_binding_review":deepcopy(item),
             "approved":approved,"approved_binding_hash":final_hash,
             "review_id":envelope["review_id"],"review_artifact_ref":envelope["review_artifact_ref"]})
    # Only binding registration metadata changed; parent semantic claims still pass original verification.
    reviewed=validate_reviewed_profile(bundle,reviewed,reviewer_registry=registry)
    return {"profile":reviewed,"review_context":{"reviewer_registry":deepcopy(registry),
                "approved_condition_binding_hashes":accepted},
            "condition_binding_receipt":{"producer_wire":VERSION,"request_fingerprint":fingerprint(review_request),
                "raw_reply_fingerprint":fingerprint(raw_reply),"entries":receipts,
                "approval_authority":"Root actual independent execution plus original P01 and existing handshake approval contract",
                "no_automatic_H01_H02_approval":True},
            "new_model_calls_by_owner":0}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=["prepare","accept","prepare-review","register"])
    for key in ("bundle","profile","prepared","extraction-context","review-request","raw-reply","envelope-metadata","registry","output"):
        p.add_argument("--"+key,required=key in ("bundle","output"))
    a=p.parse_args();bundle=read(a.bundle)
    if a.action=="prepare":result=prepare_extraction(bundle)
    elif a.action=="accept":result=accept_extraction(bundle,read(a.prepared),read(a.raw_reply),read(a.extraction_context))
    elif a.action=="prepare-review":result=prepare_review(bundle,read(a.profile))
    else:result=register_review(bundle,read(a.profile),read(a.review_request),read(a.raw_reply),read(a.envelope_metadata),read(a.registry))
    write(a.output,result)
    if a.action=="prepare":
        write(Path(a.output).parent/"extraction-reply.schema.json",extraction_schema())
        write(Path(a.output).parent/"review-reply.schema.json",review_schema())
    print(json.dumps({"status":"written","path":a.output,"new_model_calls":0},ensure_ascii=False))


if __name__=="__main__":main()
