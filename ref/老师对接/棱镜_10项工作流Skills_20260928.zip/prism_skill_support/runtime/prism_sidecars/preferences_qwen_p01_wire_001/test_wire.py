"""Bounded offline protocol tests. Existing synthetic fixtures are never run-input answers."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE.parents[1]))
import p01_wire as wire
from prism_runtime.preferences import engine
from prism_runtime.preferences.demo import build_fixture

def replies_for_test_fixture(bundle,findings,prepared):
    # Only pre-existing synthetic development annotations from demo.py are used here.
    responses=[]
    for request in prepared["requests"]:
        ids=set(request["evidence_ids"])
        responses.append({
            "request_id":request["request_id"],"input_digest":request["input_digest"],
            "findings":[deepcopy(f) for f in findings["findings"] if set(f["evidence_refs"]).issubset(ids)],
            "dispositions":[deepcopy(d) for d in findings["dispositions"] if d["evidence_id"] in ids],
        })
    return responses

class WireCases(unittest.TestCase):
    def setUp(self):
        self.bundle,self.findings=build_fixture()
        self.prepared=wire.prepare_requests(self.bundle,max_sources=3,max_chars=512000)
    def test_count_cap_and_exact_coverage(self):
        self.assertEqual([len(r["evidence_ids"]) for r in self.prepared["requests"]],[3,3,3,1])
        self.assertEqual([x for r in self.prepared["requests"] for x in r["evidence_ids"]],
                         engine.select_users(self.bundle)["eligible_evidence_ids"])
    def test_original_user_payload_dna_and_fingerprint_unchanged(self):
        for req in self.prepared["requests"]:
            base=engine._request(self.bundle,self.prepared["selection"],req["evidence_ids"])
            self.assertEqual(req["messages"][1],base["messages"][1])
            self.assertEqual(req["input_digest"],base["input_digest"])
            self.assertTrue(req["messages"][0]["content"].startswith(engine.SYSTEM_PROMPT))
            self.assertEqual(req["message_chars"],sum(len(m["content"]) for m in req["messages"]))
    def test_count_only_does_not_override_character_cap(self):
        individual=wire.prepare_requests(self.bundle,max_sources=1,max_chars=512000)
        largest=max(r["message_chars"] for r in individual["requests"])
        result=wire.prepare_requests(self.bundle,max_sources=100,max_chars=largest+100)
        self.assertGreater(len(result["requests"]),1)
        self.assertTrue(all(r["message_chars"]<=largest+100 for r in result["requests"]))
    def test_oversize_source_rejected_without_truncation(self):
        bundle=deepcopy(self.bundle);bundle["evidence"][0]["text"]+="x"*20000
        before=deepcopy(bundle)
        with self.assertRaises(wire.WireError):
            wire.prepare_requests(bundle,max_sources=8,max_chars=10000)
        self.assertEqual(bundle,before)
    def test_invalid_budget_inputs(self):
        for kw in [{"max_sources":0},{"max_sources":True},{"max_chars":100},{"max_chars":False}]:
            with self.assertRaises(wire.WireError):wire.prepare_requests(self.bundle,**kw)
    def test_empty_scope_has_no_requests(self):
        self.bundle["brief"]["target_tags"]={"segment":["missing"]}
        result=wire.prepare_requests(self.bundle)
        self.assertEqual(result["requests"],[])
        self.assertEqual(result["status"],"empty")
    def test_reply_is_passed_unchanged_to_original_accept_batches(self):
        replies=replies_for_test_fixture(self.bundle,self.findings,self.prepared)
        before=deepcopy(replies)
        expected=engine.accept_batches(self.bundle,self.prepared,replies)
        actual=wire.accept_batches(self.bundle,self.prepared,replies)
        self.assertEqual(actual,expected)
        self.assertEqual(replies,before)
    def test_string_quotes_rejected_not_converted(self):
        bad=deepcopy(self.findings["findings"][0])
        bad["quotes"]=[q["text"] for q in bad["quotes"]]
        before=deepcopy(bad)
        with self.assertRaisesRegex(wire.WireError,"quotes"):
            wire.validate_finding_wire(bad)
        self.assertEqual(bad,before)
    def test_string_observation_refs_rejected(self):
        bad=deepcopy(self.findings["findings"][5])
        bad["features"][0]["observation_refs"]=["research-r1:o-contour"]
        with self.assertRaisesRegex(wire.WireError,"observation_refs"):
            wire.validate_finding_wire(bad)
    def test_condition_object_not_silently_rendered_to_text(self):
        bad=deepcopy(self.findings["findings"][2])
        bad["conditions"]=[{"场景":"办公室"}]
        with self.assertRaisesRegex(wire.WireError,"conditions"):wire.validate_finding_wire(bad)
    def test_disposition_reason_and_object_shape_are_explicit(self):
        good=replies_for_test_fixture(self.bundle,self.findings,self.prepared)[-1]
        bad=deepcopy(good);bad["dispositions"]=["skip"]
        with self.assertRaises(wire.WireError):wire.validate_wire_reply(bad)
        bad=deepcopy(good);bad["dispositions"]=[{"evidence_id":"e13","reason":"budget"}]
        with self.assertRaises(wire.WireError):wire.validate_wire_reply(bad)
    def test_wrong_transport_binding_rejected(self):
        reply=replies_for_test_fixture(self.bundle,self.findings,self.prepared)[0]
        reply["input_digest"]="wrong"
        with self.assertRaisesRegex(wire.WireError,"digest"):
            wire.validate_wire_reply(reply,self.prepared["requests"][0])
    def test_truncated_reason_rejected_even_with_valid_json(self):
        reply=replies_for_test_fixture(self.bundle,self.findings,self.prepared)[0]
        with self.assertRaisesRegex(wire.WireError,"finish_reason"):
            wire.decode_raw_reply(json.dumps(reply),finish_reason="length")
    def test_bad_json_is_not_salvaged(self):
        with self.assertRaises(wire.WireError):
            wire.decode_raw_reply('{"findings":[',finish_reason="stop")
        with self.assertRaises(wire.WireError):
            wire.decode_raw_reply(chr(96)*3+'json\n{}\n'+chr(96)*3,finish_reason="stop")
    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(wire.WireError):
            wire.decode_raw_reply('{"request_id":"one","request_id":"two"}',finish_reason="stop")
    def test_native_root_provider_wrapper_preserves_reply(self):
        reply=replies_for_test_fixture(self.bundle,self.findings,self.prepared)[0]
        native={"ok":True,"http_status":200,"data":{"output":{"choices":[{
            "finish_reason":"stop","message":{"role":"assistant","content":[{"text":json.dumps(reply,ensure_ascii=False)}]}}]}}}
        self.assertEqual(wire.decode_native_provider(native,request=self.prepared["requests"][0]),reply)
        native["data"]["output"]["choices"][0]["finish_reason"]="length"
        with self.assertRaises(wire.WireError):wire.decode_native_provider(native)
    def test_original_source_rules_still_reject_cross_batch_quotes(self):
        replies=replies_for_test_fixture(self.bundle,self.findings,self.prepared)
        foreign=deepcopy(self.findings["findings"][4])
        foreign["preference_id"]="foreign-in-this-request"
        replies[0]["findings"].append(foreign)
        with self.assertRaises(ValueError):
            wire.accept_batches(self.bundle,self.prepared,replies)
    def test_original_conditions_guard_still_applies(self):
        replies=replies_for_test_fixture(self.bundle,self.findings,self.prepared)
        f=next(f for r in replies for f in r["findings"] if f["attitude"]=="conditional")
        f["conditions"]=[]
        with self.assertRaises(ValueError):
            wire.accept_batches(self.bundle,self.prepared,replies)

if __name__=="__main__":
    unittest.main()
