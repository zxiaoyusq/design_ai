"""Read-only audit of the real P01 input/prepared set and preserved bad response artifacts."""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import p01_wire as wire

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--bundle",required=True);p.add_argument("--prepared",required=True)
    p.add_argument("--original-p01",required=True);p.add_argument("--protected-before",required=True)
    p.add_argument("--output",required=True);p.add_argument("--runtime-root")
    a=p.parse_args()
    bundle=wire.read(a.bundle);prepared=wire.read(a.prepared)
    runtime=wire.load_runtime(a.runtime_root)
    ids=runtime.select_users(bundle)["eligible_evidence_ids"]
    original=Path(a.original_p01)
    sources={x["evidence_id"]:x for x in bundle["evidence"]}
    images={x["image_id"]:x for x in bundle["images"]}
    flattened=[];rows=[]
    for r in prepared["requests"]:
        baseline=runtime._request(bundle,prepared["selection"],r["evidence_ids"])
        assert r["messages"][1]==baseline["messages"][1],"original user payload changed"
        assert r["messages"][0]["content"].startswith(runtime.SYSTEM_PROMPT+"\n\n")
        assert r["input_digest"]==baseline["input_digest"]
        payload=json.loads(r["messages"][1]["content"])
        assert [e["evidence_id"] for e in payload["evidence"]]==r["evidence_ids"]
        assert all(e==sources[e["evidence_id"]] for e in payload["evidence"])
        for image in payload["image_dna"]:
            originals=images[image["image_id"]].get("observations",[])
            assert len(image["observations"])==len(originals),"DNA observation count changed"
            assert all(o=={k:src.get(k) for k in
                ("observation_id","parameter_id","object_id","value","value_status","region_ref","evidence_refs")}
                for o,src in zip(image["observations"],originals)),"DNA field value changed"
        count=len(r["evidence_ids"]);chars=sum(len(m["content"]) for m in r["messages"])
        assert 1<=count<=prepared["sidecar"]["max_sources_per_request"]
        assert chars==r["message_chars"]<=prepared["sidecar"]["max_message_chars"]
        flattened.extend(r["evidence_ids"])
        rows.append({"request_id":r["request_id"],"source_count":count,"message_chars":chars,
                     "input_digest":r["input_digest"],
                     "system_prompt_sha256":wire.sha_bytes(r["messages"][0]["content"].encode("utf-8")),
                     "messages_sha256":wire.sha_bytes(json.dumps(r["messages"],ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")),
                     "linked_images":len(payload["image_dna"]),
                     "supplied_DNA_observations":sum(len(i["observations"]) for i in payload["image_dna"])})
    assert flattened==ids and len(set(flattened))==len(flattened)==132
    provider=wire.read(original/"calls/P01-001/provider-response.json")
    diagnostic=wire.read(original/"first-complete-finding-diagnostic-only.json")
    output=(original/"calls/P01-001/output.txt").read_text(encoding="utf-8-sig")
    choice=provider["data"]["output"]["choices"][0]
    assert output==choice["message"]["content"][0]["text"],"original output differs from provider content"
    rejections={}
    for name,action in [
        ("original_truncated_provider",lambda:wire.decode_native_provider(provider)),
        ("original_raw_truncated_json_even_if_stop_claimed",lambda:wire.decode_raw_reply(output,finish_reason="stop")),
        ("original_complete_finding_with_string_quotes",lambda:wire.validate_finding_wire(diagnostic["finding"])),
    ]:
        try:action()
        except (wire.WireError,ValueError,KeyError,TypeError,AttributeError) as exc:
            rejections[name]={"rejected":True,"error_type":type(exc).__name__,"reason":str(exc)}
        else:raise AssertionError(name+" was unexpectedly accepted")
    # This is deliberately an invalid, diagnostic-only wrapper. No semantic fields are supplied or fixed.
    bad={"findings":[diagnostic["finding"]]}
    try:runtime.compile_preferences(bundle,bad)
    except (ValueError,KeyError,TypeError,AttributeError) as exc:
        rejections["unchanged_original_compiler_bad_quotes"]={"rejected":True,"error_type":type(exc).__name__,"reason":str(exc)}
    else:raise AssertionError("Original bad quote shape unexpectedly became valid")
    before=wire.read(a.protected_before);integrity=[]
    for entry in before["files"]:
        path=Path(entry["path"])
        actual=wire.sha_bytes(path.read_bytes())
        integrity.append({**entry,"after_sha256":actual,"unchanged":actual==entry["sha256"]})
    assert all(r["unchanged"] for r in integrity),"protected old source changed"
    source_hash=wire.sha_bytes(Path(a.bundle).read_bytes())
    assert source_hash==prepared["sidecar"]["bundle_file_sha256"]
    result={
        "issue_id":"QWEN-P01-WIRE-001","sidecar_version":wire.VERSION,
        "offline_prepare_qualified":True,"qwen_retest_performed":False,"semantic_quality_qualified":False,
        "source_count":132,"unique_source_count":132,"duplicate_source_ids":[],
        "requests":rows,"request_count":len(rows),
        "source_count_distribution":dict(Counter(r["source_count"] for r in rows)),
        "max_message_chars":max((r["message_chars"] for r in rows),default=0),
        "total_message_chars":sum(r["message_chars"] for r in rows),
        "source_text_unchanged":True,"existing_payload_DNA_unchanged":True,
        "input_digest_unchanged":prepared["input_digest"]==runtime.fingerprint(bundle,prepared["selection"]["selected_user_ids"],ids),
        "original_failed_artifacts_still_rejected":rejections,
        "protected_original_files":integrity,
        "source_file":{"path":str(Path(a.bundle).resolve()),"sha256":source_hash},
        "prepared_file":{"path":str(Path(a.prepared).resolve()),"sha256":wire.sha_bytes(Path(a.prepared).read_bytes())},
        "prompt_and_runtime":prepared["sidecar"],"new_api_calls":0,"semantic_answers_authored_for_this_input":0,
        "notes":["8-source cap reduces output risk but does not guarantee model completion.",
                 "No original finding, Like/Dislike, condition or quote attribution was repaired.",
                 "Invalid first finding is used for rejection testing only, never as a profile.",
                 "Character counts are not token counts; original per-image unknown/empty DNA states are retained."],
    }
    wire.write(a.output,result)
    print(json.dumps({k:result[k] for k in ("source_count","request_count","source_count_distribution","max_message_chars","total_message_chars","qwen_retest_performed")},ensure_ascii=False))
    return 0

if __name__=="__main__":raise SystemExit(main())
