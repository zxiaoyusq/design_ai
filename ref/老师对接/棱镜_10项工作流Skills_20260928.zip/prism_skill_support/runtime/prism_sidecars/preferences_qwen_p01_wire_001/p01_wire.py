"""QWEN-P01-WIRE-001: bounded sidecar; no networking and no semantic answer repair."""
from __future__ import annotations
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
DEFAULT_RUNTIME_ROOT=HERE.parents[1]
VERSION="qwen-p01-wire-001-v1"
MODEL="qwen3.8-flash"

class WireError(ValueError):
    pass

def require(condition,message):
    if not condition:raise WireError(message)

def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def load_runtime(runtime_root=None):
    root=Path(runtime_root or DEFAULT_RUNTIME_ROOT).resolve()
    require((root/"prism_runtime/preferences/engine.py").is_file(),"runtime root does not contain existing preferences engine")
    sys.path.insert(0,str(root))
    engine=importlib.import_module("prism_runtime.preferences.engine")
    require(Path(engine.__file__).resolve()==root/"prism_runtime/preferences/engine.py",
            "a different prism_runtime is already imported; use a fresh Python process")
    return engine

def metadata(engine):
    return {
        "version":VERSION,"intended_semantic_model":MODEL,
        "original_engine_path":str(Path(engine.__file__).resolve()),
        "original_engine_sha256":sha_bytes(Path(engine.__file__).read_bytes()),
        "original_system_prompt_sha256":sha_bytes(engine.SYSTEM_PROMPT.encode("utf-8")),
        "wire_prompt_sha256":sha_bytes((HERE/"WIRE_PROMPT.md").read_bytes()),
        "reply_schema_sha256":sha_bytes((HERE/"reply-schema.json").read_bytes()),
    }

def _request(engine,bundle,selection,ids,request_id,wire,schema_text):
    req=engine._request(bundle,selection,ids)
    req["request_id"]=request_id
    binding={"request_id":request_id,"input_digest":req["input_digest"]}
    req["messages"][0]["content"] += (
        "\n\n"+wire+"\n\n本次回复绑定值："+json.dumps(binding,ensure_ascii=False,separators=(",",":"))
        +"\n\n完整回复JSON Schema：\n"+schema_text
    )
    req["message_chars"]=sum(len(m["content"]) for m in req["messages"])
    req["wire_protocol"]=VERSION
    return req

def prepare_requests(bundle,*,max_sources=8,max_chars=512000,runtime_root=None):
    require(type(max_sources) is int and max_sources>0,"max_sources must be a positive integer")
    require(type(max_chars) is int and max_chars>=4000,"max_chars must be an integer >=4000")
    engine=load_runtime(runtime_root)
    selection=engine.select_users(bundle)
    ids=selection["eligible_evidence_ids"]
    wire=(HERE/"WIRE_PROMPT.md").read_text(encoding="utf-8")
    schema_text=json.dumps(read(HERE/"reply-schema.json"),ensure_ascii=False,separators=(",",":"))
    requests=[];pending=[]
    def make(values):
        return _request(engine,bundle,selection,values,f"preference-wire001-{len(requests)+1:03d}",wire,schema_text)
    current=None
    for eid in ids:
        if len(pending)==max_sources:
            requests.append(current);pending=[];current=None
        candidate=pending+[eid]
        req=make(candidate)
        if req["message_chars"]>max_chars and pending:
            requests.append(current);pending=[eid]
            req=make(pending)
        else:
            pending=candidate
        require(req["message_chars"]<=max_chars,
                f"single source {eid} plus complete existing image DNA/protocol needs {req['message_chars']} chars, exceeds {max_chars}; no truncation")
        current=req
    if pending:requests.append(current)
    flattened=[x for r in requests for x in r["evidence_ids"]]
    require(flattened==ids and len(flattened)==len(set(flattened)),"input source coverage must be exact, ordered and unique")
    return {
        "schema_version":"prism.preference_requests.v0.1","selection":selection,"requests":requests,
        "status":"ready" if requests else "empty",
        "input_digest":engine.fingerprint(bundle,selection["selected_user_ids"],ids),
        "provenance":bundle["provenance"],
        "sidecar":{**metadata(engine),"max_sources_per_request":max_sources,"max_message_chars":max_chars,
                   "character_cap_includes_protocol":True,"source_or_DNA_truncation":False,
                   "input_source_count":len(ids),"new_model_calls":0,
                   "output_fit_guaranteed":False},
    }

def _is_type(value,name):
    return {"object":isinstance(value,dict),"array":isinstance(value,list),"string":isinstance(value,str),
            "integer":type(value) is int,"number":type(value) in (int,float),"boolean":type(value) is bool,
            "null":value is None}[name]

def _schema_check(value,schema,root,path="$"):
    if "$ref" in schema:
        parts=schema["$ref"].removeprefix("#/").split("/")
        target=root
        for part in parts:target=target[part]
        return _schema_check(value,target,root,path)
    types=schema.get("type")
    if types:
        options=types if isinstance(types,list) else [types]
        require(any(_is_type(value,t) for t in options),f"{path}: expected {options}, got {type(value).__name__}")
    if "enum" in schema:require(value in schema["enum"],f"{path}: value outside enum")
    if isinstance(value,str):require(len(value)>=schema.get("minLength",0),f"{path}: string too short")
    if isinstance(value,list):
        require(len(value)>=schema.get("minItems",0),f"{path}: too few items")
        if "maxItems" in schema:require(len(value)<=schema["maxItems"],f"{path}: too many items")
        if schema.get("uniqueItems"):
            serialized=[json.dumps(x,sort_keys=True,ensure_ascii=False) for x in value]
            require(len(serialized)==len(set(serialized)),f"{path}: repeated items")
        for i,item in enumerate(value):_schema_check(item,schema.get("items",{}),root,f"{path}[{i}]")
    if isinstance(value,dict):
        require(set(schema.get("required",[])).issubset(value),f"{path}: missing fields {sorted(set(schema.get('required',[]))-set(value))}")
        props=schema.get("properties",{})
        if schema.get("additionalProperties") is False:
            require(set(value).issubset(props),f"{path}: unexpected fields {sorted(set(value)-set(props))}")
        for key,item in value.items():
            if key in props:_schema_check(item,props[key],root,path+"."+key)

def validate_finding_wire(finding):
    schema=read(HERE/"reply-schema.json")
    _schema_check(finding,schema["$defs"]["finding"],schema)
    return finding  # Same object, no conversion.

def validate_wire_reply(reply,request=None):
    schema=read(HERE/"reply-schema.json")
    _schema_check(reply,schema,schema)
    if request is not None:
        require(reply["request_id"]==request["request_id"],"reply request_id mismatch")
        require(reply["input_digest"]==request["input_digest"],"reply input_digest mismatch")
    # Cross-field semantic/source rules remain the unchanged base accept_batches.
    return reply

def _unique_object(pairs):
    obj={}
    for key,value in pairs:
        require(key not in obj,"duplicate JSON object key")
        obj[key]=value
    return obj

def decode_raw_reply(text,*,finish_reason,request=None):
    require(finish_reason=="stop",f"incomplete or unsupported finish_reason={finish_reason!r}; no salvage")
    require(isinstance(text,str),"reply content must be an unmodified text string")
    def invalid_constant(token):raise WireError("non-standard JSON constant: "+token)
    try:
        result=json.loads(text,object_pairs_hook=_unique_object,parse_constant=invalid_constant)
    except json.JSONDecodeError as exc:
        raise WireError(f"invalid/truncated JSON at offset {exc.pos}; no repair") from exc
    return validate_wire_reply(result,request)

def decode_native_provider(provider,*,request=None):
    """Read Root's saved DashScope wrapper, or its native data object. Do not edit content."""
    require(isinstance(provider,dict),"provider response must be an object")
    if "data" in provider:
        require(provider.get("ok") is True and type(provider.get("http_status")) is int
                and 200<=provider["http_status"]<300,"unsuccessful provider HTTP response")
        data=provider["data"]
    else:data=provider
    require(isinstance(data,dict) and isinstance(data.get("output"),dict),"expected native DashScope output")
    choices=data["output"].get("choices")
    require(isinstance(choices,list) and len(choices)==1,"exactly one response choice required")
    choice=choices[0];message=choice.get("message",{})
    require(message.get("role")=="assistant","expected assistant response")
    content=message.get("content")
    require(isinstance(content,list) and len(content)==1 and isinstance(content[0],dict)
            and set(content[0])=={"text"},"expected one native text content block; no implicit concatenation")
    return decode_raw_reply(content[0]["text"],finish_reason=choice.get("finish_reason"),request=request)

def accept_batches(bundle,prepared,replies,*,extraction_context=None,runtime_root=None):
    """Validate model-produced wire data, then pass it unchanged to the original compiler."""
    engine=load_runtime(runtime_root)
    require(isinstance(replies,list),"replies must be a list")
    index={r["request_id"]:r for r in prepared["requests"]}
    for reply in replies:
        require(isinstance(reply,dict),"reply must be an object")
        require(reply.get("request_id") in index,"unknown reply request_id")
        validate_wire_reply(reply,index[reply["request_id"]])
    return engine.accept_batches(bundle,prepared,replies,extraction_context=extraction_context)

def accept_provider_files(bundle,prepared,manifest,*,extraction_context=None,runtime_root=None):
    index={r["request_id"]:r for r in prepared["requests"]}
    rows=manifest.get("responses",[])
    require(isinstance(rows,list),"provider manifest responses must be a list")
    replies=[]
    for row in rows:
        rid=row.get("request_id")
        require(rid in index,"unknown transport request_id")
        provider=read(row["provider_response_path"])
        replies.append(decode_native_provider(provider,request=index[rid]))
    return accept_batches(bundle,prepared,replies,extraction_context=extraction_context,runtime_root=runtime_root)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=["prepare","check-provider","accept-providers"])
    p.add_argument("--runtime-root",default=str(DEFAULT_RUNTIME_ROOT))
    p.add_argument("--bundle");p.add_argument("--prepared");p.add_argument("--provider")
    p.add_argument("--responses-manifest");p.add_argument("--extraction-context")
    p.add_argument("--request-id");p.add_argument("--output",required=True)
    p.add_argument("--max-sources",type=int,default=8);p.add_argument("--max-chars",type=int,default=512000)
    a=p.parse_args()
    try:
        if a.action=="prepare":
            require(a.bundle is not None,"--bundle required")
            result=prepare_requests(read(a.bundle),max_sources=a.max_sources,max_chars=a.max_chars,runtime_root=a.runtime_root)
            result["sidecar"]["bundle_file_sha256"]=sha_bytes(Path(a.bundle).read_bytes())
        elif a.action=="check-provider":
            require(a.prepared and a.provider and a.request_id,"--prepared --provider --request-id required")
            prepared=read(a.prepared)
            request=next((r for r in prepared["requests"] if r["request_id"]==a.request_id),None)
            require(request is not None,"request not present in prepared set")
            decoded=decode_native_provider(read(a.provider),request=request)
            result={"wire_valid":True,"request_id":decoded["request_id"],"input_digest":decoded["input_digest"],
                    "findings_count":len(decoded["findings"]),"dispositions_count":len(decoded["dispositions"]),
                    "note":"Shape check only; original accept_batches and independent semantic review still required."}
        else:
            require(a.bundle and a.prepared and a.responses_manifest,"--bundle --prepared --responses-manifest required")
            result=accept_provider_files(read(a.bundle),read(a.prepared),read(a.responses_manifest),
                extraction_context=read(a.extraction_context) if a.extraction_context else None,runtime_root=a.runtime_root)
        write(a.output,result)
    except (WireError,ValueError,KeyError,TypeError,AttributeError) as exc:
        print(json.dumps({"status":"rejected","error":str(exc),"error_type":type(exc).__name__,"semantic_repairs":0},ensure_ascii=False))
        return 2
    print(json.dumps({"status":"written","path":a.output},ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
