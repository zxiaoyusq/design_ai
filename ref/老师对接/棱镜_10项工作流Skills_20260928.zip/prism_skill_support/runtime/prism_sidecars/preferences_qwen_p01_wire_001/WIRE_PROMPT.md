P01 JSON线协议补充（不改变上面的语义任务）

只输出一个完整JSON对象，不输出Markdown围栏、前后解释、注释或省略号。具体类型见后附JSON Schema。示例占位符不是答案，不得原样输出。

顶层字段：
- request_id：原样复制本请求的绑定值，不使用云服务的request_id。
- input_digest：原样复制本请求的绑定值，不计算或改写。
- findings：对象数组，允许空数组。
- dispositions：对象数组，允许空数组。

每个finding是一个用户的一条原子解释：
- preference_id、level、topic_key、title、summary、attitude均为字符串。preference_id在本回复内唯一。
- level只能为theme、element、image；attitude只能为like、dislike、conditional、neutral、unknown。
- user_ids、evidence_refs、image_ids、conditions是字符串数组，不是单字符串、字典或null。
- user_ids恰好一项，必须等于其evidence_refs对应来源的user_id。只允许使用本包提供的来源。
- evidence_refs可多项，但属于同一用户；不得跨包引用。每项恰好是原始evidence_id，不是user_id、图号或序号。
- quotes必须是对象数组。例如形状为 [{"evidence_id":"<本包的来源ID>","text":"<该来源text中的逐字片段>"}]。不能输出 ["一段引文"]，不能把来源ID当对象键。每一条有文字的引用来源都需要自己的quote对象。
- quote.text必须逐字取自该来源text，不翻译、不改否定、不改条件、不补主语，不把问题当回答。start/end如提供须同时为整数并与原文片段一致；不要求提供它们。
- record_refs如需要，是字符串数组；用于没有文字但有明确图片选择的来源，不代替有文字来源的quotes。
- features必须是对象数组。theme/image的features必须为[]；element至少有一项。每项含parameter_id、value、attribution、evidence_refs。
- feature.value保留相应类型，可以是字符串/数值/布尔/数组/对象，不能为null，不能把字段名连同值塞进一个字符串。不要编造未由原文归因的值。
- feature.attribution仅为explicit_text或pointed_image_feature。feature.evidence_refs必须是当前finding.evidence_refs的子集。
- observation_refs如提供，必须为对象数组，每项形状为 {"image_id":"<已有图片ID>","observation_id":"<该图片的已有观察ID>"}。不能是字符串数组。
- pointed_image_feature必须提供非空observation_refs；引用的DNA观察须为known，字段/值与目标对象或区域相符。整图Like不能自动传播为全部特征Like。不能根据region_id猜另一套object_id，也不能把unknown写成已知。
- explicit_text可以没有图片观察；这种映射仍是语义解释，不代表看过图片或测量了材料。
- image_ids只列原引用来源确实关联的图；image级记录至少一张图。没有关联则[]，不能补图。
- conditions每项都是自然语言字符串，保留接受范围和负向范围。conditional必须有非空conditions；已有recorded_conditions不可丢失。不要输出条件字典，不把条件性排斥改成全局排斥。

dispositions只用于未提取出偏好的来源，每项形状：
{"evidence_id":"<本包来源ID>","reason":"no_preference"}
reason仅限no_preference、unmentioned、ambiguous、non_preference_context。它不是错误兜底或节省输出的手段。

覆盖要求：
- 本包每条来源要么被一个或多个finding引用，要么在dispositions中出现一次。
- 不得同时被引用和跳过，不得为凑数量将一个来源强制变成一条偏好。
- 一段中整体接受而局部排斥可分成不同原子记录，必须各自引用对应原话及对象范围；不为减少输出而合并相反态度。
- 不重复输出整套输入或图片DNA；只输出原子解释所需字段和真实引用。不要为了缩短结果漏记录、截引文、改变条件或生成未知来源归属。
- 不添加reviewed、supported、confirmed_user_support等自我通过标记。独立复核由后续流程完成。

本请求的来源条数已单独限制；输入字数与输出token不是同一概念。仍须输出完整、可解析的JSON。不要假设输出被截断后会由宿主补完。
