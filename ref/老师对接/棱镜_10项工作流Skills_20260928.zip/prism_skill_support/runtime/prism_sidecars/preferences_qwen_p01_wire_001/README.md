# QWEN-P01-WIRE-001：独立分包与线协议 sidecar

版本 qwen-p01-wire-001-v1。此目录是新增路径；不修改 preferences 0.3.1 的engine.py、validation.py、review.py、现有SYSTEM_PROMPT及其他旧文件。

## 范围

1. 原engine.select_users选择来源；每包同时受max_sources（默认8）与max_chars（默认512000）限制。
2. 原engine._request构造原始来源和图片DNA，原fingerprint不变。只在生成的新请求system文本后附加本目录WIRE_PROMPT与reply-schema，写清嵌套类型和绑定值。
3. 原用户payload逐字节保留。没有裁剪原话、图片DNA观察或单条来源；单条连同完整现有上下文仍超限时明确报错。
4. 新Qwen原始回复先检查finish_reason、JSON完整性与线协议，再原样交给原engine.accept_batches。不存在语义修补器。

本sidecar没有网络客户端，不执行模型调用，不填Like/Dislike，不修条件，不给引文补来源ID，不把失败来源改成disposition。Qwen3.8 Flash仍是Root唯一执行的语义模型；实际调用身份和参数由Root原CLI留痕。

## 准备新小包

从工程根目录运行：

    python -B prism_sidecars/preferences_qwen_p01_wire_001/p01_wire.py prepare --bundle INPUT_BUNDLE.json --max-sources 8 --max-chars 512000 --output NEW_STAGE/prepared.json

如需使用另一份冻结runtime根目录，可加--runtime-root DIRECTORY，该目录须包含prism_runtime/preferences/engine.py。请使用新Python进程；若进程已经导入另一份runtime，sidecar会拒绝混用。

输出保留原prism.preference_requests.v0.1结构、原source/input_digest，另附sidecar版本、源码／原提示／补充提示／schema／输入文件哈希。message_chars包含追加协议，不是token数量。

当前132条实际输入的离线产物：

D:/Codex/传音AI创客营/outputs/prism-algorithm-loop-20260926/modules/preferences/sidecars/QWEN-P01-WIRE-001/prepared-132.json

该产物不是回答，只有17个Qwen请求。Root可以直接读取requests[*].messages并使用原消息运输方式；每个request_id已为preference-wire001-NNN，模型必须原样返回该ID和对应digest。

## Root接入

- 为这批新请求使用新的stage/调用目录，例如P01-wire001；不要覆盖或复用原P01失败call路径和回包。
- 不剥除本sidecar追加的system协议，也不要在运输层重新按更大来源数组合包。
- 模型每条回复顶层需要request_id、input_digest、findings、dispositions。完整类型见reply-schema.json。
- quotes必须是evidence_id/text对象数组；observation_refs必须是image_id/observation_id对象数组；conditions是字符串数组。输入中没有的来源归属不能由宿主补。
- 不将provider自身request_id误当P01的逻辑request_id。
- 原始provider-response.json与output.txt完整留存。finish_reason=length一律不挽救，即使局部JSON看起来可读。
- 本schema以提示和客户端校验形式使用；未宣称Qwen服务原生强制执行JSON Schema，也未修改Root provider API参数。

单包只读检查（支持Root保存的DashScope包裹结构，以及其原生data对象）：

    python -B prism_sidecars/preferences_qwen_p01_wire_001/p01_wire.py check-provider --prepared NEW_STAGE/prepared.json --provider CALL/provider-response.json --request-id preference-wire001-001 --output CHECK.json

全部模型返回后建立运输清单。每项只记录逻辑请求ID与已保存provider回包位置，不填语义答案：

    {"responses":[{"request_id":"preference-wire001-001","provider_response_path":"ABSOLUTE_CALL_PATH/provider-response.json"}]}

实际清单必须覆盖全部请求。然后：

    python -B prism_sidecars/preferences_qwen_p01_wire_001/p01_wire.py accept-providers --bundle INPUT_BUNDLE.json --prepared NEW_STAGE/prepared.json --responses-manifest REPLIES_MANIFEST.json --extraction-context TRUSTED_EXTRACTION_CONTEXT.json --output PROFILE.json

该入口不转换引文，不翻译或改正文，不为回复补ID或digest。原accept_batches已有的批次命名空间行为保留。原编译器的source/quote/条件/对象范围检查继续执行。

调用方仍须检查PROFILE的status和coverage。原编译器可以返回partial；partial不能当132条语义处理完成，也不能跳过独立语义复核。

## 验证与限制

    python -B -m unittest discover -s prism_sidecars/preferences_qwen_p01_wire_001 -p test_wire.py -v

18项有限离线检查使用原先已有的合成开发夹具，测试代码没有为本次132条运行输入生成任何偏好答案。实际132条只验证重新分包、来源唯一覆盖、指纹、原user payload及DNA未改。

当前实际结果：17包＝16×8＋4，最大245918字符，总消息1125173字符。每条来源恰好分配一次；同图在不同必要包里可再次作为上下文出现，但来源记录不重复。

输入字符预算和输出token风险分别控制。8条/包只降低截断风险，不保证Qwen输出一定完整或语义正确；不能通过限制每条只生成一项偏好来删掉原意。

原首次回包仍以finish_reason=length拒绝；其完整首条finding的字符串quotes仍被线协议及未改动的原编译器拒绝。诊断片段只用于拒绝测试，不拼装成可用profile。

当前自评：离线分包、类型协议与原代码保护范围合格；新Qwen小包实跑、全覆盖接收与语义质量未验证。新增API调用0。Root负责下一轮真实Qwen执行。
