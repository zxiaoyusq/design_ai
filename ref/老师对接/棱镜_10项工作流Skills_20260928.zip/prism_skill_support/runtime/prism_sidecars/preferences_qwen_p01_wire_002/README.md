# QWEN-P01-WIRE-001 · cycle2 / v2

仅新增本目录。preferences0.3.1、v1 sidecar、旧提示、全部17包实测请求/回复保持不变。没有网络客户端或自动模型调用。

## 本轮范围

原17包中，原compiler可接受11包、84来源；6包、48来源失败。本轮只为004、008、010、013、014、016建立新的请求，不重跑其余11包。

原失败仍成立：

- 004／010：pointed用户目标与DNA载体不匹配。
- 008／014：模型引文不是原文逐字子串。
- 013／016：quotes=[{}]，真实缺少来源与原文，不是一个可解包的字符串格式问题。

## 新协议：按模型明确选择的来源ID展开完整文本

新请求/新回复必须声明citation_protocol=prism.p01.full-source-citations.v2，并使用新的request_id。

Qwen仍自行选择evidence_refs以及所有语义字段：用户、态度、摘要、条件、层级、特征值、归因与dispositions。新wire不再让模型输出quotes或record_refs。

适配器只按Qwen明确给出的合法evidence_id读取完整原始record.text，生成derived quotes。没有文字的合法选择记录生成derived record_refs。引用展开不找相似句，不裁剪、不翻译、不补用户或来源、不改任何语义字段。

旧响应缺少这个新协议、ID与实际新请求绑定，仍会拒绝。不能删除旧quotes、加一个协议标记后追认旧响应；公共入口还会逐字比对实际保存的provider request消息。

记录包含：

- 原始请求/响应文件位置及SHA256，真实模型、参数、finish_reason、服务请求ID和usage（有值时）。
- raw_quote_field明确标为未由模型输出；derived_quote_field保留完整原文。
- 模型选择的原始evidence_refs、每条source record/text摘要。
- 语义字段展开前/后摘要及相等检查。
- 引文来自确定性检索、不代表模型抄录准确率，也不代表语义已获支持。

原compiler仍负责来源、归属、态度、图像、对象、条件等校验。完整覆盖另外检查，缺项不填补。独立语义复核仍然必须执行。

## Pointed能力不再含糊

本批48来源都有source_image_annotation，但没有已登记的target_object_id或target_region_ref。它们的注释不是DNA观察ID或原生目标绑定。

每个新请求包含source_capabilities，直接按原validator和原有登记计算。48条的pointed能力均为false（40条region、8条mixed）。不根据region_id、region_name或近似框推测object_id。

新Qwen需自行选择有效归因：有充分文字依据才可explicit_text；否则保持较合适层级或明确歧义。适配器绝不会把返回的pointed改成explicit_text。模型若仍选择无效pointed，原compiler照常拒绝。

## 提示词版本

新sidecar生成独立的system副本，仅对原提示中“模型复制quotes”的三处机械输出措辞作精确、显式版本替换，保留“题干不能作回答”等原语义约束，再附上新wire/schema和能力表。旧SYSTEM_PROMPT常量和文件未改。

这样不会同时要求模型“复制quotes”和“不输出quotes”。原基线措辞如发生变化，sidecar会报错，不静默做宽泛替换。

## 准备与实际调用

    python -B prism_sidecars/preferences_qwen_p01_wire_002/p01_wire_v2.py prepare-retry --bundle INPUT_V2.json --previous-prepared P01_WIRE001/prepared.json --audit P01_WIRE001/independent-each-request-check.json --dispatch QWEN-P01-WIRE-001-cycle2.json --output NEW_STAGE/retry-plan.json

retry-plan.requests只有6项，Root只调用这6项的messages，模型仍为Qwen3.8 Flash。放在新的stage/call目录，保存原始request.json与provider-response.json。

retry-plan.merge_prepared有17项，其中11项原请求保持原样，6项替换为新的preference-wire002-from-NNN请求。全局132来源仍一次覆盖。

实际已准备的计划：

D:/Codex/传音AI创客营/outputs/prism-algorithm-loop-20260926/modules/preferences/sidecars/QWEN-P01-WIRE-001-cycle2/retry-plan.json

### 单包验证

    python -B prism_sidecars/preferences_qwen_p01_wire_002/p01_wire_v2.py accept-one --bundle INPUT_V2.json --plan NEW_STAGE/retry-plan.json --request-id preference-wire002-from-004 --provider-request NEW_CALL/request.json --provider-response NEW_CALL/provider-response.json --extraction-context TRUSTED_CONTEXT.json --output NEW_CALL/accepted.json

输出分开保存derived_reply、citation_receipt和原compiler profile。原始Qwen回复文件不被改动。

实际request的model必须为qwen3.8-flash；input.messages必须与计划完全一致。actual request/reply文件属于可信调用方日志，本模块不声称对其做密码学身份认证。

### 复用11包后合并

将reuse-11-provider-manifest.json的11项与6个新调用记录合并成responses清单。每项字段：

    {"request_id":"逻辑请求ID","provider_request_path":"原始实际请求文件","provider_response_path":"原始实际回复文件"}

    python -B prism_sidecars/preferences_qwen_p01_wire_002/p01_wire_v2.py accept-mixed --bundle INPUT_V2.json --plan NEW_STAGE/retry-plan.json --responses-manifest ALL17.json --extraction-context TRUSTED_CONTEXT.json --output NEW_STAGE/merged.json

v1的11包保持原始引文；v2的6包明确走新引用展开。逐包原compiler通过且完整覆盖后，才调用原accept_batches合并。输出的citation_receipts保留两种引用来源的差别，不能把程序展开报告成Qwen逐字引用准确率提升。

任何新包继续失败时，保留原始调用并回报，不凭宿主改字段来合并。

## 离线自评

    python -B -m unittest discover -s prism_sidecars/preferences_qwen_p01_wire_002 -p test_wire_v2.py -v

17项有限测试通过：只重试失败范围、未知/空/跨包引用、错用户、无效pointed、旧调用冒充v2、完整否定/条件保存、原compiler条件约束、混合复用、缺包和截断拒绝。测试仅使用已有合成开发夹具，不为当前48来源写答案。

实际数据离线检查：6×8=48待新调用，11包84来源复用；合计132一次覆盖。6个原失败逐一仍拒绝，11个旧有效原回复通过读取/原compiler检查且内容未改。93份受保护文件哈希一致。

整体partial：离线协议与数据保护范围合格；新6包Qwen结果、全量接收与语义效果未验证。新增API调用0，不恢复计时器。
