"""Offline check of exact six retry scopes, reused native replies, and frozen artifacts."""
from pathlib import Path
from collections import Counter
from copy import deepcopy
import argparse
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import p01_wire_v2 as v2

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--bundle",required=True);p.add_argument("--plan",required=True);p.add_argument("--old-stage",required=True)
    p.add_argument("--protected-before",required=True);p.add_argument("--output",required=True)
    a=p.parse_args()
    bundle=v2.read(a.bundle);plan=v2.read(a.plan);old_stage=Path(a.old_stage)
    old=v2.read(old_stage/"prepared.json");runtime=v2.v1.load_runtime()
    by_old={r["request_id"]:r for r in old["requests"]}
    selected=runtime.select_users(bundle)
    flat=[x for r in plan["merge_prepared"]["requests"] for x in r["evidence_ids"]]
    assert flat==selected["eligible_evidence_ids"] and len(flat)==len(set(flat))==132
    retry_ids=[x for r in plan["requests"] for x in r["evidence_ids"]]
    reuse_ids=[x for rid in plan["reused_request_ids"] for x in by_old[rid]["evidence_ids"]]
    assert len(retry_ids)==len(set(retry_ids))==48 and len(reuse_ids)==84 and not set(retry_ids)&set(reuse_ids)
    requests=[]
    for r in plan["requests"]:
        prior=by_old[r["parent_request_id"]]
        baseline=runtime._request(bundle,selected,r["evidence_ids"])
        assert r["evidence_ids"]==prior["evidence_ids"]
        assert r["input_digest"]==prior["input_digest"]==baseline["input_digest"]
        assert r["messages"][1]==baseline["messages"][1],"source or DNA payload changed"
        caps=r["source_capabilities"]
        assert len(caps)==8 and all(not c["pointed_image_feature_available"] for c in caps)
        assert all(c["source_image_annotation_present"] and c["registered_target_object_id"] is None
                   and c["registered_target_region_ref"] is None for c in caps)
        requests.append({"request_id":r["request_id"],"parent_request_id":r["parent_request_id"],"source_count":len(r["evidence_ids"]),
                         "input_digest":r["input_digest"],"message_chars":r["message_chars"],
                         "messages_sha256":v2.digest(r["messages"]),"pointed_capable_source_count":0,
                         "target_scope_counts":dict(Counter(c["target_scope"] for c in caps))})
    reuse_entries=[];reuse_checks=[]
    for rid in plan["reused_request_ids"]:
        req=by_old[rid]
        merged=next(r for r in plan["merge_prepared"]["requests"] if r["request_id"]==rid)
        assert req==merged,"accepted request changed"
        call=old_stage/"requests"/rid/"calls"/rid
        entry={"request_id":rid,"provider_request_path":str(call/"request.json"),
               "provider_response_path":str(call/"provider-response.json")}
        parsed,receipt=v2.validate_actual_call(req,entry)
        original=deepcopy(parsed)
        accepted=v2.accept_one(bundle,req,entry)
        assert accepted["derived_reply"]==original and accepted["profile"]["coverage"]["status"]=="complete"
        reuse_entries.append(entry)
        reuse_checks.append({"request_id":rid,"sources":len(req["evidence_ids"]),"raw_reply_unchanged":True,
                             "native_compiler_status":accepted["profile"]["status"],"call_receipt":receipt})
    old_rejections=[]
    for r in plan["requests"]:
        rid=r["parent_request_id"];prior=by_old[rid];call=old_stage/"requests"/rid/"calls"/rid
        raw,_,_=v2.raw_provider(v2.read(call/"provider-response.json"))
        checks={}
        for name,fn in [
            ("v1_original_rejection",lambda raw=raw,prior=prior,call=call:
                v2.accept_one(bundle,prior,{"provider_request_path":str(call/"request.json"),
                                         "provider_response_path":str(call/"provider-response.json")})),
            ("cannot_adopt_old_reply_as_v2",lambda raw=raw,r=r:v2.validate_reply(raw,r)),
            ("cannot_adopt_old_call_as_v2",lambda r=r,call=call:v2.validate_actual_call(r,{
                "provider_request_path":str(call/"request.json"),"provider_response_path":str(call/"provider-response.json")})),
        ]:
            try:fn()
            except (ValueError,KeyError,TypeError,AttributeError) as exc:
                checks[name]={"rejected":True,"type":type(exc).__name__,"reason":str(exc)}
            else:raise AssertionError(name+" unexpectedly passed")
        old_rejections.append({"request_id":rid,"checks":checks})
    frozen=v2.read(a.protected_before);protected=[]
    for row in frozen["files"]:
        actual=v2.v1.sha_bytes(Path(row["path"]).read_bytes())
        protected.append({**row,"after_sha256":actual,"unchanged":actual==row["sha256"]})
    assert all(r["unchanged"] for r in protected),"frozen code or actual old reply changed"
    out=Path(a.output)
    v2.write(out.parent/"reuse-11-provider-manifest.json",{"responses":reuse_entries,
        "scope":"These are old actual Qwen replies, not new model calls; append the6 fresh provider records for final merge."})
    result={"issue_id":"QWEN-P01-WIRE-001","repair_cycle":2,"new_sidecar_version":v2.VERSION,
            "offline_scope_qualified":True,"fresh_qwen_retest_performed":False,"semantic_effect_qualified":False,
            "retry_source_count":48,"reuse_source_count":84,"total_merge_sources_once":132,
            "new_requests":requests,"reused_native_replies":reuse_checks,"old_failed_replies_remain_failed":old_rejections,
            "all48_sources_pointed_capability_unavailable":True,
            "max_message_chars":max(r["message_chars"] for r in plan["requests"]),
            "protected_files":protected,"new_api_calls":0,"actual48_answers_authored_by_host":0,
            "citation_expansion_does_not_establish_semantic_support":True,
            "input_bundle_sha256":v2.v1.sha_bytes(Path(a.bundle).read_bytes()),
            "retry_plan_sha256":v2.v1.sha_bytes(Path(a.plan).read_bytes())}
    v2.write(out,result)
    print(json.dumps({k:result[k] for k in ["retry_source_count","reuse_source_count","total_merge_sources_once","max_message_chars","fresh_qwen_retest_performed"]},ensure_ascii=False))

if __name__=="__main__":main()
