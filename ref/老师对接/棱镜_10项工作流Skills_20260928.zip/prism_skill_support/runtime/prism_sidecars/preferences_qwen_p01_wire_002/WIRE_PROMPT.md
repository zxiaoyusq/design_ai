本次是新的 P01 引用协议 prism.p01.full-source-citations.v2，仅适用于本次新请求和新调用。

语义提取、用户范围、态度、条件、对象和特征规则全部保留；原协议“由模型复制quotes”的机械工作在本协议中明确改由确定性适配器完成。

模型必须独立完成：
1. 选择每个finding的合法evidence_refs；不能空、不能猜、不能跨包。
2. 自己给出user_ids、level、topic_key、title、summary、attitude、conditions、image_ids、features及全部特征值/归因。
3. 区分整体喜爱、局部否定、条件接受和未知；来源中相反态度不能为凑格式而合并。
4. 选择dispositions：只有确实没有可提偏好/未提及/歧义/非偏好语境才跳过，不能用来省输出。

模型不要输出quotes或record_refs字段。也不要输出引用片段、字符位置或自填引用对象。
你明确选择evidence_refs后，适配器只会逐ID读取该record完整原始text，形成derived quotes。
它不会替你挑来源，不做近似匹配，不修态度、摘要、条件、特征或user_ids。
原文所有否定和上下文都会保留，所以你选择的来源必须真正支持你的原子解释。
没有文字的合法选择记录只形成derived record_refs。
引用展开仅证明取回了选定记录，不表示语义已被支持；还须原compiler检查和独立语义复核。

完整输出仍为一个JSON对象，顶层：
- citation_protocol：严格复制本请求指定的协议值。
- request_id、input_digest：严格复制绑定值。
- findings：对象数组。
- dispositions：对象数组。
不得输出Markdown围栏、解释前后缀、reviewed或自我通过标记。

finding中的user_ids必须是单元素字符串数组，等于所选来源的真实user_id。
evidence_refs是非空、唯一的字符串数组，所有来源属于同一用户且都在本包。
conditions是字符串数组，conditional不得为空；已有来源条件不能丢失。
theme/image的features为[]；image必须有真正关联的image_ids。
element的features非空，每项含parameter_id、value、attribution、evidence_refs。
value保持真实类型，不编造字段值；feature.evidence_refs必须是finding引用来源的子集。
observation_refs如提供，仍必须为image_id/observation_id对象数组。

归因能力：
- 随请求给出的source_capabilities是根据原有数据和原validator计算的机械可用性，不是偏好答案。
- source_image_annotation只是原研究资料对刺激图的注释；不是DNA observation_id，也不是已登记的DNA target。
- pointed_image_feature只有在你所选来源确实具备可用pointed绑定、且引用的known观察/字段/值匹配时才成立。
- 不得根据region_id、region_name、近似bbox或图片相似性猜target_object_id/target_region_ref。
- pointed能力缺失时，不得输出pointed_image_feature。
- 可以由你重新判断是否有充分文字依据选择explicit_text；这不是格式退路。文字也不充分时应保留theme/image层级或明确歧义，不能造出字段值来过检查。
- 宿主不会把你返回的pointed改为explicit_text，也不会制造任何目标绑定。

本包每条来源必须被至少一个finding使用，或出现在dispositions中一次，不得两者兼有。
同一来源可以因不同对象/态度/条件拆出多个finding；不要为减少输出而丢失局部否定。
所有嵌套字段的精确类型以附带schema为准。旧v1的空引文/坏引文不是本协议回复，不能追认。
