"""Cycle2: fresh exact-ID citation protocol; no semantic repair, no provider calls."""
from __future__ import annotations
from copy import deepcopy
import argparse
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location("prism_p01_wire_v1_readonly",HERE.parent/"preferences_qwen_p01_wire_001/p01_wire.py")
v1=importlib.util.module_from_spec(spec);spec.loader.exec_module(v1)
WireError=v1.WireError
require=v1.require
read=v1.read
write=v1.write
VERSION="qwen-p01-wire-001-v2"
CITATION_PROTOCOL="prism.p01.full-source-citations.v2"

def render_v2_base_prompt(original):
    """Change only citation-output wording in a new in-memory prompt, never the old constant/file."""
    replacements=[
        ("每条含preference_id,level,topic_key,title,summary,attitude,user_ids,evidence_refs,quotes,image_ids,features,conditions。",
         "每条含preference_id,level,topic_key,title,summary,attitude,user_ids,evidence_refs,image_ids,features,conditions。"),
        ("quotes逐字摘取回答，不能把题干当回答；无文字的明确选图记录使用record_refs，保留image级态度。",
         "由模型选择引用的evidence_refs，不能把题干当回答；无文字的明确选图记录保留image级态度，引用由适配器按所选来源ID展开。"),
        ("返回JSON对象findings和dispositions，并复制请求input_digest。",
         "返回citation_protocol、request_id、input_digest、findings和dispositions；不要输出quotes或record_refs。"),
    ]
    result=original
    for before,after in replacements:
        require(result.count(before)==1,"base citation wording changed; review this new prompt revision explicitly")
        result=result.replace(before,after,1)
    return result

def digest(value):
    return v1.sha_bytes(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8"))

def source_capabilities(bundle,ids,runtime):
    evidence={e["evidence_id"]:e for e in bundle["evidence"]}
    images={im["image_id"]:im for im in bundle["images"]}
    result=[]
    for eid in ids:
        e=evidence[eid];iid=e.get("image_id")
        eligible=[]
        has_target=e.get("target_object_id") not in {None,"","unknown"} or e.get("target_region_ref") is not None
        if e.get("target_scope") in {"object","region"} and has_target and iid in images:
            for o in images[iid].get("observations",[]):
                if o.get("value_status")!="known" or o.get("value") is None:continue
                probe={"parameter_id":o["parameter_id"],"value":o["value"],"attribution":"pointed_image_feature",
                       "evidence_refs":[eid],"observation_refs":[{"image_id":iid,"observation_id":o["observation_id"]}]}
                try:runtime.validate_feature(probe,[eid],[e],images)
                except (ValueError,KeyError,TypeError,AttributeError):continue
                eligible.append({"image_id":iid,"observation_id":o["observation_id"],"object_id":o["object_id"],
                                 "parameter_id":o["parameter_id"],"value":o["value"],"region_ref":o["region_ref"]})
        result.append({
            "evidence_id":eid,"user_id":e["user_id"],"image_id":iid,
            "target_scope":e.get("target_scope"),"registered_target_object_id":e.get("target_object_id"),
            "registered_target_region_ref":e.get("target_region_ref"),
            "source_image_annotation_present":"source_image_annotation" in e,
            "source_image_annotation_is_DNA_binding":False,
            "pointed_image_feature_available":bool(eligible),"eligible_pointed_observations":eligible,
            "explicit_text_mechanically_eligible_for_this_source":bool(e.get("text","").strip())
                and e.get("evidence_role","unclassified")!="selection_record" and e.get("target_scope")!="image",
            "semantic_support_inferred":False,
            "capability_note":"Only existing registered targets are evaluated. No annotation-to-target matching or new binding is created.",
        })
    return result

def prepare_retry(bundle,previous,audit,retry_request_ids,*,max_chars=512000,runtime_root=None):
    runtime=v1.load_runtime(runtime_root)
    require(type(max_chars) is int and max_chars>=4000,"max_chars must be >=4000")
    old={r["request_id"]:r for r in previous["requests"]}
    checks={r["request_id"]:r for r in audit["checks"]}
    require(len(old)==len(previous["requests"]) and set(old)==set(checks),"audited scope must match original request set")
    rejected={rid for rid,r in checks.items() if r.get("native_accept") is not True}
    require(len(retry_request_ids)==len(set(retry_request_ids)) and set(retry_request_ids)==rejected,
            "retry must include exactly the failed scopes; do not rerun accepted scopes or omit failures")
    selected=runtime.select_users(bundle)
    ids=selected["eligible_evidence_ids"]
    require(previous["input_digest"]==runtime.fingerprint(bundle,selected["selected_user_ids"],ids),"input source version differs from original")
    require([eid for r in previous["requests"] for eid in r["evidence_ids"]]==ids,"old input coverage/order differs")
    wire=(HERE/"WIRE_PROMPT.md").read_text(encoding="utf-8")
    schema=json.dumps(read(HERE/"reply-schema.json"),ensure_ascii=False,separators=(",",":"))
    new=[];merged=deepcopy(previous);new_by_old={}
    for rid in retry_request_ids:
        prior=old[rid]
        require(len(prior["evidence_ids"])==checks[rid]["source_count"],"audit source count mismatch")
        req=runtime._request(bundle,selected,prior["evidence_ids"])
        require(req["input_digest"]==prior["input_digest"],"source fingerprint mismatch")
        new_id="preference-wire002-from-"+rid.rsplit("-",1)[-1]
        caps=source_capabilities(bundle,prior["evidence_ids"],runtime)
        req.update({"request_id":new_id,"parent_request_id":rid,"wire_protocol":VERSION,
                    "citation_protocol":CITATION_PROTOCOL,"source_capabilities":caps})
        binding={"citation_protocol":CITATION_PROTOCOL,"request_id":new_id,"input_digest":req["input_digest"]}
        req["messages"][0]["content"]=render_v2_base_prompt(runtime.SYSTEM_PROMPT)+"\n\n"+wire+"\n绑定值："+json.dumps(binding,ensure_ascii=False,separators=(",",":"))+"\n实际来源归因能力："+json.dumps(caps,ensure_ascii=False,separators=(",",":"))+"\nJSON Schema："+schema
        req["message_chars"]=sum(len(m["content"]) for m in req["messages"])
        require(req["message_chars"]<=max_chars,"complete retry source/DNA/capabilities exceed character cap; no truncation")
        require(len(req["evidence_ids"])<=8,"retry unexpectedly exceeds the original8-source cap")
        new.append(req);new_by_old[rid]=req
    merged["requests"]=[deepcopy(new_by_old.get(r["request_id"],r)) for r in previous["requests"]]
    return {
        "schema_version":"prism.preference_retry_plan.v1","version":VERSION,"citation_protocol":CITATION_PROTOCOL,
        "input_digest":previous["input_digest"],"requests":new,
        "reused_request_ids":[r["request_id"] for r in previous["requests"] if r["request_id"] not in rejected],
        "replaced_request_ids":retry_request_ids,"merge_prepared":merged,
        "old_prepared_content_sha256":digest(previous),"bundle_content_sha256":digest(bundle),
        "metadata":{"base_engine_path":str(Path(runtime.__file__).resolve()),
                    "base_engine_sha256":v1.sha_bytes(Path(runtime.__file__).read_bytes()),
                    "base_SYSTEM_PROMPT_sha256":v1.sha_bytes(runtime.SYSTEM_PROMPT.encode()),
                    "new_v2_base_prompt_sha256":v1.sha_bytes(render_v2_base_prompt(runtime.SYSTEM_PROMPT).encode()),
                    "citation_only_prompt_wording_revision":True,
                    "wire_prompt_sha256":v1.sha_bytes((HERE/"WIRE_PROMPT.md").read_bytes()),
                    "schema_sha256":v1.sha_bytes((HERE/"reply-schema.json").read_bytes()),
                    "max_message_chars":max_chars,"max_sources_per_retry":8,"owner_new_api_calls":0,
                    "semantic_fields_authored_or_repaired":False,"source_text_or_DNA_truncated":False},
    }

def validate_reply(reply,request):
    schema=read(HERE/"reply-schema.json")
    v1._schema_check(reply,schema,schema)
    require(reply["citation_protocol"]==request.get("citation_protocol")==CITATION_PROTOCOL,"new citation protocol required")
    require(request.get("wire_protocol")==VERSION,"not a fresh v2 prepared request")
    require(reply["request_id"]==request["request_id"],"request identity mismatch")
    require(reply["input_digest"]==request["input_digest"],"source digest mismatch")
    return reply

def raw_provider(provider):
    require(isinstance(provider,dict),"provider response must be an object")
    require(provider.get("ok") is True and type(provider.get("http_status")) is int
            and 200<=provider["http_status"]<300,"successful saved Root provider wrapper required")
    data=provider.get("data",{})
    choices=data.get("output",{}).get("choices")
    require(isinstance(choices,list) and len(choices)==1,"one native choice required")
    choice=choices[0]
    require(choice.get("finish_reason")=="stop","incomplete/truncated response remains rejected")
    message=choice.get("message",{})
    require(message.get("role")=="assistant","assistant role required")
    content=message.get("content")
    require(isinstance(content,list) and len(content)==1 and isinstance(content[0],dict)
            and set(content[0])=={"text"} and isinstance(content[0]["text"],str),"one unmodified native text block required")
    text=content[0]["text"]
    def invalid_constant(token):raise WireError("nonstandard JSON constant: "+token)
    try:reply=json.loads(text,object_pairs_hook=v1._unique_object,parse_constant=invalid_constant)
    except json.JSONDecodeError as exc:raise WireError("invalid JSON; no repair") from exc
    return reply,text,data.get("request_id")

def validate_actual_call(request,entry):
    """Literal binding to actual saved request/reply artifacts; not cryptographic authentication."""
    request_path=Path(entry["provider_request_path"])
    response_path=Path(entry["provider_response_path"])
    native=read(request_path);provider=read(response_path)
    require(native.get("model")==v1.MODEL,"actual request model must remain qwen3.8-flash")
    expected=[{"role":m["role"],"content":[{"text":m["content"]}]} for m in request["messages"]]
    require(native.get("input",{}).get("messages")==expected,"actual call does not match fresh planned messages")
    reply,text,provider_id=raw_provider(provider)
    receipt={
        "logical_request_id":request["request_id"],"input_digest":request["input_digest"],
        "planned_messages_sha256":digest(request["messages"]),
        "actual_request_path":str(request_path.resolve()),"actual_request_sha256":v1.sha_bytes(request_path.read_bytes()),
        "actual_response_path":str(response_path.resolve()),"actual_response_sha256":v1.sha_bytes(response_path.read_bytes()),
        "raw_model_text_sha256":v1.sha_bytes(text.encode("utf-8")),"raw_reply_sha256":digest(reply),
        "provider_request_id":provider_id,"actual_model":native["model"],"actual_parameters":native.get("parameters",{}),
        "http_status":provider["http_status"],"provider_request_seconds":provider.get("provider_request_seconds"),
        "usage":deepcopy(provider.get("data",{}).get("usage")),
        "finish_reason":"stop","artifact_assurance":"trusted caller saved actual-call records; no cryptographic provenance claim",
    }
    return reply,receipt

def _materialize(bundle,request,reply,call_receipt):
    """Explicit new-protocol operation; not a repair function for v1 model quotes."""
    validate_reply(reply,request)
    require(call_receipt.get("logical_request_id")==request["request_id"]
            and call_receipt.get("raw_reply_sha256")==digest(reply),"validated actual-call receipt required")
    evidence={e["evidence_id"]:e for e in bundle["evidence"]}
    allowed=set(request["evidence_ids"])
    derived={k:deepcopy(v) for k,v in reply.items() if k!="citation_protocol"}
    audit=[]
    for raw,f in zip(reply["findings"],derived["findings"]):
        refs=raw["evidence_refs"]
        require(refs and len(refs)==len(set(refs)) and set(refs).issubset(allowed),"empty/unknown/cross-request evidence refs rejected")
        rows=[evidence[r] for r in refs]
        require(all(e.get("source_kind")=="research" for e in rows),"only selected research sources may be cited")
        owners=sorted({e.get("user_id") for e in rows})
        require(len(owners)==1 and raw["user_ids"]==owners,"model user attribution differs from explicitly selected records")
        for feature in raw["features"]:
            require(set(feature["evidence_refs"]).issubset(refs),"feature sources outside finding")
        quotes=[];record_refs=[];source_proofs=[]
        for row in rows:
            text=row.get("text","")
            require(isinstance(text,str),"original text must already be a string")
            if text.strip():quotes.append({"evidence_id":row["evidence_id"],"text":text})
            else:
                require(row.get("evidence_role")=="selection_record","empty non-selection source cannot be quoted")
                record_refs.append(row["evidence_id"])
            source_proofs.append({"evidence_id":row["evidence_id"],"source_record_sha256":digest(row),
                                  "source_text_sha256":v1.sha_bytes(text.encode("utf-8")),"source_text_chars":len(text)})
        f["quotes"]=quotes;f["record_refs"]=record_refs
        remaining={k:v for k,v in f.items() if k not in {"quotes","record_refs"}}
        require(remaining==raw,"semantic fields changed during citation materialization")
        audit.append({"preference_id":raw["preference_id"],"model_selected_evidence_refs":deepcopy(refs),
                      "raw_quote_field":{"present":False,"value":None},
                      "raw_record_refs_field":{"present":False,"value":None},
                      "derived_quote_field":deepcopy(quotes),"derived_record_refs_field":record_refs,
                      "raw_semantic_sha256":digest(raw),"derived_semantic_sha256":digest(remaining),
                      "semantic_fields_unchanged":True,"source_proofs":source_proofs})
    return derived,{
        "citation_protocol":CITATION_PROTOCOL,"call":call_receipt,"items":audit,
        "raw_reply_sha256":digest(reply),"derived_reply_sha256":digest(derived),
        "derivation":"full original record.text via model-selected exact evidence_id; no quote search, substring choice or paraphrase",
        "quote_text_was_model_transcribed":False,"semantic_support_verified":False,
        "old_v1_responses_reclassified":False,
    }

def accept_one(bundle,request,entry,*,runtime_root=None,extraction_context=None):
    runtime=v1.load_runtime(runtime_root)
    selected=runtime.select_users(bundle)
    require(request["input_digest"]==runtime.fingerprint(bundle,selected["selected_user_ids"],request["evidence_ids"]),"stale source snapshot")
    raw,call=validate_actual_call(request,entry)
    if request.get("wire_protocol")==VERSION:
        derived,citations=_materialize(bundle,request,raw,call)
    else:
        v1.validate_wire_reply(raw,request)
        derived=raw
        citations={"citation_protocol":"unchanged_v1_model_quotes","call":call,
                   "raw_reply_sha256":digest(raw),"derived_reply_sha256":digest(raw),"semantic_fields_unchanged":True}
    subset=deepcopy(bundle)
    subset["evidence"]=[e for e in bundle["evidence"] if e["evidence_id"] in request["evidence_ids"]]
    profile=runtime.compile_preferences(subset,derived,require_input_digest=True,extraction_context=extraction_context)
    require(profile["coverage"]["status"]=="complete","new model output did not cover its whole source scope; no filling")
    return {"derived_reply":derived,"citation_receipt":citations,"profile":profile}

def accept_mixed(bundle,plan,manifest,*,runtime_root=None,extraction_context=None):
    runtime=v1.load_runtime(runtime_root)
    require(plan.get("version")==VERSION and plan.get("bundle_content_sha256")==digest(bundle),"retry plan/input mismatch")
    prepared=plan["merge_prepared"]
    entries=manifest.get("responses",[])
    require(isinstance(entries,list),"responses manifest must contain a list")
    byid={r["request_id"]:r for r in entries}
    require(len(byid)==len(entries) and set(byid)=={r["request_id"] for r in prepared["requests"]},
            "all11 reused and6 fresh responses must be present once; no partial merge")
    replies=[];receipts=[]
    for request in prepared["requests"]:
        accepted=accept_one(bundle,request,byid[request["request_id"]],runtime_root=runtime_root,extraction_context=extraction_context)
        replies.append(accepted["derived_reply"]);receipts.append(accepted["citation_receipt"])
    profile=runtime.accept_batches(bundle,prepared,replies,extraction_context=extraction_context)
    require(profile["coverage"]["status"]=="complete","merged source coverage incomplete")
    return {"profile":profile,"derived_replies":replies,"citation_receipts":receipts,
            "new_protocol_requests":[r["request_id"] for r in plan["requests"]],
            "reused_v1_requests":plan["reused_request_ids"],
            "semantic_support_verified":False}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=["prepare-retry","accept-one","accept-mixed"])
    p.add_argument("--bundle",required=True);p.add_argument("--previous-prepared");p.add_argument("--audit");p.add_argument("--dispatch")
    p.add_argument("--plan");p.add_argument("--request-id");p.add_argument("--provider-request");p.add_argument("--provider-response")
    p.add_argument("--responses-manifest");p.add_argument("--extraction-context");p.add_argument("--runtime-root")
    p.add_argument("--max-chars",type=int,default=512000);p.add_argument("--output",required=True)
    a=p.parse_args()
    try:
        bundle=read(a.bundle)
        context=read(a.extraction_context) if a.extraction_context else None
        if a.action=="prepare-retry":
            require(a.previous_prepared and a.audit and a.dispatch,"previous prepared/audit/dispatch required")
            dispatch=read(a.dispatch)
            result=prepare_retry(bundle,read(a.previous_prepared),read(a.audit),dispatch["requested_retest_scope"],
                                 max_chars=a.max_chars,runtime_root=a.runtime_root)
            result["file_inputs"]={key:{"path":str(Path(path).resolve()),"sha256":v1.sha_bytes(Path(path).read_bytes())}
                for key,path in {"bundle":a.bundle,"previous_prepared":a.previous_prepared,"audit":a.audit,"dispatch":a.dispatch}.items()}
        elif a.action=="accept-one":
            require(a.plan and a.request_id and a.provider_request and a.provider_response,"plan/request-id/native call files required")
            plan=read(a.plan)
            require(plan["bundle_content_sha256"]==digest(bundle),"plan bundle differs")
            request=next((r for r in plan["merge_prepared"]["requests"] if r["request_id"]==a.request_id),None)
            require(request is not None,"request is not part of mixed plan")
            result=accept_one(bundle,request,{"provider_request_path":a.provider_request,"provider_response_path":a.provider_response},
                              runtime_root=a.runtime_root,extraction_context=context)
        else:
            require(a.plan and a.responses_manifest,"plan and provider manifest required")
            result=accept_mixed(bundle,read(a.plan),read(a.responses_manifest),runtime_root=a.runtime_root,extraction_context=context)
        write(a.output,result)
        print(json.dumps({"status":"written","path":a.output},ensure_ascii=False))
        return 0
    except (ValueError,KeyError,TypeError,AttributeError) as exc:
        print(json.dumps({"status":"rejected","error_type":type(exc).__name__,"error":str(exc),"semantic_repairs":0},ensure_ascii=False))
        return 2

if __name__=="__main__":raise SystemExit(main())
