"""Offline protocol fixtures only. No answers for the actual48 retry sources are created."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));sys.path.insert(0,str(HERE.parents[1]))
import p01_wire_v2 as v2
from prism_runtime.preferences.demo import build_fixture

class V2Cases(unittest.TestCase):
    def setUp(self):
        self.bundle,self.findings=build_fixture()
        self.old=v2.v1.prepare_requests(self.bundle,max_sources=3)
        self.retry_id=self.old["requests"][1]["request_id"]
        self.audit={"checks":[{"request_id":r["request_id"],"source_count":len(r["evidence_ids"]),
                              "native_accept":r["request_id"]!=self.retry_id} for r in self.old["requests"]]}
        self.plan=v2.prepare_retry(self.bundle,self.old,self.audit,[self.retry_id])
        self.request=self.plan["requests"][0]
        self.temp=tempfile.TemporaryDirectory(prefix="prism-p01wire-v2-test-")
        self.tmp=Path(self.temp.name).resolve()
        assert self.tmp.parent==Path(tempfile.gettempdir()).resolve() and self.tmp.name.startswith("prism-p01wire-v2-test-")
    def tearDown(self):
        # The generated cleanup target has been checked above; no user workspace paths are removed.
        self.temp.cleanup()
    def response(self,request,new=True):
        ids=set(request["evidence_ids"])
        fs=[deepcopy(f) for f in self.findings["findings"] if set(f["evidence_refs"]).issubset(ids)]
        if new:
            for f in fs:
                f.pop("quotes",None);f.pop("record_refs",None)
        result={"request_id":request["request_id"],"input_digest":request["input_digest"],"findings":fs,
                "dispositions":[deepcopy(d) for d in self.findings["dispositions"] if d["evidence_id"] in ids]}
        if new:result["citation_protocol"]=v2.CITATION_PROTOCOL
        return result
    def call(self,request,reply,*,actual_request=None):
        base=self.tmp/request["request_id"];base.mkdir(exist_ok=True)
        native={"model":"qwen3.8-flash","input":{"messages":[{"role":m["role"],"content":[{"text":m["content"]}]} for m in request["messages"]]},
                "parameters":{"max_tokens":16384,"offline_fixture":True}}
        provider={"ok":True,"http_status":200,"data":{"request_id":"offline-fixture-not-an-API-call",
                  "output":{"choices":[{"finish_reason":"stop","message":{"role":"assistant",
                  "content":[{"text":json.dumps(reply,ensure_ascii=False)}]}}]}}}
        v2.write(base/"request.json",actual_request or native);v2.write(base/"provider-response.json",provider)
        return {"request_id":request["request_id"],"provider_request_path":str(base/"request.json"),
                "provider_response_path":str(base/"provider-response.json")}
    def test_only_failed_scope_replaced(self):
        self.assertEqual(len(self.plan["requests"]),1)
        self.assertEqual(self.request["evidence_ids"],self.old["requests"][1]["evidence_ids"])
        self.assertNotEqual(self.request["request_id"],self.retry_id)
        for r,new in zip(self.old["requests"],self.plan["merge_prepared"]["requests"]):
            if r["request_id"]!=self.retry_id:self.assertEqual(r,new)
    def test_new_prompt_has_no_copy_quotes_conflict_and_old_prompt_stays(self):
        runtime=v2.v1.load_runtime()
        old=runtime.SYSTEM_PROMPT
        rendered=v2.render_v2_base_prompt(old)
        self.assertNotIn("quotes逐字摘取回答",rendered)
        self.assertIn("不能把题干当回答",rendered)
        self.assertIn("不要输出quotes或record_refs",rendered)
        self.assertEqual(runtime.SYSTEM_PROMPT,old)
        base=runtime._request(self.bundle,self.old["selection"],self.request["evidence_ids"])
        self.assertEqual(self.request["messages"][1],base["messages"][1])
    def test_negative_and_conditional_full_text_are_not_trimmed(self):
        rid=self.old["requests"][0]["request_id"]
        audit={"checks":[{"request_id":r["request_id"],"source_count":len(r["evidence_ids"]),"native_accept":r["request_id"]!=rid} for r in self.old["requests"]]}
        req=v2.prepare_retry(self.bundle,self.old,audit,[rid])["requests"][0]
        raw=self.response(req)
        accepted=v2.accept_one(self.bundle,req,self.call(req,raw))
        negative=next(f for f in accepted["derived_reply"]["findings"] if f["attitude"]=="dislike")
        conditional=next(f for f in accepted["derived_reply"]["findings"] if f["attitude"]=="conditional")
        self.assertEqual(negative["quotes"][0]["text"],"我不喜欢满版图案，信息太杂。")
        self.assertEqual(conditional["conditions"],["办公室场景"])
        self.assertEqual(conditional["quotes"][0]["text"],"在办公室我只接受低亮度的灯效。")
    def test_attempt_to_rerun_accepted_scope_rejected(self):
        with self.assertRaises(v2.WireError):
            v2.prepare_retry(self.bundle,self.old,self.audit,[self.old["requests"][0]["request_id"]])
    def test_caps_require_real_target_not_region_annotation(self):
        b=deepcopy(self.bundle)
        e=next(x for x in b["evidence"] if x["evidence_id"]=="e6")
        e.pop("target_object_id");e.pop("target_region_ref")
        e["source_image_annotation"]={"region_id":"body","bbox_xyxy":[0,0,1,1]}
        caps=v2.source_capabilities(b,["e6"],v2.v1.load_runtime())
        self.assertFalse(caps[0]["pointed_image_feature_available"])
        self.assertEqual(caps[0]["eligible_pointed_observations"],[])
        self.assertFalse(caps[0]["source_image_annotation_is_DNA_binding"])
    def test_actual_existing_pointed_binding_is_exposed(self):
        caps=v2.source_capabilities(self.bundle,["e6"],v2.v1.load_runtime())
        self.assertTrue(caps[0]["pointed_image_feature_available"])
        self.assertTrue(any(x["observation_id"]=="o-contour" for x in caps[0]["eligible_pointed_observations"]))
    def test_materialization_copies_full_original_and_keeps_semantics(self):
        raw=self.response(self.request);before=deepcopy(raw)
        entry=self.call(self.request,raw)
        result=v2.accept_one(self.bundle,self.request,entry)
        source={e["evidence_id"]:e for e in self.bundle["evidence"]}
        for old,new in zip(raw["findings"],result["derived_reply"]["findings"]):
            self.assertEqual({k:v for k,v in new.items() if k not in {"quotes","record_refs"}},old)
            for q in new["quotes"]:self.assertEqual(q["text"],source[q["evidence_id"]]["text"])
        self.assertEqual(raw,before)
        receipts=result["citation_receipt"]["items"]
        self.assertTrue(all(x["raw_quote_field"]["present"] is False for x in receipts))
        self.assertTrue(all(x["semantic_fields_unchanged"] for x in receipts))
        self.assertFalse(result["citation_receipt"]["semantic_support_verified"])
    def test_old_v1_response_cannot_be_reclassified(self):
        raw=self.response(self.request)
        raw.pop("citation_protocol")
        with self.assertRaises(v2.WireError):v2.validate_reply(raw,self.request)
        raw=self.response(self.request);raw["findings"][0]["quotes"]=[{}]
        with self.assertRaises(v2.WireError):v2.validate_reply(raw,self.request)
    def test_old_actual_request_cannot_masquerade_as_fresh_call(self):
        raw=self.response(self.request)
        old=self.old["requests"][1]
        native={"model":"qwen3.8-flash","input":{"messages":[{"role":m["role"],"content":[{"text":m["content"]}]} for m in old["messages"]]},"parameters":{}}
        entry=self.call(self.request,raw,actual_request=native)
        with self.assertRaisesRegex(v2.WireError,"actual call"):
            v2.accept_one(self.bundle,self.request,entry)
    def test_empty_unknown_and_cross_batch_refs_rejected(self):
        for refs in [[],["unknown"],[self.old["requests"][0]["evidence_ids"][0]]]:
            raw=self.response(self.request);raw["findings"][0]["evidence_refs"]=refs
            with self.assertRaises((ValueError,KeyError)):
                v2.accept_one(self.bundle,self.request,self.call(self.request,raw))
    def test_wrong_user_not_filled_from_selected_record(self):
        raw=self.response(self.request);raw["findings"][0]["user_ids"]=["wrong-user"]
        before=deepcopy(raw)
        with self.assertRaisesRegex(v2.WireError,"user attribution"):
            v2.accept_one(self.bundle,self.request,self.call(self.request,raw))
        self.assertEqual(raw,before)
    def test_pointed_is_not_converted_to_explicit_text(self):
        b=deepcopy(self.bundle);e=next(x for x in b["evidence"] if x["evidence_id"]=="e6")
        e.pop("target_object_id");e.pop("target_region_ref")
        old=v2.v1.prepare_requests(b,max_sources=3)
        audit={"checks":[{"request_id":r["request_id"],"source_count":len(r["evidence_ids"]),"native_accept":r["request_id"]!=old["requests"][1]["request_id"]} for r in old["requests"]]}
        plan=v2.prepare_retry(b,old,audit,[old["requests"][1]["request_id"]]);req=plan["requests"][0]
        raw=self.response(req)
        pointed=next(f for f in raw["findings"] if any(x["attribution"]=="pointed_image_feature" for x in f["features"]))
        before=deepcopy(pointed)
        with self.assertRaisesRegex(ValueError,"pointed user target"):
            v2.accept_one(b,req,self.call(req,raw))
        self.assertEqual(pointed,before)
    def test_conditions_still_checked_by_original_compiler(self):
        req=self.plan["merge_prepared"]["requests"][0]
        raw=self.response(req,new=False)
        conditional=next(f for f in raw["findings"] if f["attitude"]=="conditional")
        conditional["conditions"]=[]
        with self.assertRaises(ValueError):
            v2.accept_one(self.bundle,req,self.call(req,raw))
    def test_mixed_merge_reuses_original_replies(self):
        entries=[]
        expected_raw={}
        for req in self.plan["merge_prepared"]["requests"]:
            new=req.get("wire_protocol")==v2.VERSION
            raw=self.response(req,new=new);expected_raw[req["request_id"]]=deepcopy(raw)
            entries.append(self.call(req,raw))
        result=v2.accept_mixed(self.bundle,self.plan,{"responses":entries})
        self.assertEqual(result["profile"]["coverage"]["status"],"complete")
        for reply in result["derived_replies"]:
            if reply["request_id"] in self.plan["reused_request_ids"]:
                self.assertEqual(reply,expected_raw[reply["request_id"]])
    def test_missing_new_reply_does_not_complete_merge(self):
        with self.assertRaisesRegex(v2.WireError,"responses"):
            v2.accept_mixed(self.bundle,self.plan,{"responses":[]})
    def test_incomplete_source_coverage_rejected_not_filled(self):
        raw=self.response(self.request)
        raw["findings"]=[]
        with self.assertRaisesRegex(v2.WireError,"whole source scope"):
            v2.accept_one(self.bundle,self.request,self.call(self.request,raw))
    def test_wrong_model_or_truncation_rejected(self):
        raw=self.response(self.request);entry=self.call(self.request,raw)
        native=v2.read(entry["provider_request_path"]);native["model"]="another-model"
        v2.write(entry["provider_request_path"],native)
        with self.assertRaises(v2.WireError):v2.accept_one(self.bundle,self.request,entry)
        entry=self.call(self.request,raw);provider=v2.read(entry["provider_response_path"])
        provider["data"]["output"]["choices"][0]["finish_reason"]="length"
        v2.write(entry["provider_response_path"],provider)
        with self.assertRaises(v2.WireError):v2.accept_one(self.bundle,self.request,entry)

if __name__=="__main__":unittest.main()
