审阅producer完整JSON线协议：prism.preference.review-producer-wire.v1。
这只是输出结构和消息绑定说明，不改变前面的独立语义核对标准。

只输出一个完整JSON对象，顶层必须是：
{"request_id":"<本次绑定ID>","input_digest":"<本次绑定摘要>","items":[...]}
数组键必须是items，不得写reviews、review、results、review_results或findings。
不要输出Markdown围栏、前后解释或自我通过标记。

只审本包candidate_bindings列出的候选，每个preference_id恰好出现一次。不得漏项、重复或引用其他包候选。
逐字复制对应preference_id和candidate_digest；不要自己重新计算，也不能拿input_digest代替candidate_digest。

每个items元素必须为对象，字段如下：
- preference_id：字符串，复制本包候选ID。
- candidate_digest：字符串，复制该候选摘要。
- verdict：字符串，只能为supported、contradicted、insufficient。由你实际核对语义后独立判断，不要求通过。
- reason：非空字符串，解释原文、对象、条件和候选之间的关系。材料不足要说明，不编造理由。
- quotes：对象数组；每项必须是{"evidence_id":"<该候选引用的来源ID>","text":"<该来源text中的逐字片段>"}。
  不能写["原话"]，不能写空对象，也不能把证据ID当成JSON对象的键。
  每个有文字的引用来源都要有自己的quote对象。读完整source_evidence后引用，不把提取模型的片段自动当正确证明。
  text必须是原文逐字片段，不翻译、不改否定、不补词、不改标点、不改条件。程序不会替你补来源或修引文。
- record_refs：字符串数组，仅引用无文字的明确选择记录；普通文字来源不能用它代替quotes，没有则[]。
- checked_aspects：字符串数组，必须恰好包含下面五个值，各一次；名称和复数形式不得改变：
  ["attitude","attribution","conditions","summary","user_scope"]
  attitude=态度及否定；attribution=对象/特征归因；conditions=条件和适用范围；
  summary=摘要是否超出原话；user_scope=用户/账号/人群范围。
  object_attribution、condition、summary_accuracy等同义改名不符合协议。
  必须实际检查五方面。发现某方面证据不足仍要解释不足并给insufficient，不能删掉检查项或假称已经支持。
- corrected_attitude：可选字符串，只能like/dislike/conditional/neutral/unknown。它只是复核纠正建议，不覆盖候选。supported时不能建议不同态度。

不能输出review_id、reviewer_id、reviewed_at或审阅者身份；真实身份、调用时间和源记录由可信调用方根据实际执行登记。
不要使用旧审阅裁决或作者oracle。候选的like/dislike不是你的结论，引用存在也不是语义支持。
checked_aspects完整只表示协议完整，不独立证明判断正确。

详细嵌套类型见下面的JSON Schema。本次request/input和每个candidate的绑定值随后提供。
