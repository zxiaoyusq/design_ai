"""New review producer wire only. No API, verdict generation, old-answer repair or state consumer."""
from __future__ import annotations
from copy import deepcopy
import argparse
import importlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location("prism_native_transport_readonly",HERE.parent/"preferences_qwen_p01_wire_002/p01_wire_v2.py")
transport=importlib.util.module_from_spec(spec);spec.loader.exec_module(transport)
wire=transport.v1
WireError=wire.WireError
require=wire.require
read=wire.read
write=wire.write
VERSION="qwen-p01-review-wire-001-v1"

def digest(obj):
    return transport.digest(obj)

def runtime_review(runtime_root=None):
    engine=wire.load_runtime(runtime_root)
    review=importlib.import_module("prism_runtime.preferences.review")
    require(Path(review.__file__).resolve().parent==Path(engine.__file__).resolve().parent,"review and engine runtime roots differ")
    return review

def prepare(bundle,profile,failed_prepared,*,max_candidates=6,max_chars=512000,runtime_root=None):
    review=runtime_review(runtime_root)
    scope=failed_prepared.get("preference_ids")
    require(isinstance(scope,list) and scope and len(scope)==len(set(scope)),"failed candidate scope must be explicit and unique")
    require(len(scope)<=12,"this bounded producer repair is limited to the12 failed candidates")
    require(type(max_candidates) is int and max_candidates>0,"max_candidates must be positive")
    require((len(scope)+max_candidates-1)//max_candidates<=2,"no more than two fresh requests allowed")
    require(failed_prepared.get("input_digest")==profile.get("input_digest"),"failed scope belongs to a different source snapshot")
    require(type(max_chars) is int and max_chars>=4000,"max_chars must be >=4000")
    byid={f["preference_id"]:f for f in profile["preferences"]}
    require(set(scope).issubset(byid),"unknown original candidate")
    schema=json.dumps(read(HERE/"reply-schema.json"),ensure_ascii=False,separators=(",",":"))
    extra=(HERE/"WIRE_PROMPT.md").read_text(encoding="utf-8")
    requests=[]
    for offset in range(0,len(scope),max_candidates):
        ids=scope[offset:offset+max_candidates]
        req=review.prepare_semantic_review(bundle,profile,ids)
        payload=json.loads(req["messages"][1]["content"])
        for f in payload["candidates"]:
            a=f.get("semantic_assessment",{})
            require(a.get("status")=="pending_independent_review" and a.get("review_ids")==[]
                    and not f.get("confirmed_user_support"),"prior approval state leaked into fresh review input")
            require("latest_review_reason" not in a and "suggested_correction" not in a,
                    "prior review content leaked into producer input")
            require(not f.get("untrusted_review_claims"),"untrusted prior-review claims require explicit input inspection")
        require(set(payload)=={"input_digest","extraction_context","candidates","source_evidence","image_dna","required_checked_aspects"},
                "base request payload changed; review the producer contract")
        sources={e["evidence_id"]:e for e in payload["source_evidence"]}
        bindings=[{
            "preference_id":pid,"candidate_digest":byid[pid]["semantic_assessment"]["candidate_digest"],
            "textual_evidence_refs":[r for r in byid[pid]["evidence_refs"] if sources[r].get("text","").strip()],
            "textless_record_refs":[r for r in byid[pid]["evidence_refs"] if not sources[r].get("text","").strip()],
        } for pid in ids]
        rid=f"preference-review-wire001-{len(requests)+1:03d}"
        binding={"request_id":rid,"input_digest":req["input_digest"],"candidate_bindings":bindings}
        req["messages"][0]["content"]+="\n\n"+extra+"\n本次绑定表："+json.dumps(binding,ensure_ascii=False,separators=(",",":"))+"\n完整JSON Schema："+schema
        req.update({"request_id":rid,"producer_wire":VERSION,"candidate_bindings":bindings,
                    "message_chars":sum(len(m["content"]) for m in req["messages"]),
                    "base_user_payload_sha256":wire.sha_bytes(req["messages"][1]["content"].encode("utf-8"))})
        require(req["message_chars"]<=max_chars,"source/candidate context exceeds cap; no truncation or third request")
        requests.append(req)
    require([pid for r in requests for pid in r["preference_ids"]]==scope,"failed candidate coverage changed")
    return {
        "schema_version":"prism.review_producer_retry.v1","version":VERSION,
        "original_failed_preference_ids":scope,"requests":requests,
        "candidate_count":len(scope),"other_profile_candidates_not_requested":len(profile["preferences"])-len(scope),
        "input_digest":profile["input_digest"],"profile_content_sha256":digest(profile),
        "candidate_fingerprints":{pid:byid[pid]["semantic_assessment"]["candidate_digest"] for pid in scope},
        "provenance":deepcopy(profile["provenance"]),
        "metadata":{"original_consumer_path":str(Path(review.__file__).resolve()),
                    "original_consumer_sha256":wire.sha_bytes(Path(review.__file__).read_bytes()),
                    "wire_prompt_sha256":wire.sha_bytes((HERE/"WIRE_PROMPT.md").read_bytes()),
                    "reply_schema_sha256":wire.sha_bytes((HERE/"reply-schema.json").read_bytes()),
                    "max_candidates":max_candidates,"max_requests":2,"max_chars":max_chars,
                    "intended_semantic_model":wire.MODEL,
                    "old_review_decisions_sent":False,"oracle_sent":False,
                    "source_or_DNA_truncation":False,"semantic_verdicts_authored":False,"new_api_calls":0},
    }

def validate_reply(reply,request,*,runtime_root=None):
    """Read-only shape, binding and original quote checks; never approve semantic truth."""
    schema=read(HERE/"reply-schema.json")
    wire._schema_check(reply,schema,schema)
    require(request.get("producer_wire")==VERSION,"new producer request required")
    require(reply["request_id"]==request["request_id"] and reply["input_digest"]==request["input_digest"],"reply/request binding mismatch")
    bindings={b["preference_id"]:b for b in request["candidate_bindings"]}
    ids=[x["preference_id"] for x in reply["items"]]
    require(len(ids)==len(set(ids)) and set(ids)==set(request["preference_ids"]),"candidate scope missing, repeated or outside this request")
    payload=json.loads(request["messages"][1]["content"])
    evidence={e["evidence_id"]:e for e in payload["source_evidence"]}
    candidates={f["preference_id"]:f for f in payload["candidates"]}
    review=runtime_review(runtime_root)
    for item in reply["items"]:
        binding=bindings[item["preference_id"]];candidate=candidates[item["preference_id"]]
        require(item["candidate_digest"]==binding["candidate_digest"],"candidate digest mismatch")
        require(bool(item["reason"].strip()),"review reason required")
        require(set(item["checked_aspects"])==review.CHECKED_ASPECTS,"original checked_aspects must be exact")
        quoted=set()
        for q in item["quotes"]:
            require(q["evidence_id"] in candidate["evidence_refs"],"quote outside candidate evidence")
            review.validate_quote(q,evidence)
            quoted.add(q["evidence_id"])
        require(set(binding["textual_evidence_refs"]).issubset(quoted),"each textual source requires a model quote object")
        require(set(item["record_refs"]).issubset(candidate["evidence_refs"]),"record_ref outside candidate")
        require(set(binding["textless_record_refs"]).issubset(item["record_refs"]),"textless selection record reference missing")
        if "corrected_attitude" in item:
            require(item["verdict"]!="supported" or item["corrected_attitude"]==candidate["attitude"],
                    "supported verdict cannot silently change attitude")
    return reply  # Same parsed model object. No keys/quotes/aspects/defaults are rewritten.

def as_native_messages(request):
    return [{"role":m["role"],"content":[{"text":m["content"]}]} for m in request["messages"]]

def check_provider(request,provider_request_path,provider_response_path,*,runtime_root=None):
    native=read(provider_request_path);provider=read(provider_response_path)
    require(native.get("model")==wire.MODEL,"actual model must be qwen3.8-flash")
    require(native.get("input",{}).get("messages")==as_native_messages(request),"actual messages do not match fresh planned request")
    raw,text,provider_id=transport.raw_provider(provider)
    validate_reply(raw,request,runtime_root=runtime_root)
    return {
        "producer_wire_valid":True,"raw_model_reply":raw,
        "binding_receipt":{"request_id":request["request_id"],"input_digest":request["input_digest"],
            "candidate_fingerprints":{b["preference_id"]:b["candidate_digest"] for b in request["candidate_bindings"]},
            "actual_request_path":str(Path(provider_request_path).resolve()),"actual_request_sha256":wire.sha_bytes(Path(provider_request_path).read_bytes()),
            "actual_response_path":str(Path(provider_response_path).resolve()),"actual_response_sha256":wire.sha_bytes(Path(provider_response_path).read_bytes()),
            "messages_sha256":digest(request["messages"]),"raw_model_text_sha256":wire.sha_bytes(text.encode("utf-8")),
            "raw_reply_sha256":digest(raw),
            "provider_request_id":provider_id,"actual_model":native["model"],"finish_reason":"stop",
            "items_passed_unchanged":True,"semantic_truth_verified":False,
            "consumer_receipt_applied":False,
            "artifact_assurance":"trusted caller saved actual-call artifacts; no cryptographic provenance claim",
            "next_step":"Root binds real execution identity/time/artifact and passes these exact items to unchanged apply/validate."}
    }

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=["prepare","check-provider"])
    p.add_argument("--dispatch");p.add_argument("--plan");p.add_argument("--request-id")
    p.add_argument("--provider-request");p.add_argument("--provider-response")
    p.add_argument("--runtime-root");p.add_argument("--max-candidates",type=int,default=6)
    p.add_argument("--max-chars",type=int,default=512000);p.add_argument("--output",required=True)
    a=p.parse_args()
    try:
        if a.action=="prepare":
            require(a.dispatch is not None,"dispatch required")
            d=read(a.dispatch);failed=read(d["prepared"])
            require(len(failed["preference_ids"])==d["scope"]["candidate_count"]==12,"dispatch scope must be the original12 candidates")
            result=prepare(read(d["bundle"]),read(d["candidate_profile"]),failed,max_candidates=a.max_candidates,max_chars=a.max_chars,runtime_root=a.runtime_root)
            result["file_inputs"]={key:{"path":d[key],"sha256":wire.sha_bytes(Path(d[key]).read_bytes())}
                                  for key in ["bundle","candidate_profile","prepared"]}
            result["dispatch_ref"]=str(Path(a.dispatch).resolve())
        else:
            require(a.plan and a.request_id and a.provider_request and a.provider_response,"plan/request-id/actual call files required")
            plan=read(a.plan);request=next((r for r in plan["requests"] if r["request_id"]==a.request_id),None)
            require(request is not None,"request not in bounded plan")
            result=check_provider(request,a.provider_request,a.provider_response,runtime_root=a.runtime_root)
        write(a.output,result);print(json.dumps({"status":"written","path":a.output},ensure_ascii=False));return 0
    except (ValueError,KeyError,TypeError,AttributeError) as exc:
        print(json.dumps({"status":"rejected","error_type":type(exc).__name__,"error":str(exc),"repairs":0},ensure_ascii=False));return 2

if __name__=="__main__":raise SystemExit(main())
