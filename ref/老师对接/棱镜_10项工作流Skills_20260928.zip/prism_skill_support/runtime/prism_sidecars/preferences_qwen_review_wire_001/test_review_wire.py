"""Offline contract tests on explicit synthetic fixtures; never author real-run review verdicts."""
from copy import deepcopy
import argparse
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

import review_wire as rw

review=rw.runtime_review()
from prism_runtime.preferences.tests.test_semantic_review import case, envelope, REGISTRY


class ReviewWireTests(unittest.TestCase):
    def setUp(self):
        self.bundle,_,self.profile=case()
        self.old=review.prepare_semantic_review(self.bundle,self.profile,["p2"])
        self.req=rw.prepare(self.bundle,self.profile,self.old)["requests"][0]
        self.reply={
            "request_id":self.req["request_id"],"input_digest":self.req["input_digest"],
            "items":envelope(self.profile)["items"],
        }

    def reject(self,reply=None,request=None):
        with self.assertRaises(ValueError):
            rw.validate_reply(self.reply if reply is None else reply,self.req if request is None else request)

    def test_valid_synthetic_reply_is_same_object_and_does_not_approve_profile(self):
        before=deepcopy(self.profile)
        self.assertIs(rw.validate_reply(self.reply,self.req),self.reply)
        self.assertEqual(self.profile,before)
        self.assertTrue(all(not f["confirmed_user_support"] for f in self.profile["preferences"]))

    def test_items_compatible_with_unchanged_original_consumer(self):
        raw=deepcopy(self.reply)
        checked=rw.validate_reply(raw,self.req)
        fixture_envelope=envelope(self.profile)
        fixture_envelope["items"]=checked["items"]  # Fixture-only external execution metadata.
        accepted=review.apply_semantic_reviews(self.bundle,self.profile,fixture_envelope,reviewer_registry=REGISTRY)
        accepted=review.validate_reviewed_profile(self.bundle,accepted,reviewer_registry=REGISTRY)
        f=next(f for f in accepted["preferences"] if f["preference_id"]=="p2")
        self.assertEqual(f["semantic_assessment"]["support_eligibility"],"reviewed_negative")
        self.assertFalse(f["confirmed_user_support"])
        self.assertEqual(raw,self.reply)
        self.assertEqual(accepted["semantic_review_receipts"][0]["items"],raw["items"])

    def test_exact_subset_no_unrelated_sources(self):
        old=review.prepare_semantic_review(self.bundle,self.profile,["p2","p5"])
        before=deepcopy((self.bundle,self.profile,old))
        plan=rw.prepare(self.bundle,self.profile,old,max_candidates=1)
        self.assertEqual([p for r in plan["requests"] for p in r["preference_ids"]],["p2","p5"])
        self.assertEqual([len(r["preference_ids"]) for r in plan["requests"]],[1,1])
        self.assertEqual(plan["other_profile_candidates_not_requested"],7)
        self.assertEqual((self.bundle,self.profile,old),before)
        for req in plan["requests"]:
            base=review.prepare_semantic_review(self.bundle,self.profile,req["preference_ids"])
            self.assertEqual(base["messages"][1],req["messages"][1])
            self.assertTrue(req["messages"][0]["content"].startswith(base["messages"][0]["content"]))
            data=json.loads(req["messages"][1]["content"])
            self.assertEqual({r["evidence_id"] for r in data["source_evidence"]},
                             {ref for f in data["candidates"] for ref in f["evidence_refs"]})

    def test_more_than_two_requests_rejected(self):
        old=review.prepare_semantic_review(self.bundle,self.profile,["p1","p2","p3"])
        with self.assertRaises(ValueError):
            rw.prepare(self.bundle,self.profile,old,max_candidates=1)

    def test_scope_duplicate_or_unknown_rejected(self):
        for ids in (["p2","p2"],["nonexistent"]):
            with self.subTest(ids=ids),self.assertRaises(ValueError):
                rw.prepare(self.bundle,self.profile,{**self.old,"preference_ids":ids})

    def test_stale_input_or_candidate_rejected(self):
        with self.assertRaises(ValueError):
            rw.prepare(self.bundle,self.profile,{**self.old,"input_digest":"stale"})
        changed=deepcopy(self.profile)
        changed["preferences"][1]["summary"]="changed"
        with self.assertRaises(ValueError):
            rw.prepare(self.bundle,changed,self.old)

    def test_cached_approval_hidden_from_fresh_request(self):
        p=review.apply_semantic_reviews(self.bundle,self.profile,envelope(self.profile),reviewer_registry=REGISTRY)
        before=deepcopy(p)
        req=rw.prepare(self.bundle,p,self.old)["requests"][0]
        f=json.loads(req["messages"][1]["content"])["candidates"][0]
        self.assertEqual(f["semantic_assessment"]["status"],"pending_independent_review")
        self.assertEqual(f["semantic_assessment"]["review_ids"],[])
        self.assertNotIn("latest_review_reason",f["semantic_assessment"])
        self.assertNotIn("suggested_correction",f["semantic_assessment"])
        self.assertFalse(f["confirmed_user_support"])
        self.assertEqual(p,before)
        self.assertEqual(req["messages"][1],self.req["messages"][1])

    def test_context_over_cap_rejected_without_truncation(self):
        before=deepcopy(self.old)
        with self.assertRaises(ValueError):
            rw.prepare(self.bundle,self.profile,self.old,max_chars=4000)
        self.assertEqual(self.old,before)

    def test_top_level_reviews_alias_rejected_unchanged(self):
        raw=deepcopy(self.reply);raw["reviews"]=raw.pop("items")
        before=deepcopy(raw)
        self.reject(raw)
        self.assertEqual(raw,before)

    def test_string_quote_not_converted(self):
        raw=deepcopy(self.reply);raw["items"][0]["quotes"]=["我不喜欢满版图案，信息太杂。"]
        before=deepcopy(raw)
        self.reject(raw)
        self.assertEqual(raw,before)

    def test_missing_or_renamed_checked_aspects_rejected(self):
        for aspects in (["attitude"],["attitude","object_attribution","condition","summary_accuracy","user_scope"]):
            raw=deepcopy(self.reply);raw["items"][0]["checked_aspects"]=aspects
            with self.subTest(aspects=aspects):
                self.reject(raw)

    def test_missing_duplicate_or_foreign_candidate_rejected(self):
        for items in ([],[self.reply["items"][0]]*2,[{**self.reply["items"][0],"preference_id":"p1"}]):
            with self.subTest(items=items):
                self.reject({**self.reply,"items":items})

    def test_request_input_and_candidate_digests_bound(self):
        for key in ("request_id","input_digest"):
            self.reject({**self.reply,key:"wrong"})
        raw=deepcopy(self.reply);raw["items"][0]["candidate_digest"]="wrong"
        self.reject(raw)

    def test_nonverbatim_or_out_of_scope_quote_rejected(self):
        for quote in ({"evidence_id":"e2","text":"我喜欢满版图案"},
                      {"evidence_id":"e1","text":"我喜欢圆润的轮廓，看起来柔和。"}):
            raw=deepcopy(self.reply);raw["items"][0]["quotes"]=[quote]
            with self.subTest(quote=quote):
                self.reject(raw)

    def test_missing_text_source_cannot_be_replaced_with_record_ref(self):
        raw=deepcopy(self.reply);raw["items"][0]["quotes"]=[]
        raw["items"][0]["record_refs"]=["e2"]
        self.reject(raw)

    def test_textless_selection_must_keep_record_ref(self):
        old=review.prepare_semantic_review(self.bundle,self.profile,["p5"])
        req=rw.prepare(self.bundle,self.profile,old)["requests"][0]
        reply={**self.reply,"items":envelope(self.profile,pid="p5")["items"]}
        self.assertIs(rw.validate_reply(reply,req),reply)
        reply["items"][0]["record_refs"]=[]
        self.reject(reply,req)

    def test_supported_cannot_change_attitude_but_contradiction_can_suggest(self):
        raw=deepcopy(self.reply);raw["items"][0]["corrected_attitude"]="like"
        self.reject(raw)
        raw["items"][0]["verdict"]="contradicted"
        self.assertIs(rw.validate_reply(raw,self.req),raw)

    def test_blank_reason_and_model_identity_fields_rejected(self):
        raw=deepcopy(self.reply);raw["items"][0]["reason"]=" "
        self.reject(raw)
        self.reject({**self.reply,"reviewer_id":"made-up"})

    def test_validated_offset_still_uses_original_quote_rule(self):
        raw=deepcopy(self.reply)
        q=raw["items"][0]["quotes"][0];q["start"]=0;q["end"]=len(q["text"])
        self.assertIs(rw.validate_reply(raw,self.req),raw)
        q["end"]-=1
        self.reject(raw)

    def provider(self,raw=None,finish="stop"):
        return {"ok":True,"http_status":200,"data":{"request_id":"synthetic-provider-only","output":{"choices":[{
            "finish_reason":finish,"message":{"role":"assistant","content":[{"text":raw if raw is not None else json.dumps(self.reply,ensure_ascii=False)}]}
        }]}}}

    def call_check(self,native=None,provider=None):
        directory=Path(tempfile.mkdtemp(prefix=".test-review-wire-",dir=rw.HERE)).resolve()
        def checked_cleanup():
            if directory.parent!=rw.HERE.resolve() or not directory.name.startswith(".test-review-wire-"):
                raise ValueError("unsafe test cleanup path")
            shutil.rmtree(directory)
        self.addCleanup(checked_cleanup)
        reqpath=directory/"request.fixture.json";respath=directory/"response.fixture.json"
        rw.write(reqpath,native if native is not None else {"model":"qwen3.8-flash","input":{"messages":rw.as_native_messages(self.req)}})
        rw.write(respath,provider if provider is not None else self.provider())
        before=(reqpath.read_bytes(),respath.read_bytes())
        result=rw.check_provider(self.req,reqpath,respath)
        self.assertEqual((reqpath.read_bytes(),respath.read_bytes()),before)
        return result

    def test_actual_native_fixture_bound_and_no_semantic_promotion(self):
        checked=self.call_check()
        self.assertEqual(checked["raw_model_reply"],self.reply)
        self.assertFalse(checked["binding_receipt"]["semantic_truth_verified"])
        self.assertFalse(checked["binding_receipt"]["consumer_receipt_applied"])
        self.assertEqual(checked["binding_receipt"]["raw_reply_sha256"],rw.digest(self.reply))

    def test_different_native_messages_or_model_rejected(self):
        native={"model":"qwen3.8-flash","input":{"messages":rw.as_native_messages(self.req)}}
        for variant in ("model","messages"):
            broken=deepcopy(native)
            if variant=="model":broken["model"]="not-qwen3.8-flash"
            else:broken["input"]["messages"][0]["content"][0]["text"]+=" extra legacy wrapper"
            with self.subTest(variant=variant),self.assertRaises(ValueError):
                self.call_check(native=broken)

    def test_truncation_non_json_duplicate_keys_and_fences_rejected_without_repair(self):
        text=json.dumps(self.reply,ensure_ascii=False)
        duplicate='{"request_id":"first","request_id":"second","input_digest":"x","items":[]}'
        for raw,finish in ((text,"length"),(text[:-1],"stop"),(duplicate,"stop"),
                           (chr(96)*3+"json\n"+text+"\n"+chr(96)*3,"stop"),('{"value":NaN}',"stop")):
            with self.subTest(finish=finish,raw=raw[:40]),self.assertRaises(ValueError):
                self.call_check(provider=self.provider(raw,finish))


class RecordingResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.passed=[]
    def addSuccess(self,test):
        super().addSuccess(test);self.passed.append(test.id())


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--output")
    a=p.parse_args()
    result=unittest.TextTestRunner(verbosity=2,resultclass=RecordingResult).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(ReviewWireTests))
    if a.output:
        rw.write(a.output,{"schema_version":"prism.offline_contract_tests.v1","fixture_only":True,
                 "new_api_calls":0,"tests_run":result.testsRun,"all_passed":result.wasSuccessful(),
                 "passed":result.passed,"failures":[{"test":t.id(),"trace":trace} for t,trace in result.failures],
                 "errors":[{"test":t.id(),"trace":trace} for t,trace in result.errors]})
    sys.exit(0 if result.wasSuccessful() else 1)
