"""Verify bounded retry provenance and reject old wire bytes; no semantic decisions or API calls."""
import argparse
import json
from pathlib import Path
from datetime import datetime, timezone
import review_wire as rw


def rejection(fn):
    try:
        fn()
    except (ValueError,TypeError,KeyError,AttributeError) as exc:
        return {"rejected":True,"error_type":type(exc).__name__,"error":str(exc),"repairs":0}
    return {"rejected":False,"repairs":0}


def run(dispatch_path,output):
    out=Path(output).resolve()
    dispatch=rw.read(dispatch_path)
    baseline=rw.read(out/"protected-before.json")
    plan=rw.read(out/"prepared-retry.json")
    tests=rw.read(out/"contract-tests.json")
    bundle=rw.read(dispatch["bundle"]);profile=rw.read(dispatch["candidate_profile"])
    failed=rw.read(dispatch["prepared"]);old=rw.read(dispatch["raw_reply"])
    old_before=rw.digest(old)
    result=rw.read(dispatch["result"])
    schema=rw.read(rw.HERE/"reply-schema.json")
    original_review=rw.runtime_review()
    protected=[]
    for record in baseline["files"]:
        path=Path(record["path"])
        current=rw.wire.sha_bytes(path.read_bytes()) if path.is_file() else None
        protected.append({**record,"current_sha256":current,"unchanged":current==record["sha256"]})
    old_rejection=rejection(lambda:rw.validate_reply(old,plan["requests"][0]))
    native_rejection=rejection(lambda:rw.check_provider(plan["requests"][0],dispatch["raw_request"],dispatch["raw_response"]))
    quote_checks=[];aspect_checks=[]
    # Read the legacy fields as separate diagnostics, never place them into a repaired envelope.
    for item in old.get("reviews",[]):
        quote_checks.append({"preference_id":item.get("preference_id"),
            **rejection(lambda item=item:rw.wire._schema_check(item.get("quotes"),schema["$defs"]["review_item"]["properties"]["quotes"],schema))})
        aspect_checks.append({"preference_id":item.get("preference_id"),
            **rejection(lambda item=item:rw.wire._schema_check(item.get("checked_aspects"),schema["$defs"]["checked_aspects"],schema))})
    accepted_records=[r for r in result["records"] if r["accepted"]]
    accepted_ids=[i["preference_id"] for r in accepted_records for i in rw.read(r["envelope_ref"])["items"]]
    protected_by_path={str(Path(r["path"]).resolve()):r for r in protected}
    protected_accepted_calls=[]
    for record in accepted_records:
        request_id=record["request_id"];directory=Path(record["envelope_ref"]).parent
        paths=[directory/"envelope.json"]+[directory/"calls"/request_id/name for name in
                                           ("request.json","provider-response.json","output.json","output.txt")]
        for path in paths:
            saved=protected_by_path.get(str(path.resolve()))
            protected_accepted_calls.append({"request_id":request_id,"path":str(path),"unchanged":bool(saved and saved["unchanged"])})
    request_checks=[]
    for req in plan["requests"]:
        base=original_review.prepare_semantic_review(bundle,profile,req["preference_ids"])
        data=json.loads(req["messages"][1]["content"])
        clean=all(f["semantic_assessment"]["status"]=="pending_independent_review"
                  and f["semantic_assessment"]["review_ids"]==[]
                  and not f["confirmed_user_support"]
                  and "latest_review_reason" not in f["semantic_assessment"]
                  and "suggested_correction" not in f["semantic_assessment"]
                  and not f.get("untrusted_review_claims")
                  for f in data["candidates"])
        request_checks.append({
            "request_id":req["request_id"],"candidate_count":len(req["preference_ids"]),
            "source_count":len(data["source_evidence"]),"image_dna_count":len(data["image_dna"]),
            "message_chars":req["message_chars"],"messages_sha256":rw.digest(req["messages"]),
            "native_messages_sha256":rw.digest(rw.as_native_messages(req)),
            "original_user_payload_identical":req["messages"][1]==base["messages"][1],
            "original_system_preserved_prefix":req["messages"][0]["content"].startswith(base["messages"][0]["content"]+"\n\n"),
            "no_prior_review_approval_or_reason":clean,
            "base_user_payload_sha256":req["base_user_payload_sha256"],
        })
    ids=[p for r in plan["requests"] for p in r["preference_ids"]]
    byid={f["preference_id"]:f for f in profile["preferences"]}
    raw_sha=rw.wire.sha_bytes(Path(dispatch["raw_reply"]).read_bytes())
    checks={
        "protected_files_unchanged":all(r["unchanged"] for r in protected),
        "all_14_successful_calls_and_envelopes_unchanged":len(accepted_records)==14 and all(r["unchanged"] for r in protected_accepted_calls),
        "only_original_12_failed_candidates":ids==failed["preference_ids"] and len(ids)==12 and len(set(ids))==12,
        "at_most_two_requests":1<=len(plan["requests"])<=2,
        "other_167_candidates_not_repeated":len(accepted_ids)==len(set(accepted_ids))==167 and not(set(ids)&set(accepted_ids)),
        "profile_content_binding":plan["profile_content_sha256"]==rw.digest(profile),
        "source_file_bindings":all(v["sha256"]==rw.wire.sha_bytes(Path(v["path"]).read_bytes()) for v in plan["file_inputs"].values()),
        "all_candidate_fingerprints_bound":plan["candidate_fingerprints"]=={
            pid:byid[pid]["semantic_assessment"]["candidate_digest"] for pid in failed["preference_ids"]},
        "original_source_and_candidate_payloads_preserved":all(r["original_user_payload_identical"] for r in request_checks),
        "original_independent_semantic_instructions_preserved":all(r["original_system_preserved_prefix"] for r in request_checks),
        "fresh_inputs_do_not_carry_review_outcomes":all(r["no_prior_review_approval_or_reason"] for r in request_checks),
        "old_invalid_reply_rejected_unchanged":old_rejection["rejected"] and old_before==rw.digest(old) and raw_sha==dispatch["raw_sha256"],
        "old_native_call_not_rebound_as_fresh":native_rejection["rejected"],
        "old_string_quotes_remain_rejected":len(quote_checks)==12 and all(c["rejected"] for c in quote_checks),
        "old_wrong_aspect_labels_remain_rejected":len(aspect_checks)==12 and all(c["rejected"] for c in aspect_checks),
        "synthetic_contract_tests_passed":tests["all_passed"] and tests["tests_run"]==22,
    }
    audit={
        "issue_id":dispatch["issue_id"],"verified_at":datetime.now(timezone.utc).isoformat(),
        "offline_all_passed":all(checks.values()),"checks":checks,
        "new_api_calls":0,"real_run_semantic_verdicts_authored":0,"old_answer_repairs":0,
        "scope":{"retry_candidates":12,"retry_requests":len(plan["requests"]),"retained_candidates":167,
                 "retained_requests":14,"protected_files":len(protected)},
        "requests":request_checks,"old_raw_sha256":raw_sha,
        "old_reply_rejection":old_rejection,"old_actual_call_rejection":native_rejection,
        "old_quote_field_diagnostics":quote_checks,"old_aspect_field_diagnostics":aspect_checks,
        "protected":protected,"retained_calls":protected_accepted_calls,
        "protocol_tests":tests,
        "limits":["Only producer shape, binding and original citation checks tested.",
                  "No new Qwen review response exists in this delivery.",
                  "No real-user effect or semantic truth is established by offline checks."],
    }
    rw.write(out/"offline-verification.json",audit)
    rw.require(audit["offline_all_passed"],"offline verification incomplete; inspect the report")
    manifest={
        "issue_id":dispatch["issue_id"],"input_digest":plan["input_digest"],
        "files":[{"path":str(path.resolve()),"sha256":rw.wire.sha_bytes(path.read_bytes()),"bytes":path.stat().st_size}
                 for path in sorted(rw.HERE.iterdir()) if path.is_file()],
        "prepared":{"path":str(out/"prepared-retry.json"),"sha256":rw.wire.sha_bytes((out/"prepared-retry.json").read_bytes())},
        "protected_before":{"path":str(out/"protected-before.json"),"sha256":rw.wire.sha_bytes((out/"protected-before.json").read_bytes())},
        "protected_files":protected,
    }
    rw.write(out/"source-manifest.json",manifest)
    handoff={
        "issue_id":dispatch["issue_id"],"status":"offline_producer_qualified_pending_fresh_root_calls",
        "algorithm_version_unchanged":"preferences0.3.1","producer_wire":rw.VERSION,
        "owner_thread_id":"01a0dcdc-049e-75d3-b956-94c091a4f063",
        "root_thread_id":"01a0dd0f-c4b6-7ae0-9a61-4bb57a2985de",
        "entrypoint":str(rw.HERE/"review_wire.py"),"readme":str(rw.HERE/"README.md"),
        "prepared":str(out/"prepared-retry.json"),"manifest":str(out/"source-manifest.json"),
        "offline_verification":str(out/"offline-verification.json"),
        "request_ids":[r["request_id"] for r in plan["requests"]],
        "input_digest":plan["input_digest"],"candidate_fingerprints":plan["candidate_fingerprints"],
        "scope":{"candidate_count":12,"requests":2,"accepted_candidates_retained":167,"accepted_requests_retained":14,
                 "maximum_fresh_calls":2,"new_api_calls_by_owner":0},
        "root_requirements":[
            "Freeze this new sidecar and hashes; preserve original runtime and all historic call artifacts.",
            "Send exactly as_native_messages(request) with model qwen3.8-flash. Do not append the old messages_for(review=True) wrapper.",
            "Store actual native request and provider response in new output paths, then call check-provider.",
            "Wrap the untouched raw_model_reply.items using real execution metadata and the unchanged trusted reviewer registry snapshot.",
            "Apply and validate with the unchanged review consumer while retaining the existing 14 accepted envelopes.",
            "Do not repair rejected JSON, quote fields, checked_aspects or semantic verdicts; failed scope remains pending.",
        ],
        "semantic_review_status":"pending_fresh_independent_review_for_these_12",
        "real_user_effect_validated":False,
    }
    rw.write(out/"handoff.json",handoff)
    rw.write(out/"self-assessment.json",{
        "issue_id":dispatch["issue_id"],"overall_status":"partial",
        "producer_wire_offline_status":"qualified","owner_scope_complete":True,
        "fresh_model_and_original_consumer_acceptance":"not_run_by_owner",
        "real_user_effect_validated":False,"semantic_truth_established":False,
        "contract_test_count":tests["tests_run"],"protected_file_count":len(protected),
        "new_api_calls":0,"authored_real_run_review_decisions":0,"old_answers_converted":0,
        "files_modified_outside_new_sidecar_and_delivery":[],
        "remaining_owner":"Root","remaining_work":"At most two fresh Qwen reviews for the original12 candidates, then unchanged consumer validation.",
    })
    (out/"report.md").write_text("\n".join([
        "# 用研偏好独立复核：12条失败请求的输出协议修复","",
        "状态：离线 producer 检查通过；这12条的新模型审阅及原 consumer 验收仍待总控执行。","",
        "原实际运行共179条候选：14包167条已有回执，其中166条supported、1条contradicted；失败包12条保持pending。",
        "本次仅新增输出结构、候选/请求绑定说明，以及只读检查器。原偏好算法0.3.1、独立语义规则和消费端未修改。","",
        "| 新请求 | 候选数 | 完整证据记录 | 消息字符数 |",
        "| --- | ---: | ---: | ---: |",
        *[f"| {r['request_id']} | {r['candidate_count']} | {r['source_count']} | {r['message_chars']} |" for r in request_checks],
        "",
        "两包刚好覆盖原失败12条，未重复其余167条。原prepare_semantic_review生成的user内容逐字保留；没有注入旧裁决或作者答案。",
        "模型必须按原协议输出items、逐字引用对象、全部五个checked_aspects和真实独立判断。程序不补引文、不换标签、不改裁决。","",
        f"离线验证：22项合成协议测试通过；{len(protected)}个受保护文件哈希一致，包含15次旧调用与14个成功envelope。",
        "原坏回复未转换：顶层reviews、字符串quotes、错误checked_aspects分别保持拒绝；旧调用不能冒充新请求。",
        "全部检查见[offline-verification.json](offline-verification.json)，交付接口见[handoff.json](handoff.json)，精确摘要见[source-manifest.json](source-manifest.json)。","",
        "总控只需执行两次新的Qwen3.8 Flash审阅：逐字发送prepared-retry.json内的messages，不再叠加旧review包装词；",
        "check-provider通过后，把原始items连同真实执行信息交给原apply_semantic_reviews和validate_reviewed_profile。",
        "保留原登记表快照及14份旧回执；新审阅是否支持候选，由新的独立判断决定。","",
        "本次新增API调用为0。离线协议通过不证明语义正确，也不代表真实用户效果已经验证。","",
    ]),encoding="utf-8")
    return {"status":handoff["status"],"all_offline_checks":True,"requests":request_checks,
            "protected_files":len(protected),"new_api_calls":0,"report":str(out/"report.md")}


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--dispatch",required=True);p.add_argument("--output",required=True)
    a=p.parse_args()
    print(json.dumps(run(a.dispatch,a.output),ensure_ascii=False,indent=2))
