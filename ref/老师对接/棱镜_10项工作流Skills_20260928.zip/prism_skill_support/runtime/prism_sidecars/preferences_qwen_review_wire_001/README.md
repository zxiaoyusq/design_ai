# QWEN-P01-REVIEW-WIRE-001

仅修复独立复核 producer 的输出说明及消息绑定。原 preferences 0.3.1、prepare_semantic_review、apply_semantic_reviews、validate_reviewed_profile 均保持不变。

范围固定为旧 preference-review-001 的12条候选；交付两包各6条，其余14包167条不重跑。新代码不调用API，也不创建任何实际运行的语义裁决或审阅身份。

输出类型必须明确：顶层 items；quotes 为含 evidence_id/text 的对象数组；checked_aspects 必须恰好为 attitude、attribution、conditions、summary、user_scope。每条候选、输入快照、请求都有摘要绑定。

原语义规则保留：核对完整原文和上下文，检查否定、对象/特征归因、条件、摘要和用户范围。supported、contradicted、insufficient 都是合法判断，不要求模型给出支持结论。合成资料的判断不代表真实用户效果。

## 离线准备

在工作区根目录执行（python应使用已配置的本地运行时）：

    python -B -X utf8 prism_sidecars/preferences_qwen_review_wire_001/review_wire.py prepare --dispatch <原分派JSON的绝对路径> --output <新交付目录/prepared-retry.json>

默认 max-candidates=6，只允许最多两包，保留全部上下文，不截短证据。CLI要求原失败范围恰好12条。测试只使用现有合成协议夹具：

    python -B -X utf8 prism_sidecars/preferences_qwen_review_wire_001/test_review_wire.py --output <新交付目录/contract-tests.json>

## 总控执行两次新审阅

1. 冻结新sidecar、prepared-retry.json及source-manifest.json。使用模型 qwen3.8-flash。
2. 将每个 request.messages 逐字转为原生 input.messages；可调用 as_native_messages(request)。不得继续叠加旧 messages_for(req, review=True) 的格式补充词，否则实际消息绑定检查会拒绝。
3. 在新路径保存原生 request.json、provider-response.json和原始输出。不要覆盖15次旧调用。
4. 对每次新调用运行下面的检查，再根据实际执行元数据登记审阅。

    python -B -X utf8 prism_sidecars/preferences_qwen_review_wire_001/review_wire.py check-provider --plan <prepared-retry.json绝对路径> --request-id preference-review-wire001-001 --provider-request <新request.json绝对路径> --provider-response <新provider-response.json绝对路径> --output <新wire-check.json绝对路径>

第二包的 request-id 为 preference-review-wire001-002。check-provider 要求真实保存的原生HTTP响应成功、finish_reason=stop、单一完整JSON文本、无重复键，且调用消息逐字匹配本包。它只检查协议、绑定、引文和范围。

检查结果的 raw_model_reply.items 必须原样交给原审阅 consumer。总控在外层提供真实的 review_id、reviewer_id、reviewed_at、review_artifact_ref 等，不由模型填写。沿用已有可信登记表快照及其中合格的审阅者；登记表变更会触发历史回执哈希校验，不应为了重试随意改表。

保留14份既有有效回执，然后调用原 apply_semantic_reviews 和 validate_reviewed_profile。check-provider本身不更新画像，不授予支持资格，不代替 consumer。实际文件绑定依赖可信调用方保存的记录，并非密码学身份证明。

任何失败保留原始文件及pending状态。禁止把 reviews 改成 items、把字符串quotes补成对象、替换checked_aspects同义名称、截短JSON后补全或从原文自动代写引文。抽取阶段的全文引用生成协议不适用于此次审阅。

## 离线证据

offline_verify.py读取既有受保护文件基线、准备好的请求和测试结果，核查新请求只覆盖原12条、原user内容不变、112份受保护文件未变；原坏回复在不转换的情况下分别验证结构拒绝与字段拒绝。

    python -B -X utf8 prism_sidecars/preferences_qwen_review_wire_001/offline_verify.py --dispatch <原分派JSON绝对路径> --output <新交付目录绝对路径>

离线合格仅表示producer协议可供重试；新Qwen回复是否通过原consumer、语义是否正确及真实用户效果均须分别评估。
