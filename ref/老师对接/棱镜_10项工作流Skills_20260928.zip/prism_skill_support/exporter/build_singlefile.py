"""Package the frozen report and original images into one offline HTML file.

No algorithm/model calls; image bytes and source reports are never modified.
Text resources use gzip to avoid duplicating large input/output records.
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import json
import mimetypes
import os
from collections import Counter
from datetime import datetime, timezone
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit
import zipfile

OUT = Path(__file__).resolve().parent
LOOP = OUT.parent
PROJECT = LOOP.parents[2]
CLOSURE = LOOP / "closure-20260927"
MAIN = CLOSURE / "report.html"
NAME = "棱镜_120图报告_单文件.html"


def xp(path):
    return "\\\\?\\" + os.path.normpath(os.path.abspath(path))


def read_bytes(path):
    with open(xp(path), "rb") as f:
        return f.read()


def exists(path):
    return os.path.isfile(xp(path))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rel(path):
    return os.path.relpath(path, PROJECT).replace("\\", "/")


class Refs(HTMLParser):
    def __init__(self):
        super().__init__()
        self.items = []

    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in ("src", "href") and value:
                self.items.append((tag, key, value))


def resolve(page, url):
    parts = urlsplit(url)
    if parts.scheme or parts.netloc or not parts.path:
        return None
    path = Path(os.path.normpath(page.parent / unquote(parts.path)))
    if not path.is_relative_to(PROJECT):
        raise ValueError(f"Reference outside project: {page} {url}")
    if "private-ops" in path.parts:
        raise ValueError("Personal operations must not be exported")
    return path


def build():
    pages = {
        MAIN,
        *sorted((CLOSURE / "image-pages").glob("*.html")),
        LOOP / "workload/report.html",
        LOOP / "guide-20260928/index.html",
        LOOP / "simulation-120-20260926/report.html",
        LOOP / "simulation-120-20260926/h01-candidates.html",
        CLOSURE / "report-before-qualified-B.html",
        PROJECT / "docs/prism/核心工作流.html",
    }
    assert len(list((CLOSURE / "image-pages").glob("*.html"))) == 120
    files = set(pages)
    refs = {}
    deferred = set()
    main_images = set()
    for page in sorted(pages):
        parser = Refs()
        parser.feed(read_bytes(page).decode("utf-8-sig"))
        refs[page] = parser.items
        for tag, key, url in parser.items:
            target = resolve(page, url)
            if target is None:
                continue
            if not exists(target):
                raise FileNotFoundError(f"Missing local dependency: {target}")
            if target.suffix.lower() in (".html", ".htm") and target not in pages:
                deferred.add(target)
            else:
                files.add(target)
            if page == MAIN and tag == "img" and key == "src":
                main_images.add(target)
    assert len(main_images) == 120
    ordered = sorted(files | deferred)
    ids = {path: f"f{i:04d}" for i, path in enumerate(ordered)}
    resources = {}
    manifest = []
    for path in ordered:
        raw = read_bytes(path)
        placeholder = path in deferred
        image_mimes = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
                       ".webp": "image/webp", ".gif": "image/gif", ".svg": "image/svg+xml"}
        mime = image_mimes.get(path.suffix.lower()) or mimetypes.guess_type(str(path))[0] or "text/plain"
        if placeholder:
            raw_export = (
                "<!doctype html><meta charset='utf-8'><title>历史资料位于完整交接包</title>"
                "<style>body{font:17px/1.8 sans-serif;max-width:850px;margin:50px auto;padding:20px}"
                "code{overflow-wrap:anywhere}</style><h1>这份历史资料位于完整交接包</h1>"
                "<p>本单文件内含最新结论、120张原图、逐图解析与复核、工作量和接手说明。"
                "更早的对照实验及源码浏览页仍保存在完整交接包中。</p>"
                f"<p>交接包内位置：<code>project/{escape(rel(path))}</code></p>"
                "<p>使用上方“返回”或“完整报告”继续查看本次结果。</p>"
            ).encode("utf-8")
            kind = "html"
        else:
            raw_export = raw
            kind = "html" if path in pages else "image" if mime.startswith("image/") else "text"
        links = {}
        if path in pages:
            for tag, key, url in refs[path]:
                target = resolve(path, url)
                if target:
                    links[url] = {"id": ids[target], "fragment": unquote(urlsplit(url).fragment)}
        encoded = gzip.compress(raw_export, compresslevel=6, mtime=0)
        item = {
            "name": path.name, "path": rel(path), "kind": kind, "mime": mime,
            "sha256": sha(raw), "bytes": len(raw), "links": links,
            "data": base64.b64encode(encoded).decode("ascii"),
            "historical_notice": placeholder,
        }
        resources[ids[path]] = item
        manifest.append({"id": ids[path], "path": rel(path), "kind": kind,
                         "source_sha256": sha(raw), "source_bytes": len(raw),
                         "embedded_sha256": sha(raw_export), "embedded_bytes": len(raw_export),
                         "historical_notice": placeholder})
    bundle = {"main": ids[MAIN], "resources": resources,
              "main_image_ids": [ids[p] for p in sorted(main_images)],
              "image_pages": {p.stem: ids[p] for p in pages if p.parent.name == "image-pages"},
              "workload": ids[LOOP / "workload/report.html"]}
    payload = json.dumps(bundle, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    template = (OUT / "viewer.html").read_text(encoding="utf-8")
    assert template.count("__BUNDLE_JSON__") == 1
    destination = OUT / NAME
    destination.write_text(template.replace("__BUNDLE_JSON__", payload), encoding="utf-8")
    # Check embedded bytes against the immutable sources, not generated filenames.
    for resource_id in bundle["main_image_ids"]:
        item = resources[resource_id]
        assert item["kind"] == "image"
        decoded = gzip.decompress(base64.b64decode(item["data"]))
        assert sha(decoded) == item["sha256"]
    counts = Counter(item["kind"] for item in resources.values())
    summary = {
        "built_at_utc": datetime.now(timezone.utc).isoformat(),
        "report": NAME, "main_source": rel(MAIN), "original_images": len(main_images),
        "image_bytes_preserved": True, "image_pages": len(bundle["image_pages"]),
        "resource_counts": dict(counts), "historical_notice_pages": len(deferred),
        "html_bytes": destination.stat().st_size, "html_sha256": sha(read_bytes(destination)),
        "new_model_calls": 0, "network_required_for_embedded_content": False,
        "external_public_source_links_require_network": True,
        "source_reports_unchanged": True,
    }
    (OUT / "embedded-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    readme = (
        "棱镜 120图报告：单文件离线版\n\n"
        "解压后用电脑上的 Chrome 或 Edge 打开“棱镜_120图报告_单文件.html”。\n"
        "只转发这一个HTML即可；120张原图和逐图解析、复核资料都已内嵌。\n"
        "不需要图片文件夹、原电脑盘符、服务器或登录。微信等软件的内置预览可能限制大HTML，请下载后用浏览器打开。\n"
        "公开来源网页仍需联网；早期历史对照页和全部源码请使用完整交接包。\n"
        "这是交付格式修复，算法结果和原图字节均未改变。\n"
    )
    (OUT / "打开说明.txt").write_text(readme, encoding="utf-8-sig")
    zip_path = OUT / "棱镜_120图报告_单文件.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.write(destination, NAME)
        z.write(OUT / "打开说明.txt", "打开说明.txt")
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        assert sha(z.read(NAME)) == summary["html_sha256"]
    summary.update(zip_bytes=zip_path.stat().st_size, zip_sha256=sha(read_bytes(zip_path)), zip_verified=True)
    (OUT / "build-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    build()
