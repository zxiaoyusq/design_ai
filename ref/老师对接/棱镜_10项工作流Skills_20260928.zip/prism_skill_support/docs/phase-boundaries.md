# 两次握手的分工

H01：确认大风格/主题、适用场景、证据和案例池，输出主题选择。H02：在已选方向内确认具体局部特征、观察尺度、允许变化和负向范围，输出正式请求。

当前前提、阶段范围、后续设计义务、unknown须由真实提案及实际复核区分。H01角色确认不能替代H02角色确认。不能把本阶段适用的负向约束改名为“后续义务”以解锁请求；宗教来源未解决时不得凭金色外观推断具体传统。

受信偏好入口：validate_reviewed_profile的返回副本。H02 context受信入口：stage_scope_v1.h02.verify_context，连同完整inventory与请求一起核。

历史Root AI确认只证明用户在那一次模拟中授权代确认，不是新项目的默认人类选择。再次授权时标记user_delegated_ai，保存来源、选择与版本；不写human_designer_reviewed=true。
