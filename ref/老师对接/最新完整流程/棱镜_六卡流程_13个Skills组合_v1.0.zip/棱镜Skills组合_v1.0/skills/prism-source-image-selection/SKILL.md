---
name: prism-source-image-selection
description: 依据已选视觉家族从趋势全库检索、查看原图并确定每来源的目标和备选，维护项目/文章/图片身份。用于选图及来源去重；不授予DNA或品质通过。
metadata:
  version: "1.0.0"
---

# 原图召回与目标选择

先读 [组合输入输出合同](../prism_skill_support/references/contracts.md) 的“素材与目标”。消费已选H01及visual-family，不重新投用研偏好票。

用可见关系词和载体词从完整文字库召回；当前可用 [字面召回辅助器](../prism_skill_support/scripts/recall.py)。配置词组、字段权重和队列上限，不按旧卡标题固定答案。输出是文字候选，旧视觉描述和文章名称不能证明实际照片。

在有界文章池中按不同项目/系列和视角组织原图：缓存字节相同则复用；缺图可在当前授权下按给定URL获取。`assets.py acquire --plan plan.json --out originals`默认仅取本地原图，`--download`才GET给定URL，不爬新库或重试。`assets.py gallery`生成内嵌原图导航页。

先看导航，再打开原图与必要备选。每篇最多留一张待入板；记录article_id、source_group_id、image_sha和有实际依据的source_project_id/series_id，未知不能随便合并。文章级去重不冒充完整项目级去重。

选择中性具体的目标：哪个物件、哪种声明状态、哪些可见部位；保留原图大小、像素范围和限制。ID保留整件主要关系；CMF可取局部。不借旁物、包装或黑背景形成想要的特征。不同来源呈现相似关系有助于一致性，不以“新增关系有限”自动排除。

输出候选/拒绝/看不清及理由、目标范围、原图FileRef、建议ROI和原图阅读记录；这些不是品质PASS。校准板永远不混入候选。只选源图，不改色、重画或用生成细节作证据。
