---
name: prism-cmf-moodboard
description: 基于已选语义方向、DNA和目标品质比较当前表面色域、纹样、光感或相邻界面，产生CMF视觉选组。用于局部情绪卡；不推断材料成分或触感。
metadata:
  version: "2.0.0"
---

# 棱镜｜CMF细节第二次握手

读取 [原生H2合同](../prism_skill_support/references/contracts.md) 和 [CMF接口](../prism_skill_support/references/native-api.md)。使用cmf-reference-board-v4；使用同字节别名时全程用alias-cmf。

输入原图、当前comparison_scope、brief、R5已知局部观察、目标绑定、品质bundle和实际视窗。surface的共同条件必须在当前同一声明表面得到支持；same_object_interface的两端必须属于同一物件且确实相邻。不能拼接不同物件的颜色、纹理或光泽。

让比较尺度可比：局部对局部，同一种可见关系为主。父品质范围大于局部时，仅核对实际比较范围的覆盖；不要把父范围所有部件强塞进每张裁片。当前目标变了，需重新绑定及审品质。

具体检查主关系是否被第二强信号抢走。比如有褶纹却同时有明显花色，可能单张符合而整板偏离；色域、纹理、光感允许变化由本家族预先说明。槽纹案例不意味着所有CMF卡都要低彩度。自然题材或深色背景都不自动证明表面特征与高级感。

广候选完整保留，最终精选约10张；同来源/已识别同项目每板最多一张。反例、未决和不适用原因完整列出，不能以没有旧DNA提前排除新素材。

保留原负向和未来义务；需要future-reference适配时走完整同一入口，不能伪造resolved或无关索引。实际选组经accept_grouping后，交裁切/展示处理和 `$prism-board-review`。物理材质、工艺、真实反射率和手感继续保留未知。
