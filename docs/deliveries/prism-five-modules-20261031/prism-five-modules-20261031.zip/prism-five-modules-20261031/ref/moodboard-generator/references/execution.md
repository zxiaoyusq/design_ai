# 情绪板执行

当前生产入口为 `/moodboards`。它读取高潜方向关联的真实图片与已有设计卡，核对范围和预算后，先在明确授权时补缺 DNA，再经 DeepAgents 统一聚类。

所有独立 Skill 和页面统一复用 `backend/app/agents/design_dna_preparation.py` 的执行器，默认模型 `gemini-3.8-flash`。模型地址与密钥由接收方配置，不依赖其他 Agent 或个人登录状态。

底层关系比较仍使用 `.agents/skills/prism-dna-cluster-moodboard` 的规则。新运行按 SDK、模型、配置和输入哈希区分缓存，不复用不同模型的旧执行身份。已有成果可只读回查，原模型、Prompt 与原始状态不改写。

先用页面预览输入，确认图片来源、可复用 DNA、待补项、调用上限和并发，再执行小样。候选板仍需人工审阅；缺图、未知用量或未审阅状态都应如实保留。
