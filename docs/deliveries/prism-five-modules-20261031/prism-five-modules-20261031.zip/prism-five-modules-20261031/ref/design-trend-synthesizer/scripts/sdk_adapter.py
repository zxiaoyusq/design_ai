"""趋势流程的工程内 DeepAgents 适配器；不执行外部 Agent 或命令。"""

from __future__ import annotations

from pathlib import Path
import sys
from time import monotonic

import core

# 独立运行 runner 时仍只接入随交付包提供的后端 SDK，不读取个人 Agent 配置。
_BACKEND = Path(__file__).resolve().parents[3] / "backend"
if not (_BACKEND / "app/agents/bounded.py").is_file():
    raise RuntimeError("缺少工程 backend/app，无法启动内置 DeepAgents 适配器")
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from langchain_core.messages import AIMessage

from app.agents.bounded import AGENT_RUNTIME_VERSION, create_bounded_agent
from app.services.llm import create_chat_model
from app.services.llm.catalog import DEFAULT_MODEL_ID
from app.services.llm.redaction import safe_exception
from app.services.llm.telemetry import ModelCallTelemetry


BUILTIN_ADAPTER = ["deepagents-sdk"]
_PARAMETERS = {"temperature", "top_p", "max_tokens", "max_completion_tokens",
               "reasoning_effort", "seed", "stop"}


def validate_adapter(command):
    """旧参数只接受内置标识，不能用参数数组绕过 SDK 执行其他 Agent。"""
    if command != BUILTIN_ADAPTER:
        raise ValueError('adapter-command-json 仅接受 ["deepagents-sdk"]，不支持外部命令')


def _request_parts(request):
    """核对真实输入哈希，保留原 profile 和顺序，不在适配器中追加研究指令。"""
    profile = request.get("model_profile")
    if profile is None:
        profile = {"model": DEFAULT_MODEL_ID, "parameters": {}}
    if not isinstance(profile, dict) or not isinstance(profile.get("parameters", {}), dict):
        raise ValueError("model_profile 及 parameters 必须是对象")
    model_id = profile.get("model") or DEFAULT_MODEL_ID
    if not isinstance(model_id, str) or not model_id.strip():
        raise ValueError("模型 ID 必须是非空字符串")
    parameters = profile.get("parameters", {})
    if set(parameters) - _PARAMETERS:
        raise ValueError("model_profile.parameters 包含不支持的参数或连接配置")
    messages = request.get("messages")
    if not isinstance(messages, list) or len(messages) < 2:
        raise ValueError("messages 必须包含首条系统提示及待处理文本")
    if any(not isinstance(message, dict) or not isinstance(message.get("content"), str)
           or set(message) != {"role", "content"} for message in messages):
        raise ValueError("趋势适配器只接受 role/content 纯文本消息")
    if messages[0]["role"] != "system" or any(message["role"] not in {"user", "assistant"} for message in messages[1:]):
        raise ValueError("只允许首条 system，其余消息必须为 user 或 assistant")
    message_hash = core.digest(messages)
    for key in ("messages_sha256", "message_sha256"):
        if key in request and request[key] != message_hash:
            raise ValueError("模型输入 messages 哈希不匹配")
    return profile, model_id, parameters, messages, message_hash


def _error_category(exc):
    code = getattr(exc, "status_code", None)
    if code in (401, 403):
        return "authentication"
    if code == 429:
        return "rate_limit"
    if code in (408, 504) or isinstance(exc, TimeoutError) or "timeout" in type(exc).__name__.lower():
        return "timeout"
    if code in (502, 503):
        return "overload"
    if isinstance(exc, (ValueError, TypeError, KeyError, RuntimeError)) or isinstance(code, int) and 400 <= code < 500:
        return "permanent"
    return "transport"


def execute_request(request):
    """一次请求最多一次 DeepAgents 模型调用；重试由上层 runner 记账。"""
    profile, model_id, parameters, messages, message_hash = _request_parts(request)
    model = create_chat_model(model_id, **parameters, timeout=180, max_retries=0)
    agent = create_bounded_agent(
        model=model, system_prompt=messages[0]["content"],
        name="design-trend-synthesizer-sdk", model_call_limit=1,
    )
    telemetry = ModelCallTelemetry()
    result = agent.invoke({"messages": messages[1:]},
                          config={"callbacks": [telemetry], "recursion_limit": 40})
    message = result["messages"][-1]
    if not isinstance(message, AIMessage) or message.tool_calls or message.invalid_tool_calls:
        raise RuntimeError("本阶段只接受模型正文，不能执行工具或委派")
    content = message.content
    raw = content if isinstance(content, str) else "".join(
        block.get("text", "") for block in content
        if isinstance(block, dict) and block.get("type") == "text")
    usage = message.usage_metadata or {}
    observed = telemetry.snapshot()
    if not usage and observed["requests_with_usage"]:
        usage = {"input_tokens": observed["input_tokens"], "output_tokens": observed["output_tokens"]}
    metadata = message.response_metadata or {}
    reported = next((metadata[key] for key in ("model_name", "model", "model_id")
                     if isinstance(metadata.get(key), str) and metadata[key].strip()), None)
    # model 保留兼容性，另列请求身份；没有服务回执时 provider 字段必须为 null。
    return {"status": "ok", "model_profile": profile, "model": reported or model_id,
            "requested_model": model_id, "model_reported_by_provider": reported,
            "response": None, "raw_response": raw,
            "input_tokens": usage.get("input_tokens"), "output_tokens": usage.get("output_tokens"),
            "finish_reason": metadata.get("finish_reason", metadata.get("stop_reason")),
            "observability": {"agent_runtime_version": AGENT_RUNTIME_VERSION,
                              "messages_sha256": message_hash, "telemetry": observed}}


def invoke_builtin(command, request_path, result_path):
    """沿用文件请求/响应协议；失败只写脱敏原因，不保存 SDK 连接信息。"""
    validate_adapter(command)
    started = monotonic()
    try:
        result = execute_request(core.read(request_path))
    except Exception as exc:
        result = {"status": "error", "category": _error_category(exc),
                  "message": safe_exception(exc)}
    result["elapsed_seconds"] = round(monotonic() - started, 3)
    core.write(result_path, result)
    return None
