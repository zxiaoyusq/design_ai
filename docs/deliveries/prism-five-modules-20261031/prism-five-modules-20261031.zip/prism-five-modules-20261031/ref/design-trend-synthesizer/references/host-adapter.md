# 趋势宿主：内置 DeepAgents SDK

本交付版使用内置 `scripts/sdk_adapter.py`，不执行任意外部适配器命令。默认模型为工程目录中的 `gemini-3.8-flash`；连接由接收方配置的 LLM_KEY / LLM_URL 提供。

```bash
python ref/design-trend-synthesizer/scripts/runner.py --run /path/to/run \
  --adapter-command-json '["deepagents-sdk"]'
```

兼容参数只接受上述内置标识，也可省略；其他命令直接拒绝。lean 入口使用同一执行方式。准备阶段不调用模型；实际运行前由使用者核对输入、模型和预算。

执行器保留请求的首条 system 与其余消息顺序，校验 messages_sha256 和 model_profile，使用 create_bounded_agent 限制阶段调用，不委派外部 Agent。raw_response 原文保存，不为满足 Schema 静默改写。

响应文件继续保留 status、model_profile、requested_model、model_reported_by_provider、raw_response、用量及执行观察。供应商未报告的身份与用量保持未知；错误通过统一 safe_exception 脱敏，配置密钥不写入结果。
