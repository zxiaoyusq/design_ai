"""离线审计交付范围和凭据；只报告命中文件与规则，不回显敏感值。"""
from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
import re
from urllib.parse import quote

from prepare_manifest import ROOT, files

PRIVATE_NAMES = {"auth.json", "credentials.json", "secrets.json", "token.json", "tokens.json"}
PATTERNS = {
    "private_key": rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----(?:\\[rn]|\s)+[A-Za-z0-9+/=]{32,}",
    "api_key": rb"(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{32,}",
    "google_api_key": rb"AIza[A-Za-z0-9_-]{35}",
}


def audit(root: Path, secret_values: list[str] = ()) -> dict:
    """精确比对原配置时只在内存保存原值，不将其加入清单或结果。"""
    variants = set()
    for secret in secret_values:
        if secret:
            variants.update((secret.encode(), quote(secret, safe="").encode(), base64.b64encode(secret.encode())))
    findings = []
    checked = 0
    for path in files(root):
        relative = path.relative_to(root).as_posix()
        raw = path.read_bytes()
        checked += 1
        if path.name.lower() in PRIVATE_NAMES or path.suffix.lower() in {".pem", ".key", ".p12"}:
            findings.append({"path": relative, "rule": "private_filename"})
        if any(value in raw for value in variants):
            findings.append({"path": relative, "rule": "configured_secret_value"})
        for name, pattern in PATTERNS.items():
            if re.search(pattern, raw):
                findings.append({"path": relative, "rule": name})
    return {"checked_files": checked, "findings": findings, "secrets_printed": False, "model_calls": 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--private-env", type=Path, help="可选：只读比对本机配置，绝不输出或复制配置值")
    parser.add_argument("--private-values-file", type=Path, help="可选：外部 JSON 字符串数组，供交付负责人比对")
    args = parser.parse_args()
    secrets = []
    if args.private_env:
        from dotenv import dotenv_values
        secrets.extend(value for name, value in dotenv_values(args.private_env).items()
                       if value and len(value) >= 8
                       and (re.search(r"(?i)key|token|secret|password|database_url|llm_url", name))
                       and not value.startswith("replace-with-"))
    if args.private_values_file:
        values = json.loads(args.private_values_file.read_text(encoding="utf-8"))
        if not isinstance(values, list) or any(not isinstance(value, str) for value in values):
            raise ValueError("外部敏感值输入必须是字符串数组")
        secrets.extend(values)
    report = audit(args.root.resolve(), secrets)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(bool(report["findings"]))


if __name__ == "__main__":
    main()
