"""离线验证交付文件的路径、大小和 SHA-256，不连接模型或业务服务。"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "metadata/manifest.json").read_text(encoding="utf-8"))
    failures = []
    for entry in manifest["files"]:
        path = root / entry["path"]
        # 校验清单也按不可信输入处理，不能借此读取交付根目录外的文件。
        if not path.resolve().is_relative_to(root) or path.is_symlink():
            failures.append({"path": entry["path"], "error": "unsafe_path"})
        elif not path.is_file():
            failures.append({"path": entry["path"], "error": "missing"})
        elif path.stat().st_size != entry["bytes"] or hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            failures.append({"path": entry["path"], "error": "content_changed"})
    print(json.dumps({"checked_files": len(manifest["files"]), "failures": failures,
                      "model_calls": 0}, ensure_ascii=False, indent=2))
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
