"""生成可审计的源码文件清单；不读取服务器环境变量文件或运行数据。"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {".git", ".runtime", "node_modules", "dist", "build", "__pycache__",
             ".pytest_cache", ".mypy_cache", ".ruff_cache", ".venv", "data"}
GENERATED = {"metadata/manifest.json", "metadata/source-comparison.json"}
EVIDENCE_MAP = {
    "docs/evidence/情绪版选图.json": "ref/问题反馈/情绪版选图.json",
    "docs/evidence/asset-recovery-recheck.json": "data/result/user_research_intake/asset-recovery-recheck.json",
}


def files(root: Path):
    """固定交付目录，逐层过滤；不跟随软链接到依赖或外部目录。"""
    for entry in sorted(root.iterdir()):
        if entry.name in SKIP_DIRS:
            continue
        if entry.is_symlink():
            raise ValueError(f"交付包含未实体化软链接：{entry.relative_to(ROOT)}")
        if entry.is_dir():
            yield from files(entry)
        elif entry.is_file():
            if entry.name.startswith(".env") and entry.name != ".env.example":
                raise ValueError("交付目录中出现私有环境文件")
            if entry.suffix in {".pyc", ".pyo", ".tsbuildinfo", ".sqlite", ".db", ".zip", ".bundle"}:
                raise ValueError(f"交付目录中出现非源码产物：{entry.relative_to(ROOT)}")
            yield entry


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, document: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="只读源码来源根目录")
    args = parser.parse_args()
    entries = []
    for path in files(ROOT):
        relative = path.relative_to(ROOT).as_posix()
        if relative in GENERATED:
            continue
        source = args.source / EVIDENCE_MAP.get(relative, relative)
        record = {"path": relative, "delivery_sha256": sha(path)}
        if source.is_file():
            record.update(source=EVIDENCE_MAP.get(relative, relative), source_sha256=sha(source))
            record["status"] = "identical" if record["source_sha256"] == record["delivery_sha256"] else "adapted"
        else:
            record["status"] = "new_delivery_file"
        entries.append(record)
    dump(ROOT / "metadata/source-comparison.json", {
        "source_base_commit": "0b627cc77ebc119bfe14ffb000df2129f62d6d47",
        "source_is_working_tree_snapshot": True, "date": "2026-10-31", "files": entries,
        "note": "纳入来源工作区的实际文件；独立交付不携带原仓库历史。来源软链已实体化。"})
    entries = [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size, "sha256": sha(p)}
               for p in files(ROOT) if p.relative_to(ROOT).as_posix() != "metadata/manifest.json"]
    dump(ROOT / "metadata/manifest.json", {"schema": "prism-five-modules-handoff-v1", "date": "2026-10-31",
        "branch": "codex/prism-five-modules-handoff-20261031", "model_calls_during_packaging": 0,
        "contains_production_environment_or_database": False, "contains_business_gallery": False,
        "contains_explicit_demo_login_in_business_handoff": False,
        "agent_framework": "DeepAgents", "default_model": "gemini-3.8-flash",
        "requires_external_agent_cli_or_personal_login": False,
        "file_count": len(entries), "bytes": sum(x["bytes"] for x in entries), "files": entries,
        "manifest_note": "清单不列自身；整个交付压缩包另附 SHA-256。"})
    print(json.dumps({"files": len(entries), "bytes": sum(x["bytes"] for x in entries)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
