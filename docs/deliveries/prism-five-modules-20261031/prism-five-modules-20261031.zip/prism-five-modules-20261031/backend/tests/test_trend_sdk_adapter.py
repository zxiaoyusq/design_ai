"""趋势独立宿主使用真实 DeepAgents 图与假模型，验证调用、身份和脱敏边界。"""

import importlib
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch

from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage
from pydantic import Field


SCRIPTS = Path(__file__).resolve().parents[2] / "ref/design-trend-synthesizer/scripts"
sys.path.insert(0, str(SCRIPTS))
sdk = importlib.import_module("sdk_adapter")


class RecordingModel(FakeMessagesListChatModel):
    received: list = Field(default_factory=list)

    def _generate(self, messages, **kwargs):
        self.received.append(messages)
        return super()._generate(messages, **kwargs)


def request(model="gpt-6-sol"):
    messages = [{"role": "system", "content": "冻结的阶段规则"},
                {"role": "user", "content": "真实用户与趋势原文"},
                {"role": "assistant", "content": "原回复"},
                {"role": "user", "content": "保留证据，只修正指定问题"}]
    return {"messages": messages, "messages_sha256": sdk.core.digest(messages),
            "model_profile": {"model": model, "parameters": {"temperature": 0}}}


class TrendSdkAdapterTests(TestCase):
    def test_frozen_messages_explicit_model_and_raw_invalid_json_are_preserved(self):
        value = request()
        model = RecordingModel(responses=[AIMessage(content="原始且未修复的文本 { invalid")])
        with patch.object(sdk, "create_chat_model", return_value=model) as create:
            result = sdk.execute_request(value)
        create.assert_called_once_with("gpt-6-sol", temperature=0, timeout=180, max_retries=0)
        self.assertEqual(result["model_profile"], value["model_profile"])
        self.assertIsNone(result["model_reported_by_provider"])
        self.assertIsNone(result["response"])
        self.assertEqual(result["raw_response"], "原始且未修复的文本 { invalid")
        self.assertIsNone(result["input_tokens"])
        self.assertEqual(len(model.received), 1)
        self.assertEqual([m.content for m in model.received[0]], [m["content"] for m in value["messages"]])
        self.assertEqual(result["observability"]["messages_sha256"], value["messages_sha256"])

    def test_provider_reported_identity_and_real_usage_are_recorded(self):
        model = RecordingModel(responses=[AIMessage(
            content=[{"type": "text", "text": "# 方向正文"}],
            response_metadata={"model_name": "gemini-service-reported", "finish_reason": "stop"},
            usage_metadata={"input_tokens": 11, "output_tokens": 7, "total_tokens": 18})])
        with patch.object(sdk, "create_chat_model", return_value=model):
            result = sdk.execute_request(request("gemini-3.8-flash"))
        self.assertEqual(result["requested_model"], "gemini-3.8-flash")
        self.assertEqual(result["model_reported_by_provider"], "gemini-service-reported")
        self.assertEqual((result["input_tokens"], result["output_tokens"]), (11, 7))
        self.assertEqual(result["raw_response"], "# 方向正文")

    def test_missing_profile_defaults_to_gemini_without_changing_the_input_file(self):
        value = request()
        del value["model_profile"]
        model = RecordingModel(responses=[AIMessage(content="正文")])
        with TemporaryDirectory() as folder:
            source, target = Path(folder) / "request.json", Path(folder) / "result.json"
            sdk.core.write(source, value)
            original = source.read_bytes()
            with patch.object(sdk, "create_chat_model", return_value=model) as create:
                self.assertIsNone(sdk.invoke_builtin(["deepagents-sdk"], source, target))
            create.assert_called_once_with("gemini-3.8-flash", timeout=180, max_retries=0)
            self.assertEqual(source.read_bytes(), original)
            self.assertEqual(sdk.core.read(target)["status"], "ok")

    def test_altered_hash_is_rejected_before_creating_any_model(self):
        value = request()
        value["messages"][1]["content"] = "被替换的来源"
        with patch.object(sdk, "create_chat_model") as create:
            with self.assertRaisesRegex(ValueError, "哈希不匹配"):
                sdk.execute_request(value)
            create.assert_not_called()

    def test_external_commands_cannot_run(self):
        with patch.object(sdk, "execute_request") as execute:
            with self.assertRaisesRegex(ValueError, "不支持外部命令"):
                sdk.invoke_builtin(["python", "outside-agent.py"], Path("missing"), Path("result"))
            execute.assert_not_called()

    def test_failures_do_not_save_the_gateway_key(self):
        fake_key = "synthetic-test-secret-93249259"
        with TemporaryDirectory() as folder:
            source, target = Path(folder) / "request.json", Path(folder) / "result.json"
            sdk.core.write(source, request())
            with patch.dict(os.environ, {"LLM_KEY": fake_key}), patch.object(
                    sdk, "create_chat_model", side_effect=RuntimeError("gateway rejected " + fake_key)):
                sdk.invoke_builtin(["deepagents-sdk"], source, target)
            self.assertNotIn(fake_key, target.read_text())
            result = json.loads(target.read_text())
            self.assertEqual(result["status"], "error")
            self.assertIn("[REDACTED]", result["message"])
