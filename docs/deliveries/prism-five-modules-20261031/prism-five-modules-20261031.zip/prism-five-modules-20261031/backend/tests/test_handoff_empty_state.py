"""交付包空业务目录与损坏资料的区分；全部离线，不使用真实账号或模型。"""

import json

import pytest

from app.api import article_trends, high_trends, moodboards, user_research
from app.services.article_trends.catalog import ArticleCatalog
from app.services.article_trends.history import HistoricalTrendResults
from app.services.dna import preparation, storage
from app.services.high_trends.tasks import HighTrendManager
from app.services.moodboards.clustering import MoodboardClusteringManager
from app.services.moodboards.saved_results import SavedMoodboardResults, RUNS
from app.services.moodboards.sources import MoodboardSources
from app.services.moodboards.tasks import MoodboardManager
from app.services.user_research.storage import ResearchStore
from app.services.user_research.tasks import ResearchTasks
from tests.auth_helpers import authenticated_client


def test_five_modules_can_be_browsed_before_business_data_import(tmp_path, monkeypatch):
    monkeypatch.setattr(preparation, "FROZEN_MANIFEST", tmp_path / "historical/prepared-manifest.json")
    monkeypatch.setattr(preparation, "WEB_ROOT", tmp_path / "data/result/dna_preparation_web")
    monkeypatch.setattr(storage, "RESULTS_DIR", tmp_path / "data/result")
    monkeypatch.setattr(storage, "UPLOADS_DIR", tmp_path / "data/uploads")
    monkeypatch.setattr(article_trends.cluster_manager, "catalog", ArticleCatalog(tmp_path))
    monkeypatch.setattr(article_trends.cluster_manager, "output", tmp_path / "data/result/article_trend_clustering")
    monkeypatch.setattr(article_trends, "historical_results", HistoricalTrendResults(tmp_path))
    monkeypatch.setattr(high_trends, "high_trend_manager", HighTrendManager(tmp_path))
    store = ResearchStore(tmp_path / "data/result/user_research_intake",
                          tmp_path / "data/userreseach_data/users_selected_5.json")
    monkeypatch.setattr(user_research, "store", store)
    monkeypatch.setattr(user_research, "manager", ResearchTasks(store))
    monkeypatch.setattr(moodboards, "moodboard_clustering_manager", MoodboardClusteringManager(tmp_path))
    monkeypatch.setattr(moodboards, "saved_moodboard_results", SavedMoodboardResults(tmp_path))
    monkeypatch.setattr(moodboards, "moodboard_manager", MoodboardManager(tmp_path))

    client = authenticated_client()
    paths = ["/dna/images", "/dna-v2/preparation", "/dna-v2/results", "/article-trends/catalog",
             "/article-trends/articles", "/article-trends/history", "/article-trends/tasks",
             "/user-research/users", "/user-research/tasks", "/high-trends/catalog",
             "/high-trends/inputs", "/high-trends/tasks", "/moodboards/clustering/catalog",
             "/moodboards/clustering/saved-results", "/moodboards/clustering/tasks",
             "/moodboards/tasks", "/moodboards/catalog"]
    results = {}
    for path in paths:
        response = client.get("/api/v1" + path)
        assert response.status_code == 200, (path, response.text)
        results[path] = response.json()
    assert results["/dna-v2/results"] == []
    assert results["/dna-v2/preparation"]["counts"]["images"] == 0
    assert results["/dna-v2/preparation"]["snapshot_id"] is None
    assert results["/user-research/users"]["users"] == []
    assert results["/high-trends/inputs"] == {"research_outputs": [], "trend_outputs": []}
    assert results["/moodboards/clustering/catalog"]["results"] == []
    assert results["/moodboards/clustering/catalog"]["warnings"] == []
    assert results["/moodboards/clustering/saved-results"] == {"default_result_id": None, "results": []}
    assert preparation._prior_for_upload("not-in-empty-library")[0] is None


def test_existing_broken_snapshots_are_not_presented_as_empty_success(tmp_path, monkeypatch):
    manifest = tmp_path / "historical/prepared-manifest.json"
    manifest.parent.mkdir()
    manifest.write_text("not-json", encoding="utf-8")
    monkeypatch.setattr(preparation, "FROZEN_MANIFEST", manifest)
    with pytest.raises(json.JSONDecodeError):
        preparation.list_prepared_results()
    manifest.unlink()
    with pytest.raises(FileNotFoundError):
        preparation.preparation_overview()
    result_id = next(iter(RUNS))
    (tmp_path / RUNS[result_id]["folder"]).mkdir(parents=True)
    with pytest.raises(FileNotFoundError):
        SavedMoodboardResults(tmp_path).list()


def test_new_empty_sources_do_not_mask_malformed_business_json(tmp_path):
    path = tmp_path / "data/trend_data/trends.json"
    path.parent.mkdir(parents=True)
    path.write_text("not-json", encoding="utf-8")
    with pytest.raises(json.JSONDecodeError):
        HighTrendManager(tmp_path).catalog()
    native = tmp_path / "data/result/semantic_handshake/sol61_native_v2_20261006"
    native.mkdir(parents=True)
    assert MoodboardSources(tmp_path).catalog()["warnings"]
