"""模型目录测试。"""

import unittest

from app.api.llm import read_available_models
from app.schemas.article_trends import ClusterRequest
from app.schemas.dna import ExtractionRequest
from app.schemas.high_trends import HighTrendRequest
from app.schemas.moodboards import MoodboardClusteringRequest, MoodboardRequest
from app.services.llm.catalog import DEFAULT_MODEL_ID, ModelProvider, get_model, list_models
from app.services.visual_workflow.colleague_v2 import default_project_policy


class ModelCatalogTestCase(unittest.TestCase):
    def test_catalog_contains_all_configured_models(self) -> None:
        self.assertEqual(
            [model.id for model in list_models()],
            [
                "claude-opus-5-20260820",
                "gpt-5.6-terra",
                "gpt-6-sol",
                "MiniMax-M3",
                "qwen3.8-max-20260820",
                "deepseek-v4-pro-official",
                "gemini-3.7-flash",
                "gemini-3.8-flash",
            ],
        )

    def test_provider_mapping_is_explicit(self) -> None:
        self.assertIs(
            get_model("claude-opus-5-20260820").model_provider,
            ModelProvider.ANTHROPIC,
        )
        self.assertIs(
            get_model("qwen3.8-max-20260820").model_provider,
            ModelProvider.OPENAI,
        )

    def test_unknown_model_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "不支持模型"):
            get_model("unknown-model")

    def test_api_recommends_the_shared_new_task_default(self) -> None:
        response = read_available_models()
        self.assertEqual(response.default_model, "gemini-3.8-flash")
        self.assertEqual(
            [model.id for model in response.models if model.recommended],
            [DEFAULT_MODEL_ID],
        )

    def test_all_request_defaults_use_gemini_and_preserve_explicit_models(self) -> None:
        requests = (
            (ExtractionRequest, {"image_ids": ["sample"]}),
            (ClusterRequest, {}),
            (HighTrendRequest, {"all_dates": True}),
            (MoodboardClusteringRequest, {"preview_id": "mbp_" + "a" * 32, "confirmed": True}),
            (MoodboardRequest, {"trend_task_id": "trend", "direction_ids": ["one"],
                               "result_ids": ["result"], "confirmed": True}),
        )
        for request_type, parameters in requests:
            with self.subTest(request_type=request_type.__name__):
                self.assertEqual(request_type(**parameters).model_id, DEFAULT_MODEL_ID)
                self.assertEqual(request_type(model_id="gpt-6-sol", **parameters).model_id, "gpt-6-sol")

    def test_new_project_contract_uses_the_shared_model_default(self) -> None:
        policy = default_project_policy({"target": 10}, {"maximum_calls": 1})
        self.assertEqual(policy["model_policy"]["model"], DEFAULT_MODEL_ID)
        self.assertTrue(policy["model_calls_paused"])


if __name__ == "__main__":
    unittest.main()
