"""原生通用请求也必须走工程 SDK；只使用临时文本和假模型执行器。"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

import pytest

from app.agents import design_dna_preparation
from app.services.llm.redaction import redact_sensitive_value, safe_exception

ROOT = Path(__file__).resolve().parents[2]


def module():
    scripts = ROOT / ".agents/skills/prism_skill_support/scripts"
    sys.path.insert(0, str(scripts))
    spec = importlib.util.spec_from_file_location("handoff_support_sdk", scripts / "run_model.py")
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def job(tmp_path, *, authorized=True):
    (tmp_path / "prompt.txt").write_text("只按原文判断。", encoding="utf-8")
    (tmp_path / "schema.json").write_text(json.dumps({"type": "object", "required": ["ok"],
        "properties": {"ok": {"type": "boolean"}}, "additionalProperties": False}), encoding="utf-8")
    path = tmp_path / "job.json"
    path.write_text(json.dumps({"stage": "test", "call_id": "C1", "prompt_path": "prompt.txt",
        "schema_path": "schema.json", "execution_authorization": {"allowed": authorized,
        "basis": "offline fixture", "maximum_attempts": 1}}), encoding="utf-8")
    return path


def test_prepare_needs_no_credentials_or_other_agent(tmp_path):
    with patch("app.services.llm.settings.get_llm_settings", side_effect=AssertionError("should not read credentials")), \
         patch.object(design_dna_preparation, "execute_structured") as execute:
        result = module().run(job(tmp_path), tmp_path / "prepared")
    assert result["model_calls"] == 0
    assert not execute.called
    request = json.loads((tmp_path / "prepared/request.json").read_bytes())
    assert request["execution_config"]["model"] == "gemini-3.8-flash"
    assert request["framework"] == "DeepAgents"
    assert "command_argv" not in request


def test_execution_uses_shared_sdk_and_original_schema(tmp_path):
    with patch.object(design_dna_preparation, "execute_structured", return_value={"ok": True}) as execute:
        result = module().run(job(tmp_path), tmp_path / "executed", True)
    assert result["schema_valid"] is True
    assert execute.call_count == 1
    assert execute.call_args.kwargs["model_id"] == "gemini-3.8-flash"
    assert execute.call_args.kwargs["timeout_seconds"] == 600
    assert json.loads((tmp_path / "executed/answer.json").read_bytes()) == {"ok": True}


def test_no_implicit_execution_and_no_schema_repair(tmp_path):
    with patch.object(design_dna_preparation, "execute_structured") as execute:
        with pytest.raises(ValueError, match="授权"):
            module().run(job(tmp_path, authorized=False), tmp_path / "denied", True)
    assert not execute.called
    with patch.object(design_dna_preparation, "execute_structured", return_value={"ok": "yes"}) as execute:
        with pytest.raises(RuntimeError):
            module().run(job(tmp_path), tmp_path / "invalid", True)
    assert execute.call_count == 1
    assert not (tmp_path / "invalid/answer.json").exists()


def test_credential_fields_and_gateway_error_are_redacted(monkeypatch):
    fixture = "local-only-fixture-credential"
    monkeypatch.setenv("LLM_KEY", fixture)
    metadata = redact_sensitive_value({"access_token": fixture, "request_headers": {"Authorization": fixture},
        "usage": {"input_tokens": 4}, "error": "provider echoed " + fixture})
    assert fixture not in json.dumps(metadata)
    assert metadata["usage"]["input_tokens"] == 4
    assert fixture not in safe_exception(RuntimeError("provider echoed " + fixture))
