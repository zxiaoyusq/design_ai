"""统一大模型客户端测试。"""

import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from langchain_core.language_models.fake_chat_models import FakeListChatModel, FakeMessagesListChatModel
from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage, SystemMessage
from pydantic import Field

from app.services.llm.client import (
    _normalize_anthropic_stream_event,
    create_chat_model,
    invoke_model,
    stream_model,
)
from app.services.llm.settings import LLMSettings


class RecordingModel(FakeListChatModel):
    """记录真实 DeepAgents 传给模型的同步/流式消息，不访问网关。"""

    received: list = Field(default_factory=list)

    def _generate(self, messages, **kwargs):
        self.received.append(messages)
        return super()._generate(messages, **kwargs)

    def _stream(self, messages, **kwargs):
        self.received.append(messages)
        yield from super()._stream(messages, **kwargs)


class LLMClientTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.settings = LLMSettings(
            llm_key="test-key",
            llm_url="https://gateway.example.com",
        )

    @patch("app.services.llm.client.GatewayCompatibleChatAnthropic")
    def test_anthropic_model_uses_anthropic_provider_options(self, factory: Mock) -> None:
        create_chat_model(
            "claude-opus-5-20260820",
            settings=self.settings,
            temperature=0,
        )

        factory.assert_called_once_with(
            model="claude-opus-5-20260820",
            base_url="https://gateway.example.com",
            api_key="test-key",
            temperature=0,
        )

    @patch("app.services.llm.client.langchain_init_chat_model")
    def test_openai_compatible_model_uses_openai_provider_options(self, factory: Mock) -> None:
        create_chat_model("MiniMax-M3", settings=self.settings)

        factory.assert_called_once_with(
            model="MiniMax-M3",
            model_provider="openai",
            base_url="https://gateway.example.com/v1",
            api_key="test-key",
        )

    @patch("app.services.llm.client.langchain_init_chat_model")
    def test_openai_base_url_does_not_duplicate_v1(self, factory: Mock) -> None:
        settings = LLMSettings(
            llm_key="test-key",
            llm_url="https://gateway.example.com/v1/",
        )

        create_chat_model("qwen3.8-max-20260820", settings=settings)

        self.assertEqual(factory.call_args.kwargs["base_url"], "https://gateway.example.com/v1")

    def test_connection_options_cannot_be_overridden(self) -> None:
        with self.assertRaisesRegex(ValueError, "不允许覆盖"):
            create_chat_model(
                "qwen3.8-max-20260820",
                settings=self.settings,
                base_url="https://untrusted.example.com",
            )

    def test_anthropic_dict_context_event_is_normalized(self) -> None:
        event = Mock()
        event.context_management = {"applied_edits": []}
        event.model_copy.return_value = SimpleNamespace(
            context_management=event.context_management
        )
        event.model_copy.side_effect = lambda *, update: SimpleNamespace(**update)

        normalized = _normalize_anthropic_stream_event(event)

        self.assertEqual(
            normalized.context_management.model_dump(),
            {"applied_edits": []},
        )

    @patch("app.services.llm.client.create_chat_model")
    def test_invoke_and_stream_use_bounded_deepagents_and_preserve_messages(self, factory: Mock) -> None:
        chat_model = RecordingModel(responses=["你好"])
        factory.return_value = chat_model
        messages = [SystemMessage(content="原始系统规则"), HumanMessage(content=[
            {"type": "text", "text": "请阅读图片"},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64,c3ludGhldGlj"}},
        ])]
        config = {"tags": ["offline-check"], "recursion_limit": 40}
        result = invoke_model("gemini-3.8-flash", messages, settings=self.settings,
                              model_options={"temperature": 0}, stop=["END"], config=config)
        chunks = list(
            stream_model("gemini-3.8-flash", messages, settings=self.settings, config=config)
        )
        self.assertEqual(factory.call_count, 2)
        self.assertEqual(factory.call_args_list[0].kwargs,
                         {"settings": self.settings, "max_retries": 0, "temperature": 0, "stop": ["END"]})
        self.assertEqual(result.content, "你好")
        self.assertTrue(all(isinstance(chunk, AIMessageChunk) for chunk in chunks))
        self.assertEqual("".join(chunk.content for chunk in chunks), "你好")
        self.assertEqual(len(chat_model.received), 2)
        for received in chat_model.received:
            self.assertEqual([m.content for m in received], [m.content for m in messages])
        self.assertEqual(messages[0].content, "原始系统规则")
        self.assertEqual(config, {"tags": ["offline-check"], "recursion_limit": 40})

    @patch("app.services.llm.client.create_chat_model")
    def test_plain_text_and_nonstreaming_model_yield_only_ai_chunks(self, factory: Mock) -> None:
        factory.return_value = FakeMessagesListChatModel(responses=[AIMessage(content="完整正文")])
        chunks = list(stream_model("gemini-3.8-flash", "用户输入", settings=self.settings))
        self.assertTrue(chunks)
        self.assertTrue(all(isinstance(chunk, AIMessageChunk) for chunk in chunks))
        self.assertEqual("".join(chunk.content for chunk in chunks), "完整正文")

    @patch("app.services.llm.client.create_chat_model")
    def test_tools_are_rejected_instead_of_delegating(self, factory: Mock) -> None:
        factory.return_value = FakeMessagesListChatModel(responses=[AIMessage(content="", tool_calls=[
            {"name": "task", "args": {}, "id": "forbidden"},
        ])])
        with self.assertRaisesRegex(RuntimeError, "禁止调用工具或子代理"):
            invoke_model("gemini-3.8-flash", "输入", settings=self.settings)


if __name__ == "__main__":
    unittest.main()
