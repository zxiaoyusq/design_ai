"""R5 执行迁移的离线验证：真实 DeepAgents 图、保存响应、无外部Agent。"""

import hashlib
import importlib.util
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch

from langchain_core.messages import AIMessage
from PIL import Image

from app.agents import design_dna_preparation as adapter
from app.services.dna import prism_r5
from tests.test_dna_preparation_web import RecordingModel


class R5DeepAgentsRuntimeTests(TestCase):
    def setUp(self):
        self.runtime = prism_r5._execution_runtime()
        self.skill = prism_r5.SKILL_ROOT

    def _model(self):
        return RecordingModel(responses=[AIMessage(
            content=(self.skill / 'examples/H11' / name).read_text(),
            response_metadata={'model_name': 'gemini-3.8-flash-provider-report'},
            usage_metadata={'input_tokens': 10, 'output_tokens': 20, 'total_tokens': 30},
        ) for name in ('primary.json', 'focus.json')])

    def test_new_default_uses_deepagents_and_original_schema_with_bounded_focus(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            image = root / 'source.png'
            image.write_bytes(b'offline-source-image')
            model = self._model()
            with patch.object(adapter, 'create_chat_model', return_value=model) as factory:
                result = self.runtime.run_extraction(image=image, image_id='H11', out=root / 'run',
                                                     execute=True, timeout=90)
            self.assertEqual(result['model'], 'gemini-3.8-flash')
            self.assertEqual(result['framework'], 'DeepAgents')
            self.assertIsNone(result['reasoning_effort'])
            self.assertEqual(result['actual_models'], ['gemini-3.8-flash-provider-report'] * 2)
            self.assertEqual(result['model_calls'], 2)
            self.assertEqual(len(model.received), 2)
            for invocation in factory.call_args_list:
                self.assertEqual(invocation.args, ('gemini-3.8-flash',))
                self.assertEqual(invocation.kwargs['timeout'], 90)
                self.assertEqual(invocation.kwargs['max_retries'], 0)
            ledger = json.loads((root / 'run/call-ledger.json').read_text())
            self.assertEqual(ledger['limit'], 2)
            self.assertFalse(ledger['automatic_retries'])
            for call in ledger['calls']:
                self.assertEqual(call['state'], 'response_received')
            primary = root / 'run/calls/P-H11'
            self.assertEqual((primary / 'schema.json').read_bytes(), (root / 'run/primary.schema.json').read_bytes())
            self.assertEqual((primary / 'prompt.txt').read_text().rstrip('\n'),
                             (self.skill / 'assets/primary.prompt.txt').read_text().rstrip('\n'))
            request = json.loads((primary / 'request.json').read_text())
            self.assertNotIn('command', request)
            self.assertEqual(request['image_sha256'], hashlib.sha256(image.read_bytes()).hexdigest())

    def test_failed_primary_stops_without_retry_and_redacts_exception(self):
        class FailureModel(RecordingModel):
            def _generate(self, messages, **kwargs):
                self.received.append(messages)
                raise ValueError('invalid header: Authorization Bearer private-r5-test-key')

        with TemporaryDirectory() as folder:
            root = Path(folder)
            image = root / 'source.png'
            image.write_bytes(b'offline-source-image')
            model = FailureModel(responses=[AIMessage(content='unused')])
            with patch.object(adapter, 'create_chat_model', return_value=model):
                result = self.runtime.run_extraction(image=image, image_id='H11', out=root / 'run', execute=True)
            self.assertEqual(result['status'], 'primary_failed_no_retry')
            self.assertEqual(len(model.received), 1)
            self.assertFalse((root / 'run/result.json').exists())
            receipt = json.loads((root / 'run/calls/P-H11/receipt.json').read_text())
            self.assertEqual(receipt['state'], 'failed_no_retry')
            for item in (root / 'run').rglob('*.json'):
                self.assertNotIn('private-r5-test-key', item.read_text())

    def test_preparation_and_doctor_do_not_read_connection_secrets(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            image = root / 'source.png'
            image.write_bytes(b'offline-source-image')
            with patch('app.services.llm.settings.get_llm_settings', side_effect=AssertionError('credentials read')):
                prepared = self.runtime.run_extraction(image=image, image_id='IMG001', out=root / 'prepared')
                doctor = self.runtime.doctor()
            self.assertEqual(prepared['status'], 'prepared_only')
            self.assertFalse(doctor['model_request_sent'])
            self.assertTrue(doctor['ready'])
            self.assertFalse((root / 'prepared/call-ledger.json').exists())

    def test_original_strict_decoder_still_rejects_duplicate_keys(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            image = root / 'source.png'
            image.write_bytes(b'offline-source-image')
            primary = (self.skill / 'examples/H11/primary.json').read_text().strip()
            model = RecordingModel(responses=[AIMessage(content='{"areas":[],' + primary[1:])])
            with patch.object(adapter, 'create_chat_model', return_value=model):
                result = self.runtime.run_extraction(image=image, image_id='H11', out=root / 'run', execute=True)
            self.assertEqual(result['status'], 'primary_failed_no_retry')
            self.assertEqual(len(model.received), 1)
            receipt = json.loads((root / 'run/calls/P-H11/receipt.json').read_text())
            self.assertIn('Duplicate JSON key', receipt['error'])

    def test_wire_preparation_emits_only_sdk_plan_and_validates_original_response(self):
        spec = importlib.util.spec_from_file_location('r5_wire_sdk_test', self.skill / 'scripts/wire_adapter.py')
        wire = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(wire)
        with TemporaryDirectory() as folder:
            root = Path(folder)
            image = root / 'source.png'
            image.write_bytes(b'offline-source-image')
            plan = wire.prepare(self.skill, image, 'H11', 'P-H11', root / 'plan')
            request = json.loads((root / 'plan/planned-request.json').read_text())
            self.assertEqual(request['model_id'], 'gemini-3.8-flash')
            self.assertEqual(request['executor'], 'app.agents.design_dna_preparation.execute_structured')
            self.assertNotIn('argv', request)
            self.assertFalse((root / 'plan/planned-command.json').exists())
            wrapper = root / 'wrapper.json'
            wrapper.write_text(json.dumps({'binding_id': plan['binding_id'], 'normative_result_json':
                (self.skill / 'examples/H11/primary.json').read_text()}))
            result = wire.validate_response(root / 'plan', wrapper, root / 'validation', 'offline_saved_response')
            self.assertEqual(result['status'], 'normative_and_original_primary_gate_passed')
            self.assertEqual(result['new_model_calls'], 0)

    def test_historical_frozen_examples_still_replay_without_model_calls(self):
        result = self.runtime.replay_examples()
        self.assertTrue(result['passed'])
        self.assertEqual(result['new_model_calls'], 0)

    def test_web_legacy_entry_uses_same_sdk_without_external_process_or_auth(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            image = root / 'source.png'
            Image.new('RGB', (8, 8), color='white').save(image)
            result_dir = root / 'data/result/d02'
            model = self._model()
            with patch.object(prism_r5, 'PROJECT_ROOT', root), \
                 patch.object(prism_r5, 'RESULT_DIR', result_dir), \
                 patch.object(prism_r5, 'RUN_DIR', result_dir / 'r5_runs'), \
                 patch.object(prism_r5, 'save_result_image') as archive, \
                 patch.object(adapter, 'create_chat_model', return_value=model):
                output = prism_r5.run_prism_r5_extraction(image_path=image, content_type='image/png', user_prompt='')
            payload = json.loads((result_dir / f'{output.result_id}.json').read_text())
            self.assertEqual(payload['execution']['model_id'], 'gemini-3.8-flash')
            self.assertEqual(payload['execution']['adapter'], 'deepagents_r5_project_sdk')
            self.assertEqual(payload['execution']['framework'], 'DeepAgents')
            self.assertEqual(payload['execution']['attempted_calls'], 2)
            self.assertTrue(payload['validation']['primary_schema_valid'])
            self.assertEqual(payload['r5_result']['algorithm_version'], self.runtime.load_original().VERSION)
            archive.assert_called_once_with(output.result_id, image)
