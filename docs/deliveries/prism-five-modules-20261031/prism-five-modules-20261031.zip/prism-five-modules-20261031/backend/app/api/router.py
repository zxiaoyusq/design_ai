"""后端 API 路由汇总。"""

from fastapi import APIRouter, Depends

from app.api.auth import require_user

from app.api.dna import router as dna_router
from app.api.article_trends import router as article_trends_router
from app.api.dna_v2 import router as dna_v2_router
from app.api.llm import router as llm_router
from app.api.user_research import router as user_research_router
from app.api.high_trends import router as high_trends_router
from app.api.high_trend_image_review import router as high_trend_image_review_router
from app.api.moodboards import router as moodboards_router


# 在汇总路由挂载依赖，后续新增业务模块也默认要求登录。
api_router = APIRouter(dependencies=[Depends(require_user)])
api_router.include_router(article_trends_router)
api_router.include_router(llm_router)
api_router.include_router(dna_router)
api_router.include_router(dna_v2_router)
api_router.include_router(high_trends_router)
api_router.include_router(high_trend_image_review_router)
api_router.include_router(moodboards_router)

api_router.include_router(user_research_router)
