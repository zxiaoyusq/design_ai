"""R5 算法的网页薄适配；新任务统一走 DeepAgents，保留历史结果格式。"""

from __future__ import annotations

import hashlib
import importlib.util
import json
from dataclasses import dataclass
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path
from time import monotonic
from typing import Any
from uuid import uuid4

from app.agents.prism_dna_sol_r5 import (
    PRIMARY_PROMPT_PATH,
    PRIMARY_SCHEMA_PATH,
    PROMPT_VERSION,
    SKILL_NAME,
    SKILL_ROOT,
    DEFAULT_MODEL,
)
from app.schemas.dna import ExtractionStage, ProgressEventLevel
from app.services.dna.storage import PROJECT_ROOT, RESULTS_DIR, _atomic_write, save_result_image
from app.services.llm.catalog import get_model
from app.services.llm.redaction import safe_exception


RESULT_DIR = RESULTS_DIR / "d02"
RUN_DIR = RESULT_DIR / "r5_runs"


@dataclass(frozen=True)
class R5Output:
    result_id: str


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _safe_exception(exc: Exception) -> str:
    """兼容旧导入名，所有新失败回执复用工程统一脱敏规则。"""
    return safe_exception(exc)


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_json(path: Path, value: Any) -> None:
    _atomic_write(path, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8"))


@lru_cache(maxsize=1)
def _portable():
    """包内 R5 冻结源码与资产哈希由原便携加载器验证，不复制另一套字段规则。"""

    path = SKILL_ROOT / "scripts" / "engine.py"
    spec = importlib.util.spec_from_file_location("prism_sol_r5_portable_engine", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Sol R5 便携整理器不可读取")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, module.load_original()


@lru_cache(maxsize=1)
def _execution_runtime():
    """延迟加载共享 CLI 核心，避免统一 SDK 适配器引用脱敏函数时循环导入。"""
    path = SKILL_ROOT / "scripts/cli.py"
    spec = importlib.util.spec_from_file_location("prism_sol_r5_sdk_runtime", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("R5 DeepAgents 执行入口不可读取")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_r5_request(model_id: str, user_prompt: str, reasoning_effort: str = "low") -> None:
    """冻结领域提示与字段规则；模型按工程目录选择，默认 Gemini Flash。"""
    get_model(model_id)
    if user_prompt.strip():
        raise ValueError("Sol R5 使用冻结提取提示，不接受附加关注点；设计判断请在独立视觉审阅阶段完成")


def ensure_r5_execution_allowed() -> None:
    """只有新模型调用读取暂停边界；历史结果展示不受此限制。"""
    boundary_path = PROJECT_ROOT / "data/result/visual_workflow/h01_all13_20261005_expanded/execution-boundary.json"
    if boundary_path.is_file():
        boundary = json.loads(boundary_path.read_text(encoding="utf-8"))
        if boundary.get("all_model_calls_paused"):
            raise RuntimeError("模型调用已暂停；本次 Skill 更新不会启动新的 DNA 提取")


def run_prism_r5_extraction(
    *, image_path: Path, content_type: str, model_id: str = DEFAULT_MODEL, user_prompt: str,
    progress_callback: Any = None, source_record: dict[str, Any] | None = None,
    reasoning_effort: str = "low", single_request: bool = False,
) -> R5Output:
    """复用 R5 核心及同进程 DeepAgents 执行，只包装网页历史兼容格式。"""
    validate_r5_request(model_id, user_prompt, reasoning_effort)
    ensure_r5_execution_allowed()
    portable, engine = _portable()
    result_id = uuid4().hex
    run_dir = RUN_DIR / result_id
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    started = datetime.now(UTC)
    timer = monotonic()
    image_path = image_path.resolve(strict=True)
    image_hash = _sha(image_path)
    metadata_path = image_path.parent / "metadata.json"
    source_metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.is_file() else None
    image_id = image_hash[:32]
    if progress_callback:
        progress_callback(ExtractionStage.MODEL_ANALYSIS, "使用 DeepAgents 按 R5 规则解析原图，最多一次困难项复核", 12, ProgressEventLevel.INFO)
    try:
        _execution_runtime().run_extraction(image=image_path, image_id=image_id, out=run_dir,
                                            execute=True, model_id=model_id)
        if run_dir.is_dir():
            _write_json(run_dir / "web-invocation.json", {"framework": "DeepAgents", "model": model_id,
                        "transport": "project_langchain_sdk", "native_prompt_changed": False,
                        "schema_supplied_to_model": True, "connection_secrets_recorded": False})
        if not (run_dir / "result.json").is_file():
            raise RuntimeError("R5 SDK 未产生提取结果，请查看运行记录；不重试、不切换模型")
        final = portable.read(run_dir / "result.json")
        if final.get("image_sha256") != image_hash or final.get("model") != model_id:
            raise ValueError("R5 结果图片身份或模型与本次请求不一致")
        ledger = portable.read(run_dir / "call-ledger.json")
        primary_dir = run_dir / "calls" / ("P-" + image_id)
        focus_dir = run_dir / "calls" / ("F-" + image_id)
        primary_receipt = portable.read(primary_dir / "receipt.json")
        focus_receipt = portable.read(focus_dir / "receipt.json") if focus_dir.is_dir() else None
        # CLI 中困难项失败仍可产生 partial；保留原状态，不把原生未决结果包装成视觉合格。
        if not primary_receipt["schema_valid"]:
            raise ValueError("原生首次解析未通过结构校验")
        finished = datetime.now(UTC)
        payload = {
            "id": result_id, "skill": SKILL_NAME, "schema_version": "prism_sol_r5_candidate_v1",
            "image_name": image_path.name, "created_at": finished.isoformat(),
            "source": {"image_id": image_id, "image_sha256": image_hash, "image_filename": image_path.name,
                       "content_type": content_type, "upload_metadata": source_metadata,
                       "upload_metadata_sha256": _sha(metadata_path) if metadata_path.is_file() else None,
                       "research": source_record},
            "execution": {"model_id": model_id, "adapter": "deepagents_r5_project_sdk", "framework": "DeepAgents",
                          "transport": "project_langchain_sdk", "reasoning_effort": final.get("reasoning_effort"),
                          "actual_models": final.get("actual_models"), "actual_served_tier": "not_exposed",
                          "user_prompt": "", "started_at": started.isoformat(), "finished_at": finished.isoformat(),
                          "duration_seconds": round(monotonic() - timer, 3), "prompt_version": PROMPT_VERSION,
                          "skill_sha256": _sha(SKILL_ROOT / "SKILL.md"), "prompt_asset_sha256": _sha(PRIMARY_PROMPT_PATH),
                          "schema_asset_sha256": _sha(PRIMARY_SCHEMA_PATH), "source_manifest_sha256": _sha(SKILL_ROOT / "assets/source-manifest.json"),
                          "algorithm_version": engine.VERSION, "max_calls": ledger["limit"], "automatic_retries": False,
                          "attempted_calls": len(ledger["calls"]), "primary_usage": primary_receipt.get("usage"),
                          "focus_usage": focus_receipt.get("usage") if focus_receipt else None,
                          "focus_error": focus_receipt.get("error") if focus_receipt else None,
                          "trace_dir": str(run_dir.relative_to(PROJECT_ROOT)), "native_status": final["status"],
                          "native_result_sha256": _sha(run_dir / "result.json"), "native_prompt_changed": False,
                          "schema_supplied_to_model": True, "connection_secrets_recorded": False},
            "validation": {"primary_schema_valid": True, "focus_complete": not focus_receipt or focus_receipt["schema_valid"],
                           "pending_count": final["pending_count"], "invalid_count": len(final["invalid"]),
                           "full_216_visual_qualified": False, "human_gold_accuracy_established": False,
                           "note": "冻结 Sol R5 原生结果；网页仅适配展示，不赋予视觉审阅或偏好通过。"},
            "r5_result": final,
            "raw_responses": {"primary": (primary_dir / "answer.json").read_text(encoding="utf-8"),
                              "focus": (focus_dir / "answer.json").read_text(encoding="utf-8") if (focus_dir / "answer.json").is_file() else None},
        }
        path = RESULT_DIR / f"{result_id}.json"
        try:
            save_result_image(result_id, image_path)
            _write_json(path, payload)
        except Exception:
            (RESULTS_DIR / ".images" / f"{result_id}.webp").unlink(missing_ok=True)
            path.unlink(missing_ok=True)
            raise
        return R5Output(result_id)
    except Exception as exc:
        # 原生失败记录保持原样，工程只补充一份安全的网页失败回执。
        if run_dir.is_dir():
            _write_json(run_dir / "web-failure.json", {"result_id": result_id, "failed_at": _now(), "error": _safe_exception(exc)})
        raise RuntimeError(f"Sol R5 提取失败；运行记录 {result_id}：{_safe_exception(exc)}") from exc
