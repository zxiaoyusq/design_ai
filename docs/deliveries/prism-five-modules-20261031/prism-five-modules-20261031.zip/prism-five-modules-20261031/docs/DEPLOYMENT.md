# 部署与运维指南

本指南用于此五模块交付分支。旧业务成果文档描述的是既有服务器；新环境以本指南和随包 `.env.example` 为准。

## 1. 环境条件

Linux、Bash、conda、Python 3.14（环境名 `314`）、Node.js 22.23.2 或接收方验证过的兼容版本、pnpm 11.19.0、PostgreSQL 16、Docker Compose v2。脚本还需 `curl`、`lsof`、`flock`、`setsid`、`ps`。用研 PPT 渲染需要 LibreOffice，以及覆盖材料语言的字体；缺字体会影响原页阅读。

模型通过业务配置的外部服务访问，当前默认部署不要求本机 GPU。内存、磁盘和并发容量取决于导入素材与图片尺寸，本包未做生产容量定标；先以单实例、小样本、低并发试用。

## 2. 安装依赖

在交付目录根部执行。以下命令只安装代码依赖，不会导入原服务器数据。

```bash
conda create -n 314 python=3.14 -y
conda activate 314
python -m pip install -r backend/requirements.lock.txt
# 如需调整依赖，参考 backend/requirements.txt 的范围，再重新验证。
pnpm --dir frontend install --frozen-lockfile
```

随包 Python 锁定清单记录本次验证环境中运行依赖的精确版本，不是完整服务器 conda 导出；Node / pnpm 需在运行 `site.sh` 时可从 PATH 找到。系统依赖以 Debian / Ubuntu 为例可安装 `libreoffice-impress fonts-noto-cjk lsof curl util-linux`；Docker / conda 的安装由接收方环境管理员完成。

## 3. 配置数据库与模型

```bash
cp backend/.env.example backend/.env
```

编辑本机 `.env`：

| 配置 | 谁提供 / 如何设置 |
| --- | --- |
| `AUTH_POSTGRES_PASSWORD` | 运维生成数据库密码，不沿用示例占位值 |
| `AUTH_DATABASE_URL` | 与账号库用户、库名、密码、端口一致；URL 特殊字符需编码 |
| `AUTH_ALLOWED_ORIGINS` | 实际可信站点来源；包含协议与端口 |
| `AUTH_COOKIE_SECURE` | 本机 HTTP 使用 false，纯 HTTPS 环境可使用 true |
| `LLM_URL` | 业务方提供可达模型网关地址，需匹配工程支持的协议 |
| `LLM_KEY` | 业务方提供 API Key / Access Token；不要提交 Git 或发到公共文档 |

`services/llm/catalog.py` 保存模型目录与统一默认 `gemini-3.8-flash`。网页、独立 Skill、R5 和趋势宿主统一走 DeepAgents + 网关 SDK，不需要 Codex CLI 或个人 ChatGPT 登录。接收方须获得该模型的网关权限；显式选择其他目录模型时使用对应协议。新供应方、模型 ID 或不同协议可能需要适配。Access Token 是访问凭证，模型 Token 是用量单位。任务的调用预算、并发、输入规模与费用需分别确认。

## 4. 建立账号库与管理员

```bash
docker compose -p prism-five-auth --env-file backend/.env -f deploy/auth-compose.yml up -d --wait
conda run --no-capture-output -n 314 python -m alembic -c backend/alembic.ini upgrade head
cd backend
conda run --no-capture-output -n 314 python -m app.manage_auth create-admin admin
cd ..
```

按提示设置接收方自己的管理员密码。代码包、业务交接和 Git 备份不含原环境账号密码或模型凭据。默认会话 12 小时；修改密码会撤销该账号已有会话，正常重启不删除账号。

## 5. 构建并启动

```bash
conda run --no-capture-output -n 314 pnpm --dir frontend build
./site.sh start
```

浏览器打开 `http://127.0.0.1:5173`。启动为前台运行，另开终端使用 `./site.sh status` / `stop`；`Ctrl+C` 也会清理本次服务。缺少业务数据时各模块应显示空列表，按 [数据接入指南](DATA_SETUP.md) 添加输入。

SSH 转发示例（把服务器替换为接收方实际主机）：

```bash
ssh -p 22 -N -L 5173:127.0.0.1:5173 user@server
```

交付版不使用 Cloudflare。若配置端口已被占用，默认停止启动并说明冲突；只有明确需要停止原占用服务时，才使用 `DESIGN_AI_TAKEOVER_PORTS=1 ./site.sh start`。

## 6. 固定域名与常驻运行

由运维将域名解析到网关，配置有效 HTTPS 证书和反向代理。可让网关回源到 `127.0.0.1:5173`（同机），或在受控内网监听指定地址。保持前端与 `/api` 同源，转发原始 Host / HTTPS 协议信息；仅调整工程环境变量不能代替 DNS 和网关配置。

```bash
DESIGN_AI_DOMAIN=your-domain.example.com \
DESIGN_AI_FRONTEND_HOST=0.0.0.0 \
DESIGN_AI_FRONTEND_PORT=5173 \
./site.sh start
```

同步配置 `AUTH_ALLOWED_ORIGINS` 与 HTTPS Cookie 策略。`DESIGN_AI_DOMAIN` 同时用于前端 Host 校验；需要多个业务域名时，可通过逗号分隔的 `DESIGN_AI_ALLOWED_HOSTS` 追加，并分别配置可信来源。不要另行将 `frontend/dist` 放在未鉴权的静态目录中，否则会绕开工程资源登录保护。前端默认使用固定构建；源码修改后显式重建，只有开发调试才启用 `DESIGN_AI_FRONTEND_MODE=dev`。

`deploy/prism.service.example` 用于 systemd 进程托管：示例工程目录为 `/opt/prism`、运行用户为 `prism`、`CONDA_EXE=/opt/conda/bin/conda`，安装前改成实际值并确认该用户可以读写工程数据目录。Node / pnpm 也需在服务的 PATH 或 conda `314` 环境中可用。随包没有启用或改写接收服务器的系统服务。试用阶段后端维持一个 worker，不以多 worker 代替任务队列扩容。

## 7. 检查与维护

```bash
curl --fail http://127.0.0.1:8000/health
./site.sh status
tail -n 100 -f .runtime/logs/frontend.log .runtime/logs/backend.log
```

登录后依次检查五模块；在新环境按小样完成一次图片提取、趋势分析、PPT 导入及确认、趋势和用研握手、情绪板生成与人工检查。先确认模型权限、预算和证据保存，再扩大输入范围。本次交付的离线验证不代替这一步。

备份 `data/`、业务导入的 `ref/趋势信息0930.xlsx`、新增业务图片索引、账号数据库，以及与结果绑定的规则版本。PostgreSQL 可使用管理员自己的备份流程，或在数据库运行时执行：

```bash
docker compose -p prism-five-auth --env-file backend/.env -f deploy/auth-compose.yml exec -T auth-db \
  pg_dump -U design_ai_auth design_ai_auth > auth-backup.sql
```

备份含账号信息，应由运维保存；不写入源码仓库。正常停服务不会删除数据库卷。恢复时一并核对代码版本、数据引用与哈希。模型失败、额度耗尽或输入不完整时先看任务记录，人工确认后继续，避免自动重复付费调用。
