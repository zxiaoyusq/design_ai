# 五模块代码结构与接手顺序

## 一、系统如何工作

```text
浏览器
  └─ frontend：Vue 页面、Pinia 状态、Axios API
       ├─ /login → 后端独立登录页
       └─ /api/v1/* → FastAPI
            ├─ 登录校验 → PostgreSQL 用户 / 会话
            └─ 业务 services → DeepAgents / 模型协议适配
                 ├─ .agents/skills 与 ref：算法、字典、提示词、原生校验
                 └─ data：上传、冻结输入、任务状态、结果、来源与人工反馈
```

页面展示与规则执行分开：前端选择输入和显式确认任务；API 做参数与身份校验；services 冻结范围、预算和任务状态；agents 负责模型调用；Skill 保留领域规则和结果检查。不要在前端另写一套 DNA / 聚类规则。

## 二、五个模块的入口

| 模块 | 页面与 API | 主要后端代码 | 关键输入 / 产物 |
| --- | --- | --- | --- |
| DNA提取V2 | `DnaV2View.vue`；`api/dna_v2.py`，共用 `api/dna.py` 上传 | `services/dna/preparation.py`、`agents/design_dna_preparation.py` | 图片 → ID / CMF 设计卡、七组设计关系、来源与模型信息 |
| 趋势洞察 | `ArticleTrendsView.vue`；`api/article_trends.py` | `services/article_trends/catalog.py`、`tasks.py` | 趋势文章 → 可回查语义方向与文章证据 |
| 用户调研 | `UserResearchView.vue`；`api/user_research.py` | `services/user_research/presentation.py`、`storage.py`、`tasks.py` | PPTX → 用户原话、问题回答、图片偏好及来源，人工确认后可进入下游 |
| 高潜趋势 | `HighTrendsView.vue`；`api/high_trends.py` | `services/high_trends/upstream.py`、`tasks.py`、`native_result.py` | 已完成趋势 + 已确认用研 → 有双侧依据的方向及关联图片 |
| 情绪版生成 | `MoodboardsView.vue`；`api/moodboards.py` | `services/moodboards/sources.py`、`clustering.py` | 选定高潜方向 → 核对原图与已有 DNA → 经确认补缺 / 聚类 → 候选板与依据 |

表中前端路径均相对 `frontend/src/views/`，后端路径均相对 `backend/app/`。高潜图片审核子页属于第四模块；共享图片上传与模型列表属于基础能力，不是额外交付的业务模块。

## 三、目录职责

```text
frontend/
  src/api/          请求封装与类型化接口
  src/views/        五模块页面及必要子页
  src/components/   导航、图片、设计卡与图板结果
  src/stores/       登录和 DNA 页面状态
  src/types/        前后端 DTO 约定
  auth-guard.ts     在 Vite 返回资源前校验会话
backend/
  app/api/          HTTP 边界、鉴权和上传
  app/services/     任务、数据存储、来源冻结与流程编排
  app/agents/       DeepAgents 与结构化模型执行
  app/schemas/      输入输出契约
  app/models/      账号、会话 SQLAlchemy 模型
  migrations/      Alembic 账号数据库迁移
  tests/           相关离线、假模型与接口测试
.agents/skills/    当前规则、原生脚本及必要支持运行时
ref/              被运行代码引用的规则与兼容依赖；不含原参考资料仓库
deploy/           账号库与进程托管示例
docs/             工程交接、部署、数据和验证说明
metadata/         文件清单、源码来源对照和交付范围
```

部分内部兼容依赖名称仍包含旧版本。它们之所以保留，是因为当前五模块仍会导入其规则或读取其格式；不表示交付旧业务页面，也不表示已完成全部旧历史结果迁移。

## 四、接手时优先看什么

1. `frontend/src/router.ts` 和 `backend/app/api/router.py`：确认交付边界与对外入口。
2. `backend/app/services/auth.py`：账号、会话、Cookie 和来源校验；维护账号用 `app.manage_auth`。
3. `backend/app/services/llm/settings.py`、`catalog.py`、`client.py`：网关配置、允许模型与协议；统一默认 Gemini 3.8 Flash；网页、独立 Skill 和共享调用均使用 DeepAgents + SDK，不读取个人 Agent 登录。模型列表是工程配置，不保证业务新账号均有权限。
4. `backend/app/agents/bounded.py` 与各模块任务服务：预算、状态、失败与人工续跑边界。
5. 五模块主服务及对应 `.agents/skills`：了解规则版本和冻结输入，先用离线代表性样本验证，再决定真实调用范围。

## 五、数据一致性与修改原则

模型输出需保留输入图片 / 文本、模型、提示词或规则版本、执行时间和来源引用。DNA 修订、方向选择与图板采用保留人工确认。输入、设计卡和历史结果中的 SHA-256 是证据关系，迁移时不能直接全局替换绝对路径或编辑原始 JSON 后继续沿用旧哈希。

MVP 的任务与业务结果主要落本机文件；当前不是分布式任务队列。建议单实例 / 单后端 worker 试用，先完成数据和账号库备份。多副本、统一任务调度、细粒度角色、组织空间与费用归属需另行设计和验证。

## 六、本次工程分离的改动

从源码闭包选取五模块及实际共享依赖，删除不相关前端页面和静态物料；将运行依赖软链接转为包内文件；缺少历史数据时显示空状态；保留真实坏数据的错误检查；默认本机端口启动。算法规则并未因工程打包而获得新的质量结论。
