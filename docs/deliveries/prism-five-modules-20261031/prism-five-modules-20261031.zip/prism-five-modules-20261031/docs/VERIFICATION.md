# 本次源码交付验证 · 2026-10-31

本版新增统一执行迁移：网页、独立 Skill、R5、通用工作流、趋势宿主和共享调用函数均使用 DeepAgents SDK；默认 Gemini 3.8 Flash。新增测试验证首选模型、原文和 Schema 保持、旧缓存隔离、真实 DeepAgents 图配合假模型、错误脱敏及外部执行器拒绝。原生规则的历史固定 SHA 不变。

本轮后端 215 项测试及 146 个子测试、前端 23 项、情绪板 Skill 251 项及设计卡 Skill 58 项通过；情绪板有 3 项既有跳过。前端构建、历史重放及凭据审计通过。机器记录见 `metadata/deepagents-verification.json`。用户 Q/R 投票属于已归档业务成果，不冒称是本次 Gemini 迁移后的新效果测试。下表保留前一轮基础检查范围。

## 已完成

| 检查 | 结果与范围 |
| --- | --- |
| 后端代表性测试 | 193 项测试及 141 个子测试通过；覆盖登录、模型适配、上传 / DNA、趋势、用研、高潜和情绪板相关服务 |
| 空业务数据 | 17 个只读端点返回 200；五模块空列表与摘要正常；不生成虚假结果；已存在但损坏资料继续报错 |
| 第一张 DNA | 无历史图库时，以真实 DeepAgents 编排 + 假模型完成首张上传图的结构化流程；非真实模型效果评测 |
| 原生规则 | support doctor 的依赖 SHA / R5 normalizer 校验通过，R5 四例离线 self-test 通过 |
| 前端 | TypeScript / Vite 构建通过，23 项轻量测试通过；构建仍提示单个 bundle 较大，按需拆分可作为后续性能优化 |
| 隔离浏览器 | 独立临时 SQLite 测试账号库 + 包内前后端；登录、五页面、首页跳转、退出后 API 401 通过；无页面异常、HTTP 错误、外网资源请求或横向溢出 |
| 部署脚本 | Bash 语法检查通过，提供本机默认端口、显式端口接管与 systemd 示例 |
| 交接 HTML | 1440 / 768 / 390 宽度离线检查、目录链接与反馈图放大；无外部资源依赖 |
| 交付范围 | 文件白名单、原件对照、密钥文件 / 缓存 / 外部软链接排除、逐文件 SHA-256 |

后台与浏览器检查均未启动真实模型任务；浏览器写请求仅为临时测试账号登录和退出。生产账号库、现网服务和原业务数据未参与测试。

## 复核命令

```bash
python tools/verify_delivery.py
conda run --no-capture-output -n 314 python -m pip install -r backend/requirements-dev.txt
cd backend
conda run --no-capture-output -n 314 python -m pytest -q tests
cd ..
conda run --no-capture-output -n 314 pnpm --dir frontend build
node --test frontend/tests/*.test.mjs
bash -n site.sh
```

Python 运行依赖精确版本见 `backend/requirements.lock.txt`。原生规则检查可执行：

```bash
conda run --no-capture-output -n 314 python .agents/skills/prism_skill_support/scripts/native_api.py doctor
```

测试读取临时目录并替换身份或模型依赖，不应向生产库或真实模型发送请求。工程机器可读验证记录位于 `backend/HANDOFF_VALIDATION.json` 与 `metadata/browser-verification.json`、`metadata/docs-verification.json`。

## 尚未在本次打包中执行

- 未在一台全新空白主机上从互联网重新安装全部依赖；版本锁来自现有验证环境的运行依赖闭包。
- 未在业务方的新 PostgreSQL 实例执行生产上线；账号模型与迁移代码随包交付，浏览检查使用隔离 SQLite 测试库。
- 未验证接收方的 DNS、HTTPS 网关、模型网关、费用权限、全量图库与高并发容量。
- 未进行真实模型的大样本 DNA / 情绪板重放，也没有把离线假模型结果当作质量验收。

因此，包内代码与文档可以直接交接和开始部署；正式试用前仍按部署指南完成真实环境和业务小样验收。
