# 登录与账号维护（五模块交付版）

前端页面和静态资源、业务接口、图片与下载都需要登录。`GET /health` 仅用于公开探活；`GET /login` 是独立后端页面，不依赖受保护的前端资源。未登录的业务 API 返回 401。

## 初始化

按 [部署指南](DEPLOYMENT.md) 配置 PostgreSQL 及 `backend/.env`，执行 Alembic 迁移后，在 `backend/` 运行：

```bash
conda run --no-capture-output -n 314 python -m app.manage_auth create-admin admin
```

按提示输入并确认新密码。交付包不带原账号库，业务文档也已移除原环境密码；接收方自行创建和维护账号。

## 改密与会话

```bash
cd backend
conda run --no-capture-output -n 314 python -m app.manage_auth set-password admin
```

密码以随机盐 PBKDF2-SHA256 摘要保存；会话令牌只经 HttpOnly Cookie 传递，数据库保存令牌摘要。默认会话 12 小时，连续 5 次错误登录暂停约 1 分钟。退出撤销当前会话；改密撤销该用户全部已有会话。正常重启不会清除账号或有效会话。

当前没有公开注册；管理员通过命令创建账号。角色字段不等于完整的项目隔离、精细权限或费用归属。企业 SSO / 角色管理需业务方确认后扩展。

## 部署检查

| 接口 | 行为 |
| --- | --- |
| `POST /api/v1/auth/login` | 提交 username / password，成功设置会话 Cookie |
| `GET /api/v1/auth/me` | 返回账号和角色，匿名时 401 |
| `POST /api/v1/auth/logout` | 撤销当前会话 |
| `GET /health` | 仅返回服务健康状态 |

`AUTH_ALLOWED_ORIGINS` 设置可信站点来源。纯 HTTPS 可设置 `AUTH_COOKIE_SECURE=true`，HTTP 本机调试不要强制 Secure。前端代理保留原始 Host，网关应配置 HTTPS 协议透传。禁止将前端文件另行发布到未鉴权静态服务器。

相关代码为 `backend/app/services/auth.py`、`backend/app/api/auth.py`、`frontend/auth-guard.ts`；数据库迁移在 `backend/migrations/`。测试使用独立临时数据库，不读取或覆盖线上账号。
