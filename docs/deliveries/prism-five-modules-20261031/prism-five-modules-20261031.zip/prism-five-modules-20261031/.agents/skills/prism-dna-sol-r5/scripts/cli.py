"""R5 单图入口：默认仅准备；执行统一通过 DeepAgents 和工程模型网关。"""

from argparse import ArgumentParser
from datetime import datetime, timezone
from importlib import import_module
import importlib.util
from importlib.metadata import PackageNotFoundError, version
import json
import os
from pathlib import Path
import re
import sys
import time

_spec = importlib.util.spec_from_file_location('prism_sol_r5_runtime_engine', Path(__file__).with_name('engine.py'))
_engine = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_engine)
ROOT = _engine.ROOT
file_hash, read, write_new = _engine.file_hash, _engine.read, _engine.write_new
load_original, primary, finish = _engine.load_original, _engine.primary, _engine.finish
refinement_job, apply_refinement = _engine.refinement_job, _engine.apply_refinement
replay_examples, validate = _engine.replay_examples, _engine.validate

DEFAULT_MODEL = 'gemini-3.8-flash'
TRANSPORT = 'project_langchain_sdk'
PROJECT_ROOT = ROOT.parents[2]


def runtime():
    """延迟导入工程适配器：准备、样例重放不会加载连接配置或调用模型。"""
    backend = str(PROJECT_ROOT / 'backend')
    if backend not in sys.path:
        sys.path.insert(0, backend)
    return import_module('app.agents.design_dna_preparation')


def doctor(model_id=DEFAULT_MODEL):
    """仅核对依赖与模型目录；不读取密钥文件，也不请求网关。"""
    packages = {}
    for name in ('deepagents', 'langchain-core', 'jsonschema'):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    try:
        runtime().execution_config(model_id)
        error = None
    except Exception as exc:
        error = type(exc).__name__
    return {'ready': all(packages.values()) and error is None, 'packages': packages,
            'framework': 'DeepAgents', 'transport': TRANSPORT, 'model': model_id,
            'environment_variables_present': all(os.environ.get(name) for name in ('LLM_KEY', 'LLM_URL')),
            'configuration_file_present': (PROJECT_ROOT / 'backend/.env').is_file(),
            'dependency_error': error, 'account_or_model_access_verified': False,
            'model_request_sent': False, 'connection_secrets_recorded': False}


def _save_ledger(run, ledger):
    (run / 'call-ledger.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding='utf-8')


def call(engine, run, call_id, prompt, schema, image, model_id, timeout, ledger, max_calls):
    """每个逻辑请求最多一次 SDK 尝试；原生 R5 校验和困难项预算保持不变。"""
    if len(ledger['calls']) >= max_calls:
        raise RuntimeError('Request budget exhausted; no automatic retry')
    adapter = runtime()
    configuration = adapter.execution_config(model_id)
    call_dir = run / 'calls' / call_id
    call_dir.mkdir(parents=True, exist_ok=False)
    write_new(call_dir / 'prompt.txt', prompt, text=True)
    write_new(call_dir / 'schema.json', schema)
    request = {'call_id': call_id, 'model': model_id, 'framework': 'DeepAgents',
               'transport': TRANSPORT, 'reasoning_effort': configuration['reasoning_effort'],
               'image_sha256': file_hash(image), 'prompt_sha256': file_hash(call_dir / 'prompt.txt'),
               'schema_sha256': file_hash(call_dir / 'schema.json'), 'max_attempts': 1,
               'timeout_seconds': timeout, 'connection_secrets_recorded': False}
    write_new(call_dir / 'request.json', request)
    entry = {'call_id': call_id, 'state': 'attempt_started',
             'started_at': datetime.now(timezone.utc).isoformat()}
    ledger['calls'].append(entry)
    _save_ledger(run, ledger)
    start = time.monotonic()
    answer, error = None, None
    try:
        answer = adapter.execute_structured(
            call_dir / 'sdk', system=prompt, payload={'call_id': call_id},
            images=[{'path': str(image), 'sha256': request['image_sha256'], 'role': 'original_image'}],
            schema=schema, model_id=model_id, timeout_seconds=timeout,
        )
        # 工程SDK先做结构校验；R5仍使用原严格JSON解码器，不能静默接受重复键。
        raw = (call_dir / 'sdk/answer.raw.txt').read_text(encoding='utf-8').strip()
        if raw.startswith('```') and raw.endswith('```'):
            raw = '\n'.join(raw.splitlines()[1:-1]).strip()
        answer = _engine.loads(raw)
        validate(engine, schema, answer)
        write_new(call_dir / 'answer.json', answer)
    except Exception as exc:
        # 统一适配器已脱敏；此处不保存异常对象的任意请求头或完整连接字符串。
        from app.services.llm.redaction import safe_exception
        error, answer = safe_exception(exc), None
    sdk_path = call_dir / 'sdk/receipt.json'
    sdk_receipt = read(sdk_path) if sdk_path.is_file() else {}
    receipt = {'call_id': call_id, 'framework': 'DeepAgents', 'transport': TRANSPORT,
               'requested_model': model_id, 'actual_model': sdk_receipt.get('actual_model'),
               'schema_valid': answer is not None, 'wall_seconds': round(time.monotonic() - start, 4),
               'usage': sdk_receipt.get('usage'), 'error': error,
               'sdk_receipt': 'sdk/receipt.json' if sdk_path.is_file() else None,
               'state': 'response_received' if answer is not None else 'failed_no_retry'}
    write_new(call_dir / 'receipt.json', receipt)
    entry.update(receipt)
    _save_ledger(run, ledger)
    return answer, receipt


def run_extraction(*, image, image_id, out, execute=False, refine=None,
                   model_id=DEFAULT_MODEL, timeout=600):
    """供网页与 CLI 共用的执行入口；历史算法资产与新运行身份分别记录。"""
    engine = load_original()
    if not re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]{0,63}', image_id):
        raise ValueError('image-id must be a stable ASCII identifier, without path separators')
    if type(timeout) is not int or not 60 <= timeout <= 1800:
        raise ValueError('Use a bounded per-call timeout from 60 to 1800 seconds')
    if refine not in (None, 'mixed-areas', 'optics'):
        raise ValueError('Unsupported refinement mode')
    configuration = runtime().execution_config(model_id)
    image = Path(image).resolve(strict=True)
    run = Path(out).resolve()
    run.mkdir(parents=True, exist_ok=False)
    max_calls = 3 if refine else 2
    write_new(run / 'primary.prompt.txt', engine.prompt(), text=True)
    write_new(run / 'primary.schema.json', engine.schema())
    prepared = {'algorithm_version': engine.VERSION, 'model': model_id, 'requested_model': model_id,
                'framework': 'DeepAgents', 'transport': TRANSPORT,
                'reasoning_effort': configuration['reasoning_effort'], 'image_id': image_id,
                'image_path': str(image), 'image_sha256': file_hash(image), 'max_calls': max_calls,
                'automatic_retries': False, 'optional_refinement': refine,
                'few_shot_examples_in_runtime_input': False, 'status': 'prepared_only',
                'execution_requested': execute, 'timeout_seconds': timeout,
                'connection_secrets_recorded': False}
    write_new(run / 'prepared.json', prepared)
    if not execute:
        return prepared
    environment = doctor(model_id)
    write_new(run / 'runtime-environment.json', environment)
    if not environment['ready']:
        raise RuntimeError('SDK preflight failed; no model request sent. See runtime-environment.json')
    ledger = {'limit': max_calls, 'automatic_retries': False, 'calls': []}
    answer, receipt = call(engine, run, 'P-' + image_id, engine.prompt(), engine.schema(), image,
                           model_id, timeout, ledger, max_calls)
    if answer is None:
        return {'status': 'primary_failed_no_retry', 'run': str(run)}
    unpacked = primary(engine, answer, image_id)
    write_new(run / 'unpacked.json', unpacked)
    focus, focus_receipt = None, None
    if unpacked['issues']:
        focus, focus_receipt = call(engine, run, 'F-' + image_id, engine.focus_prompt(unpacked['issues']),
            engine.focus_schema(unpacked['issues']), image, model_id, timeout, ledger, max_calls)
    final = finish(engine, unpacked, focus, image_id)
    write_new(run / 'before-refinement.json', final)
    if refine and not (focus_receipt and focus is None):
        job = refinement_job(engine, refine, answer, final)
        write_new(run / 'refinement-plan.json', job)
        if job['target_count']:
            extra, _ = call(engine, run, 'H-' + image_id, job['prompt'], job['schema'], image,
                            model_id, timeout, ledger, max_calls)
            if extra is not None:
                final = apply_refinement(engine, final, answer, job, extra, image_id)
    final.update(image_sha256=prepared['image_sha256'], model=model_id, requested_model=model_id,
                 framework='DeepAgents', transport=TRANSPORT,
                 actual_models=[x.get('actual_model') for x in ledger['calls']],
                 reasoning_effort=configuration['reasoning_effort'], model_calls=len(ledger['calls']),
                 failed_calls=sum(x['state'] != 'response_received' for x in ledger['calls']),
                 status='partial' if final['pending'] or final['invalid'] or any(
                     x['state'] != 'response_received' for x in ledger['calls']) else 'accepted_for_pilot')
    write_new(run / 'result.json', final)
    return final


def main():
    parser = ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    command = sub.add_parser('parse')
    command.add_argument('--image', type=Path, required=True)
    command.add_argument('--image-id', required=True)
    command.add_argument('--out', type=Path, required=True)
    command.add_argument('--execute', action='store_true')
    command.add_argument('--refine', choices=['mixed-areas', 'optics'])
    command.add_argument('--model', dest='model_id', default=DEFAULT_MODEL)
    command.add_argument('--timeout', type=int, default=600)
    sub.add_parser('self-test')
    command = sub.add_parser('doctor')
    command.add_argument('--model', dest='model_id', default=DEFAULT_MODEL)
    args = vars(parser.parse_args())
    action = args.pop('action')
    if action == 'self-test':
        result = replay_examples()
        code = 0 if result['passed'] else 2
    elif action == 'doctor':
        result = doctor(**args)
        code = 0 if result['ready'] else 2
    else:
        result = run_extraction(**args)
        code = 2 if result['status'] == 'primary_failed_no_retry' or result.get('failed_calls') else 0
    keys = ('image_id', 'status', 'ID_unique', 'CMF_unique', 'pending_count', 'model_calls')
    print(json.dumps({key: result[key] for key in keys if key in result} if action == 'parse'
                     else result, ensure_ascii=False))
    return code


if __name__ == '__main__':
    sys.exit(main())
