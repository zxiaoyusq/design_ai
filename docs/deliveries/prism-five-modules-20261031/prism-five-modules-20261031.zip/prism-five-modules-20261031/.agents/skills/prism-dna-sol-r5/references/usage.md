# 给同事的使用说明

本版本随五模块工程交付，使用`backend/app/agents/design_dna_preparation.py`的统一执行器；应在完整工程中运行，不能只复制本Skill后直接联网执行。

需要工程 Python 3.14 环境与 DeepAgents 等后端依赖。默认模型为`gemini-3.8-flash`。由业务方在自己的环境中配置`LLM_KEY`、`LLM_URL`；交付包不提供密钥、账号登录状态或私人网关配置。先安装工程依赖：

```text
python -m pip install -r backend/requirements.txt
```

从项目根执行。路径有空格时加双引号。

```text
python -B -X utf8 .agents/skills/prism-dna-sol-r5/scripts/cli.py doctor
python -B -X utf8 .agents/skills/prism-dna-sol-r5/scripts/cli.py self-test
```

doctor只检查本地依赖和模型目录，报告配置是否存在，不读取密钥内容、不联网验证模型权限。可用`--model MODEL_ID`显式选择目录中的模型；不可用时停止，不自动切换模型。`--codex`参数和外部Agent执行方式已移除。

仅生成请求，不调用模型：

```text
python -B -X utf8 .agents/skills/prism-dna-sol-r5/scripts/cli.py parse --image "图片.png" --image-id IMG001 --out "outputs/r5-preview"
```

真正解析（会使用同事自己的模型额度）：

```text
python -B -X utf8 .agents/skills/prism-dna-sol-r5/scripts/cli.py parse --image "图片.png" --image-id IMG001 --out "outputs/r5-run-001" --execute
```

输出目录必须尚不存在。每个请求一次尝试；失败保留记录，不自动重启旧运行。未做定点复核的困难项保持pending。执行失败退出码2；有未决语义但调用成功时，结果状态partial不应误当程序崩溃。

可选补查：`--refine mixed-areas`只检查原区域名中并列多个部位的外观差异；`--refine optics`只检查有疑义的透明/透射字段。两者不能同时选择，最多增加一次调用；目标为空时不调用。它们来自R5实际试验的两种有界补查，并不保证每张新图都需要或受益。

## 输出怎么用

`result.json`保留：

- `local_features`：原字段p、值v、位置at、回复路径path和来源source。局部CMF以此判断同位置条件。
- `features`：图级按字段和值去重的索引，包含ID/CMF views、locations和provenance。适合图级召回，不证明不同部位属性共现。
- `pending`、`invalid`、`decisions`、`admission_adjustments`：不确定、程序拒绝、复核及显式纠正记录。
- 计数、图像哈希、模型配置、调用次数；全216视觉合格和人工准确率始终不自动宣称。

`calls/`中保留实际输入、schema、输出与receipt；`calls/*/sdk/`保存统一 DeepAgents 请求和供应商响应证据；`call-ledger.json`记录尝试。请求模型与实际报告模型分别记录。模型SDK未返回用量或实际模型时保持未知，不从历史结果推断。所有调用禁用自动重试；不读取其他Agent的登录状态。

## 验证口径

运行方式迁移的验证采用保存响应重放与离线假模型，核对原生字段校验、困难项预算、结果身份和无自动重试；没有新增真实模型解析。历史4图样例保留原身份，不能用来宣称新的 Gemini 组合已通过真实视觉验证。新机器的完整模型执行仍需业务方配置自己的网关后用少量代表图确认。

图片素材、原字典和原模型回复分别保存；examples目录不会被加入正式prompt。字段数接近Astra不等于准确率接近Astra。
