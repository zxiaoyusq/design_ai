"""经工程 DeepAgents 执行一次结构化请求；默认只准备，不调用模型。"""
from __future__ import annotations

import argparse
from datetime import UTC, datetime
import json
from pathlib import Path
import sys
from time import monotonic

from io_utils import fresh, read, ref, resolve, write

PROJECT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(PROJECT / "backend"))


def run(job_path, out, execute=False):
    """冻结输入、授权与 SDK 配置；执行时保留原规范校验和真实回执。"""
    from app.agents.design_dna_preparation import execution_config, execute_structured
    from app.services.llm.catalog import DEFAULT_MODEL_ID
    from app.services.llm.redaction import safe_exception
    from jsonschema import Draft202012Validator

    job_path = Path(job_path).resolve()
    job = read(job_path)
    prompt_path = resolve(job["prompt_path"], job_path.parent)
    schema_path = resolve(job["schema_path"], job_path.parent)
    images = [resolve(item, job_path.parent) for item in job.get("images", [])]
    if any(path.suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp", ".gif") for path in images):
        raise ValueError("仅接受真实图片；PDF 等资料需先渲染")
    seconds = job.get("timeout_seconds", 600)
    policy = job.get("model_policy", {})
    configuration = execution_config(policy.get("model", DEFAULT_MODEL_ID), timeout_seconds=seconds)
    requested_effort = policy.get("reasoning_effort")
    if requested_effort is not None and requested_effort != configuration["reasoning_effort"]:
        raise ValueError("所选模型不支持该推理参数；请使用工程目录的实际配置")
    normative = read(schema_path)
    wire = read(resolve(job["wire_schema_path"], job_path.parent)) if job.get("wire_schema_path") else normative
    Draft202012Validator.check_schema(normative)
    Draft202012Validator.check_schema(wire)
    grant = job.get("execution_authorization", {})
    if execute and not (grant.get("allowed") is True and isinstance(grant.get("basis"), str)
                        and grant["basis"].strip() and grant.get("maximum_attempts") == 1):
        raise ValueError("实际执行需有本次明确授权依据，且 maximum_attempts=1")
    image_refs = [ref(path) for path in images]
    folder = fresh(out)
    text = prompt_path.read_text(encoding="utf-8-sig")
    write(folder / "prompt.txt", text)
    write(folder / "schema.normative.json", normative)
    write(folder / "schema.json", wire)
    plan = {"stage": job["stage"], "call_id": job["call_id"], "job_ref": ref(job_path),
            "framework": "DeepAgents", "transport": configuration["transport"],
            "execution_config": configuration, "images": image_refs,
            "prompt_ref": ref(folder / "prompt.txt"), "normative_schema_ref": ref(folder / "schema.normative.json"),
            "wire_schema_ref": ref(folder / "schema.json"), "timeout_seconds": seconds,
            "automatic_retries": 0, "execution_authorized_for_this_invocation": execute,
            "connection_secrets_recorded": False}
    write(folder / "request.json", plan)
    if not execute:
        return {"status": "prepared_only", "out": str(folder), "model_calls": 0}
    started = datetime.now(UTC).isoformat()
    timer = monotonic()
    receipt = {"call_id": job["call_id"], "schema_valid": False, "status": "failed",
               "framework": "DeepAgents", "transport": configuration["transport"],
               "requested_model": configuration["model"], "started_at": started}
    try:
        answer = execute_structured(folder / "sdk-call", system=text,
                                    payload={"stage": job["stage"], "call_id": job["call_id"]},
                                    images=image_refs, schema=wire, model_id=configuration["model"],
                                    timeout_seconds=seconds)
        # wire 只约束传输；最后仍按原完整 Schema 验证，不能补值或改写结果来通过。
        Draft202012Validator(normative).validate(answer)
        write(folder / "answer.json", answer)
        receipt.update(status="completed", schema_valid=True, answer_ref=ref(folder / "answer.json"))
    except Exception as exc:
        receipt["error"] = safe_exception(exc)
        raise RuntimeError(receipt["error"]) from exc
    finally:
        sdk_receipt = folder / "sdk-call/receipt.json"
        if sdk_receipt.is_file():
            actual = read(sdk_receipt)
            receipt.update(actual_model=actual.get("actual_model"), usage=actual.get("usage"),
                           sdk_receipt_ref=ref(sdk_receipt))
        receipt.update(finished_at=datetime.now(UTC).isoformat(), wall_seconds=round(monotonic() - timer, 3))
        write(folder / "receipt.json", receipt)
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    print(json.dumps(run(args.job, args.out, args.execute), ensure_ascii=False))
