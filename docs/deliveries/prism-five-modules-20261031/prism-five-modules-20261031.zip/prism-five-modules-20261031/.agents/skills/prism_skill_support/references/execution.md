# 当前执行与回执

全部新模型请求使用工程 DeepAgents 和统一网关 SDK，默认 `gemini-3.8-flash`。无需外部 Agent CLI 或个人登录；模型凭据由接收方在自己的环境配置。历史 R5 / Sol 记录保留原身份，不当作 Gemini 新运行结果。

`run_model.py` 默认只准备，不读取模型连接或消耗额度：

```bash
python .agents/skills/prism_skill_support/scripts/run_model.py --job model-job.json --out call-prepared
```

明确执行时使用新输出目录：

```bash
python .agents/skills/prism_skill_support/scripts/run_model.py --job model-job.json --out call-actual --execute
```

job 包含 stage、call_id、prompt_path、schema_path、images[]，可选 model_policy 和 timeout_seconds（60–1800 秒）。实际执行需 execution_authorization.allowed=true、非空 basis 及 maximum_attempts=1。路径相对 job 文件。

model_policy 省略时使用工程默认；显式模型须来自模型目录，推理参数必须匹配该模型实际配置。wire_schema_path 可选，返回结果最终仍按原 schema_path 完整校验，不补值或修复结果。

原图按 SHA 绑定，PDF 应先渲染。输出包含原始 prompt / schema、request、answer、receipt，以及 sdk-call 中的真实 SDK 证据。失败不自动重试，预算不自动扩大。未获得实际用量或供应商模型身份时保持未知。

Quality / H2 的审阅仍需真实原图、视窗和独立结论，程序通过不冒充人工验收。R5 的单图状态机使用其自身 DeepAgents CLI，不在通用请求中重建。跨机交接只带业务输入输出与公开配置，密钥和个人会话不随包提供。
