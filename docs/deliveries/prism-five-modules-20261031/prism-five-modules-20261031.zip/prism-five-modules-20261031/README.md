# 棱镜 · 五模块工程交付

这是 DNA提取V2 → 趋势洞察 → 用户调研 → 高潜趋势 → 情绪版生成的一期 MVP 源码交付。保留五模块所需的登录、模型调用、上传、来源追踪及人工审核能力。交付日期：2026-10-31。

**先打开 [工程交接导航](index.html)**，业务成果与验证证据见 [MVP 成果说明](docs/handoffs/prism-mvp-handoff-20261030.html)。两份 HTML 均可双击离线阅读。

## 包内内容

| 内容 | 入口 | 用途 |
| --- | --- | --- |
| 前端 | `frontend/src/router.ts` | 五个主模块、登录状态、高潜图片审核子页 |
| 后端 | `backend/app/main.py` | FastAPI 服务、业务 API、登录和任务执行 |
| 算法与规则 | `.agents/skills/`、`ref/` 中保留的规则目录 | DeepAgents 适配、提示词、Schema、DNA 字典、语义聚类与成板规则 |
| 部署 | `site.sh`、`deploy/auth-compose.yml` | 前后端启停及 PostgreSQL 账号库 |
| 工程说明 | [代码结构](docs/ENGINEERING.md)、[部署指南](docs/DEPLOYMENT.md) | 模块入口、调用链、部署步骤与运维 |
| 数据说明 | [数据接入与迁移](docs/DATA_SETUP.md) | 新环境输入准备、存储位置、历史证据迁移边界 |
| 交付核验 | `metadata/manifest.json`、`tools/verify_delivery.py` | 文件范围、来源与 SHA-256 完整性 |

这是一份**空业务数据的源码交付**，不携带历史大图库、上传原件、账号数据库、运行缓存、路演 PPT、旧演示模块或服务器 `.env`。少量算法自身的字典、Schema、校准资产属于运行依赖，随代码保留。业务成果文档中的投票截图属于交接证据，也随包保留。

源工程基线：`0b627cc77ebc119bfe14ffb000df2129f62d6d47`。本次快照还纳入原工作区中已完成的登录与固定构建修改，并进行五模块边界整理；具体差异见 `metadata/source-comparison.json`。交付分支为 `codex/prism-five-modules-handoff-20261031`，使用独立根提交，不携带源仓库的无关历史。原工程及线上部署未切换到本分支。

## 首次运行

完整步骤见 [部署指南](docs/DEPLOYMENT.md)。基本顺序是：准备 Python 3.14 / conda `314`、Node / pnpm → 安装依赖 → 从 `backend/.env.example` 建立本机配置 → 启动账号库并迁移 → 创建管理员 → 构建前端 → `./site.sh start`。

默认入口为 `http://127.0.0.1:5173`，后端为 `127.0.0.1:8000`。接收方自行配置模型密钥并创建管理员。源码、交接文档和 Git 分支备份均不携带原服务器密码、API Key、个人登录令牌或会话。

所有模型执行入口（包括独立 Skill、R5、趋势宿主与共享调用函数）均通过 DeepAgents 和统一网关 SDK；默认模型为 `gemini-3.8-flash`。无需安装 Codex CLI 或读取个人 ChatGPT 登录状态。显式选择其他已配置模型时按实际模型记录回执，历史结果保留原身份。

```bash
./site.sh start
./site.sh status
./site.sh stop
./site.sh restart
```

交付版遇到端口占用默认报错，避免部署时误停同机工程；确需接管时才显式设置 `DESIGN_AI_TAKEOVER_PORTS=1`。固定域名接入由业务方配置 DNS、HTTPS / 反向代理和实际监听地址。

## 验收与当前边界

先验证登录、五模块空态、图片上传和浏览，再在业务批准的模型账号、数据、调用预算下验证小样流程。情绪板等多阶段 DeepAgents 流程仍需在接收方实际模型环境验证，不能把安装成功或离线测试通过当作生产模型效果验收。

业务方需确认模型供应方、模型 ID、协议和网关、API Key / Access Token、调用权限与预算；Web / HTTP API 已有，是否新增 MCP 接入待确认。当前业务结果仍以文件保存，PostgreSQL 用于账号与会话，不能按“全部业务数据已数据库化”理解。

```bash
python tools/verify_delivery.py
```

该命令仅校验随包文件，不访问模型。随包具体测试结果与未执行范围见 [验证记录](docs/VERIFICATION.md)。
