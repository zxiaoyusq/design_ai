import { createRouter, createWebHistory } from 'vue-router'

import { useAuthStore } from '@/stores/auth'

// 交付入口仅保留五个业务模块，以及高潜趋势页必需的图片整理子页。
const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', redirect: '/dna-v2' },
    { path: '/dna-v2', name: 'dna-v2', component: () => import('@/views/DnaV2View.vue') },
    { path: '/article-trends', name: 'article-trends', component: () => import('@/views/ArticleTrendsView.vue') },
    { path: '/user-research', name: 'user-research', component: () => import('@/views/UserResearchView.vue') },
    { path: '/high-trends', name: 'high-trends', component: () => import('@/views/HighTrendsView.vue') },
    { path: '/high-trends/image-review', name: 'high-trend-image-review', component: () => import('@/views/HighTrendImageReviewView.vue') },
    { path: '/moodboards', name: 'moodboards', component: () => import('@/views/MoodboardsView.vue') },
  ],
})

// 页面与资源共用后端会话；401 由请求拦截器跳转至独立登录页。
router.beforeEach(async () => {
  try {
    await useAuthStore().checkSession()
    return true
  } catch {
    return false
  }
})

router.onError((error: Error) => {
  console.error(error)
  window.dispatchEvent(new CustomEvent('app:module-load-error', { detail: error.message }))
})

export default router
