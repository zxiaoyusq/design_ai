/** 与服务端目录默认值对应；旧目录尚未携带推荐字段时使用此回退。 */
export const DEFAULT_MODEL_ID = 'gemini-3.8-flash'

/** 模块显式默认优先，其次使用目录推荐；调用方只在创建任务或选项失效时使用。 */
export function selectDefaultModel(models: { id: string; recommended?: boolean }[], preferredId?: string): string {
  return models.find(model => model.id === preferredId)?.id
    ?? models.find(model => model.recommended)?.id
    ?? models.find(model => model.id === DEFAULT_MODEL_ID)?.id
    ?? models[0]?.id
    ?? ''
}
