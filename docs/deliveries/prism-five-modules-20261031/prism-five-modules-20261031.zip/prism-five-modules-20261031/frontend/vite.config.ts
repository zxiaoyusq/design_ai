import { fileURLToPath, URL } from 'node:url'

import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'

import { devBuildAssets } from './dev-build-assets.ts'
import { sessionGuard } from './auth-guard.ts'

const backendUrl = process.env.VITE_BACKEND_URL ?? 'http://127.0.0.1:8000'
// 业务域名由部署方提供；不依赖原演示域名或临时隧道。
const allowedHosts = [...new Set([
  'localhost',
  process.env.DESIGN_AI_DOMAIN ?? '',
  ...(process.env.DESIGN_AI_ALLOWED_HOSTS ?? '').split(','),
].map(value => value.trim()).filter(Boolean))]
const backendProxy = {
  // 保留浏览器访问的 Host，后端才能按实际站点校验写请求 Origin。
  '/api': { target: backendUrl, changeOrigin: false },
  '^/login(?:\\?|$)': { target: backendUrl, changeOrigin: false },
}

export default defineConfig({
  plugins: [sessionGuard(backendUrl), vue(), devBuildAssets(fileURLToPath(new URL('./dist/assets/', import.meta.url)))],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  // 发布新构建时保留本部署的旧哈希资源，避免已打开的页面加载失败。
  build: { emptyOutDir: false },
  server: {
    host: '127.0.0.1',
    port: 5173,
    headers: { 'Cache-Control': 'private, no-store' },
    allowedHosts,
    // 五模块的业务图片均经受保护的 API 提供，无需开放工程外的素材目录。
    fs: {
      allow: [fileURLToPath(new URL('.', import.meta.url))],
    },
    proxy: backendProxy,
  },
  preview: { allowedHosts, proxy: backendProxy, headers: { 'Cache-Control': 'private, no-store' } },
})
