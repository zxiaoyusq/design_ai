(() => {
  'use strict';
  const talk = JSON.parse(document.getElementById('talk-data').textContent);
  const slides = [...document.querySelectorAll('.slide')];
  const byId = id => document.getElementById(id);
  const escape = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const time = seconds => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  let current = 0;
  let reading = matchMedia('(max-width: 760px)').matches;
  let remaining = 900;
  let deadline = 0;
  let timerRunning = false;
  let restoreReading = false;
  let scrollFrame = 0;
  const starts = [];
  talk.slides.reduce((total, slide) => { starts.push(total); return total + slide.seconds; }, 0);

  function resize() {
    const scale = Math.min((innerWidth - 36) / 1600, (innerHeight - 106) / 900);
    document.documentElement.style.setProperty('--scale', String(Math.max(.1, scale)));
  }

  function updateNotes() {
    const slide = talk.slides[current];
    byId('notes-heading').textContent = `${String(current + 1).padStart(2, '0')} / ${slide.title}`;
    byId('notes-body').innerHTML = `<p class="speaker-cue">${time(starts[current])}–${time(starts[current] + slide.seconds)} · 本页 ${slide.seconds} 秒<br>${escape(slide.cue)}</p>` + slide.paragraphs.map(text => `<p>${escape(text)}</p>`).join('') + `<p class="note-bridge">转场：${escape(slide.bridge)}</p>`;
    byId('notes-prev').disabled = current === 0;
    byId('notes-next').disabled = current === slides.length - 1;
    byId('notes-dialog').scrollTop = 0;
  }

  function go(index, scroll = true) {
    current = Math.max(0, Math.min(slides.length - 1, index));
    slides.forEach((slide, i) => {
      slide.classList.toggle('active', i === current);
      slide.setAttribute('aria-hidden', String(!reading && i !== current));
      slide.inert = !reading && i !== current;
    });
    byId('counter').textContent = `${String(current + 1).padStart(2, '0')} / ${slides.length}`;
    byId('prev').disabled = current === 0;
    byId('next').disabled = current === slides.length - 1;
    byId('progress-bar').style.width = `${(current + 1) / slides.length * 100}%`;
    byId('live-status').textContent = `第 ${current + 1} 页，${talk.slides[current].title}`;
    document.querySelectorAll('[data-slide]').forEach(button => button.setAttribute('aria-current', String(Number(button.dataset.slide) === current)));
    // 本地文件也可以翻页；部分浏览器限制 file: 下改历史记录时，只略过地址同步。
    try { history.replaceState(null, '', `#slide-${current + 1}`); } catch (_) { /* 展示不依赖地址写入。 */ }
    if (reading && scroll) slides[current].scrollIntoView({behavior:'instant', block:'start'});
    if (byId('notes-dialog').open) updateNotes();
  }

  function setReading(value) {
    reading = value;
    document.body.classList.toggle('reading', reading);
    byId('reading-button').textContent = reading ? '演示' : '阅读';
    byId('reading-button').setAttribute('aria-pressed', String(reading));
    resize();
    go(current);
  }

  function openDialog(id) {
    document.querySelectorAll('dialog[open]').forEach(dialog => dialog.close());
    if (id === 'notes-dialog') updateNotes();
    byId(id).showModal();
  }

  async function fullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch (_) {
      byId('live-status').textContent = '此浏览器不支持页面全屏，可以使用浏览器的全屏功能。';
    }
  }

  function updateTimer() {
    if (timerRunning) remaining = Math.max(0, Math.ceil((deadline - performance.now()) / 1000));
    if (remaining === 0) timerRunning = false;
    const label = remaining === 0 ? '结束' : timerRunning ? (remaining <= 120 ? '问答' : '主讲') : (remaining === 900 ? '开始' : '继续');
    byId('timer-button').textContent = `${time(remaining)} ${label}`;
    byId('timer-button').classList.toggle('warning', remaining <= 120);
    byId('timer-button').setAttribute('aria-label', `${timerRunning ? '暂停' : '开始'}计时，剩余 ${Math.floor(remaining / 60)} 分 ${remaining % 60} 秒`);
  }

  byId('prev').addEventListener('click', () => go(current - 1));
  byId('next').addEventListener('click', () => go(current + 1));
  byId('notes-prev').addEventListener('click', () => go(current - 1));
  byId('notes-next').addEventListener('click', () => go(current + 1));
  byId('notes-button').addEventListener('click', () => openDialog('notes-dialog'));
  byId('overview-button').addEventListener('click', () => openDialog('overview-dialog'));
  byId('qa-button').addEventListener('click', () => openDialog('qa-dialog'));
  byId('sources-button').addEventListener('click', () => openDialog('sources-dialog'));
  byId('mobile-sources').addEventListener('click', () => openDialog('sources-dialog'));
  byId('reading-button').addEventListener('click', () => setReading(!reading));
  byId('fullscreen-button').addEventListener('click', fullscreen);
  byId('timer-button').addEventListener('click', () => {
    if (remaining === 0) remaining = 900;
    if (timerRunning) { updateTimer(); timerRunning = false; }
    else { deadline = performance.now() + remaining * 1000; timerRunning = true; }
    updateTimer();
  });
  byId('reset-timer').addEventListener('click', () => { timerRunning = false; remaining = 900; updateTimer(); });
  byId('print-button').addEventListener('click', () => { byId('sources-dialog').close(); window.print(); });
  // 打印始终使用投屏版的 16:9 排版，打印结束后恢复阅读模式。
  window.addEventListener('beforeprint', () => { restoreReading = reading; document.body.classList.remove('reading'); });
  window.addEventListener('afterprint', () => document.body.classList.toggle('reading', restoreReading));

  byId('overview-list').innerHTML = talk.slides.map((slide, i) => `<button type="button" data-slide="${i}"><span>${String(i + 1).padStart(2,'0')} · ${time(starts[i])}–${time(starts[i] + slide.seconds)}</span>${escape(slide.title)}</button>`).join('');
  byId('overview-list').addEventListener('click', event => {
    const button = event.target.closest('[data-slide]');
    if (!button) return;
    byId('overview-dialog').close();
    go(Number(button.dataset.slide));
  });
  byId('qa-body').innerHTML = talk.qa.map(item => `<details><summary>${escape(item.question)}</summary><p>${escape(item.answer)}</p></details>`).join('');
  byId('sources-body').innerHTML = talk.sources.map(source => `<h3 class="source-title">${escape(source.label)}</h3><p class="source-detail">${escape(source.detail)}</p>`).join('') + `<p class="help-line">建议节奏：13 分钟主讲 + 2 分钟问答。计时不会自动翻页；剩余 2 分钟时提示问答。点击计时可暂停，按钮下方可重置。时长为排练目标，实际语速请以试讲校准。</p><p class="source-detail">本 HTML 图片与脚本均已内嵌，可离线使用。手机默认连续阅读。讲稿弹层会显示在当前屏幕，投屏时请使用随附演讲稿。视觉示意用于说明产品逻辑，并非当前网页截图。</p>`;
  document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => button.closest('dialog').close()));
  document.querySelectorAll('dialog').forEach(dialog => dialog.addEventListener('click', event => {
    const rect = dialog.getBoundingClientRect();
    if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
  }));
  document.querySelectorAll('[data-zoom]').forEach(button => button.addEventListener('click', () => {
    const original = button.querySelector('img');
    byId('image-heading').textContent = button.dataset.zoom === 'ai' ? 'AI 处理稿 · 完整原图' : '设计师提炼稿 · 完整原图';
    byId('full-image').src = original.src;
    byId('full-image').alt = original.alt;
    openDialog('image-dialog');
  }));
  document.addEventListener('keydown', event => {
    if (event.ctrlKey || event.metaKey || event.altKey || document.querySelector('dialog[open]')) return;
    if (event.target.closest('input,textarea,select,[contenteditable]')) return;
    if (event.key === ' ' && event.target.closest('button,a')) return;
    if (['ArrowRight','ArrowDown','PageDown',' '].includes(event.key)) { event.preventDefault(); go(current + 1); }
    if (['ArrowLeft','ArrowUp','PageUp'].includes(event.key)) { event.preventDefault(); go(current - 1); }
    if (event.key === 'Home') { event.preventDefault(); go(0); }
    if (event.key === 'End') { event.preventDefault(); go(slides.length - 1); }
    if (event.key.toLowerCase() === 'n') openDialog('notes-dialog');
    if (event.key.toLowerCase() === 'f') void fullscreen();
  });
  window.addEventListener('hashchange', () => {
    const match = location.hash.match(/^#slide-(\d+)$/);
    if (match) go(Number(match[1]) - 1);
  });
  window.addEventListener('resize', resize);
  window.addEventListener('scroll', () => {
    if (!reading || scrollFrame) return;
    scrollFrame = requestAnimationFrame(() => {
      scrollFrame = 0;
      // 长页阅读以靠近屏幕上缘的章节更新目录，不改变用户的滚动位置。
      const anchor = Math.min(170, innerHeight * .25);
      let found = 0;
      slides.forEach((slide, i) => { if (slide.getBoundingClientRect().top <= anchor) found = i; });
      if (found !== current) go(found, false);
    });
  }, {passive:true});
  const initial = location.hash.match(/^#slide-(\d+)$/);
  current = initial ? Math.max(0, Math.min(slides.length - 1, Number(initial[1]) - 1)) : 0;
  setReading(reading);
  updateTimer();
  setInterval(updateTimer, 500);
})();
