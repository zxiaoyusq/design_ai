"""生成可离线路演 HTML 与同源讲稿；参考图片保留上传附件中的原始字节。"""

from __future__ import annotations

import argparse
import base64
import hashlib
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import zipfile


class ImageReader(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.sources: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "img":
            self.sources.append(dict(attrs).get("src") or "")


def stamp(seconds: int) -> str:
    return f"{seconds // 60:02}:{seconds % 60:02}"


def make_markdown(talk: dict) -> str:
    lines = [
        "# PRISM 棱镜｜产品路演演讲稿",
        "",
        "面向设计、产品、用户研究和业务决策者。12 页，主讲目标 13 分钟，另留 2 分钟问答。",
        "",
        "讲稿正文与转场共约 3,100 字符，按每分钟约 240 字符排练。实际耗时取决于语速、看图和停顿，请试讲校准。不要逐字读页面；页面用于给观众看结论，讲稿用于补充因果和例子。",
        "",
        "浏览器离线打开 index.html；方向键或空格翻页，N 查看当前讲稿，F 全屏。讲稿会显示在当前屏幕，投屏时建议另外使用这份文档。计时按钮手动开始，剩余 2 分钟提示问答。",
        "",
        "## 30 秒核心表达",
        "",
        "棱镜把参考图、趋势和用户声音，整理成有依据的设计方向，再落到可评审的情绪版。AI 整理证据、提出候选，设计师和业务团队负责取舍。我们希望用一个真实项目、三周对照验证，证明结果是否被采用，以及是否在不降低质量的前提下缩短周期。",
        "",
    ]
    total = 0
    for index, slide in enumerate(talk["slides"], 1):
        lines.extend([
            f"## {index:02}｜{slide['title']}",
            "",
            f"时间：{stamp(total)}–{stamp(total + slide['seconds'])}；建议 {slide['seconds']} 秒。",
            "",
            f"上台提示：{slide['cue']}",
            "",
            *[part for paragraph in slide["paragraphs"] for part in (paragraph, "")],
            f"转场：{slide['bridge']}",
            "",
        ])
        total += slide["seconds"]
    lines.extend(["## 两分钟问答备稿（按现场问题选用，不逐条宣读）", ""])
    for item in talk["qa"]:
        lines.extend([f"### {item['question']}", "", item["answer"], ""])
    lines.extend(["## 来源与口径（供讲者准备，不进入主讲）", ""])
    for item in talk["sources"]:
        lines.extend([f"### {item['label']}", "", item["detail"], ""])
    lines.extend([
        "## 排练提醒",
        "",
        "- 00:45 进入痛点，02:40 开始第一个产品模块，08:00 进入真实案例，10:35 进入试点方案，13:00 结束主讲。",
        "- 五个模块讲用户得到什么，不展开模型、框架、字段数或服务器。",
        "- 案例页给观众看图时间；不要把三张核心选图一致换算成整体准确率。",
        "- 如果超时，优先缩短第 4–6 页的示意解释；保留真实案例、验证标准与最后的明确请求。",
        "- “一周”“三周试点”分别是待验证目标和本次建议；不宣称节时、采用率或消费者测试结果已经成立。",
        "",
    ])
    return "\n".join(lines)


def make_speech_html(talk: dict) -> str:
    total = 0
    sections = []
    for index, slide in enumerate(talk["slides"], 1):
        body = "".join(f"<p>{html.escape(p)}</p>" for p in slide["paragraphs"])
        sections.append(
            f'<section id="p{index}"><div class="timing">{index:02} / 12 · {stamp(total)}–{stamp(total + slide["seconds"])} · 本页 {slide["seconds"]} 秒</div>'
            f'<h2>{html.escape(slide["title"])}</h2><aside>{html.escape(slide["cue"])}</aside>{body}'
            f'<p class="bridge">转场：{html.escape(slide["bridge"])}</p></section>'
        )
        total += slide["seconds"]
    qa = "".join(f'<article><h3>{html.escape(item["question"])}</h3><p>{html.escape(item["answer"])}</p></article>' for item in talk["qa"])
    sources = "".join(f'<article><h3>{html.escape(item["label"])}</h3><p>{html.escape(item["detail"])}</p></article>' for item in talk["sources"])
    toc = "".join(f'<a href="#p{i}">{i:02} · {html.escape(slide["title"].split("｜")[0])}</a>' for i, slide in enumerate(talk["slides"], 1))
    return f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PRISM 棱镜 · 路演演讲稿</title><style>
*{{box-sizing:border-box}}html{{scroll-behavior:smooth}}body{{font-family:"Noto Sans CJK SC","PingFang SC","Microsoft YaHei",sans-serif;margin:0;background:#f2f0e9;color:#232c25;line-height:1.95}}main{{max-width:850px;margin:auto;padding:60px 35px 100px}}.label,.timing{{font-size:13px;color:#63715b;letter-spacing:.06em}}h1{{font-size:42px;line-height:1.35;letter-spacing:-.04em;margin:18px 0}}h2{{font-size:29px;line-height:1.5;margin:12px 0 20px}}h3{{font-size:20px;margin:27px 0 10px;line-height:1.6}}p{{font-size:18px;margin:19px 0}}.intro{{color:#63715b;font-size:16px}}nav{{display:grid;grid-template-columns:1fr 1fr;gap:8px 18px;margin:30px 0 45px}}nav a{{font-size:13px;color:#415a38;text-decoration:none;border-bottom:1px solid #ced7c3;padding:7px 0}}section{{border-top:1px solid #c8d1bf;padding-top:30px;margin-top:40px;scroll-margin-top:25px}}aside{{padding:15px 19px;background:#e2e8d8;font-size:14px;color:#5a6d4c;line-height:1.8}}.bridge{{color:#4b643d;border-left:3px solid #aac586;padding:9px 18px;font-size:16px}}.actions{{display:flex;gap:10px;flex-wrap:wrap;margin:24px 0}}.actions a,.actions button{{font:inherit;font-size:14px;padding:9px 15px;border:1px solid #bdc9af;background:transparent;color:#415a38;text-decoration:none;border-radius:6px;cursor:pointer}}.sources p{{font-size:15px;color:#63715b}}a:focus-visible,button:focus-visible{{outline:3px solid #ed795f;outline-offset:3px}}@media(max-width:600px){{main{{padding:32px 22px 65px}}h1{{font-size:32px}}h2{{font-size:25px}}p{{font-size:17px}}nav{{grid-template-columns:1fr}}}}@media print{{@page{{size:A4;margin:18mm}}body{{background:white}}main{{padding:0;max-width:none}}.actions,nav{{display:none}}h1{{font-size:24pt}}h2{{font-size:17pt;break-after:avoid}}h3{{font-size:13pt;break-after:avoid}}p{{font-size:11pt;line-height:1.8}}aside{{font-size:9pt}}section{{margin-top:25px;padding-top:20px}}.timing{{break-after:avoid}}.bridge{{font-size:10pt}}}}
</style></head><body><main><div class="label">PRISM · PRODUCT ROADSHOW · 2026.10.22</div><h1>让设计方向，<br>有被选中的理由。</h1><p class="intro">12 页 · 13 分钟主讲 + 2 分钟问答<br>约 3,100 字符；按每分钟约 240 字符排练，实际语速请试讲校准。</p><div class="actions"><a href="index.html">打开演示页</a><a href="PRISM-产品路演演讲稿.docx" download>下载 Word 稿</a><a href="演讲稿.md" download>下载文字稿</a><button type="button" onclick="window.print()">打印 / 保存 PDF</button></div><aside>讲稿提示会显示在当前屏幕。投屏时请关闭演示页中的讲稿弹层，另外使用这份文档。按建议时间讲解即可在 13 分钟结束，把最后 2 分钟留给提问。</aside><nav aria-label="逐页目录">{toc}</nav><section><div class="timing">一句话定位 · 应急开场</div><h2>30 秒核心表达</h2><p>棱镜把参考图、趋势和用户声音，整理成有依据的设计方向，再落到可评审的情绪版。AI 整理证据、提出候选，设计师和业务团队负责取舍。我们希望用一个真实项目、三周对照验证，证明结果是否被采用，以及是否在不降低质量的前提下缩短周期。</p></section>{''.join(sections)}<section><div class="timing">13:00–15:00 · 按现场问题选用</div><h2>两分钟问答备稿</h2>{qa}</section><section class="sources"><h2>来源与口径</h2><p>以下供讲者准备，不进入主讲。</p>{sources}<h3>排练检查点</h3><p>00:45 痛点；02:40 DNA提取V2；08:00 真实案例；10:35 试点建议；13:00 结束主讲。</p><p>如超时，压缩第 4–6 页的示意解释；保留真实案例、质量与采用的验收标准，以及最后的明确请求。</p></section></main></body></html>'''


def make_docx(talk: dict, target: Path) -> None:
    from docx import Document
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor

    document = Document()
    document.core_properties.title = talk["title"]
    document.core_properties.subject = "13 分钟产品路演 + 2 分钟问答"
    document.core_properties.author = "PRISM 项目组"
    section = document.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin = section.bottom_margin = Cm(2)
    section.left_margin = section.right_margin = Cm(2.3)
    for name in ("Normal", "Title", "Subtitle", "Heading 1", "Heading 2"):
        style = document.styles[name]
        style.font.name = "Microsoft YaHei"
        style.element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")
        style.font.color.rgb = RGBColor.from_string("263127")
    document.styles["Normal"].font.size = Pt(11.5)
    document.styles["Normal"].paragraph_format.line_spacing = 1.55
    document.styles["Normal"].paragraph_format.space_after = Pt(10)
    document.styles["Title"].font.size = Pt(28)
    document.styles["Heading 1"].font.size = Pt(19)
    document.styles["Heading 2"].font.size = Pt(14)
    header = section.header.paragraphs[0]
    header.text = "PRISM 棱镜  /  产品路演演讲稿"
    header.runs[0].font.size = Pt(9)
    header.runs[0].font.color.rgb = RGBColor.from_string("74806C")
    footer = section.footer.paragraphs[0]
    footer.alignment = 2
    footer.add_run("PRISM · ")
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)
    document.add_heading("让设计方向，\n有被选中的理由。", 0)
    document.add_paragraph("PRISM 棱镜｜产品路演演讲稿", "Subtitle")
    document.add_paragraph("12 页 · 主讲 13 分钟 · 问答 2 分钟\n2026 年 10 月 22 日")
    document.add_paragraph("面向设计、产品、用户研究与业务决策者。正文及转场约 3,100 字符，按每分钟约 240 字符排练；实际耗时请用试讲校准。")
    document.add_heading("30 秒核心表达", 2)
    document.add_paragraph("棱镜把参考图、趋势和用户声音，整理成有依据的设计方向，再落到可评审的情绪版。AI 整理证据、提出候选，设计师和业务团队负责取舍。我们希望用一个真实项目、三周对照验证，证明结果是否被采用，以及是否在不降低质量的前提下缩短周期。")
    document.add_heading("讲者使用提示", 2)
    document.add_paragraph("方向键或空格翻页，N 查看讲稿，F 全屏。讲稿会显示在当前屏幕，投屏时建议另外使用本文档。计时手动开始，剩余两分钟转入问答；无需逐字读页面。")
    document.add_paragraph("排练检查点：00:45 痛点；02:40 DNA提取V2；08:00 真实案例；10:35 试点建议；13:00 结束主讲。若超时，先缩短第 4–6 页的示意解释，保留案例、验证标准和最后请求。")
    total = 0
    for index, slide in enumerate(talk["slides"], 1):
        document.add_page_break()
        document.add_heading(f"{index:02}｜{slide['title']}", 1)
        document.add_paragraph(f"{stamp(total)}–{stamp(total + slide['seconds'])}  ·  建议 {slide['seconds']} 秒", "Subtitle")
        cue = document.add_paragraph(f"上台提示：{slide['cue']}")
        for run in cue.runs:
            run.font.size = Pt(10)
            run.font.color.rgb = RGBColor.from_string("657958")
        for paragraph in slide["paragraphs"]:
            document.add_paragraph(paragraph)
        bridge = document.add_paragraph(f"转场：{slide['bridge']}")
        bridge.runs[0].italic = True
        bridge.runs[0].font.color.rgb = RGBColor.from_string("526B43")
        total += slide["seconds"]
    document.add_page_break()
    document.add_heading("两分钟问答备稿", 1)
    document.add_paragraph("按现场问题选用，不逐条宣读。")
    for item in talk["qa"]:
        document.add_heading(item["question"], 2)
        document.add_paragraph(item["answer"])
    document.add_page_break()
    document.add_heading("来源与口径", 1)
    document.add_paragraph("供讲者准备，不进入主讲。")
    for item in talk["sources"]:
        document.add_heading(item["label"], 2)
        document.add_paragraph(item["detail"])
    document.save(target)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference", type=Path, required=True)
    args = parser.parse_args()
    source_dir = Path(__file__).resolve().parent
    delivery = source_dir.parent
    talk = json.loads((source_dir / "talk.json").read_text())
    assert len(talk["slides"]) == 12
    assert sum(slide["seconds"] for slide in talk["slides"]) == talk["targetSeconds"] == 780
    reference = args.reference.read_bytes()
    reader = ImageReader()
    reader.feed(reference.decode("utf-8"))
    assert len(reader.sources) == 3, "原方案图片数量变化，请人工重新确认 R02 对照图的位置。"
    assert all(src.startswith("data:image/") for src in reader.sources), "仅嵌入已经提供的本地图片。"
    template = (source_dir / "roadshow.template.html").read_text()
    page = template.replace("__REFERENCE_AI__", reader.sources[1]).replace("__REFERENCE_DESIGNER__", reader.sources[2])
    page = page.replace("__TALK_JSON__", json.dumps(talk, ensure_ascii=False).replace("<", "\\u003c"))
    page = page.replace("<!-- SCRIPT -->", "<script>\n" + (source_dir / "viewer.js").read_text() + "\n</script>")
    assert "__REFERENCE_" not in page and "__TALK_JSON__" not in page
    (delivery / "index.html").write_text(page, encoding="utf-8")
    (delivery / "演讲稿.md").write_text(make_markdown(talk), encoding="utf-8")
    (delivery / "演讲稿.html").write_text(make_speech_html(talk), encoding="utf-8")
    make_docx(talk, delivery / "PRISM-产品路演演讲稿.docx")
    speech = "".join("".join(slide["paragraphs"]) + slide["bridge"] for slide in talk["slides"])
    manifest = {
        "title": talk["title"], "date": talk["date"], "slide_count": 12,
        "talk_seconds": 780, "qa_seconds": 120,
        "spoken_character_count": len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", speech)),
        "reference_name": args.reference.name,
        "reference_sha256": hashlib.sha256(reference).hexdigest(),
        "images": [
            {"role": role, "sha256": hashlib.sha256(base64.b64decode(src.split(",", 1)[1])).hexdigest(), "source_page": 17}
            for role, src in zip(("AI 处理稿", "设计师提炼稿"), reader.sources[1:])
        ],
        "files": {},
    }
    filenames = ["index.html", "PRISM-产品路演演讲稿.docx", "演讲稿.html", "演讲稿.md", "README.md"]
    for filename in filenames:
        artifact = delivery / filename
        manifest["files"][filename] = {"bytes": artifact.stat().st_size, "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest()}
    (delivery / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(delivery / "PRISM-产品路演与演讲稿.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for filename in [*filenames, "manifest.json"]:
            archive.write(delivery / filename, filename)
    print(json.dumps({"output": str(delivery), "slides": 12, "talk_seconds": 780, "spoken_characters": manifest["spoken_character_count"], "artifacts": list(manifest["files"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
