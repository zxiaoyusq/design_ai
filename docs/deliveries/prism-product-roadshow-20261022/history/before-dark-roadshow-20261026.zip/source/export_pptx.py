"""将浏览器逐页截图原字节铺满 16:9 PPTX，保留与当前 HTML 的来源对应。"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture_dir", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    capture = json.loads((args.capture_dir / "capture.json").read_text())
    source = Path(capture["source"])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == capture["source_sha256"]

    deck = Presentation()
    # 使用精确 EMU 尺寸，保证每页图片无裁切、无留边地铺满 16:9 画布。
    deck.slide_width, deck.slide_height = 12_192_000, 6_858_000
    deck.core_properties.title = "棱镜：让每一次设计选择，更贴近用户期待"
    deck.core_properties.subject = "原 HTML 逐页高清截图版"
    deck.core_properties.author = "PRISM 项目组"
    deck.core_properties.keywords = "PRISM, 棱镜, 产品路演, 原页面截图"
    deck.core_properties.comments = "按原 HTML 顺序生成，每页一张完整截图。"
    for item in capture["slides"]:
        image = args.capture_dir / item["filename"]
        assert hashlib.sha256(image.read_bytes()).hexdigest() == item["sha256"]
        slide = deck.slides.add_slide(deck.slide_layouts[6])
        slide.name = f'{item["number"]:02} {item["title"]}'
        picture = slide.shapes.add_picture(str(image), 0, 0, width=deck.slide_width, height=deck.slide_height)
        picture.name = item["title"]
        picture._element.nvPicPr.cNvPr.set("descr", item["title"])
    deck.save(args.output)

    # 复读实际交付，核对页数、全幅坐标与图片字节；避免遗漏备用页或图片被重新压缩。
    actual = Presentation(args.output)
    assert len(actual.slides) == len(capture["slides"])
    for slide, item in zip(actual.slides, capture["slides"]):
        assert len(slide.shapes) == 1
        image = slide.shapes[0]
        assert image.shape_type == MSO_SHAPE_TYPE.PICTURE
        assert (image.left, image.top, image.width, image.height) == (0, 0, actual.slide_width, actual.slide_height)
        assert (image.crop_left, image.crop_top, image.crop_right, image.crop_bottom) == (0, 0, 0, 0)
        assert image.image.size == (3200, 1800)
        assert hashlib.sha256(image.image.blob).hexdigest() == item["sha256"]
    with zipfile.ZipFile(args.output) as archive:
        assert archive.testzip() is None
    receipt = {
        "pptx": args.output.name,
        "pptx_bytes": args.output.stat().st_size,
        "pptx_sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
        "source_sha256": capture["source_sha256"],
        "slide_count": len(actual.slides),
        "main_slide_count": sum(not item["backup"] for item in capture["slides"]),
        "backup_slide_count": sum(item["backup"] for item in capture["slides"]),
        "aspect_ratio": "16:9",
        "screenshot_pixels": [3200, 1800],
        "checks": "页数、顺序、画布、全幅无裁切、图像原字节、ZIP 完整性通过",
    }
    (args.capture_dir / "export.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
