"""Skill 通过工程统一 DeepAgents SDK 调用模型，保留原图、原答和执行身份。"""
from __future__ import annotations

from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import importlib
import json
from pathlib import Path
import sys
from typing import Any

MODEL = "gemini-3.8-flash"
EFFORT = None
REPO = Path(__file__).resolve().parents[4]


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path: str | Path) -> dict:
    path = Path(path).resolve()
    return {"path": str(path), "sha256": digest(path)}


def write_new(path: str | Path, value: Any) -> None:
    """每个模型调用目录不可覆盖，避免将失败历史伪装为一次成功。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        stream.write(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2))
        stream.write("\n")


@lru_cache(maxsize=1)
def project_runtime():
    """独立 CLI 也复用工程网关；导入阶段不读取模型密钥或创建连接。"""
    backend = str(REPO / "backend")
    if backend not in sys.path:
        sys.path.insert(0, backend)
    return importlib.import_module("app.agents.design_dna_preparation")


def execution_config(model_id: str = MODEL) -> dict:
    """新请求以完整 SDK 配置区分缓存，不能复用历史 CLI 的执行身份。"""
    return project_runtime().execution_config(model_id)


def execute_structured(folder: str | Path, *, system: str, payload: dict,
                       images: list[dict], schema: dict, model_id: str = MODEL, timeout: int = 600) -> dict:
    """调用统一的受限 DeepAgents 单轮执行器；密钥仅由运行环境提供。"""
    return project_runtime().execute_structured(
        folder, system=system, payload=payload, images=images, schema=schema,
        model_id=model_id, timeout_seconds=timeout)
