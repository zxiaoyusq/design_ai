"""独立 Skill 入口只委托工程 DeepAgents SDK；全部调用使用离线替身。"""

import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/model_runtime.py"
spec = importlib.util.spec_from_file_location("prism_default_sdk_test", SCRIPT)
runtime = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runtime)


class DefaultRuntimeTests(unittest.TestCase):
    def test_default_and_timeout_delegate_to_project_sdk(self):
        sdk = SimpleNamespace(execute_structured=Mock(return_value={"status": "synthetic"}),
                              execution_config=Mock(return_value={"model": runtime.MODEL}))
        with patch.object(runtime, "project_runtime", return_value=sdk):
            self.assertEqual(runtime.execution_config(), {"model": "gemini-3.8-flash"})
            sdk.execution_config.assert_called_once_with("gemini-3.8-flash")
            result = runtime.execute_structured("synthetic-call", system="规则", payload={}, images=[], schema={}, timeout=900)
        self.assertEqual(result, {"status": "synthetic"})
        sdk.execute_structured.assert_called_once_with(
            "synthetic-call", system="规则", payload={}, images=[], schema={},
            model_id="gemini-3.8-flash", timeout_seconds=900)


if __name__ == "__main__":
    unittest.main()
