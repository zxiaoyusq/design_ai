"""基于模型目录创建并调用 LangChain ChatModel。"""

from collections.abc import Iterator, Mapping, Sequence
from typing import Any, TypeAlias

from langchain.chat_models import init_chat_model as langchain_init_chat_model
from langchain_anthropic import ChatAnthropic
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, AIMessageChunk, BaseMessage, HumanMessage, SystemMessage

from app.services.llm.catalog import ModelProvider, get_model
from app.services.llm.settings import LLMSettings, get_llm_settings


ModelInput: TypeAlias = str | Sequence[BaseMessage]

# 连接信息只能由统一配置层注入，调用方不能通过模型参数绕过网关。
_RESERVED_MODEL_OPTIONS = frozenset(
    {
        "model",
        "model_provider",
        "api_key",
        "openai_api_key",
        "anthropic_api_key",
        "base_url",
    }
)


class _DumpableMapping(dict[str, Any]):
    """兼容部分 Anthropic 网关在流事件中直接返回字典的情况。"""

    def model_dump(self, *_args: Any, **_kwargs: Any) -> dict[str, Any]:
        return dict(self)


def _normalize_anthropic_stream_event(event: Any) -> Any:
    """把网关的字典型上下文扩展转换为 LangChain 期望的对象。"""

    context_management = getattr(event, "context_management", None)
    if isinstance(context_management, dict) and hasattr(event, "model_copy"):
        return event.model_copy(
            update={"context_management": _DumpableMapping(context_management)}
        )
    return event


class GatewayCompatibleChatAnthropic(ChatAnthropic):
    """修正 Anthropic 流事件扩展字段与官方 SDK 类型不一致的问题。"""

    def _make_message_chunk_from_anthropic_event(
        self,
        event: Any,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        event = _normalize_anthropic_stream_event(event)
        return super()._make_message_chunk_from_anthropic_event(
            event,
            *args,
            **kwargs,
        )


def create_chat_model(
    model_id: str,
    *,
    settings: LLMSettings | None = None,
    **model_options: Any,
) -> BaseChatModel:
    """创建目录内模型的 LangChain 客户端。

    `temperature`、`max_tokens` 等模型参数可由调用方传入；模型、provider、Key
    和调用地址由本模块统一控制。
    """

    overridden_options = _RESERVED_MODEL_OPTIONS.intersection(model_options)
    if overridden_options:
        option_names = ", ".join(sorted(overridden_options))
        raise ValueError(f"以下连接参数不允许覆盖：{option_names}")

    model = get_model(model_id)
    llm_settings = settings or get_llm_settings()
    connection_options: dict[str, Any] = {}

    # LangChain 的 Anthropic 与 OpenAI 集成使用不同的密钥参数名。
    if model.model_provider is ModelProvider.ANTHROPIC:
        return GatewayCompatibleChatAnthropic(
            model=model.id,
            base_url=llm_settings.base_url,
            api_key=llm_settings.api_key,
            **model_options,
        )
    elif model.model_provider is ModelProvider.OPENAI:
        # 当前网关的 OpenAI 兼容接口位于 `/v1`；已配置时不重复追加。
        connection_options["base_url"] = _openai_base_url(llm_settings.base_url)
        connection_options["api_key"] = llm_settings.api_key
    else:  # pragma: no cover - 新 provider 必须先显式补充连接适配。
        raise ValueError(f"尚未配置 provider：{model.model_provider}")

    return langchain_init_chat_model(
        model=model.id,
        model_provider=model.model_provider.value,
        **connection_options,
        **model_options,
    )


def _openai_base_url(base_url: str) -> str:
    """规范化 OpenAI 兼容接口地址。"""

    return base_url if base_url.endswith("/v1") else f"{base_url}/v1"


def invoke_model(
    model_id: str,
    model_input: ModelInput,
    *,
    model_options: Mapping[str, Any] | None = None,
    settings: LLMSettings | None = None,
    **invoke_options: Any,
) -> BaseMessage:
    """通过一次有界 DeepAgents 推理返回完整模型消息。"""

    agent, messages, config = _bounded_model_request(
        model_id, model_input, model_options, settings, invoke_options,
    )
    result = agent.invoke({"messages": messages}, config=config)
    message = result["messages"][-1]
    if not isinstance(message, AIMessage):
        raise RuntimeError("DeepAgents 没有返回完整模型消息")
    return message


def stream_model(
    model_id: str,
    model_input: ModelInput,
    *,
    model_options: Mapping[str, Any] | None = None,
    settings: LLMSettings | None = None,
    **stream_options: Any,
) -> Iterator[BaseMessage]:
    """通过 DeepAgents 流式推理，仅向调用方返回模型消息块。"""

    agent, messages, config = _bounded_model_request(
        model_id, model_input, model_options, settings, stream_options,
    )
    for message, _metadata in agent.stream({"messages": messages}, config=config, stream_mode="messages"):
        if isinstance(message, AIMessageChunk):
            yield message
        elif isinstance(message, AIMessage):
            # 不支持逐 Token 流的模型仍可能返回完整 AIMessage；按原字节内容转为一个块。
            yield AIMessageChunk(**message.model_dump(exclude={"type"}))


def _bounded_model_request(model_id, model_input, model_options, settings, call_options):
    """集中拆分模型参数与 Runnable 配置，保留调用者的消息和显式参数。

    DeepAgents 不接受 model.bind(...) 的 RunnableBinding；stop 等调用参数需在
    构造模型时绑定。首条系统消息沿用其原始内容，其他消息保持原顺序与多模态结构。
    """
    # 局部导入避免 llm 模块初始化与 Agent 模块之间形成循环依赖。
    from app.agents.bounded import create_bounded_agent

    options = dict(call_options)
    config = dict(options.pop("config", None) or {})
    config.setdefault("recursion_limit", 40)
    parameters = {"max_retries": 0, **dict(model_options or {}), **options}
    model = create_chat_model(model_id, settings=settings, **parameters)
    messages = [HumanMessage(content=model_input)] if isinstance(model_input, str) else list(model_input)
    if not messages or any(not isinstance(message, BaseMessage) for message in messages):
        raise ValueError("模型输入必须是文本或非空 BaseMessage 序列")
    system_prompt = messages.pop(0).content if isinstance(messages[0], SystemMessage) else ""
    agent = create_bounded_agent(model=model, system_prompt=system_prompt,
                                 name="llm-sdk", model_call_limit=1)
    return agent, messages, config
