"""模型回执和异常的凭据脱敏；不读取个人登录目录或把密钥写入运行证据。"""
from __future__ import annotations

import os
import re
from typing import Any


_SENSITIVE_KEYS = ("authorization", "api_key", "apikey", "llm_key", "access_token", "refresh_token",
                   "password", "secret", "cookie", "header")


def redact_sensitive_value(value: Any) -> Any:
    """保留回执结构，屏蔽常见凭据字段及错误中回显的密钥。"""
    if isinstance(value, dict):
        return {key: "[REDACTED]" if any(part in str(key).lower() for part in _SENSITIVE_KEYS)
                else redact_sensitive_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [redact_sensitive_value(item) for item in value]
    if not isinstance(value, str):
        return value
    text = value
    # 仅读取已注入的环境变量；不额外打开服务器 .env 或个人账号文件。
    for name, secret in os.environ.items():
        if len(secret) >= 8 and any(part in name.lower() for part in _SENSITIVE_KEYS):
            text = text.replace(secret, "[REDACTED]")
    text = re.sub(r"(?i)Bearer\s+[^\s,}\"']+", "Bearer [REDACTED]", text)
    text = re.sub(r"(?i)((?:api[_-]?key|access[_-]?token|refresh[_-]?token|password)\s*[=:]\s*)[^\s,}\"']+",
                  r"\1[REDACTED]", text)
    return text


def safe_exception(exc: Exception) -> str:
    """失败原因允许追查类型，不保存网关请求头或完整长令牌。"""
    message = str(exc)
    if "invalid header:" in message.lower():
        return f"{type(exc).__name__}: 网关返回 invalid header（头部明细已隐藏）"
    message = redact_sensitive_value(message)
    message = re.sub(r"[A-Za-z0-9_-]{256,}", "[长令牌已隐藏]", message)
    return f"{type(exc).__name__}: {message[:1000]}"
