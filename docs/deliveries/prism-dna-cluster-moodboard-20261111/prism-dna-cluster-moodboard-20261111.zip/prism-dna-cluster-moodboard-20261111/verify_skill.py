"""只读检查补齐包或接收工程；不读取模型配置，不允许网络连接。"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, help='可选：要核对的接收工程根目录')
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    target = (args.project or package).resolve()
    report = {'model_calls': 0, 'network_requests': 0, 'failures': []}
    manifest_path = package / 'MANIFEST.json'
    if not manifest_path.is_file():
        report['failures'].append({'issue': 'missing_package_manifest'})
    else:
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        for row in manifest['files']:
            path = package / row['path']
            if not path.is_file() or sha(path) != row['sha256']:
                report['failures'].append({'path': row['path'], 'issue': 'package_hash_mismatch_or_missing'})
    source = json.loads((package / 'SOURCE.json').read_text(encoding='utf-8'))
    for row in source['files']:
        path = target / row['path']
        if not path.is_file():
            report['failures'].append({'path': row['path'], 'issue': 'missing'})
        elif sha(path) != row['sha256']:
            report['failures'].append({'path': row['path'], 'issue': 'different_from_delivery_review_needed'})
    report['source_files_checked'] = len(source['files'])

    # 接收方文件不同就先报告，不执行未知版本的导入；同版导入也禁止联网。
    if not report['failures']:
        def no_network(event, arguments):
            if event in {'socket.connect', 'socket.getaddrinfo'}:
                raise RuntimeError('offline_verification_blocks_network')
        sys.addaudithook(no_network)
        sys.dont_write_bytecode = True
        try:
            scripts = target / '.agents/skills/prism-dna-cluster-moodboard/scripts'
            sys.path.insert(0, str(target / 'backend'))
            sys.path.insert(0, str(scripts))
            group = load_module('prism_package_group', scripts / 'llm_group.py')
            cards = load_module('prism_package_cards', group.PREPARATION / 'scripts/design_cards.py')
            styles, references = cards.style_catalog()
            runtime = load_module('prism_package_runtime', scripts / 'model_runtime.py')
            configuration = runtime.execution_config()
            from app.agents.bounded import AGENT_RUNTIME_VERSION
            assert configuration['model'] == 'gemini-3.8-flash'
            assert configuration['transport'] == 'project_langchain_sdk'
            assert group.POLICY.is_file() and len(styles) == 38 and len(references) == 3
            report.update(default_model=configuration['model'], framework='DeepAgents',
                          runtime_version=AGENT_RUNTIME_VERSION, styles=len(styles),
                          reference_files=len(references), imports='passed')
        except Exception as exc:
            # 只给异常类型，避免将第三方模块的配置值带入共享日志。
            report['failures'].append({'issue': 'dependency_import_or_rule_check_failed',
                                       'exception_type': type(exc).__name__})
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return int(bool(report['failures']))


if __name__ == '__main__':
    raise SystemExit(main())
